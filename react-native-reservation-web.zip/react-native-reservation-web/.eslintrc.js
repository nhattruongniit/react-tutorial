module.exports = {
  root: true,
  extends: ['@react-native-community'],
  rules: {
    'no-shadow': 0,
    'react-hooks/rules-of-hooks': 0,
    'react-hooks/exhaustive-deps': 0,
  },
};
