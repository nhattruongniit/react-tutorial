# RSV - react native

## Technical

- axios, axios interceptor
- react navigation, authentication
- redux, redux thunk
- async storage
- UI Compomemts: NativeBase
- styled-components
- react-native-localize, i18n-js: [reference](https://medium.com/better-programming/creating-a-multi-language-app-in-react-native-9828b138c274)
- add font: [reference](https://medium.com/@mehran.khan/ultimate-guide-to-use-custom-fonts-in-react-native-77fcdf859cf4)
- add font icon: [reference](https://github.com/oblador/react-native-vector-icons#custom-fonts)
- material icon: [reference](https://material.io/resources/icons/?icon=description&style=baseline)

## Config VSCode Editor

### Add extension Prettier

### Add the settings below in settings.json file:

- "editor.tabSize": 2,
- "editor.formatOnSave": true
- "files.eol": "\n",
- "editor.wordWrap": "on",

## Architecture

### Format: [Image structure](/src/assets/images/structure-code.png)

### Only use index file (index.js) for indexing (logic code isn't allow)

### Features

/src/features/< name-feature >/< name-folder >/

### Redux

with actions: /src/features/< name-feature >/redux/actions.js

with reducers: /src/features/< name-feature >/redux/reducers.js

### Component

with component common: /src/components/common/< NameComponent >.js

with component of feature: /src/features/< name-feature >/components/< NameComponent >.js

### Hooks

use< HookName >.js

### HOC

with< HocName >.js

### Utility function

/src/utils/nameFile.js

### Configs

/src/config/nameFile.js

### Assets resource static

with fonts: /src/assets/fonts/

with images: /src/assets/images/

## Naming convention with folder, file

### Folder name

with one word: lowercase (e.g., login, profile).

with more 2 words: kebab-case (e.g., product-detail, product-list).

### Javascript file

mixedCase (e.g, checkAuthorize, convertToPdf).

### Component, container react

CamelCase (e.g, Table, Profile, Dialog).

## Naming convention with function

please add <b>" \_ "</b> symbol to recognize it is in this component.

relative to handle of end user: \_handleOk, \_handleCancel.

relative to behavior of change like input, checkbox: \_onChangeName, \_onCheckBox.

## Naming convention with styled component

Please add prefix <b>"\_Styled"</b> when you create an styled component.

E.g, ButtonStyled, CenterStyled ...

## Running the project

Assuming you have all the requirements installed, you can setup and run the project by running:

- `yarn start` to run metro bundler
- `yarn run android` to run the Android application (remember to start a simulator or connect an Android phone)
- `yarn run ios` to run the iOS application (remember to start a simulator or connect an iPhone phone)
- `yarn run web` to run on website
- `yarn run build:web` to build website
- `yarn run build:ios` to build ios app
- `yarn run build:android` to build android app

## Fetching Data with Cross Domain

[Refer here](https://stackoverflow.com/questions/3102819/disable-same-origin-policy-in-chrome)

- For Windows:

```
STEP 1: Open the start menu
STEP 2: Type windows+R or open "Run"
STEP 3: Execute the following command: chrome.exe --user-data-dir="C://Chrome dev session" --disable-web-security
```

- For iOS:

```
STEP 1: Go to Terminal
STEP 2: Execute the following command: open -a Google\ Chrome --args --disable-web-security --user-data-dir=""
```

If you have issue when run android or run ios. Please follow step below:

- Delete folder android/app/build
- Please change name 'android/app/debug-keystore' file to debug.keystore
- Always cmd `yarn run web` last
