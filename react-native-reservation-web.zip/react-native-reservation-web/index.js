import React from 'react';
import { Provider } from 'react-redux';
import { AppRegistry } from 'react-native';
import { name as appName } from './app.json';

// disabled Warnings
console.disableYellowBox = true;

//stores
import store from './src/stores';
import { applicationInit } from './src/features/apps/redux/actions';

// components
import AppContainer from './src/features/apps';

// localize
import { setI18nConfig } from './src/locales/translate';
setI18nConfig('en');
store.dispatch(applicationInit());

// console.disableYellowBox = true;

const App = () => {
  return (
    <Provider store={store}>
      <AppContainer />
    </Provider>
  );
};

AppRegistry.registerComponent(appName, () => App);
