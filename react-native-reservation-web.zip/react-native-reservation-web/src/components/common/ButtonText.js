import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { View, Text, TouchableOpacity } from 'react-native';

const ButtonText = ({ text, handleClick }) => {
  return (
    <View>
      <TouchableStyled onPress={handleClick}>
        <TextStyled>{text}</TextStyled>
      </TouchableStyled>
    </View>
  );
};

ButtonText.propTypes = {
  text: PropTypes.string.isRequired,
  handleAdd: PropTypes.func.isRequired,
};

export default ButtonText;

const TouchableStyled = styled(TouchableOpacity)`
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 40px;
  cuo
`;

const TextStyled = styled(Text)`
  color: #fff;
  font-size: 16px;
  font-weight: bold;
`;
