import React, { memo } from 'react';
import { View, SafeAreaView } from 'react-native';

const CenterView = memo(({ style, children, isSafe, ...props }) => {
  return isSafe ? (
    <SafeAreaView
      style={[{ flex: 1, justifyContent: 'center', alignItems: 'center' }, style]}
      {...props}
    >
      {children}
    </SafeAreaView>
  ) : (
    <View style={[{ flex: 1, justifyContent: 'center', alignItems: 'center' }, style]} {...props}>
      {children}
    </View>
  );
});

export default CenterView;
