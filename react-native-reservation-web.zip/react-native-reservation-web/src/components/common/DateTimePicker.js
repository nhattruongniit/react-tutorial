import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { DatePicker } from 'native-base';
import { View } from 'react-native';

const DatePickerDefault = memo(({ onChangeDate, textColor }) => {
  return (
    <View>
      <DatePicker
        defaultDate={new Date()}
        locale={'en'}
        timeZoneOffsetInMinutes={undefined}
        modalTransparent={false}
        animationType={'fade'}
        androidMode={'default'}
        textStyle={{ color: textColor || '#fff' }}
        placeHolderTextStyle={{ color: '#d3d3d3' }}
        onDateChange={onChangeDate}
        disabled={false}
      />
    </View>
  );
});

DatePickerDefault.propTypes = {
  onChangeDate: PropTypes.func.isRequired,
  textColor: PropTypes.string
};

export default DatePickerDefault;
