import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { View, Text } from 'react-native';

import ButtonText from './ButtonText';

const Modal = ({ isShow, hasTitleModal, width, titleModal, children, handleCancel, handleOk }) => {
  return (
    <>
      {isShow && (
        <ContainerStyled>
          <BlurStyled />
          <ContentStyled width={width}>
            {hasTitleModal && <TitleStyled>{titleModal}</TitleStyled>}
            <DescStyled>{children}</DescStyled>
            <BottomStyled>
              <CancelStyled>
                <ButtonText text="Close" handleClick={handleCancel} />
              </CancelStyled>
              <OkStyled>
                <ButtonText text="Ok" handleClick={handleOk} />
              </OkStyled>
            </BottomStyled>
          </ContentStyled>
        </ContainerStyled>
      )}
    </>
  );
};

Modal.propTypes = {
  isShow: PropTypes.bool.isRequired,
  width: PropTypes.number.isRequired,
  children: PropTypes.node.isRequired,
  handleCancel: PropTypes.func.isRequired,
  handleOk: PropTypes.func.isRequired,
  hasTitleModal: PropTypes.bool,
  titleModal: PropTypes.string,
};

export default Modal;

const ContainerStyled = styled(View)`
  align-items: center;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 50;
  justify-content: center;
`;

const BlurStyled = styled(View)`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1
  background-color: #000;
  opacity: 0.3;
`;

const ContentStyled = styled(View)`
  position: absolute;
  z-index: 2;
  flex: 1;
  background-color: #fff;
  border-style: solid;
  border-width: 1px;
  border-color: rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  width: ${props => props.width}%;
`;

const TitleStyled = styled(Text)`
  border-style: solid;
  border-bottom-width: 1px;
  border-color: #dee2e6;
  font-size: 24px;
  padding: 16px;
  height: 65px;
  color: #212529;
`;

const DescStyled = styled(View)`
  flex: 1;
  padding: 16px;
`;

const BottomStyled = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: flex-end;
  border-style: solid;
  border-top-width: 1px;
  border-color: #dee2e6;
  padding: 16px;
`;

const OkStyled = styled(View)`
  background-color: #007bff;
  align-self: center;
  border-radius: 5px;
`;

const CancelStyled = styled(View)`
  background-color: #6c757d;
  align-self: center;
  border-radius: 5px;
  margin-right: 10px;
`;
