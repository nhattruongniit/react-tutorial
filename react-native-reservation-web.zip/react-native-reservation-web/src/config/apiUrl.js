const API_URL = 'https://food-reservation-dev-aws.postas.asia/demo/public/api/v1';

export default API_URL;
