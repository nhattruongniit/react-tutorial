export default {
  DEFAULT_DATE_FORMAT: 'yyyyMMdd',
  DEFAULT_DATE_PICKER: 'dd-MM-yyyy',
};
