export default {
  LOGIN: 'Login',
  REGISTER: 'Register',
  AUTH: 'Auth',
  HOME: 'Home',
  PROFILE: 'Profile',
  RESERVATION: 'Reservation',
  WEEKVIEW: 'WeekView',
};
