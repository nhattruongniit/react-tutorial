import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { SafeAreaView } from 'react-native';

// localize
import { setI18nConfig } from '../../locales/translate';

// components
import Navigators from '../../navigators';
import Loading from './components/Loading';
import { DialogNotify } from '../dialog';

const DefaultPage = ({ language }) => {
  useEffect(() => {
    setI18nConfig(language);
  }, [language]);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Loading />
      <DialogNotify />
      <Navigators />
    </SafeAreaView>
  );
};

const mapStateToProps = state => {
  const {
    app: { language },
  } = state;

  return {
    language,
  };
};

export default connect(
  mapStateToProps,
  null
)(DefaultPage);
