import React from 'react';
import { Route } from 'react-router-dom';

// components
import Reservation from '../reservation';
import LoadingWeb from './components/Loading.web';

const DefaultPageWeb = () => {
  return (
    <>
      <LoadingWeb />
      <Route path="/reservation" component={Reservation} />
    </>
  );
};

export default DefaultPageWeb;
