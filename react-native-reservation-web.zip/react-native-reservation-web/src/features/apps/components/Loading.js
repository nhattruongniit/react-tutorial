import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Spinner from 'react-native-loading-spinner-overlay';
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  spinnerTextStyle: {
    color: '#FFF',
  },
});

const Loading = memo(({ showLoading }) => {
  return (
    <>
      {showLoading && (
        <Spinner
          visible={showLoading}
          textContent={'Loading...'}
          textStyle={styles.spinnerTextStyle}
        />
      )}
    </>
  );
});

Loading.propTypes = {
  showLoading: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  const {
    app: { showLoading },
  } = state;

  return {
    showLoading,
  };
};

export default connect(
  mapStateToProps,
  null
)(Loading);
