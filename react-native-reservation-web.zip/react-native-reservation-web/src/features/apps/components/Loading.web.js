import React, { memo } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import ReactLoading from 'react-loading';
import { View } from 'react-native';

const LoadingWeb = memo(({ showLoading }) => {
  return (
    <>
      {showLoading && (
        <ViewStyled>
          <BlurStyled />
          <LoadingStyled>
            <ReactLoading type="spinningBubbles" color="#fff" height={50} width={50} />
          </LoadingStyled>
        </ViewStyled>
      )}
    </>
  );
});

LoadingWeb.propTypes = {
  showLoading: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  const {
    app: { showLoading },
  } = state;

  return {
    showLoading,
  };
};

export default connect(
  mapStateToProps,
  null
)(LoadingWeb);

const ViewStyled = styled(View)`
  position: fixed;
  z-index: 1;
  width: 100%;
  height: 100%;
`;

const LoadingStyled = styled(View)`
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 2;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const BlurStyled = styled(View)`
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: #000;
  opacity: 0.5;
  z-index: 1;
`;
