import DefaultPage from './DefaultPage';

export default DefaultPage;
