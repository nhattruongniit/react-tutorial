import { CHANGE_LANGUAGE, SET_LOADING } from './reducer';
import axiosInstance from '../../../services/axiosInstance';

export const actChangeLanguage = payload => ({ type: CHANGE_LANGUAGE, payload: payload });

export const setLoading = showLoading => ({ type: SET_LOADING, payload: { showLoading } });

export const applicationInit = () => async dispatch => {
  axiosInstance.interceptors.request.use(
    config => {
      dispatch(setLoading(true));
      return config;
    },
    err => {
      dispatch(setLoading(false));
      return Promise.reject(err);
    }
  );
  axiosInstance.interceptors.response.use(
    res => {
      dispatch(setLoading(false));
      return res;
    },
    err => {
      dispatch(setLoading(false));
      return Promise.reject(err);
    }
  );
};
