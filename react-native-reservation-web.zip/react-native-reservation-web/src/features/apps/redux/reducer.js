export const CHANGE_LANGUAGE = 'APPS/CHANGE_LANGUAGE';
export const SET_LOADING = 'APPS/SET_LOADING';

const initialState = {
  language: 'en',
  showLoading: false,
};

export default (state = initialState, { type, payload }) => {
  switch (type) {
    case SET_LOADING: {
      return {
        ...state,
        showLoading: payload.showLoading,
      };
    }
    case CHANGE_LANGUAGE: {
      return {
        ...state,
        language: payload.language,
      };
    }
    default:
      return state;
  }
};
