import React, { useEffect } from 'react';
import { Spinner } from 'native-base';

// components
import CenterView from '../../components/common/CenterView';

const DefaultPage = ({ navigation }) => {
  useEffect(() => {
    _bootstrapAsync();
  }, []);

  const _bootstrapAsync = async () => {
    // This will switch to the App screen or Auth screen and this loading
    // screen will be unmounted and thrown away.
    navigation.navigate('Login');
  };

  // Render any loading content that you like here
  return (
    <CenterView>
      <Spinner color="green" />
    </CenterView>
  );
};

export default DefaultPage;
