import React from 'react';
import { Text, View, StyleSheet, TextInput, Button } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
  rows: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
});

const DefaultPage = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: 'bold', fontSize: 32, marginBottom: 30 }}>Login</Text>
      <View style={styles.rows}>
        <Text style={{ width: 120 }}>Company code: </Text>
        <TextInput
          style={{ width: 200, height: 40, borderColor: 'gray', borderWidth: 1, paddingLeft: 5 }}
          value="c00001"
        />
      </View>
      <View style={styles.rows}>
        <Text style={{ width: 120 }}>Password:</Text>
        <TextInput
          style={{ width: 200, height: 40, borderColor: 'gray', borderWidth: 1, paddingLeft: 5 }}
          value="p12345678"
        />
      </View>
      <View style={styles.rows}>
        <Text style={{ width: 120 }}>Store code:</Text>
        <TextInput
          style={{ width: 200, height: 40, borderColor: 'gray', borderWidth: 1, paddingLeft: 5 }}
          value="1"
        />
      </View>
      <Button
        title="Login"
        onPress={() => {
          navigation.navigate('Reservation');
        }}
      />
    </View>
  );
};

export default DefaultPage;
