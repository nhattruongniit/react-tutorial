import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Dialog from 'react-native-dialog';

// actions
import { actResetDialog } from './redux/actions';

const DefaultPage = memo(({ showDialogConfirm, children, onOk, actResetDialog }) => {
  const _closeModal = () => {
    actResetDialog();
  };

  return (
    <>
      <Dialog.Container visible={showDialogConfirm}>
        <Dialog.Title>Confirm</Dialog.Title>
        <Dialog.Description>{children}</Dialog.Description>
        <Dialog.Button label="Cancel" onPress={_closeModal} />
        <Dialog.Button label="Ok" onPress={onOk} />
      </Dialog.Container>
    </>
  );
});

DefaultPage.propTypes = {
  showDialogConfirm: PropTypes.bool,
  actResetDialog: PropTypes.func,
  children: PropTypes.node,
  onOk: PropTypes.func,
};

const mapStateToProps = state => {
  const {
    dialog: { showDialogConfirm },
  } = state;

  return {
    showDialogConfirm,
  };
};

const mapDispatchToProps = {
  actResetDialog,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
