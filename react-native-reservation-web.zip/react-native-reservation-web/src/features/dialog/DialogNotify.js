import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Dialog from 'react-native-dialog';

// actions
import { actResetDialog } from './redux/actions';

const DefaultPage = memo(
  ({ showDialogNotify, titleDialogNotify, msgDialogNotify, actResetDialog }) => {
    const _closeModal = () => {
      actResetDialog();
    };

    return (
      <>
        <Dialog.Container visible={showDialogNotify}>
          <Dialog.Title>{titleDialogNotify}</Dialog.Title>
          <Dialog.Description>{msgDialogNotify}</Dialog.Description>
          <Dialog.Button label="Ok" onPress={_closeModal} />
        </Dialog.Container>
      </>
    );
  }
);

DefaultPage.propTypes = {
  showDialogNotify: PropTypes.bool,
  titleDialogNotify: PropTypes.string,
  msgDialogNotify: PropTypes.string,
  actResetDialog: PropTypes.func,
};

const mapStateToProps = state => {
  const {
    dialog: { showDialogNotify, msgDialogNotify, titleDialogNotify },
  } = state;

  return {
    showDialogNotify,
    msgDialogNotify,
    titleDialogNotify,
  };
};

const mapDispatchToProps = {
  actResetDialog,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
