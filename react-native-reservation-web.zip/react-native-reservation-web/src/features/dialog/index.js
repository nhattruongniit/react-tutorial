import DialogNotify from './DialogNotify';
import DialogConfirm from './DialogConfirm';

export { DialogNotify, DialogConfirm };
