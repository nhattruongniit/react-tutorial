import { OPEN_DIALOG_NOTIFY, OPEN_DIALOG_CONFIRM, RESET_DIALOG } from './reducer';

export const actResetDialog = () => ({ type: RESET_DIALOG });

export const actOpenDialogNotify = (title, msgError) => ({
  type: OPEN_DIALOG_NOTIFY,
  payload: {
    title,
    msgError,
  },
});

export const actOpenDialogConfirm = () => ({ type: OPEN_DIALOG_CONFIRM });
