export const RESET_DIALOG = 'DIALOG/RESET_DIALOG';

export const OPEN_DIALOG_NOTIFY = 'DIALOG/OPEN_DIALOG_NOTIFY';

export const OPEN_DIALOG_CONFIRM = 'DIALOG/OPEN_DIALOG_CONFIRM';

const initialState = {
  showDialogNotify: false,
  msgDialogNotify: '',
  titleDialogNotify: '',
  showDialogConfirm: false,
};

export default (state = initialState, { type, payload }) => {
  switch (type) {
    case OPEN_DIALOG_NOTIFY: {
      return {
        ...state,
        showDialogNotify: true,
        titleDialogNotify: payload.title,
        msgDialogNotify: payload.msgError,
      };
    }
    case OPEN_DIALOG_CONFIRM: {
      return {
        ...state,
        showDialogConfirm: true,
      };
    }
    case RESET_DIALOG: {
      return {
        showDialogNotify: false,
        msgDialogNotify: '',
        titleDialogNotify: '',
        showDialogConfirm: false,
      };
    }
    default:
      return state;
  }
};
