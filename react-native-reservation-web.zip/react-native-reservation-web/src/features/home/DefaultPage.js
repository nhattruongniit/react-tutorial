import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Text, View, StyleSheet, Button } from 'react-native';

// actions
import { increment, decrement } from './redux/actions';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
});

const DefaultPage = ({ counter, increment, decrement }) => {
  const _onIncrement = () => {
    increment(1);
  };

  const _onDecrement = () => {
    decrement(1);
  };

  return (
    <View style={styles.container}>
      <Text>Home Screen {counter}</Text>
      <Button title="increment" onPress={_onIncrement} />
      <Button title="decrement" color="#F00" onPress={_onDecrement} />
    </View>
  );
};

const mapStateToProps = state => {
  const {
    home: { counter },
  } = state;
  return { counter };
};

const mapDispatchToProps = {
  increment,
  decrement,
};

DefaultPage.propTypes = {
  counter: PropTypes.number.isRequired,
  increment: PropTypes.func.isRequired,
  decrement: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
