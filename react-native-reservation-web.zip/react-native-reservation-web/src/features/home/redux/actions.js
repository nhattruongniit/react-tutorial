import { INCREMENT, DECREMENT } from './reducer';

export const increment = count => async dispatch => {
  dispatch({
    type: INCREMENT,
    payload: { count },
  });
};

export const decrement = count => async dispatch => {
  dispatch({
    type: DECREMENT,
    payload: { count },
  });
};
