export const INCREMENT = 'HOME/INCREMENT';
export const DECREMENT = 'HOME/DECREMENT';

const initialState = {
  counter: 0,
};

export default (state = initialState, { type, payload }) => {
  switch (type) {
    case INCREMENT: {
      return {
        ...state,
        counter: state.counter + payload.count,
      };
    }
    case DECREMENT: {
      return {
        ...state,
        counter: state.counter - payload.count,
      };
    }
    default:
      return state;
  }
};
