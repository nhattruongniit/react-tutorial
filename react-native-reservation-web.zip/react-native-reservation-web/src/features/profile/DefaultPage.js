import React from 'react';
import { connect } from 'react-redux';
import { Text, View, StyleSheet, Button } from 'react-native';

// api
import { callFetchUsers } from './api';

// actions
import { actOpenDialogNotify, actOpenDialogConfirm, actResetDialog } from '../dialog/redux/actions';
import { actChangeLanguage } from '../apps/redux/actions';
import { actFetchUsers } from './redux/actions';

// translate
import { translate } from '../../locales/translate';

// components
import { DialogConfirm } from '../dialog';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
});

const DefaultPage = ({
  actOpenDialogNotify,
  actOpenDialogConfirm,
  actResetDialog,
  actChangeLanguage,
  actFetchUsers,
}) => {
  const _onFetchUser = async () => {
    try {
      const res = await callFetchUsers();
      const users = res.data;
      actFetchUsers(users);
    } catch (err) {
      actOpenDialogNotify('Error', `fetch api error ${err}`);
    }
  };

  const _onOpenDialogConfirm = () => {
    actOpenDialogConfirm();
  };

  const _onOk = () => {
    alert('=========== ok confrim ==============');
    actResetDialog();
  };

  const _onChangeLanguage = language => async () => {
    actChangeLanguage({ language });
  };

  return (
    <View style={styles.container}>
      <Text>Test i18n: {translate('hello')}111</Text>
      <Button title="fetch user" onPress={_onFetchUser} />
      <Button title="open dialog confirm" onPress={_onOpenDialogConfirm} />
      <Button title="change language en" onPress={_onChangeLanguage('en')} />
      <Button title="change language fr" onPress={_onChangeLanguage('fr')} />
      <DialogConfirm onOk={_onOk}>test dialog confirm</DialogConfirm>
    </View>
  );
};

const mapStateToProps = state => {
  const {
    app: { language },
  } = state;

  return {
    language,
  };
};

const mapDispatchToProps = {
  actOpenDialogNotify,
  actOpenDialogConfirm,
  actResetDialog,
  actChangeLanguage,
  actFetchUsers,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
