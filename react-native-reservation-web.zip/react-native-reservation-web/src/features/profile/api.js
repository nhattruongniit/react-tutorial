import axiosInstance from '../../services/axiosInstance';

import { API_URL } from '../../config';

export const callFetchUsers = () => {
  return axiosInstance.get(`${API_URL}/users`);
};
