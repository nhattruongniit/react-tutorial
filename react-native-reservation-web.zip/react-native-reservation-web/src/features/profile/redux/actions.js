import { FETCH_USER } from './reducers';

export const actFetchUsers = users => ({ type: FETCH_USER, payload: { users } });
