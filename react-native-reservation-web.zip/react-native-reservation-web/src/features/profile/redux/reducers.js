const PREFIX = 'PROFILE';

export const FETCH_USER = `${PREFIX}/FETCH_USER`;

const initialState = {
  users: [],
};

const reducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case FETCH_USER: {
      return {
        ...state,
        users: payload.users,
      };
    }
    default:
      return state;
  }
};

export default reducer;
