import React, { lazy, useRef, useEffect, Suspense } from 'react';
import { connect } from 'react-redux';
import { View, Text, StyleSheet, ScrollView, SafeAreaView, FlatList } from 'react-native';
// configs
import { RSV_CONFIG } from '../../config';
import isWeb from '../../utils/isWeb';

// data
import { dataTimes } from './mocks/dataTimes';
import { dataRsv } from './mocks/dataRsv';

// component
import WaitingList from './components/WaitingList/WaitingList';
import TableList from './components/TableList/TableList';
import GridCols from './components/Grid/GridCols';
import GridRows from './components/Grid/GridRows';
import TimeList from './components/TimeList/TimeList';
import TimeTableMarking from './components/TimeTableMarking/TimeTableMarking';
import HeaderLeft from './components/Header/HeaderLeft';
import HeaderRight from './components/Header/HeaderRight';
import DialogDetail from './components/DialogDetail/DialogDetail';

// actions
import { fetchRsv, actShowModalDetail } from './redux/actions';

// utils
import getTableListGroup from './utils/getTableListGroup';

const HeaderCenter = isWeb
  ? lazy(() => import('./components/Header/HeaderCenter.web'))
  : lazy(() => import('./components/Header/HeaderCenter'));

const widthRow =
  (dataTimes.length + (RSV_CONFIG.DEFAULT_UNIT_COLUMN - 1)) * RSV_CONFIG.DEFAULT_TIME_WIDTH;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  calendar: {
    flex: 1,
  },
  calendarTop: {
    flexDirection: 'row',
  },
  colorWhite: {
    color: '#fff',
    fontWeight: 'bold',
  },
  nameTable: {
    width: 200,
    borderRightWidth: 1,
    borderRightColor: '#b2b2b2',
    backgroundColor: '#6A6A6A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  calendarGrid: {
    flexDirection: 'row',
    width: '100%',
  },
  containerTime: {
    flex: widthRow,
    height: 50,
  },
  timeList: {
    backgroundColor: '#6A6A6A',
    flex: 1,
    flexDirection: 'row',
  },
  containGrid: {
    width: widthRow,
  },
  grids: {
    flex: 1,
  },
  gridRows: {
    flexDirection: 'column',
    zIndex: 2,
    position: 'relative',
  },
  gridCols: {
    flexDirection: 'row',
    height: '100%',
    width: '100%',
    zIndex: 1,
    position: 'absolute',
  },
  timeStyle: {
    flex: 1,
    flexDirection: 'row',
  },
  tableList: {
    width: 200,
    backgroundColor: '#fff',
  },
  HeaderStyle: {
    height: RSV_CONFIG.DEFAULT_HEIGHT,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#0099d5',
    paddingTop: 0,
    paddingBottom: 0,
    paddingLeft: 20,
    paddingRight: 20,
    zIndex: 1,
  },
  WaitingStyle: {
    height: RSV_CONFIG.DEFAULT_HEIGHT + 20,
    flexDirection: 'row',
    borderTopColor: '#d2cfcf',
    borderTopWidth: 1,
    alignItems: 'center',
    paddingLeft: 5,
    paddingRight: 5,
  },
  ErrorStyle: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  TextStyle: {
    color: '#d0021b',
    paddingLeft: 5,
  },
  TimeCells: {
    backgroundColor: '#6a6a6a',
    flex: 1,
    flexDirection: 'row',
  },
  TimeListStyle: {
    height: RSV_CONFIG.DEFAULT_HEIGHT,
    flex: widthRow,
  },
});

const DefaultPage = ({
  isEnabledScroll,
  isEditMode,
  listTable,
  fetchRsv,
  date,
  dataWaitingList,
  isShow,
  reservationDetail,
  actShowModalDetail,
}) => {
  let isScrollTime = false;
  let isScrollGrid = false;
  let refScrollGird = useRef(null);
  let refScrollTime = useRef(null);

  const listTableGroup = getTableListGroup(listTable);

  useEffect(() => {
    fetchRsv(date);
  }, [date]);

  const renderTime = () => {
    const dataTimeListFilter = dataTimes.filter(
      (_, index) => index % RSV_CONFIG.DEFAULT_UNIT_COLUMN === 0
    );
    return (
      <View style={styles.TimeCells}>
        {dataTimeListFilter.map((val, key) => (
          <TimeList index={key} name={val.time_display_12} />
        ))}
      </View>
    );
  };

  const renderTableList = () => {
    const tableListHeight =
      listTableGroup.length > 0 ? listTableGroup.length * RSV_CONFIG.DEFAULT_HEIGHT : 'auto';
    return (
      <View style={[styles.tableList, { height: tableListHeight }]}>
        {listTableGroup.length > 0 &&
          listTableGroup.map(table => (
            <TableList
              index={table.table_no}
              tableName={table.table_name}
              seatable={table.seatable_party}
            />
          ))}
      </View>
    );
  };

  const renderCols = () => {
    const newCols = [];
    for (let i = 0; i < dataTimes.length + (RSV_CONFIG.DEFAULT_UNIT_COLUMN - 1); i++) {
      newCols.push(<GridCols index={i} />);
    }
    return newCols;
  };

  const renderRows = () => {
    return (
      <>
        {listTableGroup.length > 0 &&
          listTableGroup.map((table, key) => {
            return <GridRows tableIndex={key} rsvList={table.rsv_list} />;
          })}
      </>
    );
  };

  const _onScrollingTime = e => {
    if (!isScrollTime) {
      isScrollGrid = true;
      const scrollX = e.nativeEvent.contentOffset.x;
      refScrollGird.scrollTo({ x: scrollX, animated: false });
    }
  };

  const _onScrollingGrid = e => {
    if (!isScrollGrid) {
      isScrollTime = true;
      const scrollX = e.nativeEvent.contentOffset.x;
      refScrollTime.scrollTo({ x: scrollX, animated: false });
    }
  };

  const renderWaitingList = () => {
    return (
      <SafeAreaView style={styles.container}>
        <FlatList
          data={dataWaitingList}
          renderItem={({ item }) => (
            <WaitingList
              persons={item.persons}
              kana={item.last_name_kana || 'Walk-in'}
              startTime={item.start_time_name}
              endTime={item.end_time_name}
            />
          )}
          keyExtractor={item => item.rsv_no}
          horizontal={true}
        />
      </SafeAreaView>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.HeaderStyle}>
        <HeaderLeft />
        <Suspense fallback={null}>
          <HeaderCenter />
        </Suspense>
        <HeaderRight />
      </View>
      <View style={styles.calendar}>
        <View style={styles.calendarTop}>
          <View style={styles.nameTable}>
            <Text style={styles.colorWhite}>テーブル</Text>
          </View>
          <View style={[styles.TimeListStyle]}>
            <ScrollView
              ref={ref => {
                refScrollTime = ref;
              }}
              bounces={false}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              onScrollBeginDrag={() => {
                isScrollTime = false;
              }}
              onScroll={_onScrollingTime}
              scrollEventThrottle={1}
            >
              {renderTime()}
            </ScrollView>
          </View>
        </View>
        <ScrollView
          bounces={false}
          contentContainerStyle={styles.calendarGrid}
          showsVerticalScrollIndicator={false}
        >
          {renderTableList()}
          <ScrollView
            ref={ref => {
              refScrollGird = ref;
            }}
            horizontal={true}
            bounces={false}
            contentContainerStyle={styles.containGrid}
            onScrollBeginDrag={() => {
              isScrollGrid = false;
            }}
            onScroll={_onScrollingGrid}
            scrollEventThrottle={1}
            scrollEnabled={isEnabledScroll}
          >
            <View style={styles.grids}>
              <View style={styles.gridCols}>{renderCols()}</View>
              <View style={styles.gridRows}>{renderRows()}</View>
            </View>
            <TimeTableMarking dataTableRsv={listTableGroup} isEditMode={isEditMode} />
          </ScrollView>
        </ScrollView>
      </View>
      <View style={styles.WaitingStyle}>
        <View style={styles.ErrorStyle}>
          <Text style={styles.TextStyle}>ウェイティング ({dataWaitingList.length})</Text>
        </View>
        {renderWaitingList()}
      </View>
      <DialogDetail
        isShow={isShow}
        reservationDetail={reservationDetail}
        actShowModalDetail={actShowModalDetail}
      />
    </View>
  );
};

const mapStateToProps = state => {
  const {
    reservation: {
      isEditing,
      editingRsv,
      listTable,
      date,
      dataWaitingList,
      isEditMode,
      isShow,
      reservationDetail,
    },
  } = state;
  return {
    isEditing,
    editingRsv,
    listTable,
    date,
    dataWaitingList,
    isEditMode,
    isShow,
    reservationDetail,
  };
};

const mapDispatchToProps = {
  fetchRsv,
  actShowModalDetail,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
