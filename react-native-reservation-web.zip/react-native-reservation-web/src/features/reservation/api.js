import axiosInstance from '../../services/axiosInstance';

export const fetchRsv = calendarDate => {
  const bodyData = {
    company_code: 'c00001',
    store_code: '1',
    client_date: '201809071021',
    calendar_date: calendarDate,
    lang_code: 'jpn',
  };
  return axiosInstance.post(
    '/timetable-rsv?filter=tablelist,timelist,waitingrsv&include=tablelist:rsv',
    bodyData,
    { showSpinner: true }
  );
};
