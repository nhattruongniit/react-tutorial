import React from 'react';
import styled from 'styled-components';
import { View, Text } from 'react-native';
import AppMoment from '../../../components/common/AppMoment';

import { DEFAULT_TIME_WIDTH, DEFAULT_UNIT_COLUMN } from '../contanst';
const _default_hour = 60;
const _current_hour = () =>
  AppMoment.currentHour() < 6 ? AppMoment.currentHour() + 24 : AppMoment.currentHour();
const _left = () =>
  (
    ((_current_hour() * _default_hour + AppMoment.currentMinute()) *
      DEFAULT_TIME_WIDTH *
      DEFAULT_UNIT_COLUMN) /
    _default_hour
  ).toFixed();

const CurrentTimeLine = () => {
  return <CurrentTimeLineStyled left={_left()} />;
};

const CurrentTimeLineStyled = styled(View)`
  flex-direction: column;
  border: 0.5px solid red;
  width: auto;
  height: 100%;
  background-color: red;
  z-index: 2;
  position: absolute;
  top: 0;
  left: ${props => props.left};
`;

export default CurrentTimeLine;

/*
function showCurTime (calendarDate, mode = 'new', isScroll = true) {
    var dt = moment(moment.now());
    var current_hour = dt.hour();
    var current_minute = dt.minute();
    var calendar_date = moment(calendarDate, "YYYYMMDD").format('YYYYMMDD');
    var paramCheck = moment(moment().subtract(1, 'day')).format('YYYYMMDD');
    var now = moment(todayDateCondition).format("YYYYMMDD");
    $('#show-cur-time').remove();
    var cur_time = document.createElement('div');
    cur_time.id = 'show-cur-time';
    cur_time.className = 'cur-time';
    $('#table_rsv_outer').prepend(cur_time);
    if (isToday && parseInt(paramCheck) === parseInt(now) && current_hour < 6) {
        current_hour = parseInt(current_hour) + 24;
    }
    $("li[data-name='now']").val(String(("0" + current_hour).slice(-2)) + String(("0" + current_minute).slice(-2)));
    if (parseInt(calendar_date) !== parseInt(now)) {
        cur_time.className = 'cur-time-none';
    }
    var left = ((( (current_hour * 60) + dt.minute()) * 160) / 60 ).toFixed();
    var classCss = new Object();
    classCss.left = left + 'px';
    classCss.height = $('#table_rsv').height() + 'px';
    $('#show-cur-time').css(classCss);

    if (isScroll) {
        // Scroll to current time
        var tableOuter = $("#table_rsv_outer");
        var tableOuter_header = $("#table_rsv_outer_header");
        var scrollTo = 0;
        if (mode === 'edit') {
            var hourOfEditMode = parseInt(data_post.start_time.substr(0, 2));
            scrollTo = ( (hourOfEditMode * 60 * 160) / 60 ).toFixed();
        } else {
            scrollTo = ( (current_hour * 60 * 160) / 60 ).toFixed();
        }

        var objTimeTable = $('#objTimeTable').val();
        if (objTimeTable) {
            jsonObj = JSON.parse(objTimeTable);
            hourOfEditMode = parseInt(jsonObj.start_time.substr(0, 2));
            scrollTo = ( (hourOfEditMode * 60 * 160) / 60 ).toFixed();
        }

        tableOuter_header.scrollLeft(scrollTo);
        tableOuter.scrollLeft(scrollTo).css('overflow','scroll');

    }
}
*/
