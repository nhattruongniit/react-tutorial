import React from 'react';
import PropTypes from 'prop-types';
import { Image } from 'react-native';

// images
import SignImage from '../../../../assets/images/signature.png';
import iconCalendar from '../../../../assets/images/icon-calendar-black.png';
import iconTable from '../../../../assets/images/icon-table.png';
import iconTime from '../../../../assets/images/icon-time.png';
import iconChildCare from '../../../../assets/images/icon-children-care.png';
import iconExplicit from '../../../../assets/images/icon-explicit.png';
import iconAccessible from '../../../../assets/images/icon-accessible.png';
import iconChildFriendly from '../../../../assets/images/icon-child-friendly.png';
import iconWarning from '../../../../assets/images/icon-warning.png';
import iconBirthday from '../../../../assets/images/icon-birthday.png';
import iconPersonBlack from '../../../../assets/images/icon-person-black.png';

// components
import Modal from '../../../../components/common/Modal';

// styles
import {
  ContainerStyled,
  ContentStyled,
  OptionStyled,
  InforStyled,
  TextWhiteStyled,
  TextRsvStyled,
  CurrentStyled,
  StatusStyled,
  HeadingStyled,
  LineBottomStyled,
  TextHeadingStyled,
  RowsStyled,
  BookStyled,
  BookListStyled,
  SignStyled,
  ImageStyled,
  BookRowStyled,
  BookHeadingStyled,
  BookTextStyled,
  StageStyled,
  StageLeftStyled,
  StageRightStyled,
  TextBoldStyled,
  TextItalicStyled,
  MoreInfoStyled,
  MoreRowStyled,
  ExtraStyled,
  DateStyled,
  DateTextStyled,
  RsvInforStyled,
  RsvRowStyled,
  RsvTextStyled,
} from './styles';

const DialogDetail = ({ isShow, actShowModalDetail, reservationDetail }) => {
  const _handleCancel = () => {
    actShowModalDetail(false, {});
  };

  const _handleOk = () => {
    actShowModalDetail(false, {});
  };

  return (
    <>
      <Modal
        isShow={isShow}
        width={80}
        height={100}
        hasTitleModal={false}
        titleModal="Reservation Detail"
        handleCancel={_handleCancel}
        handleOk={_handleOk}
      >
        <ContainerStyled>
          <OptionStyled>
            <StatusStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconChildCare} />
              </ImageStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconExplicit} />
              </ImageStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconAccessible} />
              </ImageStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconChildFriendly} />
              </ImageStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconWarning} />
              </ImageStyled>
              <ImageStyled>
                <Image style={{ width: 25, height: 25 }} source={iconBirthday} />
              </ImageStyled>
            </StatusStyled>
            <InforStyled>
              <TextRsvStyled>Reservation detail </TextRsvStyled>
              <CurrentStyled>
                <TextWhiteStyled>Walk-in</TextWhiteStyled>
              </CurrentStyled>
            </InforStyled>
          </OptionStyled>
          <ContentStyled>
            <StageStyled>
              <StageLeftStyled>
                {/* <RowsStyled>
                  <HeadingStyled>
                    <TextHeadingStyled>Change Status</TextHeadingStyled>
                  </HeadingStyled>
                </RowsStyled> */}
                <RowsStyled>
                  <HeadingStyled>
                    <TextHeadingStyled>Reservaion Information</TextHeadingStyled>
                  </HeadingStyled>
                  <LineBottomStyled />
                  <RsvInforStyled>
                    <RsvRowStyled>
                      <Image style={{ width: 15, height: 15 }} source={iconCalendar} />
                      <RsvTextStyled>2019/09/19 (THU)</RsvTextStyled>
                    </RsvRowStyled>
                    <RsvRowStyled>
                      <Image style={{ width: 15, height: 15 }} source={iconTime} />
                      <RsvTextStyled>10:15~11:45(1H30Minute)</RsvTextStyled>
                    </RsvRowStyled>
                    <RsvRowStyled>
                      <Image style={{ width: 15, height: 15 }} source={iconPersonBlack} />
                      <RsvTextStyled>{reservationDetail.persons}</RsvTextStyled>
                    </RsvRowStyled>
                  </RsvInforStyled>
                  <RsvInforStyled>
                    <RsvRowStyled>
                      <Image style={{ width: 15, height: 15 }} source={iconTable} />
                      <RsvTextStyled>Table 3 - Table 4</RsvTextStyled>
                    </RsvRowStyled>
                  </RsvInforStyled>
                </RowsStyled>
              </StageLeftStyled>
              <StageRightStyled>
                <TextBoldStyled>Walk-in</TextBoldStyled>
                <MoreInfoStyled>
                  <MoreRowStyled>
                    <TextItalicStyled>Tel:</TextItalicStyled>
                    <TextBoldStyled>No Information</TextBoldStyled>
                  </MoreRowStyled>
                  <MoreRowStyled>
                    <TextItalicStyled>Visit count:</TextItalicStyled>
                    <TextBoldStyled>0</TextBoldStyled>
                  </MoreRowStyled>
                  <MoreRowStyled>
                    <TextItalicStyled>Last visit date:</TextItalicStyled>
                    <TextBoldStyled>No Information</TextBoldStyled>
                  </MoreRowStyled>
                </MoreInfoStyled>
              </StageRightStyled>
            </StageStyled>
            <RowsStyled>
              <HeadingStyled>
                <TextHeadingStyled>Booking Information</TextHeadingStyled>
              </HeadingStyled>
              <LineBottomStyled />
              <BookStyled>
                <BookListStyled>
                  <BookRowStyled>
                    <BookHeadingStyled>Menu:</BookHeadingStyled>
                    <BookTextStyled>No course menu</BookTextStyled>
                  </BookRowStyled>
                  <BookRowStyled>
                    <BookHeadingStyled>Remarks:</BookHeadingStyled>
                    <BookTextStyled>No remarks</BookTextStyled>
                  </BookRowStyled>
                </BookListStyled>
                <SignStyled>
                  <Image style={{ width: 100, height: 100 }} source={SignImage} />
                </SignStyled>
              </BookStyled>
            </RowsStyled>
            <RowsStyled>
              <ExtraStyled>None smoking - No purpose - No media</ExtraStyled>
            </RowsStyled>
            <DateStyled>
              <DateTextStyled>2019/09/19 02:08 保守者</DateTextStyled>
            </DateStyled>
          </ContentStyled>
        </ContainerStyled>
      </Modal>
    </>
  );
};

DialogDetail.propTypes = {
  isShow: PropTypes.bool.isRequired,
  actShowModalDetail: PropTypes.func.isRequired,
  reservationDetail: PropTypes.object,
};

export default DialogDetail;
