import { View, Text } from 'react-native';
import styled from 'styled-components';

export const ContainerStyled = styled(View)`
  background-color: white;
  padding-top: 10px;
  padding-bottom: 10px;
  justify-content: center;
  border-radius: 4;
  border-color: rgba(0, 0, 0, 0.1);
`;

export const ContentStyled = styled(View)`
  padding-left: 20px;
  padding-right: 20px;
`;

export const OptionStyled = styled(View)`
  flex-direction: row;
  align-items: center;
  border-style: solid;
  border-color: #e8e8e8;
  border-bottom-width: 1px;
  padding-left: 20px;
  padding-right: 20px;
  padding-bottom: 10px;
`;

export const TextButtonStyled = styled(Text)`
  font-size: 16px;
`;

export const TextCancelStyled = styled(Text)`
  color: #333;
`;

export const InforStyled = styled(View)`
  flex-direction: row;
  align-items: center;
`;

export const TextWhiteStyled = styled(Text)`
  color: #fff;
  padding-right: 3px;
  padding-left: 3px;
  font-size: 14px;
`;

export const TextRsvStyled = styled(Text)`
  font-size: 16px;
`;

export const CurrentStyled = styled(View)`
  background-color: #6399ae;
  margin-left: 5px;
`;

export const StatusStyled = styled(View)`
  flex-direction: row;
  align-items: center;
`;

export const HeadingStyled = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;
  align-items: center;
  border-left-width: 3px;
  border-style: solid;
  border-color: #0099d5;
  padding-left: 15px;
  margin-bottom: 5px;
`;

export const LineBottomStyled = styled(View)`
  border-bottom-width: 1px;
  border-style: solid;
  border-color: #0099d5;
  flex: 1;
  margin-left: 15px;
  margin-bottom: 15px;
`;

export const TextHeadingStyled = styled(Text)`
  font-size: 15px;
  padding-top: 5px;
  padding-bottom: 5px;
  color: #333;
  font-weight: bold;
`;

export const RowsStyled = styled(View)`
  margin-top: 10px;
`;

export const TextEditStyled = styled(Text)`
  color: #0099d5;
  font-size: 14px;
  padding-left: 5px;
`;

export const BookStyled = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  padding-left: 20px;
  padding-right: 20px;
`;

export const BookListStyled = styled(View)`
  flex-direction: row;
  border-bottom-width: 1px;
  border-color: #0099d5;
  flex: 1;
  margin-right: 20px;
  padding-bottom: 10px;
`;

export const SignStyled = styled(View)`
  width: 80px;
  height: 80px;
`;

export const ImageStyled = styled(View)`
  margin-right: 20px;
`;

export const BookRowStyled = styled(View)`
  flex: 1;
`;

export const BookHeadingStyled = styled(Text)`
  color: #333;
  font-weight: bold;
  font-size: 15px;
`;

export const BookTextStyled = styled(Text)`
  color: #333;
  font-size: 14px;
`;

export const StageStyled = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-start;
  margin-top: 2%;
`;

export const StageLeftStyled = styled(View)`
  flex: 1;
`;

export const StageRightStyled = styled(View)`
  border-width: 1px;
  border-color: #0099d5;
  margin-left: 20px;
  border-radius: 10px;
  width: 300px;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
`;

export const TextBoldStyled = styled(Text)`
  font-weight: bold;
  color: #333333;
  font-size: 15px;
`;

export const TextItalicStyled = styled(Text)`
  color: #333333;
  font-size: 13px;
  padding-right: 5px;
`;

export const MoreInfoStyled = styled(View)`
  margin-top: 20px;
`;

export const MoreRowStyled = styled(View)`
  flex-direction: row;
  flex-wrap: wrap;
`;

export const ExtraStyled = styled(Text)`
  color: #9b9b9b;
  padding-left: 10px;
  font-size: 14px;
`;

export const DateStyled = styled(View)`
  align-items: flex-end;
`;

export const DateTextStyled = styled(Text)`
  font-size: 14px;
  color: #333;
`;

export const RsvInforStyled = styled(View)`
  flex-direction: row;
  align-items: center;
  margin-left: 20px;
  justify-content: space-between;
  flex-wrap: wrap;
`;

export const RsvRowStyled = styled(View)`
  flex-direction: row;
  align-items: center;
  margin-bottom: 20px;
`;

export const RsvTextStyled = styled(Text)`
  font-size: 14px;
  color: #333;
  padding-left: 5px;
`;
