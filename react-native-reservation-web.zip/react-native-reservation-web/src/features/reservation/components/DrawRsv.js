import React from 'react';
import { connect } from 'react-redux';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

import { actChangeEditing, actShowModalDetail } from '../redux/actions';

// configs
import { RSV_CONFIG } from '../../../config';

// mocks
import { dataTimes } from '../mocks/dataTimes';

const rsvColors = [
  // aWaiting: Status 1 => Index Of rsvColors = 0
  {
    backgroundColor: '#F5A623',
    borderColor: '#aa6d08',
  },
  // occupied: Status 2 => Index Of rsvColors = 1
  {
    backgroundColor: '#45B4E0',
    borderColor: '#1b7da4',
  },
  // finished: Status 3 => Index Of rsvColors = 2
  {
    backgroundColor: '#027EAD',
    borderColor: '#013548',
  },
  // paid: Status 4 => Index Of rsvColors = 3
  {
    backgroundColor: '#008008',
    borderColor: '#001a02',
  },
  // cleaned: Status 5 => Index Of rsvColors = 4
  {
    backgroundColor: '#9CB2A2',
    borderColor: '#66836d',
  },
  // cancelled: Status 6 => Index Of rsvColors = 5
  {
    backgroundColor: '#4C4C4C',
    borderColor: '#353535',
  },
  // no Show: Status 7 => Index Of rsvColors = 6
  {
    backgroundColor: '#4C4C4C',
    borderColor: '#353535',
  },
];

const DrawRsv = ({
  currentEditedRsv,
  rsv,
  tableIndex,
  actChangeEditing,
  index,
  actShowModalDetail,
}) => {
  const getIndexByTime = time => dataTimes.findIndex(val => val.time_hhmm === time);

  const getIndexStartTime = () => {
    const time = getIndexByTime(rsv.start_time);
    return time === 0 ? 1 : time;
  };

  const getIndexEndTime = () => getIndexByTime(rsv.end_time);

  const getRsvSpace = () => RSV_CONFIG.DEFAULT_SPACE_RSV;

  const getRsvSpaceDouble = () => RSV_CONFIG.DEFAULT_SPACE_RSV * 2;

  const getRsvWidth = () =>
    (getIndexEndTime() - getIndexStartTime()) * RSV_CONFIG.DEFAULT_TIME_WIDTH - getRsvSpaceDouble();

  const getCssLeft = () => getIndexStartTime() * RSV_CONFIG.DEFAULT_TIME_WIDTH + getRsvSpace();

  const getCssTop = () => getRsvSpace();

  const getCssZIndex = () => tableIndex + 1000;

  const getRsvColor = status => rsvColors[status - 1];

  const getCssBackgroundColor = () => getRsvColor(rsv.rsv_status).backgroundColor;

  const getCssBorderLeftColor = () => getRsvColor(rsv.rsv_status).borderColor;

  const getCssOpacity = () => (currentEditedRsv && currentEditedRsv.id == rsv.id ? 0.0 : 0.8);

  const getRsvName = () => {
    let walkIn = 'Walk-in';
    if (rsv.walkin_flg === '1') {
      let name = rsv.last_name_kana;
      return name != null ? name : walkIn;
    }
    return walkIn;
  };

  const getRsvGroupList = () => rsv.table_group_list;

  const getRsvGroupListHeight = () =>
    RSV_CONFIG.DEFAULT_HEIGHT * getRsvGroupList().length - getRsvSpaceDouble();

  const isTableGroupList = () => (rsv.table_group_list !== null ? true : false);

  const isTableGroup = () => (rsv.table_group === true ? true : false);

  const renderRsvNone = () => (
    <>
      <TouchableOpacity
        style={styles.TouchStyle}
        onPress={_onPressButton}
        onLongPress={_onLongPressButton}
      >
        <View style={styles.RsvNoneStyle} key={index} />
      </TouchableOpacity>
    </>
  );

  const renderRsv = () => renderRsvView(RSV_CONFIG.DEFAULT_HEIGHT - getRsvSpaceDouble());

  const renderRsvGroup = () => {
    if (!isTableGroupList()) return renderRsvNone();
    return renderRsvView(getRsvGroupListHeight());
  };

  const _onPressButton = () => {
    actShowModalDetail(true, rsv);
  };

  const _onLongPressButton = () => {
    actChangeEditing(true, rsv, false);
  };

  const renderRsvView = height => {
    return (
      <View
        key={index}
        style={[
          styles.RsvStyle,
          {
            width: getRsvWidth(),
            height: height,
            backgroundColor: getCssBackgroundColor(),
            borderLeftColor: getCssBorderLeftColor(),
            top: getCssTop(),
            zIndex: getCssZIndex(),
            opacity: getCssOpacity(),
            left: getCssLeft(),
          },
        ]}
      >
        <TouchableOpacity
          style={styles.TouchStyle}
          onPress={_onPressButton}
          onLongPress={_onLongPressButton}
        >
          <View style={styles.ContentStyle}>
            <Text style={styles.NumberStyled}>{getRsvName()}</Text>
            <View style={styles.SeatStyle}>
              <Text style={styles.NumberStyled}>{rsv.persons}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return !isTableGroup() ? renderRsv() : renderRsvGroup();
};

const mapStateToProps = state => {
  const {
    reservation: { currentEditedRsv },
  } = state;
  return {
    currentEditedRsv,
  };
};
const mapDispatchToProps = {
  actChangeEditing,
  actShowModalDetail,
};

const styles = StyleSheet.create({
  RsvStyle: {
    position: 'absolute',
    paddingTop: 5,
    paddingBottom: 5,
    paddingRight: 10,
    paddingLeft: 10,
    borderLeftWidth: 6,
    borderStyle: 'solid',
  },
  RsvNoneStyle: {
    position: 'absolute',
    top: 0,
    opacity: 0,
  },
  TouchStyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  ContentStyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  NumberStyle: {
    color: '#fff',
    paddingLeft: '5px',
  },
  SeatStyle: {
    flexDirection: 'row',
  },
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DrawRsv);
