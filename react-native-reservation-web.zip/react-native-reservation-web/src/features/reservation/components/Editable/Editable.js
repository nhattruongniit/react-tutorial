import React from 'react';
import { connect } from 'react-redux';
import { View, StyleSheet, PanResponder } from 'react-native';

import PeriodMarking from './PeriodMarking';
// configs
import { RSV_CONFIG } from '../../../config';

// actions
import { actUpdatePositionSize, actSelectTable } from '../redux/actions';

const Editable = ({
  isDragResizing,
  dataRsv,
  editingRsv,
  editingStartPosition,
  editingEndPosition,
  actUpdatePositionSize,
  actSelectTable,
}) => {
  const onPositionResizeUpdateHandler = (start, end) => {
    actUpdatePositionSize(start, end);
  };

  const onSelectTableHandler = tableId => {
    actSelectTable(tableId);
  };

  return (
    <View style={styles.container}>
      {dataRsv.map((tbItem, index) => {
        return (
          <View key={index} style={styles.item}>
            <PeriodMarking
              tableId={tbItem.table_no}
              isDragResizing={isDragResizing}
              editingRsv={editingRsv}
              rsvList={tbItem.rsv_list}
              startPosition={editingStartPosition}
              endPosition={editingEndPosition}
              timeRange={{ Start: 0, End: 120 * RSV_CONFIG.DEFAULT_TIME_WIDTH }}
              onPositionResizeUpdate={onPositionResizeUpdateHandler}
              onSelectTable={onSelectTableHandler}
            ></PeriodMarking>
          </View>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 10000,
  },

  item: {
    width: '100%',
    height: RSV_CONFIG.DEFAULT_HEIGHT,
  },
});

const mapStateToProps = state => {
  const {
    reservation: { editingStartPosition, editingEndPosition, isDragResizing },
  } = state;
  return {
    editingStartPosition,
    editingEndPosition,
    isDragResizing,
  };
};

const mapDispatchToProps = {
  actUpdatePositionSize,
  actSelectTable,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Editable);
