import React from 'react';
import { connect } from 'react-redux';
import styled from 'styled-components';
import { StyleSheet, Animated, PanResponder, TouchableOpacity, View, Text } from 'react-native';
// configs
import { RSV_CONFIG } from '../../../config';

//actions
import { actSelectedMarker, actPanMoving } from '../redux/actions';

const PeriodMarker = ({
  selectedTables,
  tableId,
  isValid,
  startPosition,
  endPosition,
  timeRange,
  onPositionResizeUpdate,
  onSelectTable,
}) => {
  let canMove = true;
  let moving = false;
  let resizing = false;

  const markerWidth = endPosition - startPosition;

  // Create Movement Pan
  const maxPosition = timeRange.End - markerWidth;
  let panX = new Animated.Value(startPosition);
  let constrainedX = panX.interpolate({
    inputRange: [0, maxPosition],
    outputRange: [0, maxPosition],
    extrapolate: 'clamp',
  });

  // Create Resize Pan
  const minWidth = timeRange.Start;
  const maxWidth = timeRange.End;
  let panWidth = new Animated.Value(markerWidth);
  let constrainedWidth = panWidth.interpolate({
    inputRange: [RSV_CONFIG.DEFAULT_TIME_WIDTH, maxWidth],
    outputRange: [RSV_CONFIG.DEFAULT_TIME_WIDTH, maxWidth],
    extrapolate: 'clamp',
  });

  let startTouched = false;
  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onStartShouldSetPanResponderCapture: () => true,
    onPanResponderGrant: e => {
      canMove = e.nativeEvent.locationX < panWidth._value - 20;
      if (canMove) {
        panX.setOffset(panX._value);
      } else {
        if (panWidth._value <= 0) {
          panWidth.setOffset(0);
        } else {
          panWidth.setOffset(panWidth._value);
        }
      }
      startTouched = true;
    },
    onPanResponderMove: (e, gestureState) => {
      if (gestureState.dx != 0) {
        startTouched = false;
      }
      if (canMove) {
        moving = true;
        panX.setValue(gestureState.dx);
      } else {
        resizing = true;
        panWidth.setValue(gestureState.dx);
      }
    },
    onPanResponderRelease: () => {
      if (startTouched) {
        onSelectTable(tableId);
      }
      if (moving) {
        panX.flattenOffset();
        moving = false;

        const newStartPositionIndex = Math.round(panX._value / RSV_CONFIG.DEFAULT_TIME_WIDTH);
        const newStartPosition = newStartPositionIndex * RSV_CONFIG.DEFAULT_TIME_WIDTH;
        Animated.spring(panX, {
          toValue: newStartPosition,
        }).start();

        const currentRange = (endPosition - startPosition) / RSV_CONFIG.DEFAULT_TIME_WIDTH;
        const newEndPositionIndex = newStartPositionIndex + currentRange;
        onPositionResizeUpdate(newStartPositionIndex, newEndPositionIndex);
      }
      if (resizing) {
        panWidth.flattenOffset();
        resizing = false;
        const newStartPositionIndex = startPosition / RSV_CONFIG.DEFAULT_TIME_WIDTH;
        let newEndPositionIndex =
          Math.round(panWidth._value / RSV_CONFIG.DEFAULT_TIME_WIDTH) + newStartPositionIndex;
        if (newEndPositionIndex === newStartPositionIndex) {
          newEndPositionIndex = newStartPositionIndex + 1;
        }
        const newEndPosition =
          (newEndPositionIndex - newStartPositionIndex) * RSV_CONFIG.DEFAULT_TIME_WIDTH;
        Animated.spring(panWidth, {
          toValue: newEndPosition,
        }).start();
        onPositionResizeUpdate(newStartPositionIndex, newEndPositionIndex);
      }
    },
  });

  let style = isValid
    ? {
        ...styles.periodMarking,
        width: constrainedWidth,
      }
    : {
        ...styles.periodMarkingInvalid,
        width: constrainedWidth,
      };
  const coordsStyle = {
    top: 0,
    left: constrainedX,
  };

  if (isValid && selectedTables.includes(tableId)) {
    style = {
      ...styles.periodMarkingEditing,
      width: constrainedWidth,
    };
  }

  return (
    <Animated.View style={StyleSheet.flatten([style, coordsStyle])} {...panResponder.panHandlers}>
      <ContentStyled>
        <ResizeStyled>
          <Text>Icon</Text>
        </ResizeStyled>
      </ContentStyled>
    </Animated.View>
  );
};

const mapStateToProps = state => {
  const {
    reservation: { editingStartPosition, editingEndPosition, isDragResizing, selectedTables },
  } = state;
  return {
    editingStartPosition,
    editingEndPosition,
    isDragResizing,
    selectedTables,
  };
};

const mapDispatchToProps = {
  actSelectedMarker,
  actPanMoving,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PeriodMarker);

const styles = StyleSheet.create({
  periodMarking: {
    height: '100%',
    backgroundColor: 'rgba(0, 153, 213, 0.6)',
  },
  periodMarkingEditing: {
    height: '100%',
    backgroundColor: 'rgba(0, 153, 213, 1)',
  },
  periodMarkingInvalid: {
    height: '100%',
    backgroundColor: 'rgba(255, 0, 0, 0.6)',
  },
});

const ContentStyled = styled(View)`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;

const ResizeStyled = styled(View)`
  position: relative;
  margin-top: 10px;
  right: -15px;
  z-index: -2;
  width: 30px;
  height: 30px;
  border-radius: 15px;
  background-color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  border-width: 2px;
  border-style: solid;
  border-color: #9b9b9b;
`;
