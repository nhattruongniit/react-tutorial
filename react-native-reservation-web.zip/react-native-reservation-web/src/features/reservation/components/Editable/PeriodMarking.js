import React from 'react';

import PeriodMarker from '../components/PeriodMarker';
// Data
import { dataTimes } from '../mocks/dataTimes';

// configs
import { RSV_CONFIG } from '../../../config';

const getIndexByTime = time => dataTimes.findIndex(val => val.time_hhmm === time);

const PeriodMarking = ({
  tableId,
  isDragResizing,
  editingRsv,
  rsvList,
  startPosition,
  endPosition,
  timeRange,
  onPositionResizeUpdate,
  onSelectTable,
}) => {
  let isValid = true;
  if (!isDragResizing && editingRsv != null) {
    startPosition = getIndexByTime(editingRsv.start_time);
    endPosition = getIndexByTime(editingRsv.end_time);
  }
  rsvList.map(rsvItem => {
    if (editingRsv == null || rsvItem.id != editingRsv.id) {
      const rsvStartIndex = getIndexByTime(rsvItem.start_time);
      const rsvEndIndex = getIndexByTime(rsvItem.end_time);
      if (
        (endPosition < rsvEndIndex && endPosition > rsvStartIndex) ||
        (startPosition > rsvStartIndex && startPosition < rsvEndIndex) ||
        (startPosition <= rsvStartIndex && endPosition >= rsvEndIndex)
      ) {
        isValid = false;
      }
    }

    if (!isDragResizing && editingRsv != null && editingRsv.id == rsvItem.id) {
      onSelectTable(tableId);
    }
  });

  return (
    <PeriodMarker
      tableId={tableId}
      isValid={isValid}
      editingRsv={editingRsv}
      startPosition={startPosition * RSV_CONFIG.DEFAULT_TIME_WIDTH}
      endPosition={endPosition * RSV_CONFIG.DEFAULT_TIME_WIDTH}
      timeRange={timeRange}
      onPositionResizeUpdate={onPositionResizeUpdate}
      onSelectTable={onSelectTable}
    ></PeriodMarker>
  );
};

export default PeriodMarking;
