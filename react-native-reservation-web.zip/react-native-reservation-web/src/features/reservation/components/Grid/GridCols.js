import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';
// configs
import { RSV_CONFIG } from '../../../../config';

const GridCols = index => {
  return <View style={styles.ColStyle} key={index} />;
};

GridCols.propTypes = {
  index: PropTypes.number.isRequired,
};

const styles = StyleSheet.create({
  ColStyle: {
    flex: 1,
    flexDirection: 'row',
    height: '100%',
    width: RSV_CONFIG.DEFAULT_TIME_WIDTH,
    borderRightWidth: 1,
    borderRightColor: '#b2b2b2',
    borderStyle: 'solid',
    justifyContent: 'space-between',
  },
});

export default GridCols;
