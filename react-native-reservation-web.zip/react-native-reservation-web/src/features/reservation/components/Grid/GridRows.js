import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';

// components
import DrawRsv from '../DrawRsv';

// configs
import { RSV_CONFIG } from '../../../../config';

const GridRows = ({ tableIndex, rsvList }) => {
  const renderView = () => {
    return <View key={tableIndex} style={styles.RowStyle} />;
  };

  const renderRsvView = () => {
    return (
      <View key={tableIndex} style={styles.RowStyle}>
        {rsvList.map(rsv => {
          return <DrawRsv rsv={rsv} tableIndex={tableIndex} index={rsv.id} key={rsv.id} />;
        })}
      </View>
    );
  };

  return rsvList.length > 0 ? renderRsvView() : renderView();
};

GridRows.propTypes = {
  tableIndex: PropTypes.number.isRequired,
  rsvList: PropTypes.array,
};

const styles = StyleSheet.create({
  RowStyle: {
    width: '100%',
    borderBottomColor: '#b2b2b2',
    borderBottomWidth: 1,
    height: RSV_CONFIG.DEFAULT_HEIGHT,
  },
});

export default GridRows;
