import styled from 'styled-components';
import { View } from 'react-native';

// configs
import { RSV_CONFIG } from '../../../../config';

export const ColStyled = styled(View)`
  flex: 1;
  flex-direction: row;
  height: 100%;
  width: ${RSV_CONFIG.DEFAULT_TIME_WIDTH}px;
  border-right-width: 1px;
  border-right-color: #b2b2b2;
  border-style: solid;
  justify-content: space-between;
`;

export const RowStyled = styled(View)`
  width: 100%;
  height: ${RSV_CONFIG.DEFAULT_HEIGHT};
  border-bottom-width: 1;
  border-bottom-color: #b2b2b2;
`;
