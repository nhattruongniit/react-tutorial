import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet } from 'react-native';

// components
import DateTimePicker from '../../../../components/common/DateTimePicker';

// actions
import { actChangeDate } from '../../redux/actions';

const HeaderCenter = ({ actChangeDate }) => {
  const _onChangeDate = value => {
    const newDate = value.toString().substr(4, 12);
    actChangeDate(newDate);
  };

  return (
    <View style={styles.CenterStyle}>
      <Text style={styles.IconStyle} name="today" size={20} />
      <DateTimePicker onChangeDate={_onChangeDate} />
    </View>
  );
};

const styles = StyleSheet.create({
  CenterStyle: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  IconStyle: {
    paddingRight: 5,
    color: '#fff',
  },
});

HeaderCenter.propTypes = {
  actChangeDate: PropTypes.func.isRequired,
};

const mapDispatchToProps = {
  actChangeDate,
};

export default connect(
  null,
  mapDispatchToProps
)(HeaderCenter);
