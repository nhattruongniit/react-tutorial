import React from 'react';
import { connect } from 'react-redux';
import { View, Text, Image } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components';

// libs
import DatePicker from 'react-datepicker';

// configs
import { DATE_FORMAT } from '../../../../config';

// actions
import { actChangeDate } from '../../redux/actions';

// image
import iconCalendar from '../../../../assets/images/icon-calendar.png';

const HeaderCenterWeb = ({ actChangeDate, date }) => {
  const _onChangeDate = value => {
    actChangeDate(value);
  };

  const selectedDate = date ? date : new Date();

  return (
    <CenterStyled>
      <Image style={{ width: 20, height: 20 }} source={iconCalendar} />
      <DateStyled>
        <DatePicker
          dateFormat={DATE_FORMAT.DEFAULT_DATE_PICKER}
          selected={selectedDate}
          onChange={_onChangeDate}
        />
      </DateStyled>
    </CenterStyled>
  );
};

HeaderCenterWeb.propTypes = {
  actChangeDate: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
  const {
    reservation: { date },
  } = state;
  return { date };
};

const mapDispatchToProps = {
  actChangeDate,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HeaderCenterWeb);

const CenterStyled = styled(View)`
  align-items: center;
  flex-direction: row;
  border-bottom-width: 1px;
  border-color: #fff;
  border-style: solid;
  padding: 0px 10px 5px 10px;
`;

const DateStyled = styled(View)`
  cursor: pointer;
  margin-left: 10px;
  input {
    cursor: pointer;
    border: 0;
    background-color: transparent;
    color: #fff;
    text-align: center;
  }
`;
