import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const HeaderLeft = () => {
  return (
    <View style={styles.ContainerStyle}>
      <Text style={styles.TextWhiteStyle}>1st store</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  ContainerStyle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  TextWhiteStyle: {
    color: '#fff',
    fontFamily: 'Roboto',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default HeaderLeft;
