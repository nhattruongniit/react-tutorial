import React from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { View, Text, Button, StyleSheet } from 'react-native';

// components
import ButtonComponent from '../../../../components/common/ButtonText';

// actions
import { actChangeEditing } from '../../redux/actions';

const HeaderRight = ({ actChangeEditing, isEditMode }) => {
  const _handleAdd = () => {
    actChangeEditing(!isEditMode, null);
  };

  return (
    <RightStyled>
      {/* <Button styles={styles.ButtonStyle} transparent light vertical={true} onPress={_handleTime}>
        <Text style={styles.IconStyle} name="query-builder" size={22} />
        <Text style={styles.TextWhiteStyled}>時間選択</Text>
      </Button>
      <Button style={styles.ButtonStyle} transparent light vertical={true} onPress={_handleCheck}>
        <Text style={styles.IconStyle} name="description" size={22} />
        <Text style={styles.TextWhiteStyled}>集計</Text>
      </Button> */}
      <ButtonComponent text={isEditMode ? '閉じる' : '追加'} handleClick={_handleAdd} />
    </RightStyled>
  );
};

const styles = StyleSheet.create({
  ButtonStyle: {
    fontSize: 12,
    marginLeft: 10,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0,
    flexDirection: 'column',
  },
  TextWhiteStyle: {
    color: '#fff',
    fontFamily: 'Roboto',
    fontSize: 14,
    fontWeight: 'bold',
  },
  IconStyle: {
    paddingRight: 5,
    color: '#fff',
    fontSize: 22,
  },
});

HeaderRight.propTypes = {
  isEditMode: PropTypes.bool.isRequired,
  actChangeEditing: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
  const {
    reservation: { isEditMode },
  } = state;
  return {
    isEditMode,
  };
};

const mapDispatchToProps = { actChangeEditing };

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HeaderRight);

const RightStyled = styled(View)`
  flex-direction: row;
  align-items: center;
`;

// const ButtonStyled = styled(Button)`
//   font-size: 12px;
//   margin-left: 10px;
//   padding-left: 5px;
//   padding-right: 5px;
//   flex-direction: row;
//   border-width: 0;
//   flex-direction: column;
// `;
