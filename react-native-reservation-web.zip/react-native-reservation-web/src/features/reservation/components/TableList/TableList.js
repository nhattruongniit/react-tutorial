import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
// Config
import { RSV_CONFIG } from '../../../../config';

const TableList = ({ index, tableName, seatable }) => {
  return (
    <View style={styles.RowsStyle} key={index}>
      <View>
        <Text style={styles.fontSize}>{tableName}</Text>
      </View>
      <View style={styles.SeatStyle}>
        <Text style={[styles.NumberStyle, styles.TextFontSize]}>{seatable}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  RowsStyle: {
    paddingLeft: 10,
    paddingRight: 10,
    height: RSV_CONFIG.DEFAULT_HEIGHT,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderRightColor: '#9b9b9b',
    borderBottomColor: '#9b9b9b',
    borderStyle: 'solid',
  },
  SeatStyle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  NumberStyle: {
    color: '#9b9b9b',
    paddingLeft: 5,
  },
  TextFontSize: {
    fontSize: 18,
  },
});

TableList.propTypes = {
  index: PropTypes.number.isRequired,
  tableName: PropTypes.string.isRequired,
  seatable: PropTypes.number.isRequired,
};

export default TableList;
