import styled from 'styled-components';
import { View, Text } from 'react-native';

import { RSV_CONFIG } from '../../../../config';

export const RowsStyled = styled(View)`
  padding-left: 10px;
  padding-right: 10px;
  font-size: 18px;
  height: ${RSV_CONFIG.DEFAULT_HEIGHT}px;
  flex: 1;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  border-right-width: 1px;
  border-bottom-width: 1px;
  border-right-color: #9b9b9b;
  border-bottom-color: #9b9b9b;
  border-style: solid;
`;

export const SeatStyled = styled(View)`
  flex-direction: row;
  align-items: center;
`;

export const NumberStyled = styled(Text)`
  color: #9b9b9b;
  padding-left: 5px;
`;
