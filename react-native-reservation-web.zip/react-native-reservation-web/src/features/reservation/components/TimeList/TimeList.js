import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet } from 'react-native';

// configs
import { RSV_CONFIG } from '../../../../config';

const TimeList = ({ index, name }) => {
  return (
    <View style={styles.ViewStyle} key={index}>
      <Text style={styles.TimeStyle}>{name}</Text>
    </View>
  );
};

TimeList.propTypes = {
  index: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
};

const styles = StyleSheet.create({
  ViewStyle: {
    flex: 1,
    borderStyle: 'solid',
    borderRightColor: '#fff',
    borderRightWidth: 1,
    width: RSV_CONFIG.DEFAULT_TIME_WIDTH * RSV_CONFIG.DEFAULT_UNIT_COLUMN,
  },
  TimeStyle: {
    flex: 1,
    fontWeight: 'bold',
    fontSize: 16,
    color: '#fff',
    width: RSV_CONFIG.DEFAULT_TIME_WIDTH * RSV_CONFIG.DEFAULT_UNIT_COLUMN,
    alignItems: 'stretch',
    textAlign: 'center',
    lineHeight: RSV_CONFIG.DEFAULT_HEIGHT,
  },
});

export default TimeList;
