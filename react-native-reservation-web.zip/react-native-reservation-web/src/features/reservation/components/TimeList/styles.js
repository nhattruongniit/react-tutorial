import { View, Text } from 'react-native';
import styled from 'styled-components';

// configs
import { RSV_CONFIG } from '../../../../config';

export const ViewStyled = styled(View)`
  flex: 1;
  border-style: solid;
  border-right-color: #fff;
  border-right-width: 1px;
  width: ${RSV_CONFIG.DEFAULT_TIME_WIDTH * RSV_CONFIG.DEFAULT_UNIT_COLUMN}px;
`;

export const TimeStyled = styled(Text)`
  flex: 1;
  font-weight: bold;
  font-size: 16px;
  color: #fff;
  width: ${RSV_CONFIG.DEFAULT_TIME_WIDTH * RSV_CONFIG.DEFAULT_UNIT_COLUMN}px;
  align-items: stretch;
  text-align: center;
  line-height: ${RSV_CONFIG.DEFAULT_HEIGHT}px;
`;
