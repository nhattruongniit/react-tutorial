import React from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { StyleSheet, Animated, PanResponder, View, Text, Image } from 'react-native';

// images
import iconResize from '../../../../assets/images/icon-resize.png';
// data
import { dataTimes } from '../../mocks/dataTimes';
// configs
import { RSV_CONFIG } from '../../../../config';
//actions
import {
  actSelectedMarker,
  actPanMoving,
  actUpdatePositionSize,
  actSelectTable,
  actSetEnabledScroll,
} from '../../redux/actions';
// utils
import isWeb from '../../../../utils/isWeb';

const getIndexByTime = time => dataTimes.findIndex(val => val.time_hhmm === time);

const TimeTableItem = ({
  isFirstLoadEditMode,
  currentTable,
  currentEditedRsv,
  selectedTables,
  editingStartPosition,
  editingEndPosition,
  timeRange,
  actUpdatePositionSize,
  actSelectTable,
  actSetEnabledScroll,
}) => {
  const rsvCount = currentTable.rsv_list.length;
  let isValidated = true;
  // Get current rsv position
  if (isFirstLoadEditMode && currentEditedRsv != null) {
    editingStartPosition = getIndexByTime(currentEditedRsv.start_time);
    editingEndPosition = getIndexByTime(currentEditedRsv.end_time);
  }
  // Checking status
  for (let i = 0; i < rsvCount; i++) {
    const rsvItem = currentTable.rsv_list[i];
    if (currentEditedRsv != null && currentEditedRsv.id == rsvItem.id) {
      if (isFirstLoadEditMode && !selectedTables.includes(currentTable.table_no)) {
        actSelectTable(currentTable.table_no);
      }
      continue;
    }
    const rsvStartIndex = getIndexByTime(rsvItem.start_time);
    const rsvEndIndex = getIndexByTime(rsvItem.end_time);
    if (
      (editingEndPosition < rsvEndIndex && editingEndPosition > rsvStartIndex) ||
      (editingStartPosition > rsvStartIndex && editingStartPosition < rsvEndIndex) ||
      (editingStartPosition <= rsvStartIndex && editingEndPosition >= rsvEndIndex)
    ) {
      isValidated = false;
      break;
    }
  }

  let canMove = true;
  let moving = false;
  let resizing = false;
  const markerWidth = (editingEndPosition - editingStartPosition) * RSV_CONFIG.DEFAULT_TIME_WIDTH;
  // Create Movement Pan
  const maxPosition = timeRange.endPosition * RSV_CONFIG.DEFAULT_TIME_WIDTH - markerWidth;
  let panX = new Animated.Value(editingStartPosition * RSV_CONFIG.DEFAULT_TIME_WIDTH);
  let constrainedX = panX.interpolate({
    inputRange: [0, maxPosition],
    outputRange: [0, maxPosition],
    extrapolate: 'clamp',
  });

  // Create Resize Pan
  const maxWidth = timeRange.endPosition * RSV_CONFIG.DEFAULT_TIME_WIDTH;
  let panWidth = new Animated.Value(markerWidth);
  let constrainedWidth = panWidth.interpolate({
    inputRange: [RSV_CONFIG.DEFAULT_TIME_WIDTH, maxWidth],
    outputRange: [RSV_CONFIG.DEFAULT_TIME_WIDTH, maxWidth],
    extrapolate: 'clamp',
  });

  let startTouched = false;
  const panResponder = PanResponder.create({
    onPanResponderTerminationRequest: () => false,
    onStartShouldSetPanResponderCapture: () => true,
    onPanResponderGrant: e => {
      actSetEnabledScroll(false);
      canMove = e.nativeEvent.locationX < panWidth._value - 50 && e.nativeEvent.locationX > 30;
      if (canMove) {
        panX.setOffset(panX._value);
      } else {
        if (panWidth._value <= 0) {
          panWidth.setOffset(0);
        } else {
          panWidth.setOffset(panWidth._value);
        }
      }
      startTouched = true;
    },
    onPanResponderMove: (e, gestureState) => {
      if (gestureState.dx != 0) {
        startTouched = false;
      }
      if (canMove) {
        moving = true;
        panX.setValue(gestureState.dx);
      } else {
        resizing = true;
        panWidth.setValue(gestureState.dx);
      }
    },
    onPanResponderRelease: () => {
      actSetEnabledScroll(true);
      if (startTouched) {
        actSelectTable(currentTable.table_no);
      }
      if (moving) {
        panX.flattenOffset();
        moving = false;

        const newStartPositionIndex = Math.round(panX._value / RSV_CONFIG.DEFAULT_TIME_WIDTH);
        const newStartPosition = newStartPositionIndex * RSV_CONFIG.DEFAULT_TIME_WIDTH;
        Animated.spring(panX, {
          toValue: newStartPosition,
        }).start();

        const currentRange = editingEndPosition - editingStartPosition;
        const newEndPositionIndex = newStartPositionIndex + currentRange;
        actUpdatePositionSize(newStartPositionIndex, newEndPositionIndex);
      }
      if (resizing) {
        panWidth.flattenOffset();
        resizing = false;
        const newStartPositionIndex = editingStartPosition;
        let newEndPositionIndex =
          Math.round(panWidth._value / RSV_CONFIG.DEFAULT_TIME_WIDTH) + newStartPositionIndex;

        if (newEndPositionIndex === newStartPositionIndex) {
          newEndPositionIndex = newStartPositionIndex + 1;
        }
        const newEndPosition =
          (newEndPositionIndex - newStartPositionIndex) * RSV_CONFIG.DEFAULT_TIME_WIDTH;
        Animated.spring(panWidth, {
          toValue: newEndPosition,
        }).start();
        actUpdatePositionSize(newStartPositionIndex, newEndPositionIndex);
      }
    },
  });

  const renderViewForWeb = () => {
    let style = StyleSheet.create({
      periodMarking: {
        height: '100%',
        backgroundColor: 'rgba(0, 153, 213, 0.6)',
        width: constrainedWidth,
      },
      periodMarkingEditing: {
        height: '100%',
        backgroundColor: 'rgba(0, 153, 213, 1)',
        width: constrainedWidth,
      },
      periodMarkingInvalid: {
        height: '100%',
        backgroundColor: 'rgba(255, 0, 0, 0.6)',
        width: constrainedWidth,
      },
      coordsStyle: {
        top: 0,
        left: constrainedX,
      },
    });

    let animatedStyle = isValidated ? style.periodMarking : style.periodMarkingInvalid;

    if (isValidated && selectedTables.includes(currentTable.table_no)) {
      animatedStyle = style.periodMarkingEditing;
    }

    return (
      <Animated.View
        style={StyleSheet.flatten([animatedStyle, style.coordsStyle])}
        {...panResponder.panHandlers}
      >
        <ContentStyled>
          <ResizeStyled>
            <Image style={{ width: 20, height: 20 }} source={iconResize} />
          </ResizeStyled>
        </ContentStyled>
      </Animated.View>
    );
  };

  const renderViewForNative = () => {
    let style = isValidated
      ? {
          ...styles.periodMarkingNative,
          width: constrainedWidth,
        }
      : {
          ...styles.periodMarkingInvalidNative,
          width: constrainedWidth,
        };
    const coordsStyle = {
      top: 0,
      left: constrainedX,
    };

    if (isValidated && selectedTables.includes(currentTable.table_no)) {
      style = {
        ...styles.periodMarkingEditingNative,
        width: constrainedWidth,
      };
    }
    return (
      <Animated.View style={StyleSheet.flatten([style, coordsStyle])} {...panResponder.panHandlers}>
        <ContentStyled>
          <ResizeStyled>
            <Image style={{ width: 20, height: 20 }} source={iconResize} />
          </ResizeStyled>
        </ContentStyled>
      </Animated.View>
    );
  };

  return isWeb ? renderViewForWeb() : renderViewForNative();
};

const styles = StyleSheet.create({
  periodMarkingNative: {
    height: '100%',
    backgroundColor: 'rgba(0, 153, 213, 0.6)',
  },
  periodMarkingEditingNative: {
    height: '100%',
    backgroundColor: 'rgba(0, 153, 213, 1)',
  },
  periodMarkingInvalidNative: {
    height: '100%',
    backgroundColor: 'rgba(255, 0, 0, 0.6)',
  },
});

const mapStateToProps = state => {
  const {
    reservation: {
      isFirstLoadEditMode,
      isDragResizing,
      selectedTables,
      editingStartPosition,
      editingEndPosition,
      currentEditedRsv,
    },
  } = state;
  return {
    isFirstLoadEditMode,
    isDragResizing,
    selectedTables,
    editingStartPosition,
    editingEndPosition,
    currentEditedRsv,
  };
};

const mapDispatchToProps = {
  actSelectedMarker,
  actPanMoving,
  actUpdatePositionSize,
  actSelectTable,
  actSetEnabledScroll,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TimeTableItem);

const ResizeStyled = styled(View)`
  position: relative;
  margin-top: 10px;
  right: -15px;
  z-index: -2;
  width: 30px;
  height: 30px;
  border-radius: 15px;
  background-color: #fff;
  border-width: 2px;
  border-style: solid;
  border-color: #9b9b9b;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ContentStyled = styled(View)`
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  position: relative;
  z-index: -3;
`;
