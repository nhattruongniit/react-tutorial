import React, { memo } from 'react';
import { View, StyleSheet } from 'react-native';

// Data
import { dataTimes } from '../../mocks/dataTimes';
// configs
import { RSV_CONFIG } from '../../../../config';
// components
import TimeTableItem from './TimeTableItem';

const TimeTableMarking = memo(({ isEditMode, dataTableRsv }) => {
  return (
    <>
      {isEditMode && (
        <View style={styles.containerEditMode}>
          {dataTableRsv.map((tableItem, idx) => {
            return (
              <View key={idx} style={styles.table}>
                <TimeTableItem
                  currentTable={tableItem}
                  timeRange={{
                    startPosition: 0,
                    endPosition: dataTimes.length + (RSV_CONFIG.DEFAULT_UNIT_COLUMN - 1),
                  }}
                />
              </View>
            );
          })}
        </View>
      )}
    </>
  );
});

const styles = StyleSheet.create({
  containerEditMode: {
    flexDirection: 'column',
    position: 'absolute',
    zIndex: 100,
    width: '100%',
    height: '100%',
  },
  table: {
    width: '100%',
    height: RSV_CONFIG.DEFAULT_HEIGHT,
  },
});

export default TimeTableMarking;
