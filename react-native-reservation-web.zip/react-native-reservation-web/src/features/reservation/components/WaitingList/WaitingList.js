import React, { memo } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { View, Text, TouchableOpacity, Image } from 'react-native';

// configs
import { RSV_CONFIG } from '../../../../config';

// image
import iconPerson from '../../../../assets/images/icon-person.png';

const WaitingList = memo(({ persons, kana, startTime, endTime }) => {
  return (
    <FlatStyled>
      <UnitStyled height={RSV_CONFIG.DEFAULT_HEIGHT}>
        <TouchStyled>
          <ContentStyled>
            <NumberStyled>
              {startTime} - {endTime}
            </NumberStyled>
            <SeatStyled>
              <Image style={{ width: 20, height: 20 }} source={iconPerson} />
              <NumberStyled>{persons}</NumberStyled>
            </SeatStyled>
          </ContentStyled>
          <RsvNameStyled>{kana}</RsvNameStyled>
        </TouchStyled>
      </UnitStyled>
    </FlatStyled>
  );
});

WaitingList.propTypes = {
  persons: PropTypes.number.isRequired,
  kana: PropTypes.string.isRequired,
  startTime: PropTypes.string.isRequired,
  endTime: PropTypes.string.isRequired,
};

export default WaitingList;

const FlatStyled = styled(View)`
  flex: 1;
  flex-direction: row;
  margin-left: 20px;
  align-items: center;
`;

const UnitStyled = styled(View)`
  padding-top: 5px;
  padding-right: 5px;
  padding-bottom: 5px;
  padding-left: 3px;
  border-style: solid;
  width: 200px;
  height: ${props => props.height}px;
  margin-right: 10px;
  border-left-color: rgb(170, 109, 8);
  border-left-width: 5px;
  background-color: rgb(245, 166, 35);
`;

const TouchStyled = styled(TouchableOpacity)`
  flex: 1;
`;
const ContentStyled = styled(View)`
  flex: 1;
  flex-direction: row;
  justify-content: space-between;
`;

const SeatStyled = styled(View)`
  margin-right: 5px
  flex-direction: row;
`;

const NumberStyled = styled(Text)`
  color: #fff;
  padding-left: 5px;
`;

const RsvNameStyled = styled(Text)`
  color: #fff;
  font-size: 14px;
  align-self: flex-end;
`;
