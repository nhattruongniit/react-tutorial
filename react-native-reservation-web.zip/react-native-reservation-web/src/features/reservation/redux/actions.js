import {
  SET_DATE,
  CHANGE_EDIT,
  POSITION_RESIZE_UPDATE,
  RESET_DIALOG,
  FETCH_RSV,
  SHOW_MODAL_DETAIL,
  SELECTED_TABLE,
  SET_ENABLED_SCROLL,
} from './reducers';

// other actions
import { actOpenDialogNotify } from '../../dialog/redux/actions';

// api
import * as api from '../api';

// configs
import { DATE_FORMAT } from '../../../config';

//utils
import appGetDate from '../../../utils/getDate';

export const actChangeDate = date => ({ type: SET_DATE, payload: { date } });

export const actChangeEditing = (isEditMode, currentEditedRsv) => ({
  type: CHANGE_EDIT,
  payload: { isEditMode, currentEditedRsv },
});

export const actUpdatePositionSize = (editingStartPosition, editingEndPosition) => ({
  type: POSITION_RESIZE_UPDATE,
  payload: { editingStartPosition, editingEndPosition },
});

export const actResetDialog = () => ({ type: RESET_DIALOG });

export const actShowModalDetail = (isShow, reservationDetail) => ({
  type: SHOW_MODAL_DETAIL,
  payload: {
    isShow,
    reservationDetail,
  },
});

export const actSelectTable = selectedTable => ({
  type: SELECTED_TABLE,
  payload: { selectedTable },
});

export const actSetEnabledScroll = isEnabledScroll => ({
  type: SET_ENABLED_SCROLL,
  payload: { isEnabledScroll },
});

// fetch RSV
export const actFetchRsv = data => ({
  type: FETCH_RSV,
  payload: { data },
});

export const fetchRsv = date => async dispatch => {
  const formatDate = date
    ? appGetDate.format(new Date(date), DATE_FORMAT.DEFAULT_DATE_FORMAT)
    : appGetDate.currentDate();

  try {
    const res = await api.fetchRsv(formatDate);
    const data = res.data.data;
    dispatch(actFetchRsv(data));
  } catch (err) {
    dispatch(actOpenDialogNotify('Error', `fetch api error ${err}`));
  }
};
