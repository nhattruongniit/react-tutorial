export const SET_DATE = 'RSV/SET_DATE';
export const CHANGE_EDIT = 'RSV/CHANGE_EDIT';
export const POSITION_RESIZE_UPDATE = 'RSV/POSITION_RESIZE_UPDATE';
export const RESET_DIALOG_DETAIL = 'RSV/RESET_DIALOG_DETAIL';
export const FETCH_RSV = 'RSV/FETCH_RSV';
export const SELECTED_TABLE = 'RSV/SELECTED_TABLE';
export const SET_ENABLED_SCROLL = 'RSV/SET_ENABLED_SCROLL';
export const SHOW_MODAL_DETAIL = 'RSV/SHOW_MODAL_DETAIL';

const initialState = {
  date: '',
  isEditMode: true,
  isEnabledScroll: true,
  isFirstLoadEditMode: true,
  selectedTables: [],
  currentEditedRsv: null,
  editingStartPosition: 0,
  editingEndPosition: 8,
  isShow: false,
  listTable: [],
  listTime: [],
  showModalDetail: false,
  dataWaitingList: [],
  reservationDetail: {},
};

const reducers = (state = initialState, { type, payload }) => {
  switch (type) {
    case SET_DATE: {
      return {
        ...state,
        date: payload.date,
      };
    }
    case CHANGE_EDIT: {
      return {
        ...state,
        isEditMode: payload.isEditMode,
        currentEditedRsv: payload.currentEditedRsv,
        isFirstLoadEditMode: true,
        selectedTables: [],
        editingStartPosition: 0,
        editingEndPosition: 8,
      };
    }
    case POSITION_RESIZE_UPDATE: {
      return {
        ...state,
        editingStartPosition: payload.editingStartPosition,
        editingEndPosition: payload.editingEndPosition,
        isFirstLoadEditMode: false,
      };
    }
    case FETCH_RSV: {
      return {
        ...state,
        isEditMode: false,
        listTable: payload.data.table_list,
        listTime: payload.data.time_list,
        dataWaitingList: payload.data.rsv_waiting_list,
      };
    }
    case SHOW_MODAL_DETAIL: {
      return {
        ...state,
        isShow: payload.isShow,
        reservationDetail: payload.reservationDetail,
      };
    }
    case RESET_DIALOG_DETAIL: {
      return {
        ...state,
        isShow: false,
        reservationDetail: {},
      };
    }
    case SELECTED_TABLE: {
      const { selectedTables } = state;
      if (selectedTables.length > 0 && selectedTables.includes(payload.selectedTable)) {
        const filteredTables = selectedTables.filter(value => {
          return value != payload.selectedTable;
        });

        return {
          ...state,
          selectedTables: filteredTables,
        };
      } else {
        const newSelectedTables = [...selectedTables];
        newSelectedTables.push(payload.selectedTable);

        return {
          ...state,
          selectedTables: newSelectedTables,
        };
      }
    }
    case SET_ENABLED_SCROLL: {
      return {
        ...state,
        isEnabledScroll: payload.isEnabledScroll,
      };
    }
    default:
      return state;
  }
};

export default reducers;
