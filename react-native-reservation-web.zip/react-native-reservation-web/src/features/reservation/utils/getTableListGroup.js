import _ from 'lodash';
const getTableListGroup = listTable => {
  const ONE = 1;

  const infoObject = (table_index, table, rsv) => {
    return {
      table_index: table_index,
      table_no: table.table_no,
      table_name: table.table_name,
      start_time: rsv.start_time,
      end_time: rsv.end_time,
      rsv_id: rsv.id,
    };
  };

  const rsvInTables = data => {
    let list = [];
    _.filter(data, (table, index) => {
      if (table.rsv_list.length > 0) {
        _.filter(table.rsv_list, rsv => {
          let info = infoObject(index, table, rsv);
          list.push(info);
        });
      }
    });
    return _.groupBy(list, 'rsv_id');
  };

  const rsvGroups = data => {
    const groups = {};
    _.forIn(data, (_, rsvID) => {
      let groupTmp = {},
        lastObject = {},
        indexGroup = ONE,
        isFirst = true;
      groupTmp[indexGroup] = [];
      data[rsvID].filter((table, _) => {
        if (lastObject.table_index === undefined) {
          lastObject = table;
          return;
        }
        if (table.table_index - lastObject.table_index === ONE) {
          if (isFirst) groupTmp[indexGroup].push(lastObject);
          groupTmp[indexGroup].push(table);
          isFirst = false;
        } else {
          indexGroup++;
          groupTmp[indexGroup] = [];
          isFirst = true;
        }
        lastObject = table;
      });
      groups[rsvID] = groupTmp;
    });
    return groups;
  };

  const filterAddGroupingList = (groups, rsv, table) => {
    _.forIn(groups[rsv.id], (object, key) => {
      let dataInGroup = groups[rsv.id][key];
      let firstGroupTable = true;
      _.filter(object, o => {
        if (o.table_no === table.table_no) {
          rsv.table_group = true;
          if (firstGroupTable) rsv.table_group_list = dataInGroup;
        }
        firstGroupTable = false;
      });
    });
    return rsv;
  };

  const addTableGroupingInRsv = (rsvList, groups, table) => {
    _.map(rsvList, rsv => {
      rsv.table_group = false;
      rsv.table_group_list = null;
      if (_.keys(groups[rsv.id]).length > 0) {
        rsv = filterAddGroupingList(groups, rsv, table);
      }
    });
    return rsvList;
  };

  const addNewData = (data, groups) => {
    _.map(data, table => {
      let rsvList = table.rsv_list;
      if (rsvList.length > 0) {
        table.rsv_list = addTableGroupingInRsv(rsvList, groups, table);
      }
    });
    return data;
  };

  const listRsv = rsvInTables(listTable);
  const listRsvGroups = rsvGroups(listRsv);
  const listRsvNew = addNewData(listTable, listRsvGroups);

  return listRsvNew;
};

export default getTableListGroup;
