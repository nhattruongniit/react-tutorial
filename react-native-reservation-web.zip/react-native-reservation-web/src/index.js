import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import { AppRegistry } from 'react-native';

//stores
import store from './stores';
import { applicationInit } from './features/apps/redux/actions';

import App from './features/apps/DefaultPage.web';

store.dispatch(applicationInit());

const AppWeb = () => (
  <Provider store={store}>
    <Router>
      <App />
    </Router>
  </Provider>
);

AppRegistry.registerComponent('AppWeb', () => AppWeb);

AppRegistry.runApplication('AppWeb', {
  rootTag: document.getElementById('root'),
});
