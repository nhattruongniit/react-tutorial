import * as RNLocalize from 'react-native-localize';

import i18n from 'i18n-js';
import { memoize } from 'lodash';

const translationGetters = {
  en: () => require('./en.json'),
  fr: () => require('./fr.json'),
};

export const translate = memoize(
  (key, config) => i18n.t(key, config),
  (key, config) => (config ? key + JSON.stringify(config) : key)
);

export const setI18nConfig = tag => {
  const defaultLanguage = tag || 'en';
  const fallback = { languageTag: defaultLanguage, isRTL: false };
  const { languageTag } =
    RNLocalize.findBestAvailableLanguage(Object.keys(translationGetters[defaultLanguage])) ||
    fallback;
  // clear translation cache
  translate.cache.clear && translate.cache.clear();
  // set i18n-js config
  i18n.translations = { [languageTag]: translationGetters[defaultLanguage]() };
  i18n.locale = languageTag;
};

export default translate;
