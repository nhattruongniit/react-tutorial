import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';

import mapper from './mapper';

export default createBottomTabNavigator(
  {
    Reservation: mapper.Reservation.navigator,
    Profile: mapper.Profile.navigator,
  },
  {
    defaultNavigationOptions: ({ navigation }) => {
      const { routeName } = navigation.state;
      return {
        tabBarIcon: ({ tintColor }) => {
          return <Text name={mapper[routeName].icon} size={25} color={tintColor} />;
        },
        tabBarLabel: () => {
          return <Text style={{ textAlign: 'center' }}>{mapper[routeName].label}</Text>;
        },
      };
    },
    tabBarOptions: {
      activeTintColor: 'tomato',
      inactiveTintColor: 'gray',
    },
  }
);
