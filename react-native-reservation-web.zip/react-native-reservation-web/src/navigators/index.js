import { createAppContainer, createSwitchNavigator } from 'react-navigation';

// config
import { ROUTE_NAME } from '../config';

// navigators
import { AuthStack as mapper } from './mapper';

// screens
import Home from './side';

const appNavigator = createSwitchNavigator(
  {
    Home,
    Login: mapper.Login.navigator,
    Register: mapper.Register.navigator,
    Auth: mapper.Auth.navigator,
  },
  {
    initialRouteName: ROUTE_NAME.AUTH,
  }
);

export default createAppContainer(appNavigator);
