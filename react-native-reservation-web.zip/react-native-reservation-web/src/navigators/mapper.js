import { createStackNavigator } from 'react-navigation-stack';

// config
import { ROUTE_NAME } from '../config';

// auth
import LoginScreen from '../features/auth/login';
import RegisterScreen from '../features/auth/register';
import AuthScreen from '../features/auth';

// components
import Reservation from '../features/reservation';
import HomeScreen from '../features/home';
import ProfileScreen from '../features/profile';

export default {
  Home: {
    label: 'Home',
    icon: '',
    navigator: createStackNavigator(
      {
        Home: { screen: HomeScreen },
      },
      {
        initialRouteName: ROUTE_NAME.HOME,
        headerMode: 'none',
        header: null,
      }
    ),
  },
  Profile: {
    label: 'Profile',
    icon: '',
    navigator: createStackNavigator(
      {
        Profile: { screen: ProfileScreen },
      },
      {
        initialRouteName: ROUTE_NAME.PROFILE,
        headerMode: 'none',
        header: null,
      }
    ),
  },
  Reservation: {
    label: 'Reservation',
    icon: '',
    navigator: createStackNavigator(
      {
        Reservation: { screen: Reservation },
      },
      {
        initialRouteName: ROUTE_NAME.RESERVATION,
        headerMode: 'none',
        header: null,
      }
    ),
  },
};

export const AuthStack = {
  Login: {
    navigator: createStackNavigator(
      {
        Login: LoginScreen,
      },
      {
        initialRouteName: ROUTE_NAME.LOGIN,
        header: null,
        headerMode: 'none',
      }
    ),
  },
  Auth: {
    navigator: createStackNavigator(
      {
        Auth: { screen: AuthScreen },
      },
      {
        initialRouteName: ROUTE_NAME.AUTH,
        header: null,
        headerMode: 'none',
      }
    ),
  },
  Register: {
    navigator: createStackNavigator(
      {
        Register: { screen: RegisterScreen },
      },
      {
        initialRouteName: ROUTE_NAME.REGISTER,
        header: null,
        headerMode: 'none',
      }
    ),
  },
};
