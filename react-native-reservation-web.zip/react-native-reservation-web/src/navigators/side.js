import { createStackNavigator } from 'react-navigation-stack';
import BottomTabNavigator from './bottom';

// config
import { ROUTE_NAME } from '../config';

export default createStackNavigator(
  {
    Home: BottomTabNavigator,
  },
  {
    initialRouteName: ROUTE_NAME.HOME,
    headerMode: 'none',
    header: null,
  }
);
