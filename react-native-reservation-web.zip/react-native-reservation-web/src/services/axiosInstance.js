import axios from 'axios';

import { API_URL } from '../config';

const axiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 3000,
  headers: {
    'content-type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    timezone: (new Date().getTimezoneOffset() / 60) * -1,
  },
});

export default axiosInstance;
