import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import appReducers from './root.reducers';

export default createStore(appReducers, applyMiddleware(thunk));
