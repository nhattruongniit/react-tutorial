import { combineReducers } from 'redux';

import AppReducer from '../features/apps/redux/reducer';
import HomeReducer from '../features/home/redux/reducer';
import DialogReducer from '../features/dialog/redux/reducer';
import ReservationReducer from '../features/reservation/redux/reducers';
import ProfileReducer from '../features/profile/redux/reducers';

export default combineReducers({
  app: AppReducer,
  home: HomeReducer,
  dialog: DialogReducer,
  reservation: ReservationReducer,
  profile: ProfileReducer,
});
