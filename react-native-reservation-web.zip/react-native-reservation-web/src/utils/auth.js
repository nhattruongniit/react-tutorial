import AsyncStorage from '@react-native-community/async-storage';

import { ROUTE_NAME } from '../config';

const auth = {
  set(value) {
    return AsyncStorage.setItem('token', value);
  },
  get() {
    return AsyncStorage.getItem('token');
  },
  remove() {
    return AsyncStorage.removeItem('token');
  },
  check(self, home = ROUTE_NAME.HOME) {
    auth.get().then(token => {
      self.props.navigation.navigate(token ? home : ROUTE_NAME.LOGIN);
    });
  },
};

export default auth;
