import { format, getHours, getMinutes } from 'date-fns';
import { getDate } from 'date-fns/esm';
import { DATE_FORMAT } from '../config';

const appGetDate = {
  now() {
    return new Date();
  },
  currentDate() {
    return this.format(new Date(), DATE_FORMAT.DEFAULT_DATE_FORMAT);
  },
  currentDay() {
    return getDate(this.now());
  },
  currentHour() {
    return getHours(this.now());
  },
  currentMinute() {
    return getMinutes(this.now());
  },
  format(date, type) {
    return format(date, type);
  },
};

export default appGetDate;
