import * as moment from 'moment';
import * as session from '../db/session';
import * as trace from '../log/trace';
import { traceDebug } from '../log/trace';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import { isBeforeUtcNow } from '../date/date';

export const signIn = async (
  username: string,
  apiToken: string,
  expireDatetime: string,
  userToken: string,
  unitTest: IUnitTest
) => {
  setSession(username, apiToken, expireDatetime, userToken);
  return true;
};

const setSession = (username: string, apiToken: string, expireDatetime: string, userToken: string) => {
  const datetimeUtc = moment
    .unix(safeGetAuthTime(username))
    .utc()
    .format();
  trace.traceDebug(`signIn datetimeUtc : ${datetimeUtc}`);

  // set to DB
  // ENHANCE: calc expire-width, not use UTC_HIGH_VALUE
  session.setAsync(expireDatetime, username, apiToken, userToken);
};

export const safeGetChallengeName = (user: any): string => {
  if (!user) {
    return '';
  }
  if (!user.challengeName) {
    return '';
  }
  return user.challengeName;
};

export const safeGetAuthTime = (user: any): number => {
  if (!user) {
    return 0;
  }
  if (!user.signInUserSession) {
    return 0;
  }
  if (!user.signInUserSession.idToken) {
    return 0;
  }
  if (!user.signInUserSession.idToken.payload) {
    return 0;
  }
  if (!user.signInUserSession.idToken.payload.auth_time) {
    return 0;
  }
  return user.signInUserSession.idToken.payload.auth_time;
};

export const isSessionExpiredAsync = async (unitTest: IUnitTest = UnitTestDefault) => {
  if (unitTest.isUnitTest) {
    return unitTest.testReturnSessionExpired;
  }
  const expireDateTime = await session.getExpireDateTimeAsync();
  traceDebug(`isSessionExpiredAsync expireDateTime : ${expireDateTime}`);
  return isBeforeUtcNow(expireDateTime);
};
