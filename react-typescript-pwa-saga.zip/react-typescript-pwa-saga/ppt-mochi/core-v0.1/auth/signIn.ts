import Amplify from 'aws-amplify';
import { Auth } from 'aws-amplify';
import * as moment from 'moment';

import * as session from '../db/session';
import aws_exports from '../../sample/fashion/aws-exports';
import * as trace from '../log/trace';
import * as constant from '../constant';
import { traceDebug } from '../log/trace';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import { isBeforeUtcNow } from '../date/date';

Amplify.configure(aws_exports);

export const signIn = async (username: string, password: string, unitTest: IUnitTest) => {
  if (!username) {
    return false;
  }
  if (!password) {
    return false;
  }

  // when unit test, no check id/password.
  if (unitTest.isUnitTest) {
    return true;
  }

  let isSuccess = false;
  let user = {};
  try {
    user = await Auth.signIn(username, password);
    isSuccess = true;
  } catch (error) {
    trace.traceDebug(`signIn failed : ${JSON.stringify(error)}`);
    return isSuccess;
  }

  trace.traceDebug(`signIn isSuccess : ${isSuccess}`);

  // 初回ログインの判定をし、初回であればパスワード上書きを行う
  if (safeGetChallengeName(user) === 'NEW_PASSWORD_REQUIRED') {
    try {
      const data = await Auth.completeNewPassword(user, password, { email: 'a@a.com' });
      trace.traceDebug(`changePassword successed : ${JSON.stringify(data)}`);
    } catch (error) {
      trace.traceDebug(`changePassword failed : ${JSON.stringify(error)}`);
    }
  }

  if (isSuccess) {
    setSession(user, username);
  }

  return isSuccess;
};

const setSession = (user: any, username: string) => {
  const datetimeUtc = moment
    .unix(safeGetAuthTime(user))
    .utc()
    .format();
  trace.traceDebug(`signIn datetimeUtc : ${datetimeUtc}`);

  // set to DB
  // ENHANCE: calc expire-width, not use UTC_HIGH_VALUE
  session.setAsync(constant.UTC_HIGH_VALUE, username);
};

export const safeGetChallengeName = (user: any): string => {
  if (!user) {
    return '';
  }
  if (!user.challengeName) {
    return '';
  }
  return user.challengeName;
};

export const safeGetAuthTime = (user: any): number => {
  if (!user) {
    return 0;
  }
  if (!user.signInUserSession) {
    return 0;
  }
  if (!user.signInUserSession.idToken) {
    return 0;
  }
  if (!user.signInUserSession.idToken.payload) {
    return 0;
  }
  if (!user.signInUserSession.idToken.payload.auth_time) {
    return 0;
  }
  return user.signInUserSession.idToken.payload.auth_time;
};

export const isSessionExpiredAsync = async (unitTest: IUnitTest = UnitTestDefault) => {
  if (unitTest.isUnitTest) {
    return unitTest.testReturnSessionExpired;
  }
  const expireDateTime = await session.getExpireDateTimeAsync();
  traceDebug(`isSessionExpiredAsync expireDateTime : ${expireDateTime}`);
  return isBeforeUtcNow(expireDateTime);
};
