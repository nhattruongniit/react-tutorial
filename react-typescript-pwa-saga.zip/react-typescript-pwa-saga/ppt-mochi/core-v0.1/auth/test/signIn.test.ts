import * as signIn from '../signIn';
import { UnitTestDefault } from '../../interface/IUnitTest';

it('safeGetChallengeName', () => {
  let user = null;
  expect(signIn.safeGetChallengeName(user)).toBe('');
  user = {};
  expect(signIn.safeGetChallengeName(user)).toBe('');
  user = { challengeName: null };
  expect(signIn.safeGetChallengeName(user)).toBe('');
  const challengeName = 'DUMMY_STRING';
  user = { challengeName };
  expect(signIn.safeGetChallengeName(user)).toBe(challengeName);
});

it('safeGetAuthTime', () => {
  let user = null;
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = {};
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: null };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: null } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: { payload: null } } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: { payload: { auth_time: null } } } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);

  // When getting a number, we need to test the input space.
  user = '';
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: '' };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: '' } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: { payload: '' } } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);
  user = { signInUserSession: { idToken: { payload: { auth_time: '' } } } };
  expect(signIn.safeGetAuthTime(user)).toBe(0);

  const authTime = 123456789;
  user = { signInUserSession: { idToken: { payload: { auth_time: authTime } } } };
  expect(signIn.safeGetAuthTime(user)).toBe(authTime);
});

it('signIn', () => {
  {
    const username = '';
    const password = '';
    signIn.signIn(username, password, UnitTestDefault).then(_ => expect(_).toBe(false));
  }
  {
    const username = 'username';
    const password = '';
    signIn.signIn(username, password, UnitTestDefault).then(_ => expect(_).toBe(false));
  }
  {
    const username = '';
    const password = 'password';
    signIn.signIn(username, password, UnitTestDefault).then(_ => expect(_).toBe(false));
  }
  {
    // can not unit test. (network error)
    const username = 'username';
    const password = 'password';
    signIn.signIn(username, password, UnitTestDefault).then(_ => expect(_).toBe(false));
  }
});
