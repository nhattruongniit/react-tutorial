import * as trace from '../log/trace';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import * as localCache from '../db/cache';
import { isBeforeUtcNow } from '../date/date';
import { tryGetS3Contents } from './s3';
import { ICachedObject } from '../interface/ICachedObject';
import * as date from '../date/date';
import * as Type from './../constant';
import { injectSaga } from '../saga/sagas';
import { injectReducer } from '../saga/store';
import { IAction } from '../interface/IAction';
import { logoutSubmit } from '../saga/logout';
import * as constant from '../../core/constant';
import { IState, initialState } from '../../sample/fashion/models/state';
import { ROOT_ACTION_ASYNC, LOGOUT_SUBMIT } from '../../sample/fashion/actions';

export const tryGetCachedContentsAsync = async (
  username: string,
  bucketPath: string,
  defaultData: any,
  unitTest: IUnitTest
) => {
  // can't test IndexedDb
  if (unitTest.isUnitTest) {
    return {};
  }
  try {
    trace.traceInfo(`tryGetCachedContentsAsync try start`);
    // 1. try get local cached contents.
    const localData = await localCache.getAsync(username, bucketPath, unitTest);
    // 2. check local cached contents expire datetime (cache time set from config.)
    // 2.1. if expired or no-cache, try get S3 contents.
    // 2.2. if not-expired, return local cached contents.
    if (!isExpiredOrNoCache(localData.expireDateTime)) {
      trace.traceInfo(`tryGetCachedContentsAsync use cache`);
      return localData.cachedObject;
    }
    trace.traceInfo(`tryGetCachedContentsAsync use s3`);
    return tryGetS3ContentsAndCache(username, bucketPath, defaultData);
  } catch (_) {
    trace.traceError(`tryGetCachedContentsAsync failed : ${JSON.stringify(_)}`);
    return defaultData;
  }
};

export const isExpiredOrNoCache = (expireDateTime: string) => {
  return !expireDateTime || isBeforeUtcNow(expireDateTime);
};

export const tryGetS3ContentsAndCache = async (username: string, bucketPath: string, defaultData: any) => {
  const s3contents: any = await tryGetS3Contents(bucketPath);
  if (s3contents !== {}) {
    // 2.1.1. if successed
    // 2.1.1.1. save contents into local cache
    await localCache.setRawDataAsync(username, bucketPath, buildCachedObject(s3contents));
    // 2.1.1.2. return S3 contents.
    return s3contents;
  } else {
    // 2.1.2. if failed, return default contents.
    return defaultData;
  }
};

const buildCachedObject = (obj: any): ICachedObject => {
  return {
    expireDateTime: date.getUtcNowAddedConfigedMinutes(),
    cachedObject: obj
  };
};

const isRESTApiRequireLogin = (res: any) => false;

function RESTApiReturned(res: any) {
  if (isRESTApiRequireLogin(res)) {
    injectReducer('REST_API_MONITOR', (state: IState = initialState, reducerAction: IAction) => {
      state.auth.expireDateTime = new Date(constant.UTC_LOW_VALUE);
      state.auth.loginSucceed = false;
      return state;
    });

    injectSaga({
      key: 'CALL_LOGOUT',
      saga: logoutSubmit,
      args: [
        null,
        { type: ROOT_ACTION_ASYNC, payload: { id: '', actionType: LOGOUT_SUBMIT }, meta: {} },
        UnitTestDefault
      ]
    });
  }
}

export const tryFetchUrlAndCache = async (
  username: string,
  url: any,
  httpMethod: string,
  inputBody: any,
  defaultData: any,
  unitTest: IUnitTest
) => {
  if (unitTest.isUnitTest) {
    return {};
  }
  const FETCH_TIMEOUT = Type.FETCH_TIMEOUT;
  let didTimeOut = false;

  const timeout = setTimeout(() => {
    didTimeOut = true;
  }, FETCH_TIMEOUT);

  try {
    trace.traceInfo(`tryFetchUrlAndCache try start`);
    const { REACT_APP_LOCAL_API_URL } = process.env;
    const fullUrl = url && url.fullUrl ? url.fullUrl : `${REACT_APP_LOCAL_API_URL}/${url}`;
    const cacheKey = inputBody ? `${fullUrl}-${JSON.stringify(inputBody)}` : fullUrl;
    const localData = await localCache.getAsync(username, cacheKey, unitTest);
    if (!isExpiredOrNoCache(localData.expireDateTime)) {
      trace.traceInfo(`tryFetchUrlAndCache use cache`);
      return localData.cachedObject;
    }

    const jsonRes: any = await fetch(fullUrl, { method: httpMethod, body: inputBody });
    RESTApiReturned({ responseOK: jsonRes.ok });
    if (jsonRes.ok && !didTimeOut) {
      clearTimeout(timeout);
      const jsonResult = await jsonRes.json();
      RESTApiReturned({ responseJSONBody: jsonResult });
      await localCache.setRawDataAsync(username, cacheKey, buildCachedObject(jsonResult));
      return jsonResult;
    } else {
      if (didTimeOut) {
        return { timeout: true };
      }
      return defaultData;
    }
  } catch (_) {
    RESTApiReturned({ error: _ });
    trace.traceError(`tryFetchUrlAndCache failed : ${JSON.stringify(_)}`);
    return defaultData;
  }
};

export const tryFetchGETUrlAndCache = async (username: string, url: any, defaultData: any, unitTest: IUnitTest) =>
  tryFetchUrlAndCache(username, url, 'GET', null, defaultData, unitTest);

export const tryFetchPOSTUrlAndCache = async (
  username: string,
  url: any,
  inputBody: any,
  defaultData: any,
  unitTest: IUnitTest
) => tryFetchUrlAndCache(username, url, 'POST', inputBody, defaultData, unitTest);
