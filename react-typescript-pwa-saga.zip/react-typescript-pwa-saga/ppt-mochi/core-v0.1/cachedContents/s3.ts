import * as trace from '../log/trace';
import { Storage } from 'aws-amplify';

export const tryGetS3Contents = async (bucketPath: string, isJson: boolean = true) => {
  const url = await tryGetUrlAsync(bucketPath);
  if (url === '') {
    return {};
  }
  return await tryGetS3DataAsync(url, isJson);
};

const tryGetUrlAsync = async (bucketPath: string) => {
  try {
    return await Storage.get(bucketPath);
  } catch (error) {
    trace.traceDebug(`tryGetUrlAsync failed : ${JSON.stringify(error)}`);
    return '';
  }
};

const tryGetS3DataAsync = async (url: any, isJson: boolean = true) => {
  try {
    const data = await fetch(url, { method: 'GET' });
    if (isJson) {
      return data.json();
    }
    return data.text();
  } catch (error) {
    trace.traceDebug(`tryGetJsonDataAsync failed : ${JSON.stringify(error)}`);
    return {};
  }
};
