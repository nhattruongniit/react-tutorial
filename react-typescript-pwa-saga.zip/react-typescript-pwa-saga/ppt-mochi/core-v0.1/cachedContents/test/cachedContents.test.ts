import * as cachedContents from '../../cachedContents';
// import { jsonTestHelper } from '../../testHelper';

it('isExpiredOrNoCache 1', () => {
  expect(cachedContents.isExpiredOrNoCache(null)).toBe(true);
});

it('isExpiredOrNoCache 2', () => {
  const empty: any = {};
  expect(cachedContents.isExpiredOrNoCache(empty.child)).toBe(true);
});

it('isExpiredOrNoCache 3', () => {
  expect(cachedContents.isExpiredOrNoCache('2018-11-20 03:50')).toBe(true);
});

it('isExpiredOrNoCache 4', () => {
  expect(cachedContents.isExpiredOrNoCache('2118-11-20 03:50')).toBe(false);
});

// WARN message comes out because of can not s3 access in unit test.
// it('tryGetS3Contents 1', async () => {
//   jsonTestHelper(await cachedContents.tryGetS3Contents('dummy_bucket_path'), {});
// });

// WARN message comes out because of can not s3 access in unit test.
// it('tryGetUrlAsync 1', async () => {
//   expect(await cachedContents.tryGetUrlAsync('dummy_bucket_path')).toBe('');
// });

// Error: Error: connect ECONNREFUSED 127.0.0.1:80
// it('tryGetJsonDataAsync 1', async () => {
//   jsonTestHelper(await cachedContents.tryGetJsonDataAsync('dummy_url'), {});
// });
