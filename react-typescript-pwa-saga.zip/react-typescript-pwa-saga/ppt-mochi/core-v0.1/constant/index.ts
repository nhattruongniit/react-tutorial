export const UTC_LOW_VALUE = '1970-01-01T00:00:00.000Z';
export const UTC_HIGH_VALUE = '2100-01-01T00:00:00.000Z';
export const FETCH_TIMEOUT = 5000;

export const HOME_DATA_FILE_NAME = 'homeData.json';

// this list is using cache.removeAllAsync().
export const getAllDataFileNames = (): string[] => {
  const list: string[] = [];
  list.push(HOME_DATA_FILE_NAME);
  return list;
};
