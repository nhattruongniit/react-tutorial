import moment from 'moment';
import { traceDebug } from '../log/trace';

const { REACT_APP_CACHED_CONTENTS_EXPIRE_MINUTES } = process.env;

export const isBeforeUtcNow = (datetime: string): any => {
  traceDebug(`isBeforeUtcNow datetime : ${datetime}`);
  if (datetime === '') {
    return true;
  }
  const datetimeUtcNow = moment.utc().format();
  traceDebug(`isBeforeUtcNow datetimeUtcNow : ${datetimeUtcNow}`);
  // sample: moment('2010-10-20').isBefore('2010-10-21') -> true
  return moment(datetime).isBefore(datetimeUtcNow);
};

export const convertToYYYYMMDDHyphen = (date: Date): string => {
  return moment(date).format('YYYY-MM-DD');
};

export const getUtcNowAddedMinutes = (minutes: number): string => {
  return moment
    .utc()
    .add(minutes, 'minutes')
    .format();
};

export const getUtcNowAddedConfigedMinutes = (): string => {
  // memo: set cache time (default: 15min)
  return getUtcNowAddedMinutes(Number(REACT_APP_CACHED_CONTENTS_EXPIRE_MINUTES));
};
