import * as core from '../date';

it('convertToYYYYMMDDHyphen', () => {
  const date = new Date('2018/01/02 12:34');
  expect(core.convertToYYYYMMDDHyphen(date)).toBe('2018-01-02');
});

it('isBeforeUtcNow', () => {
  let datetime = '2018-11-14T03:10:00.000Z';
  expect(core.isBeforeUtcNow(datetime)).toBe(true);
  datetime = '2118-11-14T04:10:00.000Z';
  expect(core.isBeforeUtcNow(datetime)).toBe(false);
});
