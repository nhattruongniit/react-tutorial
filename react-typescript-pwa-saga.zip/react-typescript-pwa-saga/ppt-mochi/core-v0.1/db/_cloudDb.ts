// import { traceDebug } from '../trace';
// import { graphqlOperation, API } from "aws-amplify";
// import { safeGetString } from '../safeGet';
// import * as mutations from '../../graphql/mutations';
// import * as localDb from './localDb';
// import { IEntity } from './IEntity';

// export const exexQueryAsync = async (id: string, name:string, query: any, tableData: IEntity) => {
//   const input = {
//     id,
//     // name: TABLE_NAME_INDEXDB,
//     name,
//     description: JSON.stringify(tableData)
//   };
//   try {
//     return [true, await API.graphql(graphqlOperation(query, { input }))];
//   } catch (_) {
//     return [false, _];
//   }
// };

// export const getSessionIdAsync = async (tableName: string) => {
//   const [isSuccess, jsonData] = await localDb.getJsonDataAsync(tableName);
//   if (!isSuccess) { return ''; }
//   traceDebug(`getIdAsync session : ${JSON.stringify(jsonData)}`);
//   return safeGetString(jsonData.sessionId);
// };

// export const createCloudSessionAsync = async (tableName:string, tableData: IEntity) => {
//   traceDebug(`createCloudSessionAsync`);
//   return await exexQueryAsync('', tableName, mutations.createTodo, tableData);
// };

// export const updateCloudSessionAsync = async (sessionId: string, tableName: string, tableData: IEntity) => {
//   const [isSuccessed, result] = await exexQueryAsync(sessionId, tableName, mutations.updateTodo, tableData);
//   traceDebug(`updateCloudSessionAsync isSuccessed : ${isSuccessed}, result : ${JSON.stringify(result)}`);
//   return isSuccessed;
// };
