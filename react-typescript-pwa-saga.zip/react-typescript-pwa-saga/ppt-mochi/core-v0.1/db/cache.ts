import * as localDb from './localDb';
import { IKeyValue } from '../interface/IKeyValue';
import { IUnitTest } from '../interface/IUnitTest';
import * as constant from '../constant';
import { IEntity } from '../interface/IEntity';

const TABLE_NAME_PREFIX = '_cache_';

export const getAsync = async (username: string, cacheName: string, unitTest: IUnitTest) => {
  if (unitTest.isUnitTest) {
    return {};
  }
  const [isSuccess, jsonData] = await localDb.getJsonDataAsync(username + TABLE_NAME_PREFIX + cacheName);
  if (!isSuccess) {
    return {};
  }
  return jsonData;
};

export const setAsync = async (username: string, cacheName: string, list: IKeyValue[]) => {
  const builtData = localDb.buildTableData(username + TABLE_NAME_PREFIX + cacheName, list);
  await localDb.upsertAsync(builtData);
};

export const setRawDataAsync = async (username: string, cacheName: string, obj: any) => {
  const jsonStr = JSON.stringify(obj);
  const builtData: IEntity = { key: username + TABLE_NAME_PREFIX + cacheName, value: jsonStr };
  await localDb.upsertAsync(builtData);
};

export const removeAsync = async (username: string, cacheName: string, unitTest: IUnitTest) => {
  if (unitTest.isUnitTest) {
    return;
  }
  await localDb.deleteAsync(username + TABLE_NAME_PREFIX + cacheName);
};

export const removeAllAsync = async (username: string, unitTest: IUnitTest) => {
  if (unitTest.isUnitTest) {
    return;
  }
  const allDataFileNames = constant.getAllDataFileNames();
  for (const item of allDataFileNames) {
    await localDb.deleteAsync(username + TABLE_NAME_PREFIX + item);
  }
};
