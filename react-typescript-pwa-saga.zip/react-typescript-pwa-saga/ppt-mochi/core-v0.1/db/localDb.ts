import Dexie from 'dexie';
import { traceDebug, traceError } from '../log/trace';
import { IEntity } from '../interface/IEntity';
import { IKeyValue } from '../interface/IKeyValue';
import { jsonBuilder } from '../helper/jsonBuilder';
import { deflateToBase64, inflateFromBase64 } from '../deflate/deflate';

type DexieDatabase = { [P in keyof Dexie]: Dexie[P] };

interface IDatabase extends DexieDatabase {
  table1: Dexie.Table<IEntity, string>;
}

const { REACT_APP_IS_ENV_USE_LOCAL_DB_DEFLATE } = process.env;

export const getLocalDb = () => {
  const localDb = new Dexie('common-database') as IDatabase;
  // version control
  // see https://dexie.org/docs/Version/Version
  // db.version(2).stores({
  //   friends: "++id,name,birthdate,sex",
  //   pets: "++id,name,kind"
  // }).upgrade (trans => {
  //   var YEAR = 365 * 24 * 60 * 60 * 1000;
  //   return trans.friends.toCollection().modify (friend => {
  //     friend.birthdate = new Date(Date.now() - (friend.age * YEAR));
  //     delete friend.age;
  //   });
  // });
  // // Always keep the declarations previous versions as long as there might be users having them running.
  // db.version(1).stores({
  //   friends: "++id,name,age,sex",
  //   pets: "++id,name,kind"
  // });
  localDb.version(1).stores({
    table1: 'key'
  });
  return localDb.table1;
};

export const buildTableData = (tableKey: string, list: IKeyValue[]): IEntity => {
  return REACT_APP_IS_ENV_USE_LOCAL_DB_DEFLATE === 'true'
    ? { key: deflateToBase64(tableKey), value: deflateToBase64(jsonBuilder(list)) }
    : { key: tableKey, value: jsonBuilder(list) };
};

export const getJsonDataAsync = async (tableKey: string) => {
  try {
    traceDebug('getJsonData start');
    const deflatedKey = REACT_APP_IS_ENV_USE_LOCAL_DB_DEFLATE === 'true' ? deflateToBase64(tableKey) : tableKey;
    const data = await getLocalDb()
      .where('key')
      .equals(deflatedKey)
      .toArray();
    if (data.length === 0) {
      traceDebug('getJsonData failed');
      return [false, {}];
    }
    const base64 = data[0].value;
    traceDebug('getJsonData base64 : ' + base64);
    const inflatedData = REACT_APP_IS_ENV_USE_LOCAL_DB_DEFLATE === 'true' ? inflateFromBase64(base64) : base64;
    traceDebug('getJsonData inflatedData : ' + inflatedData);
    return [true, JSON.parse(inflatedData)];
  } catch (_) {
    traceError(`getJsonDataAsync failed : ${_}`);
    return [false, {}];
  }
};

export const upsertAsync = async (tableData: IEntity) => {
  await getLocalDb().put(tableData);
};

export const deleteAsync = async (tableKey: string) => {
  const deflatedKey = REACT_APP_IS_ENV_USE_LOCAL_DB_DEFLATE === 'true' ? deflateToBase64(tableKey) : tableKey;
  traceDebug(`localDb.deleteAsync deflatedKey : ${deflatedKey}`);
  await getLocalDb()
    .where('key')
    .equals(deflatedKey)
    .delete();
};
