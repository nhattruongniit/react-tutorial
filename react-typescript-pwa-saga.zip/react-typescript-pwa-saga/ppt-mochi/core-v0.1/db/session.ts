import * as localDb from './localDb';
import * as constant from '../constant';
import { traceDebug } from '../log/trace';
import { safeGetString } from '../safeGet/safeGet';
import { IKeyValue } from '../interface/IKeyValue';
import { IUnitTest } from '../interface/IUnitTest';

const { REACT_APP_TABLE_NAME_INDEXDB = '' } = process.env;

export const getExpireDateTimeAsync = async () => {
  const [isSuccess, session] = await localDb.getJsonDataAsync(REACT_APP_TABLE_NAME_INDEXDB);
  if (!isSuccess) {
    return constant.UTC_LOW_VALUE;
  }
  traceDebug(`session.getExpireDateTimeAsync session : ${JSON.stringify(session)}`);
  const expireDateTime = safeGetString(session.expireDateTime);
  return expireDateTime === '' ? constant.UTC_LOW_VALUE : expireDateTime;
};

export const getUsernameAsync = async (unitTest: IUnitTest) => {
  if (unitTest.isUnitTest) {
    return '';
  }
  const [isSuccess, session] = await localDb.getJsonDataAsync(REACT_APP_TABLE_NAME_INDEXDB);
  if (!isSuccess) {
    return '';
  }
  traceDebug(`session.getUsernameAsync session : ${JSON.stringify(session)}`);
  return safeGetString(session.username);
};

export const setAsync = async (expireDateTime: string, username: string = '', apiToken?: any, userToken?: string) => {
  const tableData = localDb.buildTableData(
    REACT_APP_TABLE_NAME_INDEXDB,
    buildList(expireDateTime, username, apiToken, userToken)
  );
  await localDb.upsertAsync(tableData);
};

const buildList = (expireDateTime: string, username: string, apiToken?: any, userToken?: any): IKeyValue[] => {
  const list: IKeyValue[] = [];
  list.push({ key: 'expireDatetime', value: expireDateTime });
  list.push({ key: 'username', value: username });
  list.push({ key: 'apiToken', value: apiToken });
  list.push({ key: 'userToken', value: userToken });
  return list;
};

export const removeAsync = async (unitTest: IUnitTest) => {
  if (unitTest.isUnitTest) {
    return;
  }
  await localDb.deleteAsync(REACT_APP_TABLE_NAME_INDEXDB);
};
