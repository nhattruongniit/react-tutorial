// import * as localDb from '../localDb';
// import * as safeGet from '../../safeGet';

// // can't test w/IndexedDB
// export const test1 = async () => {
//   await localDb.upsertAsync(localDb.buildTableData2('test1', 'key1', 'val1', 'key2', 'val2'));

//   const [isSuccess, test11Json] = await localDb.getJsonDataAsync('test11');
//   console.log("test11Json isSuccess : " + isSuccess);
//   console.log("test11Json key : " + test11Json.key1);
//   console.log("test11Json value : " + test11Json.key2);

//   const [isSuccessxxx, test11Jsonxxx] = await localDb.getJsonDataAsync('test11xxx');
//   console.log("test11Json isSuccess : " + isSuccessxxx);
//   console.log("test11Json key1 : " + safeGet.safeGetString(test11Jsonxxx.key1));    // undef to ''
//   console.log("test11Json key2 : " + safeGet.safeGetString(test11Jsonxxx.key2));    // undef to ''
// };

// it('db test without crashing', () => {
//   test1();
// });
