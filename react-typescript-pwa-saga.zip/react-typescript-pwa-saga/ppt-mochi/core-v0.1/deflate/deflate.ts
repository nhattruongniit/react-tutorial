import * as pako from 'pako';

export const deflateToBase64 = (json: any): string => {
  return btoa(pako.deflate(JSON.stringify(json), { to: 'string' }));
};

export const inflateFromBase64 = (base64: string): string => {
  return JSON.parse(pako.inflate(atob(base64), { to: 'string' }));
};
