import * as testHelper from '../../helper/testHelper';
import * as trace from '../../log/trace';
import * as deflate from '../deflate';

it('deflate and inflate', () => {
  const json = { my: '漢字', puper: [456, 567], awesome: 'pako' };
  const base64 = deflate.deflateToBase64(json);
  trace.traceDebug(`base64 : ${base64}`);
  const inflatedData = deflate.inflateFromBase64(base64);
  testHelper.jsonTestHelper(json, inflatedData);
});
