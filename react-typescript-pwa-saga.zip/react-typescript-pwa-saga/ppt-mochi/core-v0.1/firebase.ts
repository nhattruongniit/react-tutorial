import * as firebase from 'firebase';
import * as trace from './log/trace';
import { IFirebaseConfig } from './interface/IFirebaseConfig';

export const initializeFirebase = (firebaseConfig: IFirebaseConfig) => {
  firebase.initializeApp(firebaseConfig);
};

export const askForPermissionToReceiveNotifications = async () => {
  try {
    const messaging = firebase.messaging();
    await messaging.requestPermission();
    trace.traceDebug('FCM: Have Permission');
    const token = await messaging.getToken();
    trace.traceDebug('FCM: Token : ' + token);

    // TODO: 取得した Firebase トークンをサーバーへ送信

    // // ログアウト時の Firebase トークン削除のため、ローカルストレージに保存する
    // localStorage.setItem('FIREBASE_TOKEN', token):

    // // 通知サーバーへ Firebase トークンを送信し保存する
    // // createFirebaseToken は、そのための Action
    // return context.executeAction(createFirebaseToken, { token });

    return token;
  } catch (error) {
    if (error.code === 'messaging/permission-blocked') {
      trace.traceInfo('FCM: Please Unblock Notification Request Manually');
    } else {
      trace.traceInfo('FCM: Error Occurred : ' + error);
    }
    return null;
  }
};
