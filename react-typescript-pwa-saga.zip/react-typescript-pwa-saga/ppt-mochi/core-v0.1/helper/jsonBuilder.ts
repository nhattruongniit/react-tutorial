import { IKeyValue } from '../interface/IKeyValue';

export const jsonBuilder = (list: IKeyValue[]) => {
  const strings = new Array();
  strings.push('{');
  for (const item of list) {
    strings.push(`"${item.key}":"${item.value}",`);
  }
  const json = strings.join('');

  // remove last ',' and add '}'
  return json.substring(0, json.length - 1) + '}';
};
