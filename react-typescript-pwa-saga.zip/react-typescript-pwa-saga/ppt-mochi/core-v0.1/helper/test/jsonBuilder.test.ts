import { jsonBuilder } from '../jsonBuilder';
import { IKeyValue } from '../../interface/IKeyValue';

describe('JsonBuilder', () => {
  it('JsonBuilder', () => {
    expect(jsonBuilder(buildTestData1('k1', 'v1'))).toBe('{"k1":"v1"}');
    expect(jsonBuilder(buildTestData2('k1', 'v1', 'k2', 'v2'))).toBe('{"k1":"v1","k2":"v2"}');
  });
});

export const buildTestData1 = (key1: string, val1: string): IKeyValue[] => {
  const list: IKeyValue[] = [];
  list.push({ key: key1, value: val1 });
  return list;
};

export const buildTestData2 = (key1: string, val1: string, key2: string, val2: string): IKeyValue[] => {
  const list: IKeyValue[] = [];
  list.push({ key: key1, value: val1 });
  list.push({ key: key2, value: val2 });
  return list;
};
