export const jsonTestHelper = (s1: any, s2: any) => {
  expect(JSON.stringify(s1).toString).toBe(JSON.stringify(s2).toString);
};

export const multiStringTestHelper = (funcResult: any, s1: string, s2: string) => {
  const [r1, r2] = funcResult;
  expect(r1).toBe(s1);
  expect(r2).toBe(s2);
};
