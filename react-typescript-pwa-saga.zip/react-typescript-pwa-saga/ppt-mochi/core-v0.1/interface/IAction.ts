import * as safeGet from '../safeGet/safeGet';

export interface IAction {
  type: string; // memo : string is guaranteed to be Redux.
  payload: any;
  meta: any;
}

export const safeGetType = (reducerAction: IAction) => {
  const type = reducerAction.type;
  return safeGet.safeGetString(type);
};
