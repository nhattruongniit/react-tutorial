export interface IActionType {
  actionTypePrefix: string;
  pageName: string;
  urlMatchExact?: boolean;
  urlMatchStrict?: boolean;
  pagesStack?: string[];
  match?: any;
}
