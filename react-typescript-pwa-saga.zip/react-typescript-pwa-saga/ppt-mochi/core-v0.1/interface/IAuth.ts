export default interface IAuth {
  username: string;
  password: string;
  loginSucceed: boolean;
  message: string;
  uuid?: string;
  expireDateTime?: Date;
}
