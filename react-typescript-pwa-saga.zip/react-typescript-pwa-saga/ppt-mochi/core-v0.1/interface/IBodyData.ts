export interface IBodyData {
  mode: string;
  userid: string;
  password?: string;
  loginToken?: string;
  apiToken?: string;
  expireDatetime?: string;
  tablename?: string;
  param?: {};
  skip?: number;
}
