export interface ICachedObject {
  expireDateTime: string;
  cachedObject: any;
}
