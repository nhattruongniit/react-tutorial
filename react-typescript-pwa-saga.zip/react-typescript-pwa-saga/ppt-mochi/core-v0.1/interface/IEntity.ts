export interface IEntity {
  key: string;
  value: string;
}
