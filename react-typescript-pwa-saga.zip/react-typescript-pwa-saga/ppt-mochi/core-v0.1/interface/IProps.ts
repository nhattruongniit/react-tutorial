export default interface IProps {
  handler: any;
  match?: any;
  classes?: any;
  history?: any;
  location?: any;
}
