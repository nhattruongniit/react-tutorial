export default interface ISearchBarProps {
  placeHolder: string;
  handler: any;
}
