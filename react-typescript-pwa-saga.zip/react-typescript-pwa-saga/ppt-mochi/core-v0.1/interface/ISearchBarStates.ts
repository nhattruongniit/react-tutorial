export default interface ISearchBarStates {
  hasText: boolean;
  text: string;
}
