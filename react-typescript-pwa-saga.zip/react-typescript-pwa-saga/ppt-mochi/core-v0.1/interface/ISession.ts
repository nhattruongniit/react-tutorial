export interface ISession {
  username: string;
  expireDateTime: string;
}
