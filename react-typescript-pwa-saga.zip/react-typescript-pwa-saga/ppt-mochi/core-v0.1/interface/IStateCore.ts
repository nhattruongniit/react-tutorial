export default interface IStateCore {
  pageName?: string;
  isLoading?: boolean;
  isSidebar?: boolean;
}
