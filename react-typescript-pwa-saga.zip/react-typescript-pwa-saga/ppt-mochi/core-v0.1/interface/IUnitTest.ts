export interface IUnitTest {
  isUnitTest: boolean;
  canStatusChangeAction: boolean;
  canRedirectAction: boolean;
  testReturnSessionExpired: boolean;
}

export const UnitTestDefault: IUnitTest = {
  isUnitTest: false,
  canStatusChangeAction: true,
  canRedirectAction: true,
  testReturnSessionExpired: true
};
