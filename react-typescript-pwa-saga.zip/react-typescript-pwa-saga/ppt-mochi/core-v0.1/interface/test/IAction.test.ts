import * as IAction from '../IAction';

it('safeGetType 1', () => {
  const t1 = '@@redux/INITk.v.w.h.r.l';
  const reducerAction = { type: t1, payload: {}, meta: {} };
  expect(IAction.safeGetType(reducerAction)).toBe(t1);
});

it('safeGetType 2', () => {
  const t1 = '';
  const reducerAction = { type: t1, payload: {}, meta: {} };
  expect(IAction.safeGetType(reducerAction)).toBe('');
});

// it('safeGetType 3', () => {
//   const t1 = undefined;
//   const reducerAction = { type: t1, payload: {}, meta: {} };
//   expect(IAction.safeGetType(reducerAction)).toBe('');
// });

// it('safeGetType 4', () => {
//   const t1 = {};
//   const reducerAction = { type: t1, payload: {}, meta: {} };
//   expect(IAction.safeGetType(reducerAction)).toBe('');
// });

// export const safeGetType = (reducerAction: IAction) => {
//   const type = reducerAction.type;
//   if (type) { return type; }
//   return '';
// };
