import { Logger } from 'aws-amplify';
import IStateCore from '../interface/IStateCore';

const { REACT_APP_ENV_LOGLEVEL } = process.env;

const logger = new Logger('log', REACT_APP_ENV_LOGLEVEL);

export const traceDebug = (log: string) => {
  try {
    logger.debug(log);
  } catch (error) {
    //
  }
};

export const traceInfo = (log: string) => {
  try {
    logger.info(log);
  } catch (error) {
    //
  }
};

export const traceWarn = (log: string) => {
  try {
    logger.warn(log);
  } catch (error) {
    //
  }
};

export const traceError = (log: string) => {
  try {
    logger.error(log);
  } catch (error) {
    //
  }
};

export const traceState = <T extends IStateCore>(state: T, action: any) => {
  traceDebug('traceState in reducer *** state : ' + JSON.stringify(state) + '\naction : ' + JSON.stringify(action));
};

export const traceMatch = (pageName: string, match: any) => {
  traceDebug('traceMatch *** pageName: ' + pageName + ' match: ' + JSON.stringify(match));
};
