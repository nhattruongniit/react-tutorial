import { actions } from '../actions';
import * as trace from '../log/trace';
import * as safeGet from '../safeGet/safeGet';
import { IAction } from '../interface/IAction';
import IStateCore from '../interface/IStateCore';

export const tryGetNewStateAndActionType = <T extends IStateCore>(state: T, reducerAction: IAction): [T, string] => {
  const actionType = safeGet.safeGetActionType(reducerAction);

  if (isRootAction(reducerAction, actionType)) {
    trace.traceDebug(`tryGetNewStateAndActionType reducerAction.type : ${reducerAction.type}`);
    return [state, ''];
  }

  trace.traceState(state, reducerAction);

  // ex) redux first action
  // state : {"pageName":"","home":{"data":{}},"login":{"message":"","username":"test1","password":"password1"}}
  // action : {"type":"@@redux/INITk.v.w.h.r.l"}
  if (reducerAction && reducerAction.type && reducerAction.type.startsWith(actions.REDUX_INIT)) {
    return [state, ''];
  }
  if (!actionType) {
    return [state, ''];
  }

  // clear isLoading
  const newState = { ...state };
  newState.isLoading = false;
  newState.isSidebar = false;

  return [newState, actionType];
};

const isRootAction = (reducerAction: IAction, actionType: string) => {
  // if (config.IS_ENV_SERVER) {
  //   // ROOT_ACTION_ASYNC action send to sagas.
  //   if (reducerAction.type === actions.ROOT_ACTION_ASYNC) {
  //     return true;
  //   }
  // } else {
  // exclude LOGIN_SHOW
  if (actionType === actions.LOGIN_SHOW) {
    return false;
  }
  if (reducerAction && reducerAction.type === actions.ROOT_ACTION_ASYNC) {
    return true;
  }
  // }
  return false;
};
