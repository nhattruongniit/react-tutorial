import { IAction } from '../interface/IAction';
import IAuth from '../interface/IAuth';
import IStateCore from '../interface/IStateCore';

export const safeGetString = (obj: any): string => {
  if (!obj) {
    return '';
  }
  if (typeof obj !== 'string') {
    return '';
  }
  return obj;
};

export const safeGetActionType = (action: IAction): string => {
  if (!action) {
    return '';
  }
  if (!action.payload) {
    return '';
  }
  if (!action.payload.actionType) {
    return '';
  }
  return action.payload.actionType;
};

export const safeGetIdAndValue = (action: IAction): [string, string] => {
  if (!action) {
    return ['', ''];
  }
  if (!action.payload) {
    return ['', ''];
  }
  if (!action.payload.id) {
    if (action.payload.value) {
      return ['', action.payload.value];
    }
    return ['', ''];
  }
  if (!action.payload.value) {
    if (action.payload.id) {
      return [action.payload.id, ''];
    }
    return ['', ''];
  }
  return [action.payload.id, action.payload.value];
};

export const safeGetUsername = <T extends IAuth>(state: T): string => {
  if (!state) {
    return '';
  }
  if (!state.username) {
    return '';
  }
  return state.username;
};

export const safeGetUsernameAndPassword = <T extends IAuth>(state: T): [string, string] => {
  if (!state) {
    return ['', ''];
  }
  if (!state.username) {
    return ['', ''];
  }
  if (!state.password) {
    return ['', ''];
  }
  return [state.username, state.password];
};

export const safeGetPageName = <T extends IStateCore>(state: T): string => {
  if (!state) {
    return '';
  }
  if (!state.pageName) {
    return '';
  }
  return state.pageName;
};

export const safeGetUrl = (match: any): string => {
  // example match:{"path":"/Points","url":"/points","isExact":true,"params":{}}
  if (!match) {
    return '';
  }
  if (!match.url) {
    return '';
  }
  return match.url;
};
