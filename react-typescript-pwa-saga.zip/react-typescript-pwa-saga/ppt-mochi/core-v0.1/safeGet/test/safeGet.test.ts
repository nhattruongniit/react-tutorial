import * as safeGet from '../safeGet';
import * as testHelper from '../../helper/testHelper';
import IAuth from '../../interface/IAuth';

it('safeGetString', () => {
  let obj = {};
  expect(safeGet.safeGetString(obj)).toBe('');
  obj = {};
  expect(safeGet.safeGetString(obj)).toBe('');
  obj = { str1: null };
  expect(safeGet.safeGetString(obj)).toBe('');
  obj = { str1: 'str1' };
  expect(safeGet.safeGetString(obj)).toBe('');
  obj = 'DUMMY_STRING';
  expect(safeGet.safeGetString(obj)).toBe(obj);
});

it('safeGetActionType', () => {
  expect(safeGet.safeGetActionType({ type: '', payload: null, meta: null })).toBe('');
  expect(
    safeGet.safeGetActionType({
      type: '',
      payload: { actionType: null },
      meta: null
    })
  ).toBe('');
  const actionType = 'DUMMY_STRING';
  expect(safeGet.safeGetActionType({ type: '', payload: { actionType }, meta: null })).toBe(actionType);
});

it('safeGetPageName', () => {
  let state = {};
  expect(safeGet.safeGetPageName(state)).toBe('');
  state = {};
  expect(safeGet.safeGetPageName(state)).toBe('');
  state = { pageName: null };
  expect(safeGet.safeGetPageName(state)).toBe('');
  const pageName = 'PAGE_NAME';
  state = { pageName };
  expect(safeGet.safeGetPageName(state)).toBe(pageName);
});

it('safeGetUrl', () => {
  let match = {};
  expect(safeGet.safeGetUrl(match)).toBe('');
  match = {};
  expect(safeGet.safeGetUrl(match)).toBe('');
  match = { url: null };
  expect(safeGet.safeGetUrl(match)).toBe('');
  const url = 'URL';
  match = { url };
  expect(safeGet.safeGetUrl(match)).toBe(url);
  match = { path: '/Points', url: '/points', isExact: true, params: {} };
  expect(safeGet.safeGetUrl(match)).toBe('/points');
});

it('safeGetIdAndValue', () => {
  let DUMMY_ID = '';
  let DUMMY_VALUE = '';
  testHelper.multiStringTestHelper(safeGet.safeGetIdAndValue({ type: '', payload: null, meta: null }), '', '');

  testHelper.multiStringTestHelper(
    safeGet.safeGetIdAndValue({
      type: '',
      payload: { id: null, value: null },
      meta: null
    }),
    '',
    ''
  );

  DUMMY_ID = 'DUMMY_ID';
  testHelper.multiStringTestHelper(
    safeGet.safeGetIdAndValue({
      type: '',
      payload: { id: DUMMY_ID, value: null },
      meta: null
    }),
    DUMMY_ID,
    ''
  );

  DUMMY_VALUE = 'DUMMY_VALUE';
  testHelper.multiStringTestHelper(
    safeGet.safeGetIdAndValue({
      type: '',
      payload: { id: null, value: DUMMY_VALUE },
      meta: null
    }),
    '',
    DUMMY_VALUE
  );

  DUMMY_ID = 'DUMMY_ID';
  DUMMY_VALUE = 'DUMMY_VALUE';
  testHelper.multiStringTestHelper(
    safeGet.safeGetIdAndValue({
      type: '',
      payload: { id: DUMMY_ID, value: DUMMY_VALUE },
      meta: null
    }),
    DUMMY_ID,
    DUMMY_VALUE
  );
});

it('safeGetUsernameAndPassword', () => {
  const state: IAuth = {
    username: 'test1',
    password: 'password',
    loginSucceed: false,
    message: '',
    expireDateTime: new Date()
  };
  testHelper.multiStringTestHelper(safeGet.safeGetUsernameAndPassword(state), 'test1', 'password');
});
