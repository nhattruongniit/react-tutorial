import { delay } from 'redux-saga';
import { call } from 'redux-saga/effects';
import * as Enumerable from 'linq';
import { matchPath } from 'react-router';
import { IActionType } from '../interface/IActionType';

const { REACT_APP_ASYNC_WAIT_TIME } = process.env;

export const getActionTypeObjectByPage = (pageName: string, pageNameActions: IActionType[]): IActionType => {
  return Enumerable.from(pageNameActions)
    .where((_: any) => {
      const match = matchPath(pageName, {
        path: _.pageName,
        exact: _.urlMatchExact ? _.urlMatchExact : true,
        strict: _.urlMatchStrict ? _.urlMatchStrict : false
      });

      if (match) {
        _.match = match;
        return true;
      }
      return false;
    })
    .select(_ => _)
    .firstOrDefault();
};

export const getActionTypeObjectByType = (actionType: string, pageNameActions: IActionType[]): IActionType => {
  return Enumerable.from(pageNameActions)
    .where((_: any) => actionType.startsWith(_.actionTypePrefix))
    .select(_ => _)
    .firstOrDefault();
};

export const isHomePathname = (pathname: any) => {
  // memo
  // @server
  // context : {"history":{"length":34,"action":"POP","location":{"pathname":"/home","search":"","hash":"","key":"vxk4lx"}}}
  // @local
  // context : {"history":{"length":2,"action":"POP","location":{"pathname":"/C:/work/1120/build/index.html","search":"","hash":""}}}
  return pathname === '/#/homes' || pathname === '/#/' || pathname.endsWith('/index.html');
};

export function* testDelay() {
  // test delay for loading image
  if (Number(REACT_APP_ASYNC_WAIT_TIME) !== 0) {
    yield call(delay, Number(REACT_APP_ASYNC_WAIT_TIME));
  }
}
