// middleware
import { call, takeLatest } from 'redux-saga/effects';

// core
import * as redirector from './redirector';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import * as trace from '../log/trace';
import { IAction } from '../interface/IAction';
import { safeGetActionType } from '../safeGet/safeGet';
import { logout, logoutWhenSessionExpired } from './logout';
import { getActionTypeObjectByPage, getActionTypeObjectByType, isHomePathname, testDelay } from './helper';

// actions
import { actions } from '../actions';

export function* rootSaga(context: any) {
  // initial action dispatch one time.
  yield call(initialSaga, context);
  // normal action dispatch
  yield takeLatest(actions.ROOT_ACTION_ASYNC, commonDispatcher, context);
}

export function* commonDispatcher(context: any, action: IAction, unitTest: IUnitTest = UnitTestDefault) {
  if (action.type === actions.SAGA_TO_REDUCER_ACTION) {
    return;
  }
  try {
    trace.traceDebug(`************ commonDispatcher 1    ${JSON.stringify(action)}         ***********************`);
    // When page redirect in child saga, return 'true' and parent saga dispach is finish.
    if (yield call(logout, context, action, unitTest)) {
      return;
    }
    if (yield call(logoutWhenSessionExpired, context, action, unitTest)) {
      return;
    }
    trace.traceDebug('************ commonDispatcher 2             ***********************');
    yield call(showLoadingImage, context, action, unitTest);

    // When page redirect in child saga, return 'true' and parent saga dispach is finish.
    if (yield call(context.dispatcher, context, action, unitTest)) {
      return;
    }

    trace.traceDebug('************ commonDispatcher 3             ***********************');
    yield call(commonRedirector, context, action, unitTest);
  } catch (e) {
    trace.traceError(e);
    // redirect to error page.
    action.payload.actionType = actions.ERROR_SHOW;
    // switch saga to reducer
    yield call(redirector.callReducer, action, action.payload.actionType);
  }
}

// initial action dispatch one time.
// 初回起動で必ず呼ばれる処理。ここのみsagaActionを引き回せないため、自前で作る必要がある
export function* initialSaga(context: any, unitTest: IUnitTest = UnitTestDefault) {
  trace.traceDebug('initialSaga loginCheckForUrlRedirect');
  if (yield call(logoutWhenSessionExpired, context, {}, unitTest)) {
    return;
  }

  trace.traceDebug(`context : ${JSON.stringify(context)}`);
  const pageName = context.history.location.pathname;
  trace.traceDebug(`initialSaga pageName : ${pageName}`);
  if (isHomePathname(pageName)) {
    trace.traceDebug('initialSaga redirect to home page');
    yield call(callNextSaga, context, actions.HOME_SHOW, unitTest);
    return;
  }

  // When not home pathName, call show action.
  const actionTypeObj = getActionTypeObjectByPage(pageName, context.pageNames);
  trace.traceInfo(`initialSaga actionTypeObj : ${JSON.stringify(actionTypeObj)}`);
  trace.traceInfo(`initialSaga context : ${JSON.stringify(context)}`);
  if (actionTypeObj) {
    const actionTypePrefix = actionTypeObj.actionTypePrefix;
    trace.traceInfo(`initialSaga redirect to ${actionTypePrefix}SHOW`);
    if (!actionTypeObj.pagesStack) {
      actionTypeObj.pagesStack = [];
    }
    if (actionTypeObj.match) {
      actionTypeObj.pagesStack.push(actionTypeObj.match.url);
    } else {
      actionTypeObj.pagesStack.push(pageName);
    }

    yield call(callNextSaga, context, `${actionTypePrefix}SHOW`, unitTest);
  }
}

export function* callNextSaga(context: any, actionType: string, unitTest: IUnitTest) {
  const action = {
    type: actions.ROOT_ACTION_ASYNC,
    payload: { actionType },
    meta: {}
  };
  trace.traceDebug(`sagaAction : ${JSON.stringify(action)}`);
  // initialSagaからredirectPageをCallし内部でputしてもtakeLatest側に発火しない
  // 従って動的にinitialSaga内部でもcommonDispacherを呼ぶ
  yield call(commonDispatcher, context, action, unitTest);
}

export function* pushPageNameToHistory(context: any, action: IAction, unitTest: IUnitTest = UnitTestDefault) {
  // When not-redirect in child saga, optionally rewrite history.
  // When SHOW action, push page name to history.(SHOW action set from Navbar/Footer event)
  const actionType = safeGetActionType(action);
  trace.traceDebug(`pushPageNameToHistory actionType : ${actionType}`);

  trace.traceDebug(`pushPageNameToHistory action : ${JSON.stringify(action)}`);
  let pageName = '';
  if (action.payload && action.payload.value && action.payload.value.redirectUrl) {
    pageName = action.payload.value.redirectUrl;
  } else {
    const actionTypeObj = getActionTypeObjectByType(actionType, context.pageNames);
    if (actionTypeObj) {
      pageName = actionTypeObj.pageName;

      trace.traceDebug('pushPageNameToHistory actionTypeObj : ' + JSON.stringify(actionTypeObj));
      if (actionTypeObj.pagesStack && actionTypeObj.pagesStack.length) {
        pageName = actionTypeObj.pagesStack.pop() + '';
      }
    }
  }

  if (actionType === actions.COMMON_LEAVE) {
    return;
  }

  const pageLoadType = 'navigate';
  switch (pageLoadType) {
    case 'navigate':
      if (!(window as any).visited) {
        (window as any).visited = true;
        return;
      }
      break;
    // case 'reload':
    //   if (pageName === location.pathname) {
    //     return;
    //   }
  }

  if (pageName && pageName.length > 0) {
    trace.traceDebug(`pushPageNameToHistory push : ${pageName}`);
    yield call(redirector.safeHistoryPushExecute, context, pageName, unitTest);
  }
}

export function* showLoadingImage(context: any, action: IAction, unitTest: IUnitTest = UnitTestDefault) {
  // Actionが書き換わってしまうため、戻す必要がある
  const saveActionType = safeGetActionType(action);
  // Show loading image.
  yield call(redirector.callReducer, action, actions.COMMON_LEAVE);
  action.payload.actionType = saveActionType;
}

export function* commonRedirector(context: any, action: IAction, unitTest: IUnitTest = UnitTestDefault) {
  // test delay for loading image
  yield call(testDelay);
  // switch saga to reducer
  yield call(redirector.callReducer, action, safeGetActionType(action));
  // When not-redirect in child saga, optionally rewrite history.
  if (action.payload.actionType.endsWith('_SHOW')) {
    yield call(pushPageNameToHistory, context, action, unitTest);
  }
}
