import { call } from 'redux-saga/effects';
import * as redirector from './redirector';
import { IAction } from '../interface/IAction';
import * as session from '../db/session';
import * as cache from '../db/cache';
import * as trace from '../log/trace';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import * as safeGet from '../safeGet/safeGet';
import * as signIn from '../auth/signIn';

const { REACT_APP_IS_ENV_USE_LOGIN } = process.env;

// actions
import { actions } from '../actions';

export function* logout(context: any, action: IAction, unitTest: IUnitTest) {
  switch (action.payload.actionType) {
    case actions.LOGOUT_SUBMIT:
      return yield logoutSubmit(context, action, unitTest);
  }
  return false;
}

export function* logoutSubmit(context: any, action: IAction, unitTest: IUnitTest) {
  yield call(clearLocalDbData, unitTest);
  // redirect to login before status change in LOGOUT_SUBMIT reducer.
  yield call(logoutLeaveAndLoginShow, context, action, unitTest);
  // When page redirect in child saga, return 'true' and parent saga dispach is finish.
  return true;
}

export function* clearLocalDbData(unitTest: IUnitTest) {
  const username = yield call(session.getUsernameAsync, unitTest);
  trace.traceDebug(`logout username : ${username}`);
  yield call(cache.removeAllAsync, username, unitTest);
  yield call(session.removeAsync, unitTest);
}

export function* logoutWhenSessionExpired(context: any, action: any, unitTest: IUnitTest = UnitTestDefault) {
  if (REACT_APP_IS_ENV_USE_LOGIN === 'false') {
    return false;
  }
  const actionType = safeGet.safeGetActionType(action);
  if (actionType.startsWith(actions.ACTION_TYPE_PREFIX_LOGIN)) {
    return false;
  }
  const isExpired = yield call(signIn.isSessionExpiredAsync, unitTest);
  if (isExpired || actionType.startsWith(actions.ACTION_TYPE_PREFIX_LOGOUT)) {
    const nextAction =
      actionType === ''
        ? { type: actions.SAGA_TO_REDUCER_ACTION, payload: { actionType: actions.LOGIN_SHOW }, meta: {} }
        : action;
    // redirect to login page.
    yield call(logoutLeaveAndLoginShow, context, nextAction, unitTest);
    // When page redirect in child saga, return 'true' and parent saga dispach is finish.
    return true;
  }
  return false;
}

export function* logoutLeaveAndLoginShow(context: any, action: IAction, unitTest: IUnitTest = UnitTestDefault) {
  yield call(
    redirector.redirectPageWithStatusChange,
    context,
    action,
    actions.LOGOUT_LEAVE,
    actions.LOGIN_SHOW,
    actions.PAGE_NAME_LOGIN,
    unitTest
  );
}
