import { put, call } from 'redux-saga/effects';
import { IAction } from '../interface/IAction';
import { IUnitTest, UnitTestDefault } from '../interface/IUnitTest';
import * as trace from '../log/trace';

// actions
import { actions } from '../actions';

export function* safeHistoryPushExecute(
  context: any,
  actionsPAGENAMEXXX: string,
  unitTest: IUnitTest,
  isReplace: boolean = false
) {
  // index.html(w/applican or local files) is can not push history.
  // 非サーバー動作でHistoryライブラリを使うと、不正なURLを書き込もうとして
  // ライブラリ内でエラー発生し、SagaMiddlwareが停止する（＝Actionが発火しなくなる）
  // 危険なのでラッパーメソッドに寄せて、念のためTryCatchで挟んでおいた
  try {
    if (unitTest.isUnitTest) {
      return;
    }
    yield call(context.history.push, { pathname: actionsPAGENAMEXXX });
  } catch (error) {
    trace.traceDebug(`safeHistoryPushExecute failed : ${error}`);
  }
}

export function* redirectPage(
  context: any,
  action: IAction,
  actionsXXXSHOW: string,
  actionsPAGENAMEXXX: string,
  unitTest: IUnitTest,
  isReplace: boolean = false
) {
  trace.traceDebug(`redirector.redirectPage : ${actionsPAGENAMEXXX}`);
  // redirect to xxx page with XXX_SHOW action.
  yield call(callNextSaga, action, actionsXXXSHOW);
  // history.push execute when NOT-UnitTest.
  if (unitTest.isUnitTest) {
    return;
  }
  yield call(safeHistoryPushExecute, context, actionsPAGENAMEXXX, unitTest, isReplace);
}

export function* callNextSaga(action: IAction, actionType: string) {
  trace.traceDebug(`redirector.callNextSaga actionType : ${actionType}`);
  action.payload.actionType = actionType;
  action.type = actions.ROOT_ACTION_ASYNC;
  yield put({ ...action });
}

export function* callReducer(action: IAction, actionType: string) {
  trace.traceDebug(`redirector.callReducer actionType : ${actionType}`);
  action.payload.actionType = actionType;
  action.type = actions.SAGA_TO_REDUCER_ACTION;
  trace.traceDebug(`redirector.callReducer action : ${JSON.stringify(action)}`);
  yield put({ ...action });
}

export function* redirectPageWithStatusChange(
  context: any,
  action: IAction,
  statusChangeAction: string,
  actionsXXXSHOW: string,
  actionsPAGENAMEXXX: string,
  unitTest: IUnitTest = UnitTestDefault
) {
  trace.traceDebug(`redirector.redirectPageWithStatusChange : ${statusChangeAction}, ${actionsPAGENAMEXXX}`);

  // Since only one result can not be determined, conditions were set and made testable.
  if (unitTest.canStatusChangeAction) {
    // status change at reducer befor page redirect
    yield call(callReducer, action, statusChangeAction);
  }
  if (unitTest.canRedirectAction) {
    // redirect to XXX page.
    yield call(redirectPage, context, action, actionsXXXSHOW, actionsPAGENAMEXXX, unitTest);
  }
}
