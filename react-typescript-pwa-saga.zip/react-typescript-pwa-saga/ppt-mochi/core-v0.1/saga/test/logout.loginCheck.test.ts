import { expectSaga } from 'redux-saga-test-plan';
import { actions } from '../../actions';
import { IUnitTest } from '../../interface/IUnitTest';
import * as logout from '../logout';

describe('sagas.login.logoutWhenSessionExpired', () => {
  const context = {};
  const state = {};

  it('logoutWhenSessionExpired 1 ACTION_TYPE_PREFIX_LOGIN', () => {
    return (
      expectSaga(logout.logoutWhenSessionExpired, context, { payload: { actionType: actions.LOGIN_SHOW } })
        .withState(state)
        // .put({ type: null })
        .dispatch({ type: actions.ROOT_ACTION_ASYNC })
        .run()
    );
  });

  // it('logoutWhenSessionExpired 2 not-ACTION_TYPE_PREFIX_LOGIN SessionExpired 1', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: true,
  //     canRedirectAction: false,
  //     testReturnSessionExpired: true
  //   };
  //   // const stateLogin = { login: { username: "dummy", password: "dummy" } };
  //   return expectSaga(
  //     logout.logoutWhenSessionExpired,
  //     context,
  //     { payload: { actionType: actions.HOME_SHOW } },
  //     unitTest
  //   )
  //     .withState(state)
  //     .put({ type: actions.SAGA_TO_REDUCER_ACTION, payload: { actionType: actions.LOGOUT_LEAVE } })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  // it('logoutWhenSessionExpired 2 not-ACTION_TYPE_PREFIX_LOGIN SessionExpired 2', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: false,
  //     canRedirectAction: true,
  //     testReturnSessionExpired: true
  //   };
  //   // const stateLogin = { login: { username: "dummy", password: "dummy" } };
  //   return expectSaga(
  //     logout.logoutWhenSessionExpired,
  //     context,
  //     { payload: { actionType: actions.HOME_SHOW } },
  //     unitTest
  //   )
  //     .withState(state)
  //     .put({ payload: { actionType: actions.LOGIN_SHOW }, type: actions.ROOT_ACTION_ASYNC })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  // it('logoutWhenSessionExpired 3 ACTION_TYPE_PREFIX_LOGOUT not-SessionExpired 1', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: true,
  //     canRedirectAction: false,
  //     testReturnSessionExpired: false
  //   };
  //   // const stateLogin = { login: { username: "dummy", password: "dummy" } };
  //   return expectSaga(
  //     logout.logoutWhenSessionExpired,
  //     context,
  //     { payload: { actionType: actions.LOGOUT_SUBMIT } },
  //     unitTest
  //   )
  //     .withState(state)
  //     .put({ type: actions.SAGA_TO_REDUCER_ACTION, payload: { actionType: actions.LOGOUT_LEAVE } })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  // it('logoutWhenSessionExpired 3 ACTION_TYPE_PREFIX_LOGOUT not-SessionExpired 2', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: false,
  //     canRedirectAction: true,
  //     testReturnSessionExpired: false
  //   };
  //   return expectSaga(
  //     logout.logoutWhenSessionExpired,
  //     context,
  //     { payload: { actionType: actions.LOGOUT_SUBMIT } },
  //     unitTest
  //   )
  //     .withState(state)
  //     .put({ payload: { actionType: actions.LOGIN_SHOW }, type: actions.ROOT_ACTION_ASYNC })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  it('logoutWhenSessionExpired 4 other-action not-SessionExpired', () => {
    const unitTest: IUnitTest = {
      isUnitTest: true,
      canStatusChangeAction: true,
      canRedirectAction: false,
      testReturnSessionExpired: false
    };
    return (
      expectSaga(logout.logoutWhenSessionExpired, context, { payload: { actionType: actions.MEMBER_SHOW } }, unitTest)
        .withState(state)
        // .put({ type: null })
        .dispatch({ type: actions.ROOT_ACTION_ASYNC })
        .run()
    );
  });
});
