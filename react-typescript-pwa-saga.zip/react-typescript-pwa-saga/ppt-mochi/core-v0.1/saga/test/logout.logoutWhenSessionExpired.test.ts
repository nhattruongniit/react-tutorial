import { expectSaga } from 'redux-saga-test-plan';
import * as logout from '../logout';
import { actions } from '../../actions';
import { IUnitTest } from '../../interface/IUnitTest';

describe('sagas.login.loginCheckForUrlRedirect', () => {
  const context = {};
  const state = {};

  // it('logoutWhenSessionExpired SessionExpired action 1', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: true,
  //     canRedirectAction: false,
  //     testReturnSessionExpired: true
  //   };
  //   return expectSaga(logout.logoutWhenSessionExpired, context, {}, unitTest)
  //     .withState(state)
  //     .put({ type: actions.SAGA_TO_REDUCER_ACTION, payload: { actionType: actions.LOGOUT_LEAVE }, meta: {} })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  // it('logoutWhenSessionExpired SessionExpired action 2', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: false,
  //     canRedirectAction: true,
  //     testReturnSessionExpired: true
  //   };
  //   return expectSaga(logout.logoutWhenSessionExpired, context, {}, unitTest)
  //     .withState(state)
  //     .put({ type: actions.ROOT_ACTION_ASYNC, payload: { actionType: actions.LOGIN_SHOW }, meta: {} })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  it('logoutWhenSessionExpired NOT-SessionExpired action 1', () => {
    const unitTest: IUnitTest = {
      isUnitTest: true,
      canStatusChangeAction: true,
      canRedirectAction: false,
      testReturnSessionExpired: false
    };
    return (
      expectSaga(logout.logoutWhenSessionExpired, context, {}, unitTest)
        .withState(state)
        // .put({ type: null })
        .dispatch({ type: actions.ROOT_ACTION_ASYNC })
        .run()
    );
  });

  it('logoutWhenSessionExpired NOT-SessionExpired action 2', () => {
    const unitTest: IUnitTest = {
      isUnitTest: true,
      canStatusChangeAction: false,
      canRedirectAction: true,
      testReturnSessionExpired: false
    };
    return (
      expectSaga(logout.logoutWhenSessionExpired, context, {}, unitTest)
        .withState(state)
        // .put({ type: null })
        .dispatch({ type: actions.ROOT_ACTION_ASYNC })
        .run()
    );
  });
});
