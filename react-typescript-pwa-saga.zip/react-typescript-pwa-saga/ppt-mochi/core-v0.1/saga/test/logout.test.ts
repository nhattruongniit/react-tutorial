import { expectSaga } from 'redux-saga-test-plan';
import * as logout from '../logout';
import { actions } from '../../actions';
import { IUnitTest } from '../../interface/IUnitTest';

describe('sagas.logout', () => {
  const context = {};
  const state = {};

  // it('logout 1 LOGOUT_SUBMIT SessionExpired 1', () => {
  //   const unitTest: IUnitTest = {
  //     isUnitTest: true,
  //     canStatusChangeAction: true,
  //     canRedirectAction: false,
  //     testReturnSessionExpired: true
  //   };
  //   return expectSaga(logout.logout, context, { payload: { actionType: actions.LOGOUT_SUBMIT } }, unitTest)
  //     .withState(state)
  //     .put({ payload: { actionType: actions }, type: actions.SAGA_TO_REDUCER_ACTION })
  //     .dispatch({ type: actions.ROOT_ACTION_ASYNC })
  //     .run();
  // });

  it('logout 1 LOGOUT_SUBMIT SessionExpired 2', () => {
    const unitTest: IUnitTest = {
      isUnitTest: true,
      canStatusChangeAction: false,
      canRedirectAction: true,
      testReturnSessionExpired: true
    };
    return expectSaga(logout.logout, context, { payload: { actionType: actions.LOGOUT_SUBMIT } }, unitTest)
      .withState(state)
      .put({ payload: { actionType: actions.LOGIN_SHOW }, type: actions.ROOT_ACTION_ASYNC })
      .dispatch({ type: actions.ROOT_ACTION_ASYNC })
      .run();
  });

  it('logout 1 not-LOGOUT_SUBMIT', () => {
    const unitTest: IUnitTest = {
      isUnitTest: true,
      canStatusChangeAction: true,
      canRedirectAction: false,
      testReturnSessionExpired: true
    };
    return (
      expectSaga(logout.logout, context, { payload: { actionType: actions.HOME_SHOW } }, unitTest)
        .withState(state)
        // .put({ type: null })
        .dispatch({ type: actions.ROOT_ACTION_ASYNC })
        .run()
    );
  });
});
