import * as model from '../models';

test('should all in model are imported success', () => {
  expect(model).toBeDefined();
});
