export enum FetchApiStatus {
  None,
  Fetching,
  Success,
  Error,
  Cancelled
}
