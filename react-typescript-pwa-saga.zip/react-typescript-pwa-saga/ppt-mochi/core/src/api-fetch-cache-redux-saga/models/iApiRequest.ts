import { IHttpRequest } from './iHttpRequest';
import { IRequestRetry } from './iRequestRetry';

export interface IApiRequest {
  key: string;
  option?: IRequestOption;
  meta?: any;
  httpRequest: IHttpRequest;
  requestHook?: () => IRequestHook;
}

export interface IRequestOption {
  noLoading?: boolean;
  noCached?: boolean;
  meta?: any;
  noApiToken?: boolean | true;
  requestHook?: () => IRequestHook;
  fetch?: (httpRequest: IHttpRequest) => Promise<any>;
}

export interface IRequestHook {
  shouldRequestRetry: (response) => Promise<IRequestRetry>;
  getRetryRequest: (prev: IApiRequest) => IApiRequest;
  isResponseValid: (response) => boolean;
}
