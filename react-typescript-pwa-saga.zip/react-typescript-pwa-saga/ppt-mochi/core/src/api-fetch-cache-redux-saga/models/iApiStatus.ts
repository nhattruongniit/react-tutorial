import { FetchApiStatus } from './fetchApiStatus';
import { IApiRequest } from './iApiRequest';

export interface IApiStatus {
  status: FetchApiStatus;
  request: IApiRequest;
  httpResponse?: any;
  httpResponseJson?: any;
  httpResponseError?: any;
  gotAt?: Date;
  cached?: boolean;
}
