import { IApiStatus } from './iApiStatus';

export interface IApiStatusesMap {
  [key: string]: IApiStatus;
}
