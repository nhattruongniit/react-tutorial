import { IApiStatusesMap } from './iApiStatusesMap';
import { IApiStatus } from './iApiStatus';

export interface IFetchApiStatuses {
  isFetchingWithLoading: boolean;
  statuses: IApiStatusesMap;
  latestFetching?: IApiStatus;
}
