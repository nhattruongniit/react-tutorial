import { RequestMethod } from './requestMethod';

export interface IHttpRequest {
  fullUrl: string;
  method: RequestMethod;
  headers?: any;
  body?: any;
}
