export interface IRequestRetry {
  shouldRetry: boolean;
  refreshApiTokenSuccess: boolean;
}
