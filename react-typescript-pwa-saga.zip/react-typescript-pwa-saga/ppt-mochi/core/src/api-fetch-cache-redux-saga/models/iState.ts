import { IFetchApiStatuses } from './iFetchApiStatuses';

// State redux for Apps
export interface IState {
  fetchApi: IFetchApiStatuses;
}
