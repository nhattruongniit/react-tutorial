export enum RequestMethod {
  Get = 'GET',
  Post = 'POST'
}
