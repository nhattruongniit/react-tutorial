import * as actions from '../actions';

test('should all actions are imported success', () => {
  expect(actions).toBeDefined();
});
