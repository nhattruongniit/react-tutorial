import * as reducer from '../reducers';
import { initialState } from '../reducers';
import { fetchApi, fetchApiSuccess, fetchApiFailure, fetchApiCancelled, fetchApiRequesting } from '../actions';
import { IFetchApiStatuses, RequestMethod, FetchApiStatus } from '../..';

test('reducer should be imported successfully', () => {
  expect(reducer).toBeDefined();
});

test('reducer default should be a function', () => {
  expect(reducer.default).toBeInstanceOf(Function);
});

const testRequest = {
  key: 'TEST_REQUEST',
  httpRequest: {
    fullUrl: process.env.REACT_APP_PROD_API_URL as string,
    method: RequestMethod.Post,
    headers: { 'Accept-Charset': 'UTF-8', 'Content-Type': 'text/plain' },
    body: {}
  }
};

test('reducer with FETCH_API action status should be fetching', () => {
  const newState: IFetchApiStatuses = reducer.default(initialState, fetchApiRequesting(testRequest));

  expect(newState).toBeDefined();
  expect(newState.isFetchingWithLoading).toBeTruthy();
});

test('reducer with FETCH_API_SUCCESS action status should be fetching', () => {
  const newState: IFetchApiStatuses = reducer.default(
    initialState,
    fetchApiSuccess({
      request: testRequest,
      status: FetchApiStatus.Success,
      httpResponse: {},
      httpResponseJson: {}
    })
  );

  expect(newState.isFetchingWithLoading).toBeFalsy();
});

test('reducer with FETCH_API_SUCCESS action status should be fetching with cached', () => {
  const newState: IFetchApiStatuses = reducer.default(
    initialState,
    fetchApiSuccess({
      request: testRequest,
      status: FetchApiStatus.Success,
      httpResponse: {},
      httpResponseJson: {},
      cached: true
    })
  );

  expect(newState.isFetchingWithLoading).toBeFalsy();
});

test('reducer with FETCH_API_FAILURE action status should be fetching', () => {
  const newState: IFetchApiStatuses = reducer.default(
    initialState,
    fetchApiFailure({
      request: testRequest,
      status: FetchApiStatus.Success,
      httpResponse: {},
      httpResponseJson: {},
      cached: false
    })
  );
  expect(newState.isFetchingWithLoading).toBeFalsy();
});

test('reducer with FETCH_API_CANCELLED action status should be fetching', () => {
  const newState: IFetchApiStatuses = reducer.default(
    initialState,
    fetchApiCancelled({
      request: { ...testRequest, option: { noLoading: true } },
      status: FetchApiStatus.Fetching,
      httpResponse: {},
      httpResponseJson: {},
      cached: false
    })
  );
  expect(newState.isFetchingWithLoading).toBeFalsy();
});
