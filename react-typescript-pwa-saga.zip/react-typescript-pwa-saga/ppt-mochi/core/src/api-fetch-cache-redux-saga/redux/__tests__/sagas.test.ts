import * as sagas from '../sagas';
import { fetchApiSaga, fetchNetworkApi as r } from '../sagas';
import { FETCH_API } from '../constants';
import { takeEvery } from 'redux-saga/effects';
import { RequestMethod } from '../../models';
import { fetchApi } from '../actions';
import { expectSaga, SagaType } from 'redux-saga-test-plan';

const fetchNetworkApi = r as SagaType;
declare let global: {
  fetch: {};
};

test('import saga should success', () => {
  expect(sagas).toBeDefined();
});

test('default saga should wait for FETCH_API.ACTION', () => {
  expectSaga(sagas.default).take(FETCH_API.ACTION);
});

const testRequest: any = {
  key: 'TEST_REQUEST',
  httpRequest: {
    fullUrl: process.env.REACT_APP_PROD_API_URL as string,
    method: RequestMethod.Post,
    headers: { 'Accept-Charset': 'UTF-8', 'Content-Type': 'text/plain' },
    body: {}
  }
};

test('fetchNetworkApi saga catch', () => {
  const fakeFetch = jest.fn().mockImplementation(() => {
    throw new Error();
  });
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .catch((err) => {
      expect(fakeFetch).toBeCalled();
    });
});

test('fetchNetworkApi saga when fetch response failure', () => {
  const fakeFetch = jest.fn().mockImplementation(() => ({
    ok: false
  }));
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result: any) => {
      const json = result.toJSON();
      expect(json.put).toBeDefined();
      expect(json.put.length).toBe(2);
      expect(json.call).toBeDefined();
      expect(json.call.length).toBe(1);
    });
});

test('fetchNetworkApi saga when fetch response ok', () => {
  const fakeFetch = jest.fn().mockImplementation(() => ({
    ok: true,
    json: () => ({ success: true })
  }));
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result: any) => {
      const json = result.toJSON();
      expect(json.put).toBeDefined();
      expect(json.put.length).toBe(2);
      expect(json.call).toBeDefined();
      expect(json.call.length).toBe(2);
    });
});

test('fetchNetworkApi saga fetch response ok, cancel current response dispatch', () => {
  const fakeFetch = jest.fn().mockImplementation(() => ({
    ok: true,
    json: (response) => ({ success: true })
  }));
  testRequest.option = {
    getRetryRequest: (origin) => {
      return origin;
    },
    requestHook: () => ({
      shouldRequestRetry: (json) => ({
        shouldRetry: false,
        refreshApiTokenSuccess: false
      })
    })
  };
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result: any) => {
      const json = result.toJSON();
      expect(json.put).toBeDefined();
      expect(json.put.length).toBe(2);
      expect(json.call).toBeDefined();
      expect(json.call.length).toBe(4);
    });
});

test('fetchNetworkApi saga: fetch response ok, cancel current dispatch response and retry with new request', () => {
  const fakeFetch = jest.fn().mockImplementation(() => ({
    ok: true,
    json: (response) => ({ success: true })
  }));
  testRequest.option = {
    requestHook: () => ({
      shouldRequestRetry: (json) => ({
        shouldRetry: true,
        refreshApiTokenSuccess: false
      }),
      getRetryRequest: (origin) => {
        return origin;
      }
    })
  };
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result: any) => {
      const json = result.toJSON();
      expect(json.put).toBeDefined();
      expect(json.put.length).toBe(2);
      expect(json.call).toBeDefined();
      expect(json.call.length).toBe(5);
    });
});

test("fetchNetworkApi saga: fetch response ok, shouldn't retry and don't refresh", () => {
  const fakeFetch = jest.fn().mockImplementation(() => ({
    ok: true,
    json: (response) => ({ success: true })
  }));
  testRequest.option = {
    requestHook: () => ({
      shouldRequestRetry: (json) => ({
        shouldRetry: false,
        refreshApiTokenSuccess: true
      }),
      getRetryRequest: (origin) => {
        return origin;
      }
    })
  };
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result: any) => {
      const json = result.toJSON();
      expect(json.put).toBeDefined();
      expect(json.put.length).toBe(2);
      expect(json.call).toBeDefined();
      expect(json.call.length).toBe(4);
    });
});

test('fetchApiSaga no cache', () => {
  const fakeFetch = jest.fn().mockImplementation(() => {
    throw new Error();
  });
  global.fetch = fakeFetch;
  testRequest.option = {
    noCached: true
  };
  const action = fetchApi(testRequest);
  expectSaga(fetchApiSaga, action)
    .run()
    .catch((err) => {
      expect(fakeFetch).toBeCalled();
    });
});

test('fetchApiSaga cache not expired', () => {
  process.env = { ...process.env, REACT_APP_CACHED_CONTENTS_EXPIRE_MINUTES: '15' };
  const fakeFetch = jest.fn().mockImplementation(() => {
    throw new Error();
  });

  testRequest.option = {
    noCached: false
  };
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  const apiStatuses = [];
  apiStatuses['TEST_REQUEST'] = {
    httpResponseJson: {},
    httpResponse: {},
    gotAt: new Date().getTime()
  };

  expectSaga(fetchApiSaga, action)
    .withState({
      fetchApi: {
        statuses: apiStatuses
      }
    })
    .run()
    .catch((err) => {
      expect(fakeFetch).not.toBeCalled();
    });
});

test('fetchApiSaga cache expired', () => {
  process.env = { ...process.env, REACT_APP_CACHED_CONTENTS_EXPIRE_MINUTES: '15' };
  const fakeFetch = jest.fn().mockImplementation(() => {
    throw new Error();
  });

  testRequest.option = {
    noCached: false
  };
  global.fetch = fakeFetch;
  const action = fetchApi(testRequest);
  const apiStatuses = [];
  apiStatuses['TEST_REQUEST'] = {
    httpResponseJson: {},
    httpResponse: {},
    gotAt: 0
  };

  expectSaga(fetchApiSaga, action)
    .withState({
      fetchApi: {
        statuses: apiStatuses
      }
    })
    .run()
    .catch((err) => {
      expect(fakeFetch).not.toBeCalled();
    });
});

test('fetchNetworkApi saga custom fetch', () => {
  const fakeOptionFetch = jest.fn().mockImplementation(() => ({
    ok: true
  }));

  testRequest.option = { fetch: fakeOptionFetch };
  const action = fetchApi(testRequest);
  expectSaga(fetchNetworkApi, action)
    .run()
    .then((result) => {
      expect(fakeOptionFetch).toBeCalled();
    });
});
