import { createAction } from 'redux-actions';
import { FETCH_API } from './constants';

export const fetchApi = createAction(FETCH_API.ACTION);
export const fetchApiRequesting = createAction(FETCH_API.REQUESTING);
export const fetchApiSuccess = createAction(FETCH_API.SUCCESS);
export const fetchApiFailure = createAction(FETCH_API.FAILURE);
export const fetchApiCancelled = createAction(FETCH_API.CANCELLED);
