import { defineAction } from 'redux-define';

export const FETCH_API = defineAction('FETCH_API_REQUEST', ['REQUESTING', 'FAILURE', 'SUCCESS', 'CANCELLED']);
