import { IHttpRequest } from '../models/iHttpRequest';

export async function defaultFetch(httpRequest: IHttpRequest) {
  const { fullUrl, method, headers, body } = httpRequest;
  const response = await fetch(fullUrl, {
    method: method.toString(),
    headers,
    body: JSON.stringify(body)
  });
  return response;
}
