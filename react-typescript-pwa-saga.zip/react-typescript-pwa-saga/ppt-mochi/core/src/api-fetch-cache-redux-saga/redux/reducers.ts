import { handleActions } from 'redux-actions';
import { FETCH_API } from './constants';
import { IFetchApiStatuses } from '../models/iFetchApiStatuses';
import { IApiStatus } from '../models/iApiStatus';
import { IApiRequest } from '../models/iApiRequest';
import { FetchApiStatus } from '../models/fetchApiStatus';

export const initialState: IFetchApiStatuses = {
  isFetchingWithLoading: false,
  statuses: {}
};

const transform = (currentState: IFetchApiStatuses, action, request: IApiRequest): IFetchApiStatuses => {
  const newState: IFetchApiStatuses = { ...currentState };
  if (action.type === FETCH_API.REQUESTING) {
    newState.isFetchingWithLoading = true;
    return newState;
  }

  let apiStatus: IApiStatus = action.payload;

  if (!apiStatus || !apiStatus.status) {
    apiStatus = { ...currentState.statuses[request.key], status: FetchApiStatus.Fetching, request };
  }
  if (!request.option || !request.option.noCached) {
    newState.statuses[request.key] = apiStatus;
  }
  switch (apiStatus.status) {
    case FetchApiStatus.Fetching:
      newState.latestFetching = apiStatus;
      break;
    case FetchApiStatus.Success:
      if (!apiStatus.cached) {
        apiStatus.gotAt = new Date();
      }
      break;
  }

  newState.isFetchingWithLoading = isFetchingWithLoading(request, action, newState);

  return newState;
};

export const fetchApiReducer = handleActions(
  {
    [FETCH_API.REQUESTING]: (state: IFetchApiStatuses, action): IFetchApiStatuses =>
      transform(state, action, { ...action.payload, status: FetchApiStatus.Fetching }),
    [FETCH_API.SUCCESS]: (state: IFetchApiStatuses, action): IFetchApiStatuses =>
      transform(state, action, { ...action.payload.request, status: FetchApiStatus.Success }),
    [FETCH_API.FAILURE]: (state: IFetchApiStatuses, action): IFetchApiStatuses =>
      transform(state, action, { ...action.payload.request, status: FetchApiStatus.Error }),
    [FETCH_API.CANCELLED]: (state: IFetchApiStatuses, action): IFetchApiStatuses =>
      transform(state, action, { ...action.payload.request, status: FetchApiStatus.Cancelled })
  },
  initialState
);

export default fetchApiReducer;
function isFetchingWithLoading(request: IApiRequest, action, newState: IFetchApiStatuses): boolean {
  const { payload: apiStatus } = action;
  if (apiStatus && apiStatus.status === FetchApiStatus.Fetching && (!request.option || !request.option.noLoading)) {
    return true;
  }
  let result = false;
  Object.keys(newState.statuses).forEach((key: string) => {
    const value = newState.statuses[key];
    if (value.status === FetchApiStatus.Fetching && (!value.request.option || !value.request.option.noLoading)) {
      result = true;
      return false;
    }
    return true;
  });

  return result;
}
