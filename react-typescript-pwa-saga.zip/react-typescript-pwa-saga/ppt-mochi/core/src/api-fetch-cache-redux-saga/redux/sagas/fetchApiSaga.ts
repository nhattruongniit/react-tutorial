import { call, select, put } from 'redux-saga/effects';
import { fetchApiSuccess, fetchApiRequesting } from '../../redux/actions';
import { fetchNetworkApi } from '../sagas/fetchNetworkApi';
import { IState } from '../../models/iState';
import { IApiRequest } from '../../models/iApiRequest';
import { IApiStatus } from '../../models/iApiStatus';
import { FetchApiStatus } from '../../models/fetchApiStatus';

export function* fetchApiSaga<S extends IState>(action) {
  const request: IApiRequest = action.payload;
  const { option } = request;
  const responseAction: IApiStatus = { request, status: FetchApiStatus.Fetching };

  if (!option || !option.noCached) {
    const cachedApiStatus = yield select((state: S, key: string) => state.fetchApi.statuses[key], request.key);

    if (cachedApiStatus) {
      const { httpResponseJson, httpResponse } = cachedApiStatus;
      const gotAt = new Date(cachedApiStatus.gotAt);
      if (
        gotAt &&
        new Date().getTime() - gotAt.getTime() <
          parseInt(process.env.REACT_APP_CACHED_CONTENTS_EXPIRE_MINUTES as string, 10) * 60 * 1000
      ) {
        yield put(fetchApiRequesting());
        const successAction = fetchApiSuccess({
          ...responseAction,
          status: FetchApiStatus.Success,
          httpResponse,
          httpResponseJson,
          cached: true,
          gotAt
        });
        yield put(successAction);
        return yield successAction;
      }
    }
  }

  return yield call(fetchNetworkApi, action);
}
