import { takeEvery } from 'redux-saga';
import { fetchApiSaga } from './fetchApiSaga';
import { FETCH_API } from '../constants';

export function* fetchApiWatcher() {
  yield takeEvery(FETCH_API.ACTION, fetchApiSaga);
}
