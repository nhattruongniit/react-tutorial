import { call, put } from 'redux-saga/effects';
import { IApiRequest } from '../../models/iApiRequest';
import { FetchApiStatus } from '../../models/fetchApiStatus';
import { IApiStatus } from '../../models/iApiStatus';
import { defaultFetch } from '../fetch';
import { fetchApiCancelled, fetchApiSuccess, fetchApiFailure, fetchApiRequesting } from '../actions';

export function* fetchNetworkApi(action) {
  yield put(fetchApiRequesting());
  const request: IApiRequest = action.payload;
  const { httpRequest, option } = request;
  const responseAction: IApiStatus = { request, status: FetchApiStatus.Fetching };
  try {
    const httpResponse = yield call(option && option.fetch ? option.fetch : defaultFetch, httpRequest);

    if (httpResponse.ok) {
      const httpResponseJson = yield call(async (response) => await response.json(), httpResponse);
      if (request.option && request.option.requestHook) {
        const requestEffects = yield call(request.option.requestHook);
        const { shouldRetry, refreshApiTokenSuccess } = yield call(requestEffects.shouldRequestRetry, httpResponseJson);
        if (shouldRetry) {
          const retryRequest = yield call(requestEffects.getRetryRequest, request);
          return yield put({ ...action, payload: retryRequest });
        } else if (!refreshApiTokenSuccess) {
          const cancelledAction = fetchApiCancelled({
            ...responseAction,
            status: FetchApiStatus.Cancelled,
            httpResponse
          });
          yield put(cancelledAction);
          return yield cancelledAction;
        }
      }

      const successAction = fetchApiSuccess({
        ...responseAction,
        status: FetchApiStatus.Success,
        response: httpResponse,
        httpResponseJson
      });
      yield put(successAction);
      return yield successAction;
    } else {
      const failureAction = fetchApiFailure({ ...responseAction, status: FetchApiStatus.Error, httpResponse });
      yield put(failureAction);
      return yield failureAction;
    }
  } catch (httpResponseError) {
    const failureAction = fetchApiFailure({ ...responseAction, status: FetchApiStatus.Error, httpResponseError });
    yield put(failureAction);
    return yield failureAction;
  }
}
