import { fetchApiWatcher } from './fetchApiWatcher';
import { fetchNetworkApi } from './fetchNetworkApi';
import { fetchApiSaga } from './fetchApiSaga';
const fetchApiSagas = [fetchApiWatcher];
export default fetchApiWatcher;
export { fetchApiWatcher, fetchNetworkApi, fetchApiSaga, fetchApiSagas };
