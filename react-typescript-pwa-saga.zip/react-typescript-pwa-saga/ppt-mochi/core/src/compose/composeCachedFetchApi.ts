import { defaultPersistConfig, defaultLocalforageConfig } from '../default-config/defaultStoreConfig';
import { IStoreConfig } from '../configure-persist-redux-saga/iStoreConfig';
import { configure } from '../configure-persist-redux-saga/configurePersistStore';
import { fetchApiReducer as fetchApi } from '../api-fetch-cache-redux-saga/redux/reducers';
import { fetchApiWatcher } from '../api-fetch-cache-redux-saga/redux/sagas/fetchApiWatcher';
import { PersistConfig } from 'redux-persist';

export const composeConfigureCachedFetchStore = (config?: IStoreConfig) => {
  const reducers = config && config.reducers ? { fetchApi, ...config.reducers } : { fetchApi };

  const sagas = config && config.sagas ? [fetchApiWatcher, ...config.sagas] : [fetchApiWatcher];

  const persistConfig: PersistConfig =
    config && config.persistConfig ? { ...defaultPersistConfig, ...config.persistConfig } : defaultPersistConfig;
  const localforageConfig =
    config && config.localforageConfig
      ? { ...defaultLocalforageConfig, ...config.localforageConfig }
      : defaultLocalforageConfig;

  const composedConfig = {
    persistConfig: {
      ...persistConfig,
      whitelist: persistConfig.whitelist ? ['fetchApi', ...persistConfig.whitelist] : ['fetchApi']
    },
    localforageConfig,
    sagas,
    reducers
  };

  return configure(composedConfig);
};
