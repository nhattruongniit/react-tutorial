jest.mock('localforage', () => ({
  config: () => true
}));

jest.mock('redux-persist', () => ({
  persistStore: () => true,
  persistReducer: () => true,
  PersistConfig: () => true,
  createTransform: () => true
}));

const run = jest.fn(() => true);

jest.mock('redux-saga', () => ({
  __esModule: true,
  namedExport: run,
  default: () => {
    return {
      run
    };
  }
}));
let mockReducers: object = {};
jest.mock('redux', () => ({
  createStore: () => true,
  applyMiddleware: () => true,
  combineReducers: (reducers: any[]) => {
    mockReducers = reducers;
    return mockReducers;
  },
  compose: () => true
}));

import { configure } from '../configurePersistStore';
import { createReducerManager } from '../reducerManager';
import { injectReducer, removeReducer } from '../helpers';
import { composeConfigureCachedFetchStore } from '../../compose/composeCachedFetchApi';

test('should import injectReducer successfully', () => {
  expect(injectReducer).toBeDefined();
});

test('should import createReducerManager successfully', () => {
  expect(createReducerManager).toBeDefined();
});
test('should import configure store function successfully', () => {
  expect(configure).toBeDefined();
});

test('should inject/remove reducer success', () => {
  const { reducersManager } = composeConfigureCachedFetchStore();
  const reducersLength = Object.keys(mockReducers).length;
  injectReducer(reducersManager, 'test reducer', {});
  expect(Object.keys(mockReducers).length).toBeGreaterThan(reducersLength);

  const newReducersLength = Object.keys(mockReducers).length;
  injectReducer(reducersManager, 'test reducer', {});
  expect(Object.keys(mockReducers).length).toEqual(newReducersLength);

  removeReducer(reducersManager, 'test reducer');
  expect(Object.keys(mockReducers).length).toEqual(reducersLength);

  removeReducer(reducersManager, 'undefined');
  expect(Object.keys(mockReducers).length).toEqual(reducersLength);
});
