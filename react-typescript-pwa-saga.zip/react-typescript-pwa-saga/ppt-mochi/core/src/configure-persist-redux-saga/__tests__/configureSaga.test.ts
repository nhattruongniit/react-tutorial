const mockInjectSagaFun = jest.fn(() => true);
jest.mock('redux-saga-watch-actions/lib/middleware', () => ({
  __esModule: true,
  namedExport: mockInjectSagaFun,
  default: () => ({
    injectSaga: mockInjectSagaFun,
    cancelTask: () => true
  })
}));
import { sagaMiddleware, cancelTask, injectSaga, runSaga } from '..';

test('should import sagaMiddleware success', () => {
  expect(sagaMiddleware).toBeDefined();
});

test('should import cancelTask success', () => {
  expect(cancelTask).toBeDefined();
});

test('should import injectSaga success', () => {
  expect(injectSaga).toBeDefined();
});

test('should import runSaga success', () => {
  expect(runSaga).toBeDefined();
});

test('should runSaga callable', () => {
  const mockRunSaga = jest.spyOn(sagaMiddleware, 'run').mockImplementation();
  const saga = {};
  runSaga(saga);
  expect(mockRunSaga).toBeCalledWith(saga);
});

test('should injectSaga callable', () => {
  const saga = {};
  const key = 'key';
  injectSaga(key, saga);
  expect(mockInjectSagaFun).toBeCalled();
});
