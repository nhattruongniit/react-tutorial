import { createStore, applyMiddleware, compose } from 'redux';
import { persistStore, persistReducer, PersistConfig } from 'redux-persist';
import * as storage from 'localforage';
import { all } from 'redux-saga/effects';
import { createReducerManager } from './reducerManager';
import sagaMiddleware from './configureSaga';
import { IStoreConfig } from './iStoreConfig';

const composeEnhancers = (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

export const configure = (config: IStoreConfig) => {
  const { persistConfig, localforageConfig, reducers } = config;
  const rootSaga = function*() {
    const sagas = [];
    if (config && config.sagas) {
      config.sagas.forEach((s) => sagas.push(s() as never));
    }
    yield all(sagas);
  };
  storage.config(localforageConfig as LocalForageOptions);
  const reducersManager = createReducerManager(reducers);
  const persistedReducer = persistReducer(persistConfig as PersistConfig, reducersManager.reduce);
  const store = createStore(persistedReducer, composeEnhancers(applyMiddleware(sagaMiddleware)));
  const persister = persistStore(store);
  sagaMiddleware.run(rootSaga);
  return { store, persister, reducersManager };
};
