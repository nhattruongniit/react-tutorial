import createSagaMiddleware from 'redux-saga';
import createSagaMiddlewareHelpers from 'redux-saga-watch-actions/lib/middleware';

const SAGA_MONITOR_EXTENSION = '__SAGA_MONITOR_EXTENSION__';
const monitor = window[SAGA_MONITOR_EXTENSION];
const sagaMiddleware = createSagaMiddleware({ sagaMonitor: monitor });
const runSaga = (saga) => {
  sagaMiddleware.run(saga);
};
const { injectSaga, cancelTask } = createSagaMiddlewareHelpers(sagaMiddleware, runSaga);

const injectSagaFun = (key: any, saga: any, args?: any) => {
  injectSaga({ saga, key, args });
};
export { cancelTask, injectSagaFun as injectSaga, runSaga, sagaMiddleware };
export default sagaMiddleware;
