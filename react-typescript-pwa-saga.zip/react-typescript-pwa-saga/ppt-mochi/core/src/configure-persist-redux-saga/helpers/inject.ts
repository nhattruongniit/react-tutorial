export function injectReducer(reducersManager, key: string, reducer: any) {
  reducersManager.add(key, reducer);
}

export function removeReducer(reducersManager, key: string) {
  reducersManager.remove(key);
}
