import { PersistConfig } from 'redux-persist';

export interface IStoreConfig {
  localforageConfig?: LocalForageOptions;
  persistConfig?: PersistConfig;
  reducers?: any;
  sagas?: Array<() => any>;
}
