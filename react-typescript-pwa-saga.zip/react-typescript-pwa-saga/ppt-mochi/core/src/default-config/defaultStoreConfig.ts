import { createBlacklistFilter } from 'redux-persist-transform-filter';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';

import * as storage from 'localforage';

export const defaultLocalforageConfig: LocalForageOptions = {
  name: 'redux',
  storeName: 'persists'
};

const fetchApiSubsetBlacklistFilter = createBlacklistFilter('fetchApi', ['isFetchingWithLoading']);

export const defaultPersistConfig = {
  key: '__redux_persists__',
  storage,
  transforms: [fetchApiSubsetBlacklistFilter],
  stateReconciler: autoMergeLevel2
};
