import fetchWrap = require('fetch-wrap');
export const apply = (middleware: any[]) => {
  (window as any).fetch = fetchWrap(fetch, middleware);
};
