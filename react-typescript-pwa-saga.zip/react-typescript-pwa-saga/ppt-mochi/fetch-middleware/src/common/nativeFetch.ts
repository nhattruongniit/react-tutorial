export const nativeFetch = (url: string, options, fetch): Promise<any> => fetch(url, options);
