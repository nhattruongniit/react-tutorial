import { DeviceUUID } from 'device-uuid';
import { apply } from '../../apply/apply';
import { IAnonymousTokenInfo } from '../../middleware/anonymous-token/models/iAnonymousTokenInfo';
import { anonymousToken } from '../../middleware/anonymous-token/anonymousToken';

const { REACT_APP_PROD_API_URL } = process.env;
const anonymousChecks: Map<string, (url: string, options) => boolean> = new Map<
  string,
  (url: string, options) => boolean
>();

export const injectAnonymousCheck = (key: string, check: (url: string, options) => boolean) => {
  if (anonymousChecks.has(key)) {
    return;
  }
  anonymousChecks.set(key, check);
};

export const anonymousTokenConfig = {
  isAnonymous: (url: string, options) => {
    for (const check of anonymousChecks.values()) {
      if (check(url, options)) {
        return true;
      }
    }
    return false;
  },
  isResultOK: res =>
    (async () => {
      return true; // (await res.json()).isSuccess as boolean;
    })(),
  attachAnonymousToken: (tokenInfo: IAnonymousTokenInfo, url: string, options) => {
    let body = { anonymousToken: '', expireDateTime: 0 };
    body = JSON.parse(options.body);

    body.anonymousToken = tokenInfo.token;
    body.expireDateTime = tokenInfo.expire;
    return { url, options: { ...options, body: JSON.stringify(body) } };
  },
  getAnonymousTokenRequest: () => ({
    url: REACT_APP_PROD_API_URL as string,
    options: {
      method: 'POST',
      body: JSON.stringify({
        mode: 'MODE_CREATE_ANONYMOUS_TOKEN',
        param: {
          tenantId: { content: '1' },
          uuid: { content: new DeviceUUID().get() }
        }
      })
    }
  }),
  resolveAnonymousTokenResponse: (res: Response) => {
    return (async () => {
      const json = await res.json();
      const { anonymousToken: token, expireDateTime: expire } = json;

      return { token, expire } as IAnonymousTokenInfo;
    })();
  }
};

export const applyAnonymousToken = () => {
  apply([anonymousToken(anonymousTokenConfig)]);
};
