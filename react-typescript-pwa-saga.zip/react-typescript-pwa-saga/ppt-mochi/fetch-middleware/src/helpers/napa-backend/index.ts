export * from './applyAnonymousToken';
