import { IAnonymousConfig } from './models/iAnonymousConfig';
import * as localforage from 'localforage';
import { IAnonymousTokenInfo } from './models/iAnonymousTokenInfo';
import { nativeFetch } from '../../common/nativeFetch';

const ANONYMOUS_STORAGE_KEY = '__ANONYMOUS_ACCESS_INFO__';

const store = localforage.createInstance({
  name: 'fetch_middle_anonymous_token'
});

store.config({
  driver: localforage.INDEXEDDB, // Force WebSQL; same as using setDriver()
  name: 'fetch-middle-anonymous-token',
  storeName: 'fetch_middle_anonymous_token' // Should be alphanumeric, with underscores.
});

export const getAnonymousToken = async (config: IAnonymousConfig) => {
  try {
    const savedAnonymousInfoStr = await store.getItem(ANONYMOUS_STORAGE_KEY);
    let savedAnonymousInfo: IAnonymousTokenInfo = {
      token: '',
      expire: 0
    };
    if (savedAnonymousInfoStr) {
      savedAnonymousInfo = JSON.parse(savedAnonymousInfoStr as string) as IAnonymousTokenInfo;
    }

    if (!savedAnonymousInfoStr || savedAnonymousInfo!.expire - new Date().getTime() < (config.expireOffset || 5000)) {
      const { url: getAnonymousTokenUrl, options: getAnonymousTokenOptions } = config.getAnonymousTokenRequest();
      const requestAnonymousTokenResponse = await nativeFetch(getAnonymousTokenUrl, getAnonymousTokenOptions, fetch);
      savedAnonymousInfo = await config.resolveAnonymousTokenResponse(requestAnonymousTokenResponse);
      store.setItem(ANONYMOUS_STORAGE_KEY, JSON.stringify(savedAnonymousInfo));
    }

    return Promise.resolve(savedAnonymousInfo);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const anonymousToken = (config: IAnonymousConfig) => async (url: string, options, fetch): Promise<any> => {
  try {
    if (config.isAnonymous(url, options)) {
      const savedAnonymousInfo = await getAnonymousToken(config);

      const { url: anonymousUrl, options: anonymousOptions } = config.attachAnonymousToken(
        savedAnonymousInfo!,
        url,
        options
      );
      const anonymousResponse = await nativeFetch(anonymousUrl, anonymousOptions, fetch);
      if (!(await config.isResultOK(anonymousResponse.clone()))) {
        console.error('Fetch anonymous API error!', anonymousResponse);
        return Promise.reject({ error: new Error('Fetch anonymous API error!'), response: anonymousResponse });
      }

      return Promise.resolve(anonymousResponse);
    }
  } catch (e) {
    Promise.reject(e);
  }

  return nativeFetch(url, options, fetch);
};
