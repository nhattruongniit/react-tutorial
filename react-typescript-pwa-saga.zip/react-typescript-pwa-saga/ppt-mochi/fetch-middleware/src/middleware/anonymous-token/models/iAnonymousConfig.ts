import { IAnonymousTokenInfo } from './iAnonymousTokenInfo';

export interface IAnonymousConfig {
  expireOffset?: number;
  isAnonymous: (url: string, options) => boolean;
  isResultOK: (res) => Promise<boolean>;
  attachAnonymousToken: (
    tokenInfo: IAnonymousTokenInfo,
    previousUrl: string,
    previousOptions
  ) => { url: string; options };
  getAnonymousTokenRequest: () => { url: string; options };
  resolveAnonymousTokenResponse: (res: Response) => Promise<IAnonymousTokenInfo>;
}
