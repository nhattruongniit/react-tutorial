export interface IAnonymousTokenInfo {
  token: string;
  expire: number;
}
