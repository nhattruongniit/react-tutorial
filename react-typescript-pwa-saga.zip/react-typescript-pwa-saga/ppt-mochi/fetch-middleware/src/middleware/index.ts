export * from './anonymous-token';
