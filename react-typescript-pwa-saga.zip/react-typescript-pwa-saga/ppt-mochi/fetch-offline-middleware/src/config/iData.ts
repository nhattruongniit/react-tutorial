export interface IData {
  _id: string;
}
