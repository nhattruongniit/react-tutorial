import { IData } from './iData';

export interface IOfflineConfig<S extends IData> {
  for: (url, options) => boolean;
  rows?: (data) => S[];
  to: { dbName: string };
  when: () => boolean;
  getConfig: (url, options) => any;
}
