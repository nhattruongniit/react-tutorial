import { IOfflineConfig } from '../config';
import { IData } from '../config/iData';
import { nativeFetch } from '@mochi/fetch-middleware';
import PouchDB from 'pouchdb';
import search = require('pouchdb-quick-search');
PouchDB.plugin(search);

export function offlineSave<T extends IData>(configs: Array<IOfflineConfig<T>> = []) {
  return (url, options, fetch) => {
    let needProcess = false;
    configs.some((config: IOfflineConfig<T>) => {
      if (config.for(url, options) && config.when()) {
        needProcess = true;
        return true;
      }
      return false;
    });

    if (!needProcess) {
      return nativeFetch(url, options, fetch);
    }

    return new Promise((resolve, reject) => {
      nativeFetch(url, options, fetch).then(result => {
        const resultJsonHandler = data => {
          configs.forEach((config: IOfflineConfig<T>) => {
            if (config.for(url, options) && config.when()) {
              const { fields } = config.getConfig(url, options) || { fields: ['name'] };
              saveOffline(config, data, fields);
            }
          });
          resolve({ ok: result.ok, status: result.status, json: () => Promise.resolve(data) });
        };
        result.json().then(resultJsonHandler);
      });
    });
  };
}

async function saveOffline<T extends IData>(config: IOfflineConfig<T>, data, fields) {
  if (!config.rows) {
    console.error('Missing config rows mapping function!');
    return;
  }
  const rows = config.rows(data);

  const pouch = new PouchDB(config.to.dbName);
  console.log(`saving "${config.to.dbName}"`);

  pouch
    .bulkDocs(rows)
    .then(result => {
      console.log(`saved "${config.to.dbName}" success`, result);
      if (fields) {
        pouch
          .search({
            fields,
            include_docs: true,
            build: true
          })
          .then(_ => console.log(`assign index for FTS "${config.to.dbName}" success`))
          .catch(_ => console.error(`assign index for FTS "${config.to.dbName}" failed`));
      }
    })
    .catch(err => console.error(`saved "${config.to.dbName}" failed`, err));
}
