import { IOfflineConfig } from '../config';
import { IData } from '../config/iData';
import { nativeFetch } from '@mochi/fetch-middleware';
import PouchDB from 'pouchdb';
import search = require('pouchdb-quick-search');

PouchDB.plugin(search);
interface IResultSearchPounch {
  total_rows: number;
  rows: any[];
}

export function offlineSearch<T extends IData>(configs: Array<IOfflineConfig<T>>) {
  return async (url, options, fetch) => {
    let searchCondition: boolean = false;
    let pouch: search;
    let optionSearch: any;

    configs.forEach(async (config: IOfflineConfig<T>) => {
      if (config.for(url, options) && config.when()) {
        searchCondition = true;
        pouch = new PouchDB(config.to.dbName);
      }
      optionSearch = config.getConfig(url, options);
    });
    if (searchCondition) {
      const { search, fields } = optionSearch;
      let resultSearchPouch: IResultSearchPounch;
      if (search) {
        resultSearchPouch = await pouch.search({
          query: search,
          fields,
          include_docs: true
        });
      } else {
        resultSearchPouch = await pouch.allDocs({ include_docs: true });
      }
      return new Promise((resolve, reject) => {
        resolve({
          ok: true,
          status: 200,
          json: () =>
            Promise.resolve({
              isSuccess: true,
              total: resultSearchPouch.total_rows,
              rows: resultSearchPouch.rows.map(i => i.doc)
            })
        });
      });
    }
    return nativeFetch(url, options, fetch);
  };
}
