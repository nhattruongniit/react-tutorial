import { defineAction } from 'redux-define';
import { createAction, handleActions } from 'redux-actions';
import { ILogin } from '../../../interfaces';

// Action Constant
export const LOGIN = defineAction('LOGIN', [
  'LOGIN_TOKEN_FAILURE',
  'LOGIN_TOKEN_SUCCESS',
  'LOGIN_TOKEN_PENDING',
  'LOGIN_TOKEN_CANCELLED',
  'API_TOKEN_FAILURE',
  'API_TOKEN_SUCCESS',
  'API_TOKEN_PENDING',
  'API_TOKEN_CANCELLED',
  'CREATE_LOGIN_TOKEN',
  'CREATE_API_TOKEN'
]);

// Action Creators
export const loadTokenLogin = createAction(LOGIN.ACTION);

export const loadTokenLoginSuccess = createAction(LOGIN.LOGIN_TOKEN_SUCCESS, (payload: any) => payload);

export const loadTokenLoginFailure = createAction(LOGIN.LOGIN_TOKEN_FAILURE);

export const loadTokenLoginPending = createAction(LOGIN.LOGIN_TOKEN_PENDING);

export const loadTokenApiSuccess = createAction(LOGIN.API_TOKEN_SUCCESS, (payload: any) => payload);

export const loadTokenApiFailure = createAction(LOGIN.API_TOKEN_FAILURE);

export const loadTokenApiPending = createAction(LOGIN.API_TOKEN_PENDING);

// Reducer and initial state
const initialState: ILogin = {
  apiTokenSuccess: false,
  loginTokenSuccess: false
};

const reducer = handleActions(
  {
    [LOGIN.LOGIN_TOKEN_PENDING]: state => state,
    [LOGIN.LOGIN_TOKEN_SUCCESS]: state => ({
      ...state,
      loginTokenSuccess: true
    }),
    [LOGIN.LOGIN_TOKEN_FAILURE]: (state, { error }) => ({ ...state, loginTokenSuccess: false }),
    [LOGIN.API_TOKEN_SUCCESS]: state => ({
      ...state,
      apiTokenSuccess: true
    }),
    [LOGIN.API_TOKEN_FAILURE]: (state, { error }) => ({ ...state, apiTokenSuccess: false })
  },
  initialState
);

export default reducer;
