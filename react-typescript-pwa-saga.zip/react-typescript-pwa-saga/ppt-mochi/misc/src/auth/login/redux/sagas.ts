import { call, put, takeLatest, takeEvery } from 'redux-saga/effects';
import { LOGIN, loadTokenLoginSuccess, loadTokenLoginFailure, loadTokenApiSuccess, loadTokenApiFailure } from './index';
import * as LoginSession from '../../util/loginSession';
import { makeLambdaRequest } from '../../../fetch-api';
import { LambdaRequestMode } from '../../../enum';
import { fetchApi, FETCH_API } from '@mochi/core';

// saga
function* handleSuccessFetch(action: { payload: any }) {
  const { payload } = action;
  const {
    request: { key }
  } = payload;

  if ([LOGIN.CREATE_API_TOKEN, LOGIN.CREATE_LOGIN_TOKEN].indexOf(key) < 0) {
    return yield;
  }

  const {
    httpResponseJson,
    httpResponseJson: { isSuccess, userId },
    request: {
      httpRequest: {
        body: { param }
      }
    }
  } = payload;
  switch (key) {
    case LOGIN.CREATE_API_TOKEN:
      if (!isSuccess) {
        yield put(loadTokenApiFailure(new Error("Can't get api token !")));
        break;
      }
      yield call(
        LoginSession.putApiToken,
        httpResponseJson.apiToken as string,
        new Date(httpResponseJson.expireDateTime)
      );
      yield put(loadTokenApiSuccess({ apiToken: httpResponseJson.apiToken }));
      break;
    case LOGIN.CREATE_LOGIN_TOKEN:
      if (!isSuccess) {
        yield put(loadTokenLoginFailure(new Error('Username or password is incorrect!')));
        break;
      }
      yield put(loadTokenLoginSuccess({ userToken: httpResponseJson.loginToken }));

      yield call(LoginSession.put, {
        loginToken: httpResponseJson.loginToken as string,
        userId: userId || param.userId.content,
        uuid: param.uuid.content
      });
      yield put(
        fetchApi(
          makeLambdaRequest(
            LOGIN.CREATE_API_TOKEN,
            {
              mode: LambdaRequestMode.CreateApiToken.toString(),
              param: {
                tenantId: { content: '1' },
                userId: { content: userId || param.userId.content },
                uuid: { content: param.uuid.content },
                loginToken: { content: httpResponseJson.loginToken }
              }
            },
            { noCached: true }
          )
        )
      );
      break;
  }
}

function* handleFailureFetch(action: { payload: any }) {
  const { payload } = action;
  switch (payload.request.key) {
    case LOGIN.CREATE_API_TOKEN:
      yield put(loadTokenApiFailure(payload.response));
      break;
    case LOGIN.CREATE_LOGIN_TOKEN:
      yield put(loadTokenLoginFailure(payload.response));
  }
}

function* authorize(action: { payload: any }) {
  const { payload } = action;
  yield put(fetchApi(makeLambdaRequest(LOGIN.CREATE_LOGIN_TOKEN, payload, { noCached: true })));
}

export function* loginFlow() {
  yield takeLatest(LOGIN.ACTION, authorize);
  yield takeEvery(FETCH_API.SUCCESS, handleSuccessFetch);
  yield takeEvery(FETCH_API.FAILURE, handleFailureFetch);
}
