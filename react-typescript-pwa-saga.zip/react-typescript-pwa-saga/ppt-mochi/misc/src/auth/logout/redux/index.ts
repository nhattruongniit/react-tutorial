import { defineAction } from 'redux-define';
import { createAction, handleActions } from 'redux-actions';
import { ILogin } from '../../../interfaces';
import { call, put, takeLatest, takeEvery } from 'redux-saga/effects';
import * as LoginSession from '../../util/loginSession';
import { makeLambdaRequest } from '../../../fetch-api';
import { LambdaRequestMode } from '../../../enum';
import { FETCH_API } from '@mochi/core';
import * as fetchApiActions from '@mochi/core';

// constant
export const LOAD_TOKEN_LOGOUT = defineAction('LOAD_TOKEN_LOGOUT', ['FAILURE', 'SUCCESS', 'PENDING', 'CANCELLED']);

// action creator
export const loadTokenLogout = createAction(LOAD_TOKEN_LOGOUT.ACTION);
export const loadTokenLogoutSuccess = createAction(LOAD_TOKEN_LOGOUT.SUCCESS, ({ isSuccess }) => ({
  isSuccess
}));
export const loadTokenLogoutFailure = createAction(LOAD_TOKEN_LOGOUT.FAILURE);
export const loadTokenLogoutPending = createAction(LOAD_TOKEN_LOGOUT.PENDING);

// reducer
const initialState: ILogin = {
  apiTokenSuccess: true,
  loginTokenSuccess: true
};

const reducer = handleActions(
  {
    [LOAD_TOKEN_LOGOUT.PENDING]: (state) => state,
    [LOAD_TOKEN_LOGOUT.SUCCESS]: (state) => ({
      apiTokenSuccess: false,
      loginTokenSuccess: false
    }),
    [LOAD_TOKEN_LOGOUT.FAILURE]: (state) => state
  },
  initialState
);

export default reducer;

// saga
function* logout() {
  const session = yield call(LoginSession.get);
  yield put(
    fetchApiActions.fetchApi(
      makeLambdaRequest(
        LOAD_TOKEN_LOGOUT.ACTION,
        {
          mode: LambdaRequestMode.DeleteLoginToken.toString(),
          param: {
            tenantId: { content: '1' },
            userId: { content: session.userId },
            loginToken: { content: session.loginToken }
          }
        },
        { noCached: true }
      )
    )
  );
}

function* handleSuccessFetch(action) {
  const {
    httpResponseJson,
    httpResponseJson: { isSuccess },
    request: { key }
  } = action.payload;

  if (key === LOAD_TOKEN_LOGOUT.ACTION) {
    if (!isSuccess) {
      yield put(loadTokenLogoutFailure(new Error('Logout error!')));
      return;
    }

    yield call(LoginSession.clear);
    yield put(loadTokenLogoutSuccess(httpResponseJson));
  }
}

function* handleFailureFetch(action) {
  const {
    payload: {
      response,
      error,
      request: { key }
    }
  } = action;
  if (key === LOAD_TOKEN_LOGOUT.ACTION) {
    yield put(loadTokenLogoutFailure({ response, error }));
  }
}

export function* logoutFlow() {
  yield takeLatest(LOAD_TOKEN_LOGOUT.ACTION, logout);
  yield takeEvery(FETCH_API.SUCCESS, handleSuccessFetch);
  yield takeEvery(FETCH_API.FAILURE, handleFailureFetch);
}
