import { createActions } from 'reduxsauce';

const { Types, Creators } = createActions({
  refreshApiTokenFailure: ['error'],
  reAuthenticate: null
});

export { Types, Creators };
