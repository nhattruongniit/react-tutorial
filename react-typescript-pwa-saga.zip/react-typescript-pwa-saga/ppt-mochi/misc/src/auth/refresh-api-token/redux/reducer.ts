import { createReducer } from 'reduxsauce';
import { Types } from './actions';

const INITIAL_STATE = {};

const HANDLERS = {
  [Types.RE_AUTHENTICATE]: () => new Date()
};

export default createReducer(INITIAL_STATE, HANDLERS);
