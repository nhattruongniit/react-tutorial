import * as Encrypt from 'cryptr';

const { REACT_APP_LOGIN_SESSION_DATA_ENCRYPT, REACT_APP_LOGIN_SESSION_DATA_ENCRYPT_KEY } = process.env;
const encrypt = new Encrypt(REACT_APP_LOGIN_SESSION_DATA_ENCRYPT_KEY);
const SESSION_KEY = '__session__';
let lastLoginInfo: ILogin | undefined;

export interface ILogin {
  loginToken: string;
  userId: string;
  apiToken?: string;
  apiTokenExpired?: number;
  uuid: string;
}
/**
 * https://nolanlawson.com/2015/09/29/indexeddb-websql-localstorage-what-blocks-the-dom/
 * indexedDB may more advanced but still slow as comparison on this page
 * so we use localStorage for small data for session only
 */

function serialize(info: ILogin) {
  const infoString = JSON.stringify(info);
  return REACT_APP_LOGIN_SESSION_DATA_ENCRYPT === 'true' ? encrypt.encrypt(infoString) : infoString;
}

function isJSON(str: string) {
  if (/^\s*$/.test(str)) {
    return false;
  }
  str = str.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@');
  str = str.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']');
  str = str.replace(/(?:^|:|,)(?:\s*\[)+/g, '');
  return /^[\],:{}\s]*$/.test(str);
}

function deserialize(data: string) {
  const objectData = REACT_APP_LOGIN_SESSION_DATA_ENCRYPT === 'true' && !isJSON(data) ? encrypt.decrypt(data) : data;

  return JSON.parse(objectData);
}
export function put(info: ILogin) {
  lastLoginInfo = info;
  localStorage.setItem(SESSION_KEY, serialize(info));
}

export function clear() {
  lastLoginInfo = undefined;
  // tslint:disable-next-line: max-line-length
  localStorage.clear(); // Clear all, suppose only store session info only. All other information should be stored in indexedDB.
}

export function putApiToken(apiToken: string, apiTokenExpired: Date): boolean {
  if (!lastLoginInfo) {
    lastLoginInfo = get();
  }

  if (!lastLoginInfo) {
    return false;
  }

  lastLoginInfo.apiToken = apiToken;
  lastLoginInfo.apiTokenExpired = apiTokenExpired.getTime();

  put(lastLoginInfo);
  return true;
}

export function get() {
  const storedValue = localStorage.getItem(SESSION_KEY);
  if (!storedValue) {
    return undefined;
  }
  return deserialize(storedValue);
}

export function isExpired(): boolean {
  if (!lastLoginInfo) {
    lastLoginInfo = get();
  }

  if (!lastLoginInfo || !lastLoginInfo.apiTokenExpired) {
    return true;
  }

  return lastLoginInfo.apiTokenExpired < new Date().getTime();
}
