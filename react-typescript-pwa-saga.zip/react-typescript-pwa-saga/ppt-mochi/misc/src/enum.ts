export enum LambdaRequestMode {
  CreateAnonymousToken = 'MODE_CREATE_ANONYMOUS_TOKEN',
  CreateUser = 'MODE_CREATE_USER',
  CreateLoginToken = 'MODE_CREATE_LOGIN_TOKEN',
  CreateApiToken = 'MODE_CREATE_API_TOKEN',
  ChangePassword = 'MODE_CHANGE_PASSWORD',
  ResetPassword = 'MODE_RESET_PASSWORD',
  GetLoginTokenList = 'MODE_GET_LOGIN_TOKEN_LIST',
  DeleteLoginToken = 'MODE_DELETE_LOGIN_TOKEN',
  RegisterFcmToken = 'MODE_REGISTER_FCM_TOKEN',
  SendFcmMessageWithTopic = 'MODE_SEND_FCM_MESSAGE_WITH_TOPIC',
  Create = 'MODE_CREATE',
  ReadByPkey = 'MODE_READ_BY_PKEY',
  Update = 'MODE_UPDATE',
  Delete = 'MODE_DELETE'
}
