import { expect } from 'chai';

describe('SAMPLE', () => {
  it('just a sample passed test', () => {
    const expectedAction = 'do some sample';
    expect('do some other sample').not.equal(expectedAction);
  });
});
