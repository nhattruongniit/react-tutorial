import * as model from '@mochi/core';
import { IRequestHook, IRequestRetry } from '@mochi/core';
import { LambdaRequestMode } from './lamdaRequestMode';
import { runSaga } from '@mochi/core';
import * as LoginSession from '../auth/util/loginSession';
import { put } from 'redux-saga/effects';
import { Creators } from '../auth/refresh-api-token';
import { LOGIN } from '../auth/login/redux';
import { defaultFetch } from '@mochi/core';
import { IResultRefreshApiToken } from '../interfaces';

export async function refreshApiToken(
  loginToken: string,
  userId: string,
  uuid: string
): Promise<IResultRefreshApiToken> {
  const response = await defaultFetch(
    makeLambdaRequest(LOGIN.CREATE_API_TOKEN, {
      mode: LambdaRequestMode.CreateApiToken.toString(),
      param: {
        tenantId: { content: '1' },
        uuid: { content: uuid },
        userId: { content: userId },
        loginToken: { content: loginToken }
      }
    }).httpRequest
  );

  return await response.json();
}

function* saga() {
  yield put(Creators.reAuthenticate());
}

let lastTimeGetRefreshToken: Date;
const { REACT_APP_FETCH_REQUEST_RETRY_INTERVAL: retryInterval } = process.env;
function requestHook(): IRequestHook {
  function isResponseValid(response): boolean {
    return response.isSuccess;
  }

  function getRetryRequest(previousRequest: model.IApiRequest): model.IApiRequest {
    const {
      httpRequest,
      httpRequest: { body }
    } = previousRequest;
    const { apiToken, apiTokenExpired } = LoginSession.get();
    return {
      ...previousRequest,
      httpRequest: { ...httpRequest, body: { ...body, apiToken, expireDateTime: apiTokenExpired } }
    };
  }

  async function shouldRequestRetry(response): Promise<IRequestRetry> {
    if (
      lastTimeGetRefreshToken &&
      new Date().getTime() - lastTimeGetRefreshToken.getTime() < parseInt(retryInterval as string, 10)
    ) {
      return { shouldRetry: false, refreshApiTokenSuccess: false };
    }

    const { userId, loginToken, uuid } = LoginSession.get();
    if (!isResponseValid(response)) {
      const resultFetched = await refreshApiToken(loginToken, userId, uuid);
      if (resultFetched.isSuccess && resultFetched.apiToken) {
        LoginSession.putApiToken(resultFetched.apiToken as string, new Date(resultFetched.expireDateTime));
        lastTimeGetRefreshToken = new Date();
        return { shouldRetry: true, refreshApiTokenSuccess: true };
      } else {
        LoginSession.clear();
        runSaga(saga);
        return { shouldRetry: false, refreshApiTokenSuccess: false };
      }
    }

    lastTimeGetRefreshToken = new Date();
    return { shouldRetry: false, refreshApiTokenSuccess: true };
  }

  return {
    shouldRequestRetry,
    getRetryRequest,
    isResponseValid
  };
}

export const makeLambdaRequest = (
  key: string,
  body: any,
  option?: model.IRequestOption,
  fullUrl?: string
): model.IApiRequest => ({
  key,
  option,
  httpRequest: {
    fullUrl: fullUrl || (process.env.REACT_APP_PROD_API_URL as string),
    method: model.RequestMethod.Post,
    headers: { 'Accept-Charset': 'UTF-8', 'Content-Type': 'text/plain' },
    body
  }
});

export const makePrivateLambdaRequest = (key: string, body: any, option?: model.IRequestOption) => {
  const { userId, apiToken, apiTokenExpired } = LoginSession.get();
  const extendedBody = {
    ...body,
    userId,
    apiToken,
    expireDateTime: apiTokenExpired
  };
  return makeLambdaRequest(key, extendedBody, { ...option, noApiToken: false, requestHook });
};
