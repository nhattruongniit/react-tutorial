import { makeLambdaRequest } from '..';
import { defaultFetch } from '@mochi/core';

import { defineAction } from 'redux-define';
import { LambdaRequestMode } from '../lamdaRequestMode';

export const LOGIN = defineAction('LOGIN', [
  'LOGIN_TOKEN_FAILURE',
  'LOGIN_TOKEN_SUCCESS',
  'LOGIN_TOKEN_PENDING',
  'LOGIN_TOKEN_CANCELLED',
  'API_TOKEN_FAILURE',
  'API_TOKEN_SUCCESS',
  'API_TOKEN_PENDING',
  'API_TOKEN_CANCELLED',
  'CREATE_LOGIN_TOKEN',
  'CREATE_API_TOKEN'
]);

interface IResultRefreshApiToken {
  apiToken: string;
  expireDateTime: Date;
  isSuccess: boolean;
}

export async function refreshApiToken(
  loginToken: string,
  userId: string,
  uuid: string
): Promise<IResultRefreshApiToken> {
  const response = await defaultFetch(
    makeLambdaRequest(LOGIN.CREATE_API_TOKEN, {
      mode: LambdaRequestMode.CreateApiToken.toString(),
      param: {
        tenantId: { content: '1' },
        uuid: { content: uuid },
        userId: { content: userId },
        loginToken: { content: loginToken }
      }
    }).httpRequest
  );

  return await response.json();
}
