import { injectReducer as coreInjectReducer } from '@mochi/core';

let reducersManager = null;
export function setReducerManager(_) {
  reducersManager = _;
}

export function injectReducer(reducerKey, reducer) {
  coreInjectReducer(reducersManager, reducerKey, reducer);
}
