export interface IResultRefreshApiToken {
  apiToken: string;
  expireDateTime: Date;
  isSuccess: boolean;
}

export interface ILogin {
  loginTokenSuccess: boolean;
  apiTokenSuccess: boolean;
}
