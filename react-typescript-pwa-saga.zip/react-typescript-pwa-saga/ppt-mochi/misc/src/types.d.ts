declare module 'cryptr';
declare module 'redux-define';
