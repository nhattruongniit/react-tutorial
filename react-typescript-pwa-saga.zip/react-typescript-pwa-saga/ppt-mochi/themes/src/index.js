import React from 'react';
import ReactDOM from 'react-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { fashion } from './settingThemes/';
export { fashion };
console.log('aaaa')

const Root = () => {
  return (
    <MuiThemeProvider theme={fashion}>
      <Button variant="contained" color="primary">
        Primary
      </Button>
    </MuiThemeProvider>

  );
};
ReactDOM.render(<Root />, document.getElementById('root'));
