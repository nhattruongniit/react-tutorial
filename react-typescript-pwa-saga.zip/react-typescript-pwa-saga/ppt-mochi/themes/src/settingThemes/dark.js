import { createMuiTheme } from '@material-ui/core';
const rexPalette = {
  background: {
    default: '#850F3B', // use background for global App "Note: Root App"
    paper: '#000' // use background for Header and Footer
  },
  primary: { main: '#ba68c8' },
  secondary: {
    main: '#ffff00',
  },
  text: {
    primary: '#ccc',
    secondary: '#000'
  }
};


export const dark = createMuiTheme({
  palette: rexPalette,
});