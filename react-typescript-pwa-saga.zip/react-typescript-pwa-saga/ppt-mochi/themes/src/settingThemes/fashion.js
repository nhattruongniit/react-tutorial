import { createMuiTheme } from '@material-ui/core';
const rexPalette = {
  background: {
    default: '#F2F8FC', // use background for global App "Note: Root App"
    paper: '#850F3B' // use background for Header and Footer
  },
  primary: { main: '#ffffff' },
  secondary: {
    main: '#850F3B',
  },
  text: {
    primary: '#111111',
    secondary: '#ffffff'
  }
};

const rexTypography = {
  // Use the system font instead of the default Roboto font.
  useNextVariants: true, // change new version, when we're user false.
  fontSize: 16,
  fontFamily: ['Helvetica Regular, Helvetica, Arial, Verdana, Tahoma, sans-serif'].join(','),
  // Use for tag <h2>Title</h2> with props variant
  h1: { fontSize: '30px' },
  h2: { fontSize: '24px' },
  h3: { fontSize: '20px' },
  h4: { fontSize: '16px' },
  h5: { fontSize: '14px' },
  h6: { fontSize: '12px' }
};

const rexOverrides = {
  MuiPaper: {
    root: {
      boxSizing: 'border-box',
      padding: '10px',
      backgroundColor: '#fff'
    }
  },
  MuiTypography: {
    h1: {
      fontStyle: 'italic',
      fontFamily: 'Snell Roundhand Bold',
      fontWeight: 'bold',
      color: '#850F3B !important'
    },
    h4: {
      zIndex: 1
    },
    h5: {
      zIndex: 1
    },
    body1: {
      fontSize: 16
    }
  },
  MuiListItem: {
    root: {
      borderBottom: '1px solid #e5e5e5'
    },
    gutters: {
      padding: ' 13.5pt 8pt'
    }
  },
  MuiListItemText: {
    root: {
      padding: 0
    }
  },
  MuiButton: {
    contained: {
      height: 40,
      color: '#fff',
      backgroundColor: '#ba7402',
      fontFamily: 'Helvetica',
      fontSize: 16,
      textAlign: 'center',
      boxShadow: 'none',
      padding: '5px 16px',
      '&:hover': { backgroundColor: '#ba7402 !important' }
    },
    label: {
      textTransform: 'none',
      lineHeight: '24px',
      fontSize: '14px'
    },
    outlined: {
      border: '1px solid #C34400',
      color: '#C34400',
      backgroundColor: '#fff',
      borderRadius: 0,
      height: 40
    }
  },
  MuiDrawer: {
    paper: {
      width: '70%',
      padding: 0
    }
  },
  MuiBottomNavigation: {
    root: {
      backgroundColor: '#850F3B',
      position: 'fixed',
      bottom: '0',
      left: 0,
      width: '100%'
    }
  },
  MuiBottomNavigationAction: {
    root: {
      color: '#fff',
      '&$selected': {
        color: '#4A4A4A !important',
        backgroundColor: '#ffffff'
      }
    },
    label: {
      fontSize: 16,
      marginTop: 3
    }
  },
  MuiFab: {
    label: {
      width: 'initial'
    }
  },
  MuiExpansionPanel: {
    root: {
      padding: '4px 10px',
      boxShadow: 'none'
    }
  },
  MuiExpansionPanelSummary: {
    root: {
      backgroundColor: '#A65070',
      flex: 1,
      height: 50,
      minHeight: '40px !important',
      justifyContent: 'center',
      alignContent: 'center'
    }
  },
  MuiExpansionPanelDetails: {
    root: {
      backgroundColor: '#ffffff',
      border: '1px solid #979797',
      borderTop: '0'
    }
  }
};

export const fashion = createMuiTheme({
  palette: rexPalette,
  typography: rexTypography,
  overrides: rexOverrides
});
