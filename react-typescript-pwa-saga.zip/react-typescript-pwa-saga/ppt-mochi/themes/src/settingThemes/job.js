import { createMuiTheme } from '@material-ui/core';
const rexPalette = {
  background: {
    default: '#F2F8FC', // use background for global App "Note: Root App"
    paper: '#007FC3' // use background for Header and Footer
  },
  primary: { main: '#ffffff' },
  secondary: {
    main: '#007FC3',
  },
  text: {
    primary: '#111111',
    secondary: '#fff'
  }
};

const typography = {
  // Use the system font instead of the default Roboto font.
  useNextVariants: true, // change new version, when we're user false.
  fontSize: 16,
  fontFamily: ['Hiragino Sans'].join(','),
  // Use for tag <h2>Title</h2> with props variant
  h1: { fontSize: '36px' },
  h2: { fontSize: '24px' },
  h3: { fontSize: '20px' },
  h4: { fontSize: '16px' },
  h5: { fontSize: '14px' },
  h6: { fontSize: '12px' }
};

const rexOverrides = {
  MuiPaper: {
    root: {
      boxSizing: 'border-box',
      padding: '10px',
      backgroundColor: '#F2F8FC',
    }
  },
  MuiButton: {
    contained: {
      height: 40,
      color: '#fff',
      backgroundColor: '#C34400',
      fontFamily: 'Helvetica',
      fontSize: 16,
      textAlign: 'center',
      boxShadow: 'none',
      padding: '5px 16px',
      '&:hover': { backgroundColor: '#C34400 !important' }
    },
    label: {
      textTransform: 'capitalize',
      fontFamily: 'Hiragino Sans',
      lineHeight: '24px'
    },
    outlined: {
      border: '1px solid #C34400',
      color: '#C34400',
      backgroundColor: '#fff',
      borderRadius: 0,
      height: 40
    }
  },
  MuiDrawer: {
    paper: {
      width: '84%',
      padding: 0
    }
  },
  MuiBottomNavigation: {
    root: {
      backgroundColor: '#007FC3',
      position: 'fixed',
      bottom: '0',
      left: 0,
      width: '100%'
    }
  },
  MuiBottomNavigationAction: {
    root: {
      color: '#fff',
      '&$selected': {
        color: '#4A4A4A !important',
        backgroundColor: '#ffffff'
      }
    }
  }
};

export const job = createMuiTheme({
  palette: rexPalette,
  typography,
  overrides: rexOverrides
});
