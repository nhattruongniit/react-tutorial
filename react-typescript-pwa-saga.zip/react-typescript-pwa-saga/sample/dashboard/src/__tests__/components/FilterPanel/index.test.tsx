import React from 'react';
import { mount } from 'enzyme';
import { MenuItem, Select } from '@material-ui/core';
import FilterPanel from 'components/FilterPanel';
import styles from 'components/FilterPanel/styles';
import { withStyles } from '@material-ui/core';

const FilterPanelWithStyles = withStyles(styles)(FilterPanel);

let wrapper, mockFn, addBtn, removeBtn, searchBtn;
const filterOptions = [
  { title: 'First Name', key: 'firstName' },
  { title: 'Last Name', key: 'lastName' },
  { title: 'Age', key: 'age' }
];

describe('FilterPanel Component', () => {
  beforeEach(() => {
    mockFn = jest.fn();

    wrapper = mount(<FilterPanelWithStyles filterOptions={filterOptions} onSearch={mockFn} />);
    addBtn = wrapper.find('button[name="addBtn"]');
    searchBtn = wrapper.find('button[name="searchBtn"]');
  });

  test('Should match with snapshot', async () => {
    addBtn.simulate('click');
    await wrapper.instance().forceUpdate();

    expect(wrapper.html()).toMatchSnapshot();
  });

  test('Should search with out any options', () => {
    searchBtn.simulate('click');

    const result = mockFn.mock.calls[0][0];
    const expectResult = [];
    expect(result).toEqual(expectResult);
  });

  test('Should add option when click add button', async () => {
    addBtn.simulate('click');
    addBtn.simulate('click');

    await wrapper.instance().forceUpdate();
    wrapper.update();

    // Simulate change select option and text value for option 1
    wrapper
      .find(Select)
      .find('[role="button"]')
      .first()
      .simulate('click');
    wrapper
      .find(MenuItem)
      .at(1)
      .simulate('click');

    // Simulate change text value for option 2
    wrapper
      .find('input[type="text"]')
      .at(0)
      .simulate('change', { target: { value: '20' } });

    wrapper
      .find('input[type="text"]')
      .at(1)
      .simulate('change', { target: { value: 'User' } });

    searchBtn.simulate('click');
    const result = mockFn.mock.calls[0][0];
    const expectResult = [{ key: 'age', value: '20' }, { key: 'lastName', value: 'User' }];

    expect(result).toEqual(expectResult);
  });

  test('Should remove option when click remove button', async () => {
    addBtn.simulate('click');
    searchBtn.simulate('click');

    const resultBeforeRemove = mockFn.mock.calls[0][0];
    const expectResultBeforeRemove = [{ key: 'firstName', value: '' }];
    // before click remove button, expect option array has one value
    expect(resultBeforeRemove).toEqual(expectResultBeforeRemove);

    await wrapper.instance().forceUpdate();
    wrapper.update();

    removeBtn = wrapper.find('button[name="removeBtn"]').first();
    removeBtn.simulate('click');
    searchBtn.simulate('click');
    // after click remove button, expect option array has no value
    const result = mockFn.mock.calls[1][0];
    const expectResult = [];
    expect(result).toEqual(expectResult);
  });
});
