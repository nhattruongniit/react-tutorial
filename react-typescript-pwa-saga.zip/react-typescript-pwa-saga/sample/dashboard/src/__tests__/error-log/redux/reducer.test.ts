import errorLog from 'features/error-log/redux/duck';

describe('error log reducers test', () => {
  const { reducer, actions } = errorLog;

  test('should return the correct value from reducer without action', () => {
    expect(reducer(undefined, { type: 'anonymous' })).toEqual({ loading: 'idle', data: null, error: null });
  });

  test('should return the correct value from reducer with fetchStart', () => {
    expect(reducer(undefined, actions.fetchStart(undefined))).toEqual({ loading: 'started', data: null, error: '' });
  });

  test('should return the correct value from reducer with fetchSuccess', () => {
    expect(reducer(undefined, actions.fetchSuccess({ log: 'data from server' }))).toEqual({
      loading: 'stopped',
      data: {
        log: 'data from server'
      },
      error: null
    });
  });

  test('should return the correct value from reducer with fetchFailure', () => {
    expect(reducer(undefined, actions.fetchFailure('some error'))).toEqual({
      loading: 'stopped',
      data: '',
      error: 'some error'
    });
  });
});
