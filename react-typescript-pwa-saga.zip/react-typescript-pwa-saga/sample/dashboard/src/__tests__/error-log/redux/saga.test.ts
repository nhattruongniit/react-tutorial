import { takeLatest, put, call } from 'redux-saga/effects';
import { watchFetchErrorLogAction } from 'features/error-log/redux/saga';
import { fetchErrorLog } from 'features/error-log/redux/saga';
import * as api from 'services/http/request';
import errorLogDuck from 'features/error-log/redux/duck';

describe('watchFetchErrorLogAction test', () => {
  test('yield fetchErrorLog test', () => {
    const gen = watchFetchErrorLogAction();
    expect(gen.next().value).toEqual(takeLatest('error-log/fetch', fetchErrorLog));
  });
});

describe('fetchErrorLog test', () => {
  const action = {
    payload: {
      page: 0,
      search: []
    }
  };

  test('yield error-log/fetchSuccess test', () => {
    const gen = fetchErrorLog(action);
    let next = gen.next();
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchStart(undefined)));
    next = gen.next();
    expect(next.value).toEqual(call(api.createAnonymousToken));
    next = gen.next(true);
    expect(next.value).toEqual(call(api.getErrorLog, 0, []));
    next = gen.next({ isSuccess: true });
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchSuccess({ isSuccess: true })));
  });

  test('yield error-log/fetchFailure caused by error log api test ', () => {
    const gen = fetchErrorLog(action);
    let next = gen.next();
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchStart(undefined)));
    next = gen.next();
    expect(next.value).toEqual(call(api.createAnonymousToken));
    next = gen.next(true);
    expect(next.value).toEqual(call(api.getErrorLog, 0, []));
    next = gen.next({ isSuccess: false });
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchFailure('fail fetch error log')));
  });

  test('yield error-log/fetchFailure caused by fail anonymous token test', () => {
    const gen = fetchErrorLog(action);
    let next = gen.next();
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchStart(undefined)));
    next = gen.next();
    expect(next.value).toEqual(call(api.createAnonymousToken));
    next = gen.next(false);
    expect(next.value).toEqual(put(errorLogDuck.actions.fetchFailure('fail create anonymous token')));
  });
});
