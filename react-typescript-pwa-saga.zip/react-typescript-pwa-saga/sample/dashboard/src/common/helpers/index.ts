export const getSizeFromBase64 = base64Str => {
  if (base64Str) {
    const decoded = atob(base64Str.split('base64,')[1]);
    return decoded.length;
  }
  return 0;
};
