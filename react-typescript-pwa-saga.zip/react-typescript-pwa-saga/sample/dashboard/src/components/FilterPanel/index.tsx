import React, { useState } from 'react';
import { FormControl, Button, TextField, Select, MenuItem, Grid } from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import DeleteIcon from '@material-ui/icons/Delete';
import { withStyles } from '@material-ui/core/styles';
import styles from './styles';
import _ from 'lodash';

export interface IFilterOption {
  key: string;
  title?: string;
  inputType?: string; // Type of input, default is TextField
  value?: any;
}

export interface IFilterPanelSearchFunc {
  (resultOptions: IFilterOption[]): void;
}
export interface IFilterPanelProp {
  classes?: any;
  onSearch?: IFilterPanelSearchFunc;
  filterOptions?: IFilterOption[];
  value?: IFilterOption[];
}

const removeFromArray = (arr, obj) => {
  const curIdx = _.indexOf(arr, obj);
  _.remove(arr, (_val, idx) => idx === curIdx);
};

const FilterPanel = ({ classes, onSearch, filterOptions = [], value = [] }: IFilterPanelProp) => {
  const [resultOptions, setResultOptions] = useState(value);

  const handleAddOptionClick = () => {
    // Only add new when the Input List resultOptions still have any option is not used yet
    if (resultOptions.length < filterOptions.length) {
      // Get first available option from Input List resultOptions, which is not existed in the Used List resultOptions
      const tempArr = resultOptions.map(val => val.key);
      const firstChild = _.find(filterOptions, val => !_.includes(tempArr, val.key));

      // Add new option to the Used List
      resultOptions.push({
        key: firstChild.key,
        value: ''
      });
    }
  };

  const handleSearchClick = () => {
    if (onSearch && _.isFunction(onSearch)) {
      onSearch(resultOptions);
    }
  };

  const renderMenuItem = opt => {
    return (
      filterOptions
        // Only render menu from option which is not used, except itself
        .filter(val => !_.find(resultOptions, ['key', val.key]) || val.key === opt.key)
        .map((val, idx) => (
          <MenuItem value={val.key} key={idx}>
            {val.title}
          </MenuItem>
        ))
    );
  };

  const handleInputChange = (opt, event) => {
    opt.value = event.target.value;
    setResultOptions([...resultOptions]);
  };

  const renderValueInput = opt => {
    switch (opt.inputType) {
      // TO-DO: define more input types. Example:
      // case 'Radio':
      //   return <Radio/>
      default:
        return (
          <TextField
            fullWidth
            value={opt.value}
            onChange={event => {
              handleInputChange(opt, event);
            }}
          />
        );
    }
  };

  return (
    <div>
      <Grid container direction="row" justify="flex-start" alignItems="center">
        {resultOptions.map((opt, idx) => {
          return (
            <Grid container item spacing={24} className={classes.gridItem} key={idx}>
              <Grid item md={2} xs={5}>
                <FormControl fullWidth>
                  <Select
                    autoWidth
                    value={opt.key}
                    name="key"
                    onChange={event => {
                      opt.key = event.target.value;
                    }}
                  >
                    {renderMenuItem(opt)}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item md={2} xs={5}>
                <FormControl fullWidth>{renderValueInput(opt)}</FormControl>
              </Grid>
              <Grid item md={1} xs={2}>
                <Button
                  name="removeBtn"
                  variant="contained"
                  color="secondary"
                  onClick={() => removeFromArray(resultOptions, opt)}
                >
                  <DeleteIcon />
                </Button>
              </Grid>
            </Grid>
          );
        })}
      </Grid>

      <Grid container direction="row" justify="flex-start" alignItems="center">
        <Button
          name="addBtn"
          color="primary"
          className={classes.ml1}
          onClick={handleAddOptionClick}
          disabled={resultOptions.length >= filterOptions.length}
        >
          <AddIcon />
          Add Search Option
        </Button>
        <Button name="searchBtn" variant="contained" color="primary" onClick={handleSearchClick}>
          Search
        </Button>
      </Grid>
    </div>
  );
};

export default withStyles(styles)(FilterPanel);
