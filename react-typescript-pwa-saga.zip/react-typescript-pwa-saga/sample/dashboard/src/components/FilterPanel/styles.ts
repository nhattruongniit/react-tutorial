export default theme => ({
  gridItem: {
    margin: `${theme.spacing.unit}px 0 ${theme.spacing.unit}px 0`
  },
  ml1: {
    marginRight: theme.spacing.unit
  }
});
