import * as React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

interface IProps {
  icon: any;
  primary: any;
  secondary?: any;
  to: any;
}

export const ListItemLink: React.FC<IProps> = ({ icon, primary, secondary, to }) => {
  return (
    <li>
      <ListItem
        component={React.useCallback(
          props => (
            <RouterLink {...props} to={to} />
          ),
          [to]
        )}
      >
        {icon && <ListItemIcon>{icon}</ListItemIcon>}
        <ListItemText inset primary={primary} secondary={secondary} />
      </ListItem>
    </li>
  );
};
