import React from 'react';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { SettingsPower as LogOutIcon } from '@material-ui/icons';

export default function LogOutButton({onClick}) {
  return (
    <ListItem button onClick={onClick}>
      <ListItemIcon>
        <LogOutIcon />
      </ListItemIcon>
      <ListItemText primary="Sign Out" />
    </ListItem>
  );
}
