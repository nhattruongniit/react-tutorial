import React, { useState, useEffect } from 'react';
import { FormControl, Grid, FormLabel, Select, MenuItem } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import styles from '../styles';
import Start from './start';
import Daily from './daily';
import Weekly from './weekly';
import Monthly from './monthly';
import Yearly from './yearly';
import { useTranslation } from 'react-i18next';
import { convertCronStringToObj } from '../utils';
import { FreqEnum, DateTypeEnum } from '../constants';

interface IFunc {
  (rule: string): void;
}

interface IRrulePanel {
  classes?: any;
  onChange?: IFunc;
  value?: string;
}

const RrulePanel = ({ classes, onChange, value }: IRrulePanel) => {
  const { t: translate } = useTranslation();
  const {
    startTime: startTimeInit,
    freq: freqInit,
    dInterval: dIntervalInit,
    wByDay: wByDayInit,
    mInterval: mIntervalInit,
    monthType: monthTypeInit,
    mByDay: mByDayInit,
    mByMonthDay: mByMonthDayInit,
    mBySetPos: mBySetPosInit,
    yearType: yearTypeInit,
    yByMonth: yByMonthInit,
    yByMonthDay: yByMonthDayInit,
    yBySetPos: yBySetPosInit,
    yByDay: yByDayInit
  } = convertCronStringToObj(value);

  // start
  const [startTime, setStartTime] = useState(startTimeInit);

  const [freq, setFreq] = useState(freqInit);

  // daily
  const [dInterval, setDInterval] = useState(dIntervalInit);

  // weekly
  const [wByDay, setWByDay] = useState(wByDayInit);

  // monthly
  const [mInterval, setMInterval] = useState(mIntervalInit);
  const [monthType, setMonthType] = useState(monthTypeInit);
  const [mByDay, setMByDay] = useState(mByDayInit);
  const [mByMonthDay, setMByMonthDay] = useState(mByMonthDayInit);
  const [mBySetPos, setMBySetPos] = useState(mBySetPosInit);

  // yearly
  const [yearType, setYearType] = useState(yearTypeInit);
  const [yByMonth, setYByMonth] = useState(yByMonthInit);
  const [yByMonthDay, setYByMonthDay] = useState(yByMonthDayInit);
  const [yBySetPos, setYBySetPos] = useState(yBySetPosInit);
  const [yByDay, setYByDay] = useState(yByDayInit);

  useEffect(() => {
    handleChange();
  });

  const dailyProps = {
    interval: dInterval,
    setInterval: setDInterval,
    classes
  };

  const weeklyProps = {
    byDay: wByDay,
    setByDay: setWByDay,
    classes
  };

  const monthlyProps = {
    interval: mInterval,
    setInterval: setMInterval,
    byDay: mByDay,
    setByDay: setMByDay,
    bySetPos: mBySetPos,
    setBySetPos: setMBySetPos,
    byMonthDay: mByMonthDay,
    setByMonthDay: setMByMonthDay,
    monthType,
    setMonthType,
    classes
  };

  const yearlyProps = {
    byDay: yByDay,
    setByDay: setYByDay,
    bySetPos: yBySetPos,
    setBySetPos: setYBySetPos,
    byMonthDay: yByMonthDay,
    setByMonthDay: setYByMonthDay,
    yearType,
    setYearType,
    byMonth: yByMonth,
    setByMonth: setYByMonth,
    classes
  };

  const startProps = {
    startTime,
    setStartTime
  };

  const handleFreqChange = event => {
    setFreq(event.target.value);
  };

  const handleChange = () => {
    const times = (startTime || '00:00').split(':');
    const obj: string[] = [times[1], times[0], '*', '*', '*', '*'];

    switch (freq) {
      case FreqEnum.DAILY:
        obj[2] = '*/' + dInterval;
        break;
      case FreqEnum.WEEKLY:
        obj[2] = '?';
        obj[4] = wByDay.toString();
        break;
      case FreqEnum.MONTHLY:
        obj[3] = '*/' + mInterval;
        if (monthType === DateTypeEnum.On) {
          obj[2] = mByMonthDay;
          obj[4] = '?';
        } else {
          obj[2] = '?';

          if (mBySetPos === -1) {
            obj[4] = mByDay + 'L';
          } else {
            obj[4] = `${mByDay}#${mBySetPos}`;
          }
        }
        break;
      case FreqEnum.YEARLY:
        if (yearType === DateTypeEnum.On) {
          obj[2] = yByMonthDay;
          obj[3] = yByMonth;
          obj[4] = '?';
        } else {
          obj[2] = '?';
          obj[3] = yByMonth;
          if (yBySetPos === -1) {
            obj[4] = yByDay + 'L';
          } else {
            obj[4] = `${yByDay}#${yBySetPos}`;
          }
        }
        break;
      default:
        break;
    }
    if (onChange) {
      onChange(obj.join(' '));
    }
  };
  return (
    <div>
      <Grid container direction="row" justify="flex-start" alignItems="stretch">
        <FormLabel component="menu">Start time</FormLabel>
        <Grid container item className={classes.wrap}>
          <Start {...startProps} />
        </Grid>

        <FormLabel component="menu">Repeat</FormLabel>
        <Grid container item className={classes.wrap}>
          <Grid container item xs={12}>
            <FormControl>
              <Select value={freq} onChange={handleFreqChange}>
                <MenuItem value={FreqEnum.DAILY}>{translate('rrulePanel.Daily')}</MenuItem>
                <MenuItem value={FreqEnum.WEEKLY}>{translate('rrulePanel.Weekly')}</MenuItem>
                <MenuItem value={FreqEnum.MONTHLY}>{translate('rrulePanel.Monthly')}</MenuItem>
                <MenuItem value={FreqEnum.YEARLY}>{translate('rrulePanel.Yearly')}</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid container item xs={12} className={classes.pt10}>
            {freq === FreqEnum.DAILY && <Daily {...dailyProps} />}
            {freq === FreqEnum.WEEKLY && <Weekly {...weeklyProps} />}
            {freq === FreqEnum.MONTHLY && <Monthly {...monthlyProps} />}
            {freq === FreqEnum.YEARLY && <Yearly {...yearlyProps} />}
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};

export default withStyles(styles)(RrulePanel);
