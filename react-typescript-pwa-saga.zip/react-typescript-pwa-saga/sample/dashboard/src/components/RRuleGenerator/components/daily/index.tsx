import React from 'react';
import { FormControl, TextField, Grid } from '@material-ui/core';
import { useTranslation } from 'react-i18next';

const Daily = ({ classes, interval, setInterval }) => {
  const { t: translate } = useTranslation();

  const handleSetInterval = ({ target: { value } }) => {
    setInterval(value);
  };
  return (
    <Grid container>
      <FormControl fullWidth className={classes.inline}>
        {translate('rrulePanel.Every')}
        <TextField
          className={classes.inputNum}
          type="number"
          value={interval}
          onChange={handleSetInterval}
          inputProps={{
            min: 1
          }}
        />
        {translate('rrulePanel.Days')}
      </FormControl>
    </Grid>
  );
};

export default Daily;
