import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import RrulePanel from './container';

interface IConfirmFunc {
  (rule: string): void;
}

interface ICloseFunc {
  (): void;
}
interface IRruleDialog {
  open?: any;
  onConfirm?: IConfirmFunc;
  onClose?: ICloseFunc;
  value?: string;
  children?: any;
  disabled?: any;
}

const RRuleDialog = ({ open, onConfirm, onClose, value, children, disabled }: IRruleDialog) => {
  const [rule, setRule] = useState('');
  const handleClose = () => {
    if (onClose) {
      onClose();
    }
  };

  const handleRuleChange = obj => {
    setRule(obj);
  };

  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm(rule);
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} aria-labelledby="responsive-dialog-title">
      <DialogTitle>{'Select rule'}</DialogTitle>
      <DialogContent>
        {children}
        <RrulePanel onChange={handleRuleChange} value={value} />
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Close
        </Button>
          <Button onClick={handleConfirm} color="primary" autoFocus disabled={disabled}>
            Ok
        </Button>
        </DialogActions>
      </DialogContent>
    </Dialog>
  );
};

export default RRuleDialog;
