import React from 'react';
import { FormControl, TextField, Grid, Radio, FormControlLabel } from '@material-ui/core';
import { useTranslation } from 'react-i18next';

const End = ({ classes, endDate, setEndDate, count, setCount, endType, setEndType }) => {
  const { t: translate } = useTranslation();

  const handleSetEndDate = ({ target: { value } }) => {
    setEndDate(value);
  };

  const handleSetEndType = ({ target: { value } }: any) => {
    setEndType(value);
  };

  const handleSetCount = ({ target: { value } }) => {
    setCount(value);
  };

  return (
    <Grid container>
      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio checked={endType === 'noEnd'} onChange={handleSetEndType} value="noEnd" name="radio-endType" />
            }
            label={translate('rrulePanel.noEnd')}
          />
        </FormControl>
      </Grid>

      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio checked={endType === 'endBy'} onChange={handleSetEndType} value="endBy" name="radio-endType" />
            }
            label={translate('rrulePanel.endBy')}
          />

          <TextField
            type="date"
            value={endDate}
            onChange={handleSetEndDate}
            InputLabelProps={{
              shrink: true
            }}
            disabled={endType !== 'endBy'}
          />
        </FormControl>
      </Grid>

      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio
                checked={endType === 'endAfter'}
                onChange={handleSetEndType}
                value="endAfter"
                name="radio-endType"
              />
            }
            label={translate('rrulePanel.endAfter')}
          />
          <TextField
            className={classes.inputNum}
            type="number"
            value={count}
            onChange={handleSetCount}
            disabled={endType !== 'endAfter'}
            inputProps={{
              min: 1
            }}
          />
          &nbsp;&nbsp;
          {translate('rrulePanel.executions')}
        </FormControl>
      </Grid>
    </Grid>
  );
};

export default End;
