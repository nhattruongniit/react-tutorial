import React from 'react';
import { FormControl, TextField, Select, MenuItem, Grid, Radio, FormControlLabel } from '@material-ui/core';
import { weekDays, orders, DateTypeEnum } from '../../constants';
import { useTranslation } from 'react-i18next';

const Monthly = ({
  classes,
  interval,
  setInterval,
  byDay,
  setByDay,
  bySetPos,
  setBySetPos,
  byMonthDay,
  setByMonthDay,
  monthType,
  setMonthType
}) => {
  const { t: translate } = useTranslation();

  const monthDays = Array.from({ length: 31 }, (v, k) => k + 1);

  const handleSetInterval = ({ target: { value } }) => {
    setInterval(value);
  };

  const handleSetMonthType = ({ target: { value } }: any) => {
    setMonthType(value);
  };

  const handleSetMonthDay = ({ target: { value } }: any) => {
    setByMonthDay(value);
  };

  const handleSetPos = ({ target: { value } }: any) => {
    setBySetPos(value);
  };

  const handleSetDay = ({ target: { value } }: any) => {
    setByDay(value);
  };

  return (
    <Grid container>
      <Grid container item xs={12}>
        <FormControl fullWidth className={classes.inline}>
          {translate('rrulePanel.Every')}
          <TextField
            className={classes.inputNum}
            type="number"
            value={interval}
            onChange={handleSetInterval}
            inputProps={{
              min: 1
            }}
          />
          {translate('rrulePanel.Months')}
        </FormControl>
      </Grid>
      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio
                checked={monthType === DateTypeEnum.On}
                onChange={handleSetMonthType}
                value={DateTypeEnum.On}
                name="radio-monthType"
              />
            }
            label={translate('rrulePanel.OnDay')}
          />

          <Select value={byMonthDay} onChange={handleSetMonthDay} disabled={monthType === DateTypeEnum.OnThe}>
            {monthDays.map((day, i) => (
              <MenuItem key={i} value={day}>
                {day}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>

      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio
                checked={monthType === DateTypeEnum.OnThe}
                onChange={handleSetMonthType}
                value={DateTypeEnum.OnThe}
                name="radio-monthType"
              />
            }
            label={translate('rrulePanel.OnThe')}
          />
          <Select value={bySetPos} onChange={handleSetPos} disabled={monthType === DateTypeEnum.On}>
            {orders.map((pos, i) => (
              <MenuItem key={i} value={pos.value}>
                {translate('rrulePanel.' + pos.label)}
              </MenuItem>
            ))}
          </Select>
          &nbsp;&nbsp;
          <Select value={byDay} onChange={handleSetDay} disabled={monthType === DateTypeEnum.On}>
            {weekDays.map((day, i) => (
              <MenuItem key={i} value={day.value}>
                {translate('rrulePanel.' + day.label)}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>
    </Grid>
  );
};

export default Monthly;
