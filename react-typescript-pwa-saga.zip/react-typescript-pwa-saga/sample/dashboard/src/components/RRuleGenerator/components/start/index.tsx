import React from 'react';
import { FormControl, TextField, Grid } from '@material-ui/core';

const Start = ({ startTime, setStartTime }) => {
  const handleSetTime = ({ target: { value } }) => {
    setStartTime(value);
  };

  return (
    <Grid container>
      <FormControl>
        <TextField
          type="time"
          value={startTime}
          onChange={handleSetTime}
          InputLabelProps={{
            shrink: true
          }}
          inputProps={{
            step: 300 // 5 min
          }}
        />
      </FormControl>
    </Grid>
  );
};

export default Start;
