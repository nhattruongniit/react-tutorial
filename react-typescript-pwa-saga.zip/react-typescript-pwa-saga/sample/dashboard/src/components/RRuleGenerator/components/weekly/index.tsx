import React from 'react';
import { FormControl, Grid, Checkbox, FormControlLabel } from '@material-ui/core';
import { useTranslation } from 'react-i18next';
import { weekDays } from '../../constants';

const Weekly = ({ classes, byDay, setByDay }) => {
  const { t: translate } = useTranslation();

  const handleCheck = ({ target: { checked } }, value) => {
    if (checked) {
      setByDay([...byDay, value]);
    } else {
      setByDay(byDay.filter(d => d !== value));
    }
  };
  return (
    <Grid container item>
      <FormControl fullWidth className={classes.inline}>
        {weekDays.map((day, i) => {
          return (
            <FormControlLabel
              key={i}
              control={
                <Checkbox
                  value={day.value}
                  checked={byDay.indexOf(day.value) !== -1}
                  onChange={e => {
                    handleCheck(e, day.value);
                  }}
                />
              }
              label={translate('rrulePanel.' + day.label)}
            />
          );
        })}
      </FormControl>
    </Grid>
  );
};

export default Weekly;
