import React from 'react';
import { FormControl, Select, MenuItem, Grid, Radio, FormControlLabel } from '@material-ui/core';
import { weekDays, orders, months, DateTypeEnum, MonthsEnum } from '../../constants';
import { useTranslation } from 'react-i18next';

const Yearly = ({
  classes,
  byMonth,
  setByMonth,
  byDay,
  setByDay,
  bySetPos,
  setBySetPos,
  byMonthDay,
  setByMonthDay,
  yearType,
  setYearType
}) => {
  const { t: translate } = useTranslation();

  const getDaysOfMonth = month => {
    let max = 31;
    if (Number(month) === MonthsEnum.February) {
      max = 29;
    }
    if ([MonthsEnum.April, MonthsEnum.June, MonthsEnum.September, MonthsEnum.November].indexOf(Number(month)) !== -1) {
      max = 30;
    }

    return Array.from({ length: max }, (v, k) => k + 1);
  };

  const handleSetYearType = ({ target: { value } }: any) => {
    setYearType(value);
  };

  const handleSetMonthDay = ({ target: { value } }: any) => {
    setByMonthDay(value);
  };

  const handleSetPos = ({ target: { value } }: any) => {
    setBySetPos(value);
  };

  const handleSetDay = ({ target: { value } }: any) => {
    setByDay(value);
  };

  const handleSetMonth = e => {
    setByMonthDay(1);
    setByMonth(e.target.value);
  };

  return (
    <Grid container>
      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio
                checked={yearType === DateTypeEnum.On}
                onChange={handleSetYearType}
                value={DateTypeEnum.On}
                name="radio-yearType"
              />
            }
            label={translate('rrulePanel.On')}
          />
          <Select value={byMonth} onChange={handleSetMonth} disabled={yearType !== DateTypeEnum.On}>
            {months.map((month, i) => (
              <MenuItem key={i} value={month.value}>
                {translate('rrulePanel.' + month.label)}
              </MenuItem>
            ))}
          </Select>
          &nbsp; &nbsp;
          <Select value={byMonthDay} onChange={handleSetMonthDay} disabled={yearType !== DateTypeEnum.On}>
            {getDaysOfMonth(byMonth).map((day, i) => (
              <MenuItem key={i} value={day}>
                {day}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>
      <Grid container item xs={12}>
        <FormControl className={classes.inline}>
          <FormControlLabel
            control={
              <Radio
                checked={yearType === DateTypeEnum.OnThe}
                onChange={handleSetYearType}
                value={DateTypeEnum.OnThe}
                name="radio-yearType"
              />
            }
            label={translate('rrulePanel.OnThe')}
          />
          <Select value={bySetPos} onChange={handleSetPos} disabled={yearType !== DateTypeEnum.OnThe}>
            {orders.map((pos, i) => (
              <MenuItem key={i} value={pos.value}>
                {translate('rrulePanel.' + pos.label)}
              </MenuItem>
            ))}
          </Select>
          &nbsp;&nbsp;
          <Select value={byDay} onChange={handleSetDay} disabled={yearType !== DateTypeEnum.OnThe}>
            {weekDays.map((day, i) => (
              <MenuItem key={i} value={day.value}>
                {translate('rrulePanel.' + day.label)}
              </MenuItem>
            ))}
          </Select>
          &nbsp;&nbsp; of &nbsp;&nbsp;
          <Select value={byMonth} onChange={handleSetMonth} disabled={yearType !== DateTypeEnum.OnThe}>
            {months.map((month, i) => (
              <MenuItem key={i} value={month.value}>
                {translate('rrulePanel.' + month.label)}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>
    </Grid>
  );
};

export default Yearly;
