export enum FreqEnum {
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  MONTHLY = 'MONTHLY',
  YEARLY = 'YEARLY'
}

export enum OrdersEnum {
  First = 1,
  Second = 2,
  Third = 3,
  Fourth = 4,
  Last = -1
}

export enum MonthsEnum {
  January = 1,
  February = 2,
  March = 3,
  April = 4,
  May = 5,
  June = 6,
  July = 7,
  August = 8,
  September = 9,
  October = 10,
  November = 11,
  December = 12
}

export enum WeekDaysEnum {
  Monday = '1',
  Tuesday = '2',
  Wednesday = '3',
  Thursday = '4',
  Friday = '5',
  Saturday = '6',
  Sunday = '0'
}

export enum DateTypeEnum {
  On = 'on',
  OnThe = 'onThe'
}

export const weekDays = [
  {
    value: WeekDaysEnum.Monday,
    label: 'Monday'
  },
  {
    value: WeekDaysEnum.Tuesday,
    label: 'Tuesday'
  },
  {
    value: WeekDaysEnum.Wednesday,
    label: 'Wednesday'
  },
  {
    value: WeekDaysEnum.Thursday,
    label: 'Thursday'
  },
  {
    value: WeekDaysEnum.Friday,
    label: 'Friday'
  },
  {
    value: WeekDaysEnum.Saturday,
    label: 'Saturday'
  },
  {
    value: WeekDaysEnum.Sunday,
    label: 'Sunday'
  }
];

export const orders = [
  {
    value: OrdersEnum.First,
    label: 'First'
  },
  {
    value: OrdersEnum.Second,
    label: 'Second'
  },
  {
    value: OrdersEnum.Third,
    label: 'Third'
  },
  {
    value: OrdersEnum.Fourth,
    label: 'Fourth'
  },
  {
    value: OrdersEnum.Last,
    label: 'Last'
  }
];

export const months = [
  {
    value: MonthsEnum.January,
    label: 'January'
  },
  {
    value: MonthsEnum.February,
    label: 'February'
  },
  {
    value: MonthsEnum.March,
    label: 'March'
  },
  {
    value: MonthsEnum.April,
    label: 'April'
  },
  {
    value: MonthsEnum.May,
    label: 'May'
  },
  {
    value: MonthsEnum.June,
    label: 'June'
  },
  {
    value: MonthsEnum.July,
    label: 'July'
  },
  {
    value: MonthsEnum.August,
    label: 'August'
  },
  {
    value: MonthsEnum.September,
    label: 'September'
  },
  {
    value: MonthsEnum.October,
    label: 'October'
  },
  {
    value: MonthsEnum.November,
    label: 'November'
  },
  {
    value: MonthsEnum.December,
    label: 'December'
  }
];
