export default {
  pt10: {
    paddingTop: 10
  },
  wrap: {
    borderBottom: '1px solid rgba(0, 0, 0, 0.1)',
    paddingBottom: '20px',
    marginBottom: '20px',
  },
  inputNum: {
    width: 100,
    padding: '0 20px'
  },
  inline: {
    display: 'inline',
    lineHeight: '32px'
  }
};