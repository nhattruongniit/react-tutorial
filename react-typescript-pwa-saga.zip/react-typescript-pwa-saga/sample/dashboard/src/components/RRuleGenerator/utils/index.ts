import _ from 'lodash';
import { FreqEnum, OrdersEnum, MonthsEnum, WeekDaysEnum, DateTypeEnum } from '../constants';
import cronstrue from 'cronstrue';

export const convertCronStringToObj = (cronStr = '0 0 */1 * * *') => {
  const defaultObj = {
    startTime: '00:00',
    freq: FreqEnum.DAILY,

    dInterval: 1,

    wByDay: [WeekDaysEnum.Monday],

    mInterval: 1,
    monthType: DateTypeEnum.On,
    mByDay: WeekDaysEnum.Monday,
    mByMonthDay: 1,
    mBySetPos: OrdersEnum.First,

    yearType: DateTypeEnum.On,
    yByMonth: MonthsEnum.January,
    yByMonthDay: 1,
    yBySetPos: OrdersEnum.First,
    yByDay: WeekDaysEnum.Monday
  };

  const obj = _.cloneDeep(defaultObj);

  try {
    const crons: any[] = cronStr.split(' ');

    // join second and first element to time
    // Ex: 5 18 => 18:05
    obj.startTime = [1, 0].map(i => `${Number(crons[i]) < 10 ? '0' : ''}${Number(crons[i])}`).join(':');

    // return true if all elements in array are equal with text
    const checkEqualWith = (arr, text) => {
      return _.every(arr, a => a === text);
    };

    // Daily
    // Ex: every 5 days at 18:05
    // Ex: 5 18 */5 * * *
    if (checkEqualWith(_.takeRight(crons, 3), '*')) {
      obj.freq = FreqEnum.DAILY;
      obj.dInterval = crons[2].split('/')[1];

      return obj;
    }

    // Weekly
    // Ex: every week, on sunday and thursday at 18:05
    // Ex: 5 18 ? * 1,5 *
    if (checkEqualWith([crons[3], crons[5]], '*') && crons[2] === '?') {
      obj.freq = FreqEnum.WEEKLY;
      obj.wByDay = crons[4].split(',');

      return obj;
    }

    // Monthly
    // Ex: Every 3 months, on day 16th at 18:05
    // Ex: 5 18 16 */3 ? *
    if (crons[4] === '?' && crons[5] === '*' && _.includes(crons[3], '/')) {
      obj.freq = FreqEnum.MONTHLY;
      obj.monthType = DateTypeEnum.On;
      obj.mByMonthDay = Number(crons[2]);
      obj.mInterval = Number(crons[3].split('/')[1]);
      return obj;
    }

    // Monthly
    // Ex: Every 3 months, on the last Friday, at 18:05
    // Ex: 5 18 ? */3 6L *

    // Ex: Every 3 months, on the second Friday, at 18:05
    // Ex: 5 18 ? */3 6#2 *
    if (crons[2] === '?' && crons[5] === '*' && _.includes(crons[3], '/')) {
      obj.freq = FreqEnum.MONTHLY;
      obj.monthType = DateTypeEnum.OnThe;
      obj.mInterval = Number(crons[3].split('/')[1]);
      obj.mByDay = crons[4][0];
      if (_.includes(crons[4], 'L')) {
        obj.mBySetPos = -1;
      }
      if (_.includes(crons[4], '#')) {
        obj.mBySetPos = Number(crons[4].split('#')[1]);
      }
      return obj;
    }

    // Yearly
    // Ex: Every year on July 16th at 18:05
    // Ex: 5 18 16 7 ? *
    if (crons[4] === '?' && crons[5] === '*') {
      obj.freq = FreqEnum.YEARLY;
      obj.yearType = DateTypeEnum.On;
      obj.yByMonthDay = Number(crons[2]);
      obj.yByMonth = Number(crons[3]);
      return obj;
    }

    // Yearly
    // Ex: Every year on the second Tuesday of July at 18:05
    // Ex: 5 18 ? 7 3#2 *

    // Ex: Every year on the last Tuesday of July at 18:05
    // Ex: 5 18 ? 7 3L *
    if (crons[2] === '?' && crons[5] === '*') {
      obj.freq = FreqEnum.YEARLY;
      obj.yearType = DateTypeEnum.OnThe;
      obj.yByMonth = Number(crons[3]);
      obj.yByDay = crons[4][0];
      if (_.includes(crons[4], 'L')) {
        obj.yBySetPos = -1;
      }
      if (_.includes(crons[4], '#')) {
        obj.yBySetPos = Number(crons[4].split('#')[1]);
      }
      return obj;
    }

    return defaultObj;
  } catch (e) {
    console.log(e);
    return defaultObj;
  }
};

export const cronToReadableString = rule => {
  try {
    if (!rule) {
      return '';
    }
    return cronstrue.toString('0 ' + rule);
  } catch (error) {
    console.log(error);
    return 'Wrong format';
  }
};
