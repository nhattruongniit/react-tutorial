import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Snackbar from '@material-ui/core/Snackbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import green from '@material-ui/core/colors/green';

const styles = theme => ({
  close: {
    padding: theme.spacing.unit / 2
  },
  success: {
    'background-color': green[600]
  },
  error: {
    backgroundColor: theme.palette.error.dark
  }
});

function SimpleSnackbar({ classes, open, handleClose, message, variant, anchorOrigin = { vertical: 'bottom' as any, horizontal: 'right' as any } }) {
  return (
    <div>
      <Snackbar
        anchorOrigin={anchorOrigin}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        ContentProps={{
          'aria-describedby': 'message-id',
          classes: {
            root: classes[variant]
          }
        }}
        message={<span id="message-id">{message}</span>}
        action={[
          <IconButton key="close" aria-label="Close" color="inherit" className={classes.close} onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        ]}
      />
    </div>
  );
}

SimpleSnackbar.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(SimpleSnackbar);
