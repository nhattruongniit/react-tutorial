import * as React from 'react';
import ExampleComponent from '..';
import { shallow } from 'enzyme';
import { act } from 'react-dom/test-utils';
import { BrowserRouter as Router } from 'react-router-dom';

test("Component should show 'red' text 'Hello World'", () => {
  const component = shallow(
    <Router>
      <ExampleComponent text="World" />
    </Router>
  );
  const testInstance = component.find(ExampleComponent).props();

  expect(testInstance.text).toBe('World');

  let rendered;
  act(() => {
    rendered = component.html();
  });
  expect(rendered).toMatchSnapshot();
});
