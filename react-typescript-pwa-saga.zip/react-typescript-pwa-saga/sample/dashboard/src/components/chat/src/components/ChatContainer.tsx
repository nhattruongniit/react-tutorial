import * as React from 'react';
import { Paper } from '@material-ui/core';
import Text from './Text';
import './../asset/css/animate.css';

interface IProps {
  userid: string;
  socket: any;
}

const ChatContainer: React.FC<IProps> = ({ userid, socket }) => {
  const initDefault = [{ data: '', username: '' }];
  const [value, setValue] = React.useState(initDefault);

  React.useEffect(() => {
    const scroll: any = document.getElementById('scroll');
    const height = scroll.scrollHeight;
    scroll.scrollTo(0, height);
  });

  React.useEffect(() => {
    socket.on('server-send-data', (ms: any) => {
      value.push(...ms);
      setValue([...value]);
    });
  }, []);

  function createMarkup(displayMessage: any) {
    return { __html: displayMessage };
  }

  const renderMs = () => {
    return value.map((val: any, index: number) => {
      if (val.data === '') {
        return <div key={index} />;
      }

      const username = val.username === userid ? '' : val.username;
      const backgroundColor = val.username === userid ? '#ffffff' : '#850F3B';
      const justify = val.username === userid ? 'flex-end' : 'flex-start';
      const color = val.username === userid ? '#850F3B' : '#ffffff';

      return (
        <Text
          key={index}
          username={username}
          message={createMarkup(val.data)}
          color={color}
          backgroundColor={backgroundColor}
          justify={justify}
        />
      );
    });
  };

  return (
    <div id="scroll" style={{ height: 'calc(100% - 125px)', overflowX: 'hidden', backgroundColor: '#DFE4E4' }}>
      <Paper elevation={0} square style={{ boxShadow: 'none', height: '100%', backgroundColor: '#DFE4E4' }}>
        {renderMs()}
      </Paper>
    </div>
  );
};

export default ChatContainer;
