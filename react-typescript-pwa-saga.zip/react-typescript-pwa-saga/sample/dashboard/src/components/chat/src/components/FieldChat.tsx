import * as React from 'react';
import { Grid, FormControl, InputBase, AppBar, Button } from '@material-ui/core';
import SendIcon from '@material-ui/icons/Send';
import _ from 'lodash';

interface IProps {
  socket: any;
}

const FieldChat: React.FC<IProps> = ({ socket }) => {
  const [message, setMessage] = React.useState('');

  // tslint:disable-next-line: variable-name
  function handleChange(_message: string) {
    return (event: React.ChangeEvent<HTMLInputElement>) => setMessage(event.target.value);
  }

  function resetMessage() {
    setMessage('');
  }

  function translateMessage() {
    const words = _.split(message, ' ');
    const rl = _.flatMap(words, (word: string) => {
      const wordContainLink = word.indexOf('link:') > -1;
      const wordIsEmptyString = word === '';
      if (wordContainLink) {
        const wordsArray = _.split(word, ':');
        const url = `<a href='/${wordsArray[1]}'>${wordsArray[1]}</a>`;
        return [url];
      } else if (wordIsEmptyString) {
        return ['\u00a0'];
      } else {
        return [word];
      }
    });
    socket.emit('client-send-data', _.join(rl, ' '));
  }

  function handleEmit() {
    translateMessage();
    resetMessage();
  }

  function handleKeyPress(event: { key: string }) {
    if (event.key === 'Enter') {
      translateMessage();
      resetMessage();
    }
  }

  return (
    <AppBar position="static" style={{ boxShadow: 'none', backgroundColor: '#DFE4E4', padding: '0', height: '40px' }}>
      <Grid
        container
        direction="row"
        alignItems="flex-end"
        justify="space-between"
        style={{ position: 'fixed', bottom: 0 }}
      >
        <Grid item xs={11}>
          <FormControl fullWidth style={{ width: '100%', height: 40, backgroundColor: '#ffffff' }}>
            <InputBase
              fullWidth
              autoComplete="off"
              id="bootstrap-input"
              value={message}
              style={{ height: '100%', padding: 10 }}
              onChange={handleChange('message')}
              onKeyPress={handleKeyPress}
            />
          </FormControl>
        </Grid>
        <Grid container justify="flex-end" item xs={1} style={{ width: 64 }}>
          <Button
            variant="contained"
            color="secondary"
            size="small"
            style={{ borderRadius: 0 }}
            onClick={() => handleEmit()}
          >
            <SendIcon />
          </Button>
        </Grid>
      </Grid>
    </AppBar>
  );
};
export default FieldChat;
