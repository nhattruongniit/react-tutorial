import * as React from 'react';
import { AppBar, Grid, Typography, IconButton } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { Link } from 'react-router-dom';

interface IProps {
  socket: any;
}

const HeaderChat: React.FC<IProps> = () => {
  return (
    <Grid style={{ height: '65px' }}>
      <AppBar position="static" style={{ boxShadow: 'none', position: 'fixed' }}>
        <Grid container direction="row" justify="flex-start" alignItems="center" spacing={8}>
          <Grid container direction="row" alignItems="center" item xs={11}>
            <Typography variant="h4" color="secondary">
              Hi, <span id="username" />!
            </Typography>
          </Grid>

          <Grid container justify="flex-end" item xs={1}>
            <Link to="/">
              <IconButton aria-label="Close">
                <CloseIcon fontSize="small" />
              </IconButton>
            </Link>
          </Grid>
        </Grid>
      </AppBar>
    </Grid>
  );
};

export default HeaderChat;
