import * as React from 'react';
import { Paper, Grid } from '@material-ui/core';

interface IPROPS {
  justify: any;
  backgroundColor: any;
  username: React.ReactNode;
  color: any;
  message: any;
}

function Text(props: IPROPS) {
  return (
    <Grid container justify={props.justify}>
      <Paper
        elevation={0}
        style={{
          borderRadius: '10px 10px',
          backgroundColor: `${props.backgroundColor}`,
          margin: '5px 0',
          maxWidth: '80%',
          display: 'inline-block',
          wordBreak: 'break-all'
        }}
      >
        <p style={{ color: '#bde218', fontSize: 12, padding: 0, margin: 0 }}>{props.username}</p>
        <div style={{ wordBreak: 'break-word', color: props.color }} dangerouslySetInnerHTML={props.message} />
        {/* <div style={{ wordBreak: 'break-word', color: props.color }}>{props.message}</div> */}
      </Paper>
    </Grid>
  );
}

export default Text;
