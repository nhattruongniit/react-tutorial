import * as React from 'react';
import HeaderChat from './components/HeaderChat';
import ChatContainer from './components/ChatContainer';
import FieldChat from './components/FieldChat';
import { initSocket } from './socketio/setting';

interface IProps {
  userid: string;
  wsurl: string;
  wsOption?: any;
}

const ChatSocket: React.FC<IProps> = ({ userid, wsurl }) => {
  const socket = initSocket(wsurl).getInstance();

  React.useEffect(() => {
    socket.emit('register-user-name', userid);
  }, []);

  return (
    <>
      <HeaderChat socket={socket} />
      <ChatContainer userid={userid} socket={socket} />
      <FieldChat socket={socket} />
    </>
  );
};

export default ChatSocket;
