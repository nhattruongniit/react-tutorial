import { useState, useEffect } from 'react';
const io = require('socket.io-client');

export const useSocket = (config: any[] | [string, any]) => {
  const [wsUrl, wsOption] = config;
  const [socket] = useState(io(wsUrl, wsOption));

  useEffect(() => {
    return () => {
      socket.removeAllListeners();
      socket.close();
    };
  }, [socket]);

  return socket;
};
