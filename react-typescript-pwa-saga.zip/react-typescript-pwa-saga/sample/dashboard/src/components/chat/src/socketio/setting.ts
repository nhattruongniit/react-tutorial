const io = require('socket.io-client');

export const initSocket = (url: string) => {
  let socket: any;

  function createInstance() {
    return io(url);
  }

  return {
    getInstance: () => {
      if (!socket) {
        socket = createInstance();
      }
      return socket;
    }
  };
};
