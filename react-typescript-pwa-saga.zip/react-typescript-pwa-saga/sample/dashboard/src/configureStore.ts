import 'regenerator-runtime/runtime';
import { configureStore } from 'redux-starter-kit';
import loggerMiddleware from 'redux-logger';
import createSagaMiddleware from 'redux-saga';
import rootReducer from './reducers';
import rootSaga from './sagas';

export default function configureAppStore(preloadedState = {}) {
  const sagaMiddleware = createSagaMiddleware();
  const store = configureStore({
    reducer: rootReducer,
    middleware: [loggerMiddleware, sagaMiddleware],
    preloadedState
  });
  sagaMiddleware.run(rootSaga);

  return store;
}
