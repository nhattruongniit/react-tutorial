import React from 'react';
import ChatSocket from '@mochi/chat';
import store from 'store';

function Chat() {
  return <ChatSocket userid={store.get('userid')} wsurl={process.env.REACT_CHAT_URL as string} />;
}

export default Chat;
