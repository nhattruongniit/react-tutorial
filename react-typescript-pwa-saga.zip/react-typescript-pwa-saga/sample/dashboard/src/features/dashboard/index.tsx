import React, { useState } from 'react';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Badge from '@material-ui/core/Badge';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import NotificationsIcon from '@material-ui/icons/Notifications';
import { useTranslation } from 'react-i18next';
import { Switch, Route } from 'react-router-dom';
import Radio from '@material-ui/core/Radio';
import store from 'store';
import { mainListItems } from './listItems';
import LogOutButton from '../../components/LogoutButton';
import DialogYesNo from '../../components/DialogYesNo';
import routes from '../routes';
import styles from './styles';
import QuestionAnswer from '@material-ui/icons/QuestionAnswer';
import { ListItemLink } from '../../components/ListItemLink';

const switchRoutes = (
  <Switch>
    {routes.map(({ path, component }, key) => (
      <Route path={path} component={component} key={key} />
    ))}
  </Switch>
);
function Dashboard({ classes, history }) {
  const { t: translate, i18n } = useTranslation();
  const currentLang = store.get('i18nextLng');
  const [open, setOpen] = useState(false);
  const [openConfirmLogout, setOpenConfirmLogout] = useState(false);

  const handleDrawerOpen = () => setOpen(true);
  const handleDrawerClose = () => setOpen(false);
  const handleChangeLang = ({ target: { value } }) => i18n.changeLanguage(value);
  const handleLogout = () => {
    store.remove('login_token');
    store.remove('apiToken');
    store.remove('expireDateTime');
    history.replace('/');
  };
  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="absolute" className={classNames(classes.appBar, open && classes.appBarShift)}>
        <Toolbar disableGutters={!open} className={classes.toolbar}>
          <IconButton
            color="inherit"
            aria-label="Open drawer"
            onClick={handleDrawerOpen}
            className={classNames(classes.menuButton, open && classes.menuButtonHidden)}
          >
            <MenuIcon />
          </IconButton>
          <Typography component="h1" variant="h6" color="inherit" noWrap={true} className={classes.title}>
            {translate('dashboard.title')}
          </Typography>
          <Radio
            checked={currentLang === 'en-US'}
            onChange={handleChangeLang}
            value="en-US"
            name="radio-button-demo"
            aria-label="A"
            classes={{
              root: classes.root,
              checked: classes.checked
            }}
          />
          English aaa
          <Radio
            checked={currentLang === 'ja'}
            onChange={handleChangeLang}
            value="ja"
            name="radio-button-demo"
            aria-label="A"
            classes={{
              root: classes.root,
              checked: classes.checked
            }}
          />
          日本人
          <IconButton color="inherit">
            <Badge badgeContent={4} color="secondary">
              <NotificationsIcon />
            </Badge>
          </IconButton>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        classes={{
          paper: classNames(classes.drawerPaper, !open && classes.drawerPaperClose)
        }}
        open={open}
      >
        <div className={classes.toolbarIcon}>
          <IconButton onClick={handleDrawerClose}>
            <ChevronLeftIcon />
          </IconButton>
        </div>
        <Divider />
        <List>{mainListItems(history)}</List>
        <Divider />
        {/* <List>{secondaryListItems}</List> */}
        {/* <Divider /> */}
        <List>
          <ListItemLink to="/admin/contact" primary="Chat" icon={<QuestionAnswer />} />
        </List>
        <LogOutButton onClick={() => setOpenConfirmLogout(true)} />
      </Drawer>
      <main className={classes.content}>
        <div className={classes.appBarSpacer} />
        {switchRoutes}
      </main>
      <DialogYesNo
        open={openConfirmLogout}
        title="Sign out"
        content="Are you sure to sign out"
        handleYes={handleLogout}
        handleNo={() => setOpenConfirmLogout(false)}
      />
    </div>
  );
}

export default withStyles(styles)(Dashboard);
