import _ from 'lodash';
import moment from 'moment';
import { DeviceUUID } from 'device-uuid';

export async function getErrorLog(skip: number, search: any) {  
  const param = {
    mode: 'MODE_SEARCH_LOG',
    param: {
      level: { content: 'ERROR' },
      tenantId: { content: '1' },
      yyyymmddhh: {
        content: moment()
          .utc()
          .format('YYYYMMDDHH')
      },
      uuid: { content: new DeviceUUID().get() }
    },
    skip
  };
  _.forEach(search, val => {
    _.set(param.param, val.key, val.value);
  });

    const res = await fetch(process.env.REACT_APP_PROD_API_URL as string, {
      method: 'POST',
      headers: { 'Accept-Charset': 'UTF-8', 'Content-Type': 'text/plain' },
      body: JSON.stringify(param),
      mode: 'cors'
    });

    if(res.ok){      
      const data = await res.json();      
      
      if (data.isSuccess) {
        return data;
      } else {
        return false;
      }
    } else {
      console.log('fetch failed');
    }
}
