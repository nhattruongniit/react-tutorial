import React, { useState, useEffect } from 'react';
import styles from './CustomPaging.module.scss';
import { PagingPanel } from '@devexpress/dx-react-grid-material-ui';

export function CustomPagingPanel(props) {
  const [currentPage, setCurrentPage] = useState(props.currentPage + 1);

  useEffect(() => {
    setCurrentPage(props.currentPage + 1);
  }, [props.currentPage]);

  function handleKeyPress(e) {
    if (e.key === 'Enter') {
      props.onCurrentPageChange(currentPage - 1);
    }
  }

  function handleInputChange(e) {
    if (parseInt(e.target.value) === 0) {
      return setCurrentPage(parseInt(e.target.value) + 1);
    }
    if (parseInt(e.target.value) > props.totalPages) {
      return setCurrentPage(props.totalPages);
    }
    setCurrentPage(parseInt(e.target.value));
  }

  return (
    <div className={styles.container}>
      <label className={styles.label}>Page</label>
      <input
        onKeyPress={handleKeyPress}
        type="number"
        className={styles.input}
        value={currentPage.toString()}
        onChange={handleInputChange}
        min={props.currentPage.toString()}
        max={props.totalPages.toString()}
      />{' '}
      / {props.totalPages}
      <PagingPanel.Container {...props} />
    </div>
  );
}
