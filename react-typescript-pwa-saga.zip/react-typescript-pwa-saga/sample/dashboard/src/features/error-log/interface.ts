/* INTERFACE */
export interface IState {
  loading: string;
  data: unknown;
  error: unknown;
}

export interface IAction {
  type: string;
  payload: unknown;
}
