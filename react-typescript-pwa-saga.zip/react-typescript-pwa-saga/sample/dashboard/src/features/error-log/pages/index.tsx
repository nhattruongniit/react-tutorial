import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchErrorLog } from 'features/error-log/redux/duck';
import {
  Grid,
  Table,
  TableHeaderRow,
  PagingPanel,
  DragDropProvider,
  TableColumnReordering,
  TableColumnResizing,
  ColumnChooser,
  TableColumnVisibility,
  Toolbar
} from '@devexpress/dx-react-grid-material-ui';
import { PagingState, CustomPaging } from '@devexpress/dx-react-grid';
import CircularProgress from '@material-ui/core/CircularProgress';
import { CustomPagingPanel } from 'features/error-log/components/CustomPagingPanel';
import FilterPanel, { IFilterOption } from 'components/FilterPanel';
import _ from 'lodash';

export function ErrorLog() {
  const dispatch = useDispatch();
  const errorLog = useSelector(state => state.errorLog);
  const [currentPage, setCurrentPage] = useState(0);
  const [searchObj, setSearchObj] = useState([]);
  const [progress, setProgress] = useState(0);

  const logKeys = [
    { name: 'osFamily', title: 'OS Family' },
    { name: 'osArchitecture', title: 'OS Architecture' },
    { name: 'osVersion', title: 'OS Version' },
    { name: 'description', title: 'Description' },
    { name: 'userId', title: 'User ID' },
    { name: 'error', title: 'Error' },
    { name: 'componentStack', title: 'Component Stack' },
    { name: 'location', title: 'Location' },
    { name: 'version', title: 'Software Version' },
    { name: 'datetime', title: 'Date Time' }
  ];

  const filterOptions: IFilterOption[] = [
    { title: 'OS Family', key: 'osFamily.content' },
    { title: 'OS Architecture', key: 'osArchitecture.content' },
    { title: 'OS Version', key: 'osVersion.content' },
    { title: 'User ID', key: 'userId.content' },
    { title: 'Error', key: 'error.content' },
    { title: 'Component Stack', key: 'componentStack.content' },
    { title: 'On Date (YYYYMMDDHH)', key: 'yyyymmddhh.content' },
    { title: 'From Date (YYYYMMDDHHmm)', key: 'dateTimeFrom.content' },
    { title: 'To Date (YYYYMMDDHHmm)', key: 'dateTimeTo.content' },
    { title: 'Version', key: 'version.content' },
    { title: 'Description', key: 'description.content' },
    { title: 'Location', key: 'location.content' }
  ];
  const [defaultColumnWidths] = useState([
    { columnName: 'index', width: 180 },
    { columnName: 'osFamily', width: 180 },
    { columnName: 'osArchitecture', width: 180 },
    { columnName: 'osVersion', width: 180 },
    { columnName: 'description', width: 180 },
    { columnName: 'userId', width: 240 },
    { columnName: 'error', width: 240 },
    { columnName: 'componentStack', width: 240 },
    { columnName: 'location', width: 240 },
    { columnName: 'version', width: 240 },
    { columnName: 'datetime', width: 240 }
  ]);

  const [defaultHiddenColumnNames] = useState([]);

  useEffect(() => {
    function tick() {
      setProgress(oldProgress => (oldProgress >= 100 ? 0 : oldProgress + 1));
    }

    const timer = setInterval(tick, 20);
    return () => {
      clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    document.title = 'Error Log - Dashboard';
  }, []);

  useEffect(() => {
    dispatch(fetchErrorLog({ page: 0, search: searchObj }));
  }, [dispatch]);

  function changeCurrentPage(currentPage: number) {
    setCurrentPage(currentPage);
    dispatch(fetchErrorLog({ page: currentPage, search: searchObj }));
  }

  const handleSearchChange = obj => {
    setCurrentPage(0);
    setSearchObj(obj);
    dispatch(fetchErrorLog({ page: 0, search: obj }));
  };

  return (
    <div>
      <h1>Error Log</h1>
      <FilterPanel onSearch={handleSearchChange} filterOptions={filterOptions} />
      {errorLog.loading === 'started' && <CircularProgress size={20} variant="determinate" value={progress} />}
      {errorLog.loading === 'stopped' && errorLog.error && <div>{errorLog.error}</div>}
      {errorLog.data && errorLog.data.rows && (
        <Grid
          rows={errorLog.data.rows.map((row: any) => {
            return {
              osFamily: _.get(row, 'data.os.family', 'N/A'),
              osVersion: _.get(row, 'data.os.version', 'N/A'),
              osArchitecture: _.get(row, 'data.os.architecture', 'N/A'),
              description: row.data.description || 'N/A',
              userId: row.data.userId || 'Anonymous',
              error: row.data.error || 'N/A',
              componentStack: row.data.componentStack || 'N/A',
              location: row.data.location || 'N/A',
              version: row.data.version || 'N/A',
              datetime: row.data.datetime || 'N/A'
            };
          })}
          columns={logKeys}
        >
          <DragDropProvider />
          <PagingState currentPage={currentPage} onCurrentPageChange={changeCurrentPage} />
          <CustomPaging totalCount={errorLog.data.total} />
          <Table />
          <TableColumnReordering
            defaultOrder={[
              'index',
              'os',
              'browser',
              'user_id',
              'error',
              'component_stack',
              'location',
              'version',
              'datetime'
            ]}
          />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow />
          <TableColumnVisibility defaultHiddenColumnNames={defaultHiddenColumnNames} />
          <Toolbar />
          <ColumnChooser />
          <PagingPanel containerComponent={CustomPagingPanel} />
        </Grid>
      )}
    </div>
  );
}
