import { createSlice, createAction } from 'redux-starter-kit';
import { IState, IAction } from 'features/error-log/interface';

/* Redux */
export const ERROR_LOG = 'ERROR_LOG';
export const FETCH_ERROR_LOG = `${ERROR_LOG}/FETCH`;

export const fetchErrorLog = createAction(FETCH_ERROR_LOG);

const INITIAL_STATE: IState = {
  loading: 'idle',
  data: null,
  error: null
};

const slice = {
  slice: ERROR_LOG,
  initialState: INITIAL_STATE,
  reducers: {
    fetchStart: (state, action: IAction) => {
      state.loading = 'started';
      state.error = '';
    },
    fetchSuccess: (state, action: IAction) => {
      state.loading = 'stopped';
      state.data = action.payload;
    },
    fetchFailure: (state, action: IAction) => {
      state.loading = 'stopped';
      state.error = action.payload;
      state.data = '';
    }
  }
};

const errorLog = createSlice(slice);

export default errorLog;
