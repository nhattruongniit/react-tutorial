import { takeLatest, put, call } from 'redux-saga/effects';
import errorLogDuck, {FETCH_ERROR_LOG} from 'features/error-log/redux/duck';
import * as api from '../api/api';

export function* fetchErrorLog(action) {
  let { page } = action.payload;
  const { search } = action.payload;

  page = page ? page + 1 : 1;
  const skip = (page - 1) * 10;
  yield put(errorLogDuck.actions.fetchStart(undefined));
  
  const data = yield call(api.getErrorLog, skip, search);  
  if (data.isSuccess) {
    yield put(errorLogDuck.actions.fetchSuccess(data));
  } else {
    yield put(errorLogDuck.actions.fetchFailure('fail fetch error log'));
  }
}

export function* watchFetchErrorLogAction() {
  yield takeLatest(FETCH_ERROR_LOG, fetchErrorLog);
}
