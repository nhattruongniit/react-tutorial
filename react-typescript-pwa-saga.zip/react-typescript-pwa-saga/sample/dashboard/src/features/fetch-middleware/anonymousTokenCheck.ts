export const anonymousTokenCheck = (url: string, options) => {
  if (options && options.body) {
    let body = { mode: '' };
    try {
      body = JSON.parse(options.body);

      if (body.mode) {
        return ['MODE_SEARCH_LOG'].indexOf(body.mode) >= 0;
      }
    } catch (e) {
      console.error(e, body);
    }
  }
  return false;
};
