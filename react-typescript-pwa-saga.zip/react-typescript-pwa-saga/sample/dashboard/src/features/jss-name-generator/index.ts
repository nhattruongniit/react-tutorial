import { createGenerateClassName } from '@material-ui/styles';

export const generateClassName = createGenerateClassName({
  productionPrefix: 'fs',
  disableGlobal: true,
  seed: '--gen--'
});
