import axiosInstance from '../../../services/http/axiosInstance';
import store from 'store';
import { MODE_CREATE_API_TOKEN } from '../../../services/http/actions/auth';
const { REACT_APP_PROD_API_URL } = process.env;

export function Login({ username, password }) {
  return axiosInstance.post('', {
    mode: 'MODE_CREATE_LOGIN_TOKEN',
    param: {
      tenantId: { content: '1' },
      userId: { content: username },
      uuid: { content: '10ba038e-48da-487b-96e8-8d3b99b6d18a' },
      password: { content: password }
    }
  });
}

export async function Test() {
  const { data } = await axiosInstance.post('', {
    mode: 'MODE_READ',
    userId: 'test1',
    apiToken: store.get('api_token'),
    expireDateTime: store.get('expire_date_time'),
    tableName: 'pptrex_product',
    skip: 20
  });
  return data;
}

export const getApiToken = loginToken => {
  const userId = store.get('userid');
  const modeCreateApiToken = MODE_CREATE_API_TOKEN({ loginToken, userId });
  const config = {
    headers: { 'Content-Type': 'text/plain' }
  };
  return axiosInstance.post(REACT_APP_PROD_API_URL as string, modeCreateApiToken, config);
};
