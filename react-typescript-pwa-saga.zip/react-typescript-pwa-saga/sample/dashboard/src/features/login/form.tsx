import React from 'react';
import { Form, Field } from 'react-final-form';
import { Input } from 'final-form-material-ui';
import { InputLabel, FormControl, Button } from '@material-ui/core';
import { useTranslation } from 'react-i18next';

export default function FormLogin({ classes, onSubmit, validationSchema, schema }) {
  const { t: translate } = useTranslation();

  return (
    <Form
      onSubmit={onSubmit}
      validate={validationSchema(schema)}
      render={(props: any) => (
        <form onSubmit={props.handleSubmit} className={classes.form}>
          <FormControl margin="normal" required fullWidth>
            <InputLabel htmlFor="username">{translate('login.username')}</InputLabel>
            <Field id="username" name="username" component={Input} />
          </FormControl>
          <FormControl margin="normal" required fullWidth>
            <InputLabel htmlFor="password">{translate('login.password')}</InputLabel>
            <Field name="password" type="password" id="password" autoComplete="current-password" component={Input} />
          </FormControl>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            className={classes.pushNotification}
            disabled={props.submitting || props.pristine || props.hasValidationErrors}
          >
            {props.submitting ? translate('Loading') : translate('login.signIn')}
          </Button>
        </form>
      )}
    />
  );
}
