import React, { useState } from 'react';
import Avatar from '@material-ui/core/Avatar';
import CssBaseline from '@material-ui/core/CssBaseline';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import withStyles from '@material-ui/core/styles/withStyles';
import * as Yup from 'yup';
import store from 'store';
import Radio from '@material-ui/core/Radio';
import indigo from '@material-ui/core/colors/indigo';
import { useTranslation } from 'react-i18next';
import validator from '../../services/validator';
import { Login, getApiToken } from './api';
import LoginForm from './form';
import SnackBar from '../../components/Snackbar';
const styles = theme => ({
  root: {
    color: indigo[100],
    '&$checked': {
      color: indigo[200]
    }
  },
  main: {
    width: 'auto',
    display: 'block', // Fix IE 11 issue.
    marginLeft: theme.spacing.unit * 3,
    marginRight: theme.spacing.unit * 3,
    [theme.breakpoints.up(400 + theme.spacing.unit * 3 * 2)]: {
      width: 400,
      marginLeft: 'auto',
      marginRight: 'auto'
    }
  },
  paper: {
    marginTop: theme.spacing.unit * 8,
    display: 'flex',
    'flex-direction': 'column',
    alignItems: 'center',
    padding: `${theme.spacing.unit * 2}px ${theme.spacing.unit * 3}px ${theme.spacing.unit * 3}px`
  },
  avatar: {
    margin: theme.spacing.unit,
    backgroundColor: theme.palette.secondary.main
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing.unit
  },
  submit: {
    marginTop: theme.spacing.unit * 3
  }
});

const schema = Yup.object({
  username: Yup.string().required('Required'),
  password: Yup.string().required('Required')
});
function SignIn(props) {
  const { classes, history } = props;
  const [showErrorNotification, setShowErrorNotification] = useState(false);
  const { i18n } = useTranslation();

  const currentLang = store.get('i18nextLng');

  const handleChangeLang = ({ target: { value } }) => i18n.changeLanguage(value);

  const onSubmit = async ({ username, password }) => {
    const {
      data: { isSuccess, loginToken }
    } = await Login({ username, password });
    const {
      data: { apiToken, expireDateTime }
    } = await getApiToken(loginToken);
    store.set('login_token', loginToken);
    store.set('apiToken', apiToken);
    store.set('expireDateTime', expireDateTime);

    if (isSuccess) {
      store.set('userid', username);
      history.push('/admin/notification');
    } else {
      setShowErrorNotification(true);
    }
  };
  return (
    <main className={classes.main}>
      <CssBaseline />
      <Paper className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <LoginForm onSubmit={onSubmit} classes={classes} validationSchema={validator} schema={schema} />
        <Typography component="p">
          <Radio
            checked={currentLang === 'en-US'}
            onChange={handleChangeLang}
            value="en-US"
            name="lang-en"
            aria-label="A"
            classes={{
              root: classes.root,
              checked: classes.checked
            }}
          />
          English
          <Radio
            checked={currentLang === 'ja'}
            onChange={handleChangeLang}
            value="ja"
            name="lang-ja"
            aria-label="A"
            classes={{
              root: classes.root,
              checked: classes.checked
            }}
          />
          日本人
        </Typography>
      </Paper>
      <SnackBar
        anchorOrigin={{ vertical: 'bottom' as any, horizontal: 'center' as any }}
        variant="error"
        message="Invalid Credentials"
        open={showErrorNotification}
        handleClose={() => setShowErrorNotification(false)}
      />
    </main>
  );
}

export default withStyles(styles)(SignIn);
