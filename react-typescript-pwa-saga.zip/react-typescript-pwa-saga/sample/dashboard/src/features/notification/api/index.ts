import axios from 'axios';
import axiosInstance from '../../../services/http/axiosInstance';
import store from 'store';
import { MODE_CREATE_API_TOKEN } from './../../../services/http/actions/auth';
import defaultIcon from './defaultIcon';
import { set } from 'lodash';
const { REACT_APP_PROD_API_URL } = process.env;

const userId = store.get('userid');
const apiToken = store.get('apiToken');
const expireDateTime = store.get('expireDateTime');
const loginToken = store.get('login_token');

const config = {
  headers: { 'Content-Type': 'text/plain' }
};

export const pushNotificationByTopic = ({ message, title, link, icon, rrule }) => {
  const body = {
    mode: 'MODE_SEND_FCM_MESSAGE_WITH_TOPIC',
    param: {
      tenantId: { content: '1' },
      title: { content: title },
      message: { content: message },
      icon: { content: icon || defaultIcon },
      link: { content: link }
    }
  };
  if (rrule) {
    set(body, 'param.rrule.content', rrule);
  }

  return axios.post(REACT_APP_PROD_API_URL as string, body, config);
};

export const pushNotificationByToken = ({ token, message, title, link, icon, rrule }) => {
  return axios.post(
    REACT_APP_PROD_API_URL as string,
    {
      mode: 'MODE_SEND_FCM_MESSAGE_WITH_USER',
      param: {
        userId: { content: token },
        tenantId: { content: '1' },
        title: { content: title },
        message: { content: message },
        icon: { content: icon || defaultIcon },
        link: { content: link },
        rrule: { content: rrule }
      }
    },
    config
  );
};

export const getApiTokenAsync = () => {
  const modeCreateApiToken = MODE_CREATE_API_TOKEN({ loginToken, userId });
  return axios.post(REACT_APP_PROD_API_URL as string, modeCreateApiToken, config);
};

export const getUsername = async ({ param, apiToken, expireDateTime, skip = 0 }) => {
  return axios.post(
    REACT_APP_PROD_API_URL as string,
    {
      mode: 'MODE_SUGGEST_USER',
      tableName: 'pptrex_user',
      skip,
      userId,
      apiToken,
      expireDateTime,
      param
    },
    config
  );
};

export const getAllNotifications = (mode: string) => {
  const body = {
    mode: 'MODE_READ_PAGINATED_SCHEDULED_FCM_MESSAGES',
    userId,
    apiToken,
    expireDateTime,
    param: {
      mode: {
        content: mode
      },
      limit: {
        // optional(default = 5)
        content: '100'
      },
      tenantId: {
        content: '1'
      }
    }
  };

  return axiosInstance.post(REACT_APP_PROD_API_URL as string, body);
};

export const deleteNotification = (notifyId: string) => {
  const body = {
    mode: 'MODE_DELETE_SCHEDULED_FCM_MESSAGE',
    userId,
    apiToken,
    expireDateTime,
    param: {
      scheduleId: {
        content: notifyId
      },
      tenantId: {
        content: '1'
      }
    }
  };

  return axiosInstance.post(REACT_APP_PROD_API_URL as string, body);
};

export const editNotification = (param, type) => {
  const mode = !type ? 'MODE_SEND_FCM_MESSAGE_WITH_TOPIC' : 'MODE_SEND_FCM_MESSAGE_WITH_USER';

  param = {
    rrule: { content: param.rule },
    link: { content: param.link },
    message: { content: param.message },
    title: { content: param.title },
    tenantId: { content: '1' },
    scheduleId: { content: param.scheduleId },
    icon: { content: param.icon },
    userId: { content: param.userId }
  }

  if(!type) delete param.userId
  
  const body = {
    mode,
    param
  }
  return axiosInstance.post(REACT_APP_PROD_API_URL as string, body);
};
