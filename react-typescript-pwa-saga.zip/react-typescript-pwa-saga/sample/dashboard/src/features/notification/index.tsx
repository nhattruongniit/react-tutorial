import React, { useState } from 'react';
import { connect } from 'react-redux';
import PushNotificationByTopic from './push-notification-by-topic';
import PushNotificationByToken from './push-notification-by-token';
import ManagementNotification from './management-notification';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import { useTranslation } from 'react-i18next';

const Notification = ({ fetchAllNotificationRequest }) => {
  const [activeTab, setActiveTab] = useState(0);
  const { t: translate } = useTranslation();
  return (
    <>
      <Typography variant="h4" gutterBottom component="h2">
        {translate('dashboard.notification')}
      </Typography>
      <AppBar position="static">
        <Tabs value={activeTab} onChange={(_, value) => setActiveTab(value)}>
          <Tab label={translate('dashboard.pushNotificationByTopic')} />
          <Tab label={translate('dashboard.pushNotificationByToken')} />
          <Tab label={translate('dashboard.managementNotification')} />
        </Tabs>
      </AppBar>
      <Typography variant="h4" gutterBottom component="h2">
        {activeTab === 0 && <PushNotificationByTopic />}
        {activeTab === 1 && <PushNotificationByToken />}
        {activeTab === 2 && <ManagementNotification />}
      </Typography>
    </>
  );
};

const mapStateToProps = state => {
  const {
    notification: { data }
  } = state;
  return { data };
};

export default connect(
  mapStateToProps,
  null
)(Notification);
