import React, { FC } from 'react';
import { createStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/styles';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

interface IProps {
  open: boolean;
  handleOkDialog: () => void;
  handleCloseDialog: () => void;
}

const useStyles = makeStyles(() =>
  createStyles({
    red: {
      color: '#F00 !important'
    }
  })
);

const DialogDelete: FC<IProps> = ({ open, handleCloseDialog, handleOkDialog }) => {
  const classes = useStyles();

  return (
    <div>
      <Dialog
        open={open}
        onClose={handleCloseDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth
      >
        <DialogTitle className={classes.red} id="alert-dialog-title">
          Confirm Dialog
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">Do you want to delete it?</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Cancel
          </Button>
          <Button onClick={handleOkDialog} color="primary" autoFocus>
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default DialogDelete;
