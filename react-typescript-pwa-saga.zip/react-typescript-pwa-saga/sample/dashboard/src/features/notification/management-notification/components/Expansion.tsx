import React, { FC } from 'react';
import { createStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/styles';

import Typography from '@material-ui/core/Typography';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Button from '@material-ui/core/Button';
import { cronToReadableString } from 'components/RRuleGenerator/utils';

const useStyles = makeStyles(() =>
  createStyles({
    heading: {
      fontSize: '20px'
    },
    content: {
      width: '100%',
      '& div + div': {
        paddingTop: '15px'
      },
      '& h3': {
        width: '100%',
        margin: 0,
        fontSize: 16
      },
      '& p': {
        fontSize: 14
      }
    },
    schedule: {
      fontSize: 16
    },
    disable: {
      pointerEvents: 'none',
      opacity: 0.8
    },
    button: {
      textAlign: 'right',
      '& button': {
        minWidth: 80
      },
      '& button + button': {
        marginLeft: 25
      }
    },
    options: {
      display: 'inline-block',
      marginRight: 10,
      '& span': {
        display: 'inline-block',
        verticalAlign: 'middle',
        fontSize: 16
      }
    }
  })
);

interface IProps {
  data: any;
  handleDelete: Function;
  handledEdit: Function;
}

const Expansion: FC<IProps> = ({ data, handleDelete, handledEdit }) => {
  const classes = useStyles();

  const renderTitle = data => {
    const body = JSON.parse(data.body);

    return (
      <div>
        {body.title.content}
        <p className={classes.schedule}>{cronToReadableString(data.schedule)}</p>
      </div>
    );
  };

  const renderContent = data => {
    const body = JSON.parse(data.body);
    const link = Object.values(body.link).length > 0 && body.link.content;
    const icon = Object.values(body.icon).length > 0 && body.icon.content;
    return (
      <div className={classes.content}>
        <div>
          <h3>Message:</h3>
          <p>{body.message.content}</p>
        </div>
        {link && (
          <div>
            <h3>Link:</h3>
            <p>{link}</p>
          </div>
        )}
        <div>
          <h3>Icon:</h3> <img src={icon} title="Icon" alt="Icon" />
        </div>
        <div className={classes.button}>
          <Button variant="contained" color="secondary" onClick={handleDelete(data.scheduleId)}>
            Delete
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handledEdit(data.schedule, data.scheduleId, body, data.userId)}
          >
            Edit
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div>
      {data.length > 0 &&
        data.map((item: any, key: number) => {
          return (
            <ExpansionPanel key={key}>
              <ExpansionPanelSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography className={classes.heading}>{renderTitle(item)}</Typography>
              </ExpansionPanelSummary>
              <ExpansionPanelDetails>{renderContent(item)}</ExpansionPanelDetails>
            </ExpansionPanel>
          );
        })}
    </div>
  );
};

export default Expansion;
