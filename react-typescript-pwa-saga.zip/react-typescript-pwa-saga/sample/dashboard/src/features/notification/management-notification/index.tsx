import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { createStyles, withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/styles';

import { green } from '@material-ui/core/colors';
import Radio, { RadioProps } from '@material-ui/core/Radio';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { getSizeFromBase64 } from 'common/helpers';

// components
import Expansion from './components/Expansion';
import DialogDelete from './components/Dialog';
import { RRuleDialog } from 'components/RRuleGenerator';

// redux
import { fetchNotifyByTopicRequest, fetchNotifyByTokenRequest, reloadNotifyRequest } from '../redux/actions';

// apis
import { deleteNotification, editNotification } from '../api';

const MODE_SEND_FCM_MESSAGE_WITH_TOPIC = 'MODE_SEND_FCM_MESSAGE_WITH_TOPIC';
const MODE_SEND_FCM_MESSAGE_WITH_TOKENS = 'MODE_SEND_FCM_MESSAGE_WITH_TOKENS';

const GreenRadio = withStyles({
  root: {
    color: green[400],
    '&$checked': {
      color: green[600]
    }
  },
  checked: {}
})((props: RadioProps) => <Radio color="default" {...props} />);

const useStyles = makeStyles(() =>
  createStyles({
    heading: {
      fontSize: '20px'
    },
    content: {
      '& div + div': {
        paddingTop: '15px'
      },
      '& h3': {
        width: '100%',
        margin: 0,
        fontSize: 16
      },
      '& p': {
        fontSize: 14
      }
    },
    schedule: {
      pointerEvents: 'none',
      opacity: 0.8,
      fontSize: 16
    },
    options: {
      display: 'inline-block',
      marginRight: 10,
      '& span': {
        display: 'inline-block',
        verticalAlign: 'middle',
        fontSize: 16
      }
    },
    notifyError: {
      color: 'red'
    }
  })
);

const ManagementNotification = ({ dataByTopic, dataByToken, fetchNotifyByTopicRequest, fetchNotifyByTokenRequest, reloadNotifyRequest }) => {
  const [open, setOpen] = useState<boolean>(false);
  const [openSchedule, setOpenSchedule] = useState<boolean>(false);
  const [schedule, setSchedule] = useState<string>('');
  const [notifyId, setNotifyId] = useState<string>('');
  const classes = useStyles();
  const [selectedValue, setSelectedValue] = useState(MODE_SEND_FCM_MESSAGE_WITH_TOPIC);
  const [headerNotify, setHeaderNotify] = useState<any>({ title: '', message: '', link: '', icon: '' })
  const [userId, setUserId] = useState<string>('');
  const [validateSizeIcon, setValidateSizeIcon] = useState<boolean>(true);

  function handleChange(event: React.ChangeEvent<HTMLInputElement>) {
    const { value } = event.target;
    setSelectedValue(value);

    if (value === MODE_SEND_FCM_MESSAGE_WITH_TOPIC) {
      fetchNotifyByTopicRequest({ mode: MODE_SEND_FCM_MESSAGE_WITH_TOPIC });
    } else {
      fetchNotifyByTokenRequest({ mode: MODE_SEND_FCM_MESSAGE_WITH_TOKENS });
    }
  }

  useEffect(() => {
    fetchNotifyByTopicRequest({ mode: MODE_SEND_FCM_MESSAGE_WITH_TOPIC });
  }, []);

  const handleDelete = (id: string) => () => {
    setOpen(true);
    setNotifyId(id);
  };

  const handleOkDialog = async () => {
    const { data } = await deleteNotification(notifyId);

    if (data && data.isSuccess) {
      setOpen(false);
    }
  };

  const handleCloseDialog = () => {
    setOpen(false);
  };

  const handledEdit = (schedule, scheduleId, body, userId) => () => {
    const {
      message: { content: message },
      link: { content: link },
      icon: { content: icon },
      title: { content: title }
    } = body
    setOpenSchedule(true);
    setSchedule(schedule);
    setNotifyId(scheduleId);
    setHeaderNotify({ title, message, link, icon })
    if (userId) setUserId(userId)
  };

  const handleRRuleClose = () => {
    setOpenSchedule(false);
    setHeaderNotify({ title: '', message: '', link: '', icon: '' })
  };

  const handleSubmitRule = async rule => {
    const type = !userId ? 0 : 1;
    await editNotification({ scheduleId: notifyId, rule, ...headerNotify, userId }, type);
    setHeaderNotify({ title: '', message: '', link: '', icon: '' });
    setOpenSchedule(false);

    reloadNotifyRequest({ ...headerNotify, rule, userId, notifyId });
  };

  const checkValidate = () => !headerNotify.message || !headerNotify.title || !validateSizeIcon;
  const checkValidateTitle = () => !headerNotify.title;
  const checkValidateMessage = () => !headerNotify.message;

  const handleFileChange = async ({ target }) => {
    if (target.files && target.files[0]) {

      var reader = new FileReader();
      reader.readAsDataURL(target.files[0]);
      reader.onload = function () {
        const sizeImage = getSizeFromBase64(reader.result);
        if(sizeImage < 3000) {
          setHeaderNotify({ ...headerNotify, icon: reader.result });
          setValidateSizeIcon(true)
        } else {
          setValidateSizeIcon(false)
        }
      };
    }
  };

  const embedChildrenDialog = () => {
    return (<div className={classes.content}>
      <div>
        <h3>Title:</h3>
        <TextField
          id="standard-full-width"
          placeholder="title"
          fullWidth
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
          value={headerNotify.title}
          error={checkValidateTitle()}
          onChange={e => setHeaderNotify({ ...headerNotify, title: e.target.value })}
        />
      </div>

      <div>
        <h3>Message:</h3>
        <TextField
          id="standard-full-width"
          placeholder="Message"
          fullWidth
          required
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
          value={headerNotify.message}
          error={checkValidateMessage()}
          onChange={e => setHeaderNotify({ ...headerNotify, message: e.target.value })}
        />
      </div>

      <div>
        <h3>Link:</h3>
        <TextField
          id="standard-full-width"
          placeholder="Link"
          fullWidth
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
          value={headerNotify.link}
          onChange={e => setHeaderNotify({ ...headerNotify, link: e.target.value })}
        />
      </div>

      <div>
        <h3>Icon:</h3> <img src={headerNotify.icon} title="Icon" alt="Icon" />
        <br/>
        <Button variant="contained" component="label" color={!validateSizeIcon ? 'secondary' : 'primary'}>
          <CloudUploadIcon />
          &nbsp;
          <input type="file" accept="image/*" onChange={e => handleFileChange(e)} />                
        </Button>
        {!validateSizeIcon && <p className={classes.notifyError}>Image size should maximum size 3 kb</p>}
      </div>
    </div>)
  }

  return (
    <div>
      <div>
        <div className={classes.options}>
          <GreenRadio
            checked={selectedValue === MODE_SEND_FCM_MESSAGE_WITH_TOPIC}
            onChange={handleChange}
            value={MODE_SEND_FCM_MESSAGE_WITH_TOPIC}
            name="management-radio"
            inputProps={{ 'aria-label': MODE_SEND_FCM_MESSAGE_WITH_TOPIC }}
          />
          <span>Notification by Topic</span>
        </div>
        <div className={classes.options}>
          <GreenRadio
            checked={selectedValue === MODE_SEND_FCM_MESSAGE_WITH_TOKENS}
            onChange={handleChange}
            value={MODE_SEND_FCM_MESSAGE_WITH_TOKENS}
            name="management-radio"
            inputProps={{ 'aria-label': MODE_SEND_FCM_MESSAGE_WITH_TOKENS }}
          />
          <span>Notification by Tokens</span>
        </div>
      </div>
      {selectedValue === MODE_SEND_FCM_MESSAGE_WITH_TOPIC && (
        <Expansion data={dataByTopic} handleDelete={handleDelete} handledEdit={handledEdit} />
      )}
      {selectedValue === MODE_SEND_FCM_MESSAGE_WITH_TOKENS && (
        <Expansion data={dataByToken} handleDelete={handleDelete} handledEdit={handledEdit} />
      )}
      <DialogDelete open={open} handleOkDialog={handleOkDialog} handleCloseDialog={handleCloseDialog} />
      <RRuleDialog
        open={openSchedule}
        value={schedule}
        onConfirm={rrule => {
          handleSubmitRule(rrule);
        }}
        onClose={handleRRuleClose}
        disabled={checkValidate()}
      >
        {embedChildrenDialog()}
      </ RRuleDialog>
    </div>
  );
};

const mapStateToProps = state => {
  const {
    notification: {
      notifyByTopic: { data: dataByTopic },
      notifyByToken: { data: dataByToken }
    }
  } = state;
  return { dataByTopic, dataByToken };
};

const mapDispatchToProps = {
  fetchNotifyByTopicRequest,
  fetchNotifyByTokenRequest,
  reloadNotifyRequest
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ManagementNotification);
