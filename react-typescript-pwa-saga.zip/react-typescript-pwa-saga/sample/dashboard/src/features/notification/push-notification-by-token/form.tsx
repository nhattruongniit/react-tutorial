import React, { useState } from 'react';
import { Field, Form } from 'react-final-form';
import { TextField } from 'final-form-material-ui';
import {
  Paper,
  Grid,
  Button,
  FormControl,
  Select,
  TextField as TextFieldMaterial,
  MenuItem,
  CircularProgress
} from '@material-ui/core';
import { useTranslation } from 'react-i18next';

import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { RRuleDialog } from 'components/RRuleGenerator';
import _ from 'lodash';

export default function FormPushNotificationByTopic({
  classes,
  onSubmit,
  validationSchema,
  schema,
  onChangeName,
  isProgressing,
  listUserResponse,
  userId,
  handleChooseSelectBox
}) {
  const { t: translate } = useTranslation();
  const onChange = _.debounce(onChangeName(), 300);

  const [formOpen, setFormOpen] = useState(false);

  const handlePush = props => {
    props.form.change('rrule', '');
    props.form.submit();
  };

  const handlePushRRule = (props, rrule) => {
    props.form.change('rrule', rrule);
    props.form.submit();
    setFormOpen(false);
  };

  const handleRRuleClose = () => {
    setFormOpen(false);
  };

  const handleFileChange = (props, { target }: { target: any }) => {
    if (target.files && target.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e: any) {
        props.form.change('notiIcon', e.target.result);
      };

      reader.readAsDataURL(target.files[0]);
    }
  };
  return (
    <Form
      onSubmit={onSubmit}
      validate={validationSchema(schema)}
      render={(props: any) => (
        <form onSubmit={props.handleSubmit}>
          <Paper className={classes.paper}>
            <div className={classes.contentWrapper}>
              <Grid container spacing={24} alignItems="center">
                <Grid item xs={10} sm={11}>
                  <TextFieldMaterial
                    fullWidth
                    name="name"
                    margin="normal"
                    disabled={props.submitting}
                    className={`${classes.searchInput} ${classes.clearSpace}`}
                    label={translate('dashboard.name')}
                    onChange={event => {
                      event.persist();
                      onChange(event);
                    }}
                    autoComplete="off"
                  />
                </Grid>
                <Grid item xs={2} sm={1}>
                  {isProgressing && <CircularProgress className={classes.progress} />}
                </Grid>
                <Grid item xs={12}>
                  {listUserResponse && !!listUserResponse.length && (
                    <FormControl variant="outlined" className={classes.formControl} fullWidth>
                      <Select value={[userId]} onChange={handleChooseSelectBox()}>
                        <MenuItem value={''}>-- {translate('dashboard.SelectUserName')} --</MenuItem>
                        {listUserResponse &&
                          !!listUserResponse.length &&
                          listUserResponse.map(i => (
                            <MenuItem value={i.userId} key={i.userId}>
                              {i.name}
                            </MenuItem>
                          ))}
                      </Select>
                    </FormControl>
                  )}
                </Grid>
                <Grid item xs={12}>
                  <Field
                    name="title"
                    type="text"
                    margin="normal"
                    component={TextField}
                    disabled={props.submitting}
                    label={translate('dashboard.title')}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field
                    name="notiMessage"
                    type="text"
                    margin="normal"
                    component={TextField}
                    disabled={props.submitting}
                    label={translate('dashboard.Enter notification message')}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field
                    name="notiLink"
                    type="text"
                    margin="normal"
                    disabled={props.submitting}
                    component={TextField}
                    label={translate('dashboard.Enter notification link')}
                    fullWidth
                  />
                </Grid>

                <Grid item xs={12}>
                  <Field name="notiIcon" disabled={props.submitting} margin="normal" fullWidth>
                    {({ meta }) => (
                      <div>
                        <Button variant="contained" component="label">
                          <CloudUploadIcon />
                          &nbsp;
                          <input type="file" accept="image/*" onChange={e => handleFileChange(props, e)} />
                        </Button>
                        {meta.error && <p className={classes.errorText}>{meta.error}</p>}
                      </div>
                    )}
                  </Field>
                </Grid>

                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <Button
                    type="button"
                    variant="contained"
                    color="primary"
                    onClick={() => setFormOpen(true)}
                    disabled={props.submitting || props.pristine || props.hasValidationErrors || !userId}
                    className={classes.pushNotification}
                  >
                    {props.submitting ? translate('dashboard.Loading') : 'Push with Recurrent Rule'}
                  </Button>

                  <Button
                    type="button"
                    variant="contained"
                    color="primary"
                    className={classes.pushNotification}
                    disabled={props.submitting || props.pristine || props.hasValidationErrors || !userId}
                    onClick={() => handlePush(props)}
                  >
                    {props.submitting ? translate('dashboard.Loading') : translate('dashboard.pushNotification')}
                  </Button>
                </Grid>
              </Grid>

              <RRuleDialog
                open={formOpen}
                onConfirm={rrule => {
                  handlePushRRule(props, rrule);
                }}
                onClose={handleRRuleClose}
              />
            </div>
          </Paper>
        </form>
      )}
    />
  );
}
