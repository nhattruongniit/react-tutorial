import React, { useState, useEffect } from 'react';
import { withStyles } from '@material-ui/core';
import * as Yup from 'yup';
import { getSizeFromBase64 } from 'common/helpers';
import FormPushNotificationByToken from './form';
import validator from '../../../services/validator';
import SnackBar from '../../../components/Snackbar';

import { getUsername, getApiTokenAsync, pushNotificationByToken } from '../../notification/api';

const styles = theme => ({
  paper: {
    margin: 'auto',
    overflow: 'hidden'
  },
  searchBar: {
    borderBottom: '1px solid rgba(0, 0, 0, 0.12)'
  },
  searchInput: {
    fontSize: theme.typography.fontSize,
    marginTop: 0,
    marginBottom: 0
  },
  block: {
    display: 'block'
  },
  pushNotification: {
    marginRight: theme.spacing.unit
  },
  contentWrapper: {
    margin: '40px 16px'
  },
  groupRadio: {
    display: 'flex'
  },
  clearSpace: {
    padding: 'none'
  },
  errorText: {
    fontSize: '0.75rem',
    lineHeight: '1rem',
    color: '#f44336'
  }
});

const schema = Yup.object({
  notiMessage: Yup.string().required('Required'),
  title: Yup.string().required('Required'),
  notiIcon: Yup.string().test('len size', 'Image size should < 3 kb', value => getSizeFromBase64(value) < 3000)
});

function PushNotificationByTopic({ classes }) {
  const [isProgressing, setIsProgressing] = useState(false);
  const [showSuccessNotification, setShowSuccessNotification] = useState(false);
  const [showErrorNotification, setShowErrorNotification] = useState(false);
  const [listUserResponse, setListUserResponse] = useState([]);
  const [loginToken, setLoginToken] = useState({ apiToken: '', expireDateTime: '' });
  const [userId, setUserId] = useState('');

  useEffect(() => {
    getApiTokenAsync()
      .then(({ data }) => setLoginToken(data))
      .catch(err => err);
  }, []);

  const onSubmit = async values => {
    try {
      const { title, notiMessage: message, notiLink: link, notiIcon: icon, rrule } = values;
      const {
        data: { isSuccess }
      } = await pushNotificationByToken({ token: userId, message, title, link, icon, rrule });
      isSuccess ? setShowSuccessNotification(true) : setShowErrorNotification(true);
    } catch (error) {
      setShowErrorNotification(true);
    }
  };

  const onChangeName = () => async event => {
    setIsProgressing(true);
    event.preventDefault();
    const {
      target: { value }
    } = event;
    setUserId('');
    const { status, data } = await getUsername({
      param: {
        name: {
          content: value
        },
        userId: {
          content: value
        },
        tenantId: {
          content: '1'
        }
      },
      apiToken: loginToken.apiToken,
      expireDateTime: loginToken.expireDateTime
    });
    if (status === 200) setListUserResponse(data.rows);
    setIsProgressing(false);
  };

  const handleChooseSelectBox = () => e => {
    const value = e.nativeEvent.target.getAttribute('data-value');
    setUserId(value);
  };

  return (
    <>
      <FormPushNotificationByToken
        schema={schema}
        classes={classes}
        validationSchema={validator}
        onSubmit={onSubmit}
        onChangeName={onChangeName}
        isProgressing={isProgressing}
        listUserResponse={listUserResponse}
        userId={userId}
        handleChooseSelectBox={handleChooseSelectBox}
      />
      <SnackBar
        variant="success"
        message="Push Notification Successfully"
        open={showSuccessNotification}
        handleClose={() => setShowSuccessNotification(false)}
      />
      <SnackBar
        variant="error"
        message="Something went wrong"
        open={showErrorNotification}
        handleClose={() => setShowErrorNotification(false)}
      />
    </>
  );
}

export default withStyles(styles)(PushNotificationByTopic);
