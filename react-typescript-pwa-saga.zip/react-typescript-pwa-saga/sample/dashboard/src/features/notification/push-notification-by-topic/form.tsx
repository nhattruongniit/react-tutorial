import React, { useState } from 'react';
import { Field, Form } from 'react-final-form';
import { TextField } from 'final-form-material-ui';
import { Paper, Grid, Button } from '@material-ui/core';
import { useTranslation } from 'react-i18next';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { RRuleDialog } from 'components/RRuleGenerator';

export default function FormPushNotificationByTopic({ classes, onSubmit, validationSchema, schema }) {
  const { t: translate } = useTranslation();
  const [formOpen, setFormOpen] = useState(false);

  const handlePush = props => {
    props.form.change('rrule', '');
    props.form.submit();
  };

  const handlePushRRule = (props, rrule) => {
    props.form.change('rrule', rrule);
    props.form.submit();
    setFormOpen(false);
  };

  const handleRRuleClose = () => {
    setFormOpen(false);
  };

  const handleFileChange = (props, { target }: { target: any }) => {
    if (target.files && target.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e: any) {
        props.form.change('notiIcon', e.target.result);
      };

      reader.readAsDataURL(target.files[0]);
    }
  };

  return (
    <Form
      onSubmit={onSubmit}
      validate={validationSchema(schema)}
      render={(props: any) => (
        <form onSubmit={props.handleSubmit}>
          <Paper className={classes.paper}>
            <div className={classes.contentWrapper}>
              <Grid container spacing={24} alignItems="center">
                <Grid item xs={12}>
                  <Field
                    name="title"
                    type="text"
                    component={TextField}
                    label={translate('dashboard.title')}
                    margin="normal"
                    disabled={props.submitting}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field
                    name="notiMessage"
                    type="text"
                    component={TextField}
                    label={translate('dashboard.Enter notification message')}
                    margin="normal"
                    disabled={props.submitting}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field
                    name="notiLink"
                    type="text"
                    component={TextField}
                    label={translate('dashboard.Enter notification link')}
                    margin="normal"
                    disabled={props.submitting}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field name="notiIcon" disabled={props.submitting} margin="normal" fullWidth>
                    {({ meta }) => (
                      <div>
                        <Button variant="contained" component="label">
                          <CloudUploadIcon />
                          &nbsp;
                          <input type="file" accept="image/*" onChange={e => handleFileChange(props, e)} />
                        </Button>
                        {meta.error && <p className={classes.errorText}>{meta.error}</p>}
                      </div>
                    )}
                  </Field>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <Button
                    type="button"
                    variant="contained"
                    color="primary"
                    onClick={() => setFormOpen(true)}
                    disabled={props.submitting || props.pristine || props.hasValidationErrors}
                    className={classes.pushNotification}
                  >
                    {'Push with Recurrent Rule'}
                  </Button>

                  <Button
                    type="button"
                    variant="contained"
                    color="primary"
                    className={classes.pushNotification}
                    disabled={props.submitting || props.pristine || props.hasValidationErrors}
                    onClick={() => handlePush(props)}
                  >
                    {props.submitting ? translate('dashboard.Loading') : translate('dashboard.pushNotification')}
                  </Button>
                </Grid>
              </Grid>

              <RRuleDialog
                open={formOpen}
                onConfirm={rrule => {
                  handlePushRRule(props, rrule);
                }}
                onClose={handleRRuleClose}
              />
            </div>
          </Paper>
        </form>
      )}
    />
  );
}
