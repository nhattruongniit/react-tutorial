import React, { useState } from 'react';
import { withStyles } from '@material-ui/core';
import * as Yup from 'yup';
import { getSizeFromBase64 } from 'common/helpers';
import FormPushNotificationByTopic from './form';
import validator from '../../../services/validator';
import SnackBar from '../../../components/Snackbar';

import { pushNotificationByTopic } from '../api';

const styles = theme => ({
  paper: {
    margin: 'auto',
    overflow: 'hidden'
  },
  searchBar: {
    borderBottom: '1px solid rgba(0, 0, 0, 0.12)'
  },
  searchInput: {
    fontSize: theme.typography.fontSize
  },
  block: {
    display: 'block'
  },
  pushNotification: {
    marginRight: theme.spacing.unit
  },
  contentWrapper: {
    margin: '40px 16px'
  },
  errorText: {
    fontSize: '0.75rem',
    lineHeight: '1rem',
    color: '#f44336'
  }
});

const schema = Yup.object({
  notiMessage: Yup.string().required('Required'),
  title: Yup.string().required('Required'),
  notiIcon: Yup.string().test('len size', 'Image size should < 3 kb', value => getSizeFromBase64(value) < 3000)
});
function PushNotificationByTopic({ classes }) {
  const [showSuccessNotification, setShowSuccessNotification] = useState(false);
  const [showErrorNotification, setShowErrorNotification] = useState(false);

  const onSubmit = async values => {
    try {
      const { title, notiMessage: message, notiLink: link, notiIcon: icon, rrule } = values;
      const {
        data: { isSuccess }
      } = await pushNotificationByTopic({ message, title, link, icon, rrule });

      isSuccess ? setShowSuccessNotification(true) : setShowErrorNotification(true);
    } catch (error) {
      setShowErrorNotification(true);
    }
  };
  return (
    <>
      <FormPushNotificationByTopic schema={schema} classes={classes} validationSchema={validator} onSubmit={onSubmit} />
      <SnackBar
        variant="success"
        message="Push Notification Successfully"
        open={showSuccessNotification}
        handleClose={() => setShowSuccessNotification(false)}
      />
      <SnackBar
        variant="error"
        message="Something went wrong"
        open={showErrorNotification}
        handleClose={() => setShowErrorNotification(false)}
      />
    </>
  );
}

export default withStyles(styles)(PushNotificationByTopic);
