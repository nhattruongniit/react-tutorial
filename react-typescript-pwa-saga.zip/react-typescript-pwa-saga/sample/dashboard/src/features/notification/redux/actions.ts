import {
  FETCH_NOTIFY_BY_TOPIC_REQUEST,
  FETCH_NOTIFY_BY_TOPIC_SUCCESS,
  FETCH_NOTIFY_BY_TOPIC_FAILURE,
  FETCH_NOTIFY_BY_TOKEN_REQUEST,
  FETCH_NOTIFY_BY_TOKEN_SUCCESS,
  FETCH_NOTIFY_BY_TOKEN_FAILURE,
  RELOAD_NOTIFY_REQUEST
} from './constants';

export interface IPayload {
  data: [];
  total: number;
  isSuccess: boolean;
}

interface IRequest {
  mode: string;
}

export const fetchNotifyByTopicRequest = (payload: IRequest) => ({ type: FETCH_NOTIFY_BY_TOPIC_REQUEST, payload });
export const fetchNotifyByTopicSuccess = (payload: IPayload) => ({ type: FETCH_NOTIFY_BY_TOPIC_SUCCESS, payload });
export const fetchNotifyByTopicFailure = (error: string) => ({
  type: FETCH_NOTIFY_BY_TOPIC_FAILURE,
  payload: { error }
});

export const fetchNotifyByTokenRequest = (payload: IRequest) => ({ type: FETCH_NOTIFY_BY_TOKEN_REQUEST, payload });
export const fetchNotifyByTokenSuccess = (payload: IPayload) => ({ type: FETCH_NOTIFY_BY_TOKEN_SUCCESS, payload });
export const fetchNotifyByTokenFailure = (error: string) => ({
  type: FETCH_NOTIFY_BY_TOKEN_FAILURE,
  payload: { error }
});

export const reloadNotifyRequest = (payload: IRequest) => ({ type: RELOAD_NOTIFY_REQUEST, payload });