import { combineReducers } from 'redux';
import {
  FETCH_NOTIFY_BY_TOPIC_REQUEST,
  FETCH_NOTIFY_BY_TOPIC_SUCCESS,
  FETCH_NOTIFY_BY_TOPIC_FAILURE,
  FETCH_NOTIFY_BY_TOKEN_REQUEST,
  FETCH_NOTIFY_BY_TOKEN_SUCCESS,
  FETCH_NOTIFY_BY_TOKEN_FAILURE
} from './constants';

interface IAction {
  type: string;
  payload?: any;
}

interface IState {
  data: [];
  total: number;
  isSuccess: boolean;
}

const initialState: IState = {
  data: [],
  total: 0,
  isSuccess: false
};

function notifyByTopic(state = initialState, { type, payload }: IAction): IState {
  switch (type) {
    case FETCH_NOTIFY_BY_TOPIC_REQUEST:
      return {
        ...state,
        data: [],
        total: 0,
        isSuccess: false
      };
    case FETCH_NOTIFY_BY_TOPIC_SUCCESS:
      return {
        ...state,
        data: payload.rows.reverse(),
        total: payload.total,
        isSuccess: payload.isSuccess
      };
    case FETCH_NOTIFY_BY_TOPIC_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    default:
      return state;
  }
}

function notifyByToken(state = initialState, { type, payload }: IAction): IState {
  switch (type) {
    case FETCH_NOTIFY_BY_TOKEN_REQUEST:
      return {
        ...state,
        data: [],
        total: 0,
        isSuccess: false
      };
    case FETCH_NOTIFY_BY_TOKEN_SUCCESS:
      return {
        ...state,
        data: payload.rows.reverse(),
        total: payload.total,
        isSuccess: payload.isSuccess
      };
    case FETCH_NOTIFY_BY_TOKEN_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    default:
      return state;
  }
}

export default combineReducers({
  notifyByTopic,
  notifyByToken
});
