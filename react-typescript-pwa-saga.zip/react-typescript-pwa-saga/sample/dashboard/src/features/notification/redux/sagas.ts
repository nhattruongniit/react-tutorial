import { takeLatest, put, call, select } from 'redux-saga/effects';
import { FETCH_NOTIFY_BY_TOPIC_REQUEST, FETCH_NOTIFY_BY_TOKEN_REQUEST, RELOAD_NOTIFY_REQUEST } from './constants';

import {
  fetchNotifyByTopicSuccess,
  fetchNotifyByTopicFailure,
  fetchNotifyByTokenSuccess,
  fetchNotifyByTokenFailure
} from './actions';

// api
import { getAllNotifications } from '../api';

const getDataByTopic = ({ notification: { notifyByTopic } }) => notifyByTopic;
const getDataByToken = ({ notification: { notifyByToken } }) => notifyByToken;

function* fetchNotifyByTopic(action) {
  const { mode } = action.payload;
  try {
    const { data } = yield call(getAllNotifications, mode);
    yield put(fetchNotifyByTopicSuccess(data));
  } catch (err) {
    yield put(fetchNotifyByTopicFailure(err.response));
  }
}

function* fetchNotifyByToken(action) {
  const { mode } = action.payload;
  try {
    const { data } = yield call(getAllNotifications, mode);
    yield put(fetchNotifyByTokenSuccess(data));
  } catch (err) {
    yield put(fetchNotifyByTokenFailure(err.response));
  }
}

function* reloadNotifyByTopic(action) {
  const { icon, link, message, rule, title, userId, notifyId } = action.payload;
  if (!userId) {
    let notifyByTopic = yield select(getDataByTopic);
    notifyByTopic.rows = notifyByTopic.data.map(i => {
      if (i.scheduleId === notifyId) {
        let bodyParse = JSON.parse(i.body);
        i.schedule = rule;
        bodyParse = { ...bodyParse, title: { content: title }, message: { content: message }, link: { content: link }, icon: { content: icon } };
        i.body = JSON.stringify(bodyParse);
      }
      return i;
    }).reverse();
    yield put(fetchNotifyByTopicSuccess(notifyByTopic));
  } else {
    const notifyByToken = yield select(getDataByToken);
    notifyByToken.rows = notifyByToken.data.map(i => {
      if (i.scheduleId === notifyId) {
        let bodyParse = JSON.parse(i.body);
        i.schedule = rule;
        bodyParse = { ...bodyParse, title: { content: title }, message: { content: message }, link: { content: link }, icon: { content: icon } };
        i.body = JSON.stringify(bodyParse);
      }
      return i;
    }).reverse();
    yield put(fetchNotifyByTokenSuccess(notifyByToken));
  }
}

export function* saga() {
  yield takeLatest(FETCH_NOTIFY_BY_TOPIC_REQUEST, fetchNotifyByTopic);
  yield takeLatest(FETCH_NOTIFY_BY_TOKEN_REQUEST, fetchNotifyByToken);
  yield takeLatest(RELOAD_NOTIFY_REQUEST, reloadNotifyByTopic);
}
