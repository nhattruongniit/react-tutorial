import React, { useState, useEffect } from 'react';
import moment from 'moment';
import { FlexChart, FlexChartSeries, FlexChartDataLabel } from 'wijmo/wijmo.react.chart';
import 'wijmo/styles/wijmo.css';

const gapi = (window as any).gapi;
const AnalyticsReport = () => {
  const [dataReport, setDataReport] = useState([]);
  const normalizeData = rows => {
    return rows.map(({ dimensions, metrics }) => {
      const [date] = dimensions;
      const [
        {
          values: [value]
        }
      ] = metrics;
      const dateFormated = moment(date).format('MMM-DD');
      return {
        date: dateFormated,
        sessions: Number(value)
      };
    });
  };
  const onSuccess = async googleUser => {
    const profile = googleUser.getBasicProfile();
    if (profile) {
      const {
        result: {
          reports: [
            {
              data: { rows }
            }
          ]
        }
      } = await gapi.client.request({
        path: '/v4/reports:batchGet',
        root: 'https://analyticsreporting.googleapis.com/',
        method: 'POST',
        body: {
          reportRequests: [
            {
              viewId: 'ga:195600886',
              dateRanges: [
                {
                  startDate: '30daysAgo',
                  endDate: 'yesterday'
                }
              ],
              metrics: [
                {
                  expression: 'ga:sessions'
                }
              ],
              dimensions: [
                {
                  name: 'ga:date'
                }
              ]
            }
          ]
        }
      });
      const normalizedData = normalizeData(rows);
      setDataReport(normalizedData);
    }
  };

  const handleLoad = () => {
    (window as any).gapi.signin2.render('g-signin2', {
      scope: 'https://www.googleapis.com/auth/plus.login',
      width: 200,
      height: 50,
      longtitle: true,
      theme: 'dark',
      onsuccess: onSuccess
    });
  };
  useEffect(() => {
    handleLoad();
  }, []);
  return !dataReport.length ? (
    <p id="g-signin2" className="g-signin2" data-onsuccess="queryReports" />
  ) : (
    <div className="container-fluid">
      <FlexChart itemsSource={dataReport} bindingX="date" header="Number of sessions" tooltipContent="">
        <FlexChartSeries name="sessions" binding="sessions" />
        <FlexChartDataLabel content="{y}" />
      </FlexChart>
    </div>
  );
};

export default AnalyticsReport;
