import Notification from './notification';
import AnalyticsReport from './report';
import Chat from './chat';
import { ErrorLog } from 'features/error-log/pages';

const routes = [
  {
    path: '/admin/notification',
    exact: true,
    component: Notification
  },
  {
    path: '/admin/report',
    exact: true,
    component: AnalyticsReport
  },
  {
    path: '/admin/contact',
    exact: true,
    component: Chat
  },
  {
    path: '/admin/error-log',
    exact: true,
    component: ErrorLog
  }
];

export default routes;
