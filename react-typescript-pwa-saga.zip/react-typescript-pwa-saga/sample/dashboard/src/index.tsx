import React, { Suspense } from 'react';
import * as ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Redirect } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from 'store';
import configureAppStore from './configureStore'; // old
import Dashboard from './features/dashboard';
import Login from './features/login';
import './i18n.ts';
import registerServiceWorker from './registerServiceWorker';
import { applyAnonymousToken, injectAnonymousCheck } from '@mochi/fetch-middleware/helpers';
import { anonymousTokenCheck } from './features/fetch-middleware/anonymousTokenCheck';
import { StylesProvider } from '@material-ui/styles';
import { generateClassName } from './features/jss-name-generator';

applyAnonymousToken();
injectAnonymousCheck('anonymousTokenCheck', anonymousTokenCheck);

const authenticate = () => {
  const loginToken = store.get('login_token');
  if (loginToken) {
    return true;
  }
  return false;
};

function PrivateRoute({ component: Component, ...rest }) {
  return (
    <Route
      {...rest}
      render={props =>
        authenticate() ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: '/login',
              state: { from: props.location }
            }}
          />
        )
      }
    />
  );
}

const Loader = () => <div>loading...</div>;
const reduxStore = configureAppStore();

ReactDOM.render(
  <Provider store={reduxStore}>
    <Suspense fallback={<Loader />}>
      <Router>
        <StylesProvider generateClassName={generateClassName}>
          <PrivateRoute exact={true} path="/" component={Dashboard} />
          <PrivateRoute path="/admin" component={Dashboard} />
          <Route path="/login" component={Login} />
        </StylesProvider>
      </Router>
    </Suspense>
  </Provider>,
  document.getElementById('root') as HTMLElement
);
registerServiceWorker();
