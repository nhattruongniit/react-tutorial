import errorLog from './features/error-log/redux/duck';
import notification from 'features/notification/redux/reducers';

export default {
  errorLog: errorLog.reducer,
  notification
};
