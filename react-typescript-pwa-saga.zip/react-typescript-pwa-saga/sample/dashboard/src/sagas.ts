import { all } from 'redux-saga/effects';
import { watchFetchErrorLogAction } from 'features/error-log/redux/saga';
import { saga as watchFetchAllNotification } from 'features/notification/redux/sagas';

export default function* rootSaga() {
  yield all([watchFetchErrorLogAction(), watchFetchAllNotification()]);
}
