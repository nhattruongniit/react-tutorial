export function MODE_CREATE_ANONYMOUS_TOKEN(uuid) {
  return {
    mode: 'MODE_CREATE_ANONYMOUS_TOKEN',
    param: {
      tenantId: { content: '1' },
      uuid: { content: uuid }
    }
  };
}
