export function MODE_CREATE_API_TOKEN ({loginToken, userId}) {
    return {
        mode: 'MODE_CREATE_API_TOKEN',
        param: {
          tenantId: { content: '1' },
          userId: { content: userId },
          uuid: { content: '10ba038e-48da-487b-96e8-8d3b99b6d18a' },
          loginToken: { content: loginToken }
        }
    }
  }