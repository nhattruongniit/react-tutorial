import axios from 'axios';
import store from 'store';
import { MODE_CREATE_API_TOKEN } from './actions/auth';
const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_PROD_API_URL as string,
  timeout: 5000,
  headers: {
    'Content-Type': 'text/plain'
  }
});

function requestDataToJSON(request) {
  const { data } = request;
  const dataJson = JSON.parse(data);
  return dataJson;
}
function refreshApiToken({ dataToJSON, apiToken, expireDateTime }) {
  const withNewToken = {
    ...dataToJSON,
    apiToken,
    expireDateTime
  };
  return JSON.stringify(withNewToken);
}

function saveNewApiToken(apiToken, expireDateTime) {
  store.set('api_token', apiToken);
  store.set('expire_date_time', expireDateTime);
}

async function exchangeNewApiToken({ loginToken, userId }) {
  const {
    data: { isSuccess, apiToken, expireDateTime }
  } = await axiosInstance.post(
    process.env.REACT_APP_PROD_API_URL as string,
    MODE_CREATE_API_TOKEN({ loginToken, userId })
  );
  if (!isSuccess) {
    throw {
      type: 'MODE_CREATE_LOGIN_TOKEN',
      error: { isSuccess }
    };
  }
  return { apiToken, expireDateTime };
}

axiosInstance.interceptors.response.use(async response => {
  try {
    const {
      data: { isSuccess, isApiTokenExpire }
    } = response;
    if (!isSuccess && isApiTokenExpire) {
      const { config: originalRequest } = response;
      const loginToken = store.get('login_token');
      const userId = store.get('user_id');
      const { apiToken, expireDateTime } = await exchangeNewApiToken({ loginToken, userId });
      const dataToJSON = requestDataToJSON(originalRequest);
      originalRequest.data = refreshApiToken({ dataToJSON, apiToken, expireDateTime });
      saveNewApiToken(apiToken, expireDateTime);
      await axios(originalRequest);
      return response;
    }
    return response;
  } catch (error) {
    return error;
  }
});
export default axiosInstance;
