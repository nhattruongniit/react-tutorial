import { Schema } from 'yup';
interface IformError {
  [key: string]: any;
}
export default (schema: Schema<IformError>) => async values => {
  try {
    await schema.validate(values, { abortEarly: false });
  } catch (err) {
    const errors = err.inner.reduce(
      (formError: IformError, innerError: IformError) => ({
        ...formError,
        [innerError.path]: innerError.message
      }),
      {}
    );
    return errors;
  }
};
