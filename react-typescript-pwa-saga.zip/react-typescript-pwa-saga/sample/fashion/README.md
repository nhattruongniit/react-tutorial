# Chat Test Case

```sh
  // test case 1: a link:testasdsa asdsad asdas
  // test case 2: a link:testasds_123Z
  // test case 3: a link:test - link:aaa
  // test case 4: a link:test-link aaa va   link:hay
```
