! function(e, t) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = t();
    else if ("function" == typeof define && define.amd) define([], t);
    else {
        var n = t();
        for (var o in n)("object" == typeof exports ? exports : e)[o] = n[o]
    }
  }("undefined" != typeof self ? self : this, function() {
    return function(e) {
        var t = {};
  
        function n(o) {
            if (t[o]) return t[o].exports;
            var r = t[o] = {
                i: o,
                l: !1,
                exports: {}
            };
            return e[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports
        }
        return n.m = e, n.c = t, n.d = function(e, t, o) {
            n.o(e, t) || Object.defineProperty(e, t, {
                configurable: !1,
                enumerable: !0,
                get: o
            })
        }, n.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return n.d(t, "a", t), t
        }, n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, n.p = "", n(n.s = 9)
    }([function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(5),
            r = n(13),
            i = n(4),
            a = n(3),
            c = function() {
                function e(e, t, n) {
                    if (this.className = e, this.queue = t, "string" != typeof e || !(t instanceof o.Queue)) throw Error("Invalid arguments.");
                    this.instanceId_ = a.generateId(), this.callback = new i.Callback(this.instanceId_), n && this.queue.enqueue(this.className, "_jsConstructor", this.instanceId_, null, n)
                }
                return Object.defineProperty(e.prototype, "instanceId", {
                    get: function() {
                        return this.instanceId_
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.enqueue = function(e, t, n) {
                    return this.queue.enqueue(this.className, e, this.instanceId_, t, n)
                }, e.prototype.enqueueCb = function(e, t, n, o) {
                    var i = {
                        resolve: function(e) {
                            t && t(e)
                        },
                        reject: function(e) {
                            n && n(e)
                        }
                    };
                    return this.enqueue(e, new r.Result(i), o)
                }, e.prototype.registerCallback = function(e, t) {
                    this.callback.registerCallback(e, t)
                }, e
            }();
        t.Base = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(6),
            a = n(0),
            c = n(2),
            u = function(e) {
                function t(n, o, r) {
                    var i = e.call(this, t.API_CLASS_ID, n) || this;
                    return i.name = o, i.fullPath = r, i.isFile = !1, i.isDirectory = !0, i.filesystem = null, i.queue_ = n, i
                }
                return r(t, e), t.prototype.createReader = function() {
                    return new i.DirectoryReader(this.queue_, this.fullPath)
                }, t.prototype.getParent = function(n, o) {
                    var r = this,
                        i = {
                            fullPath: this.fullPath
                        };
                    e.prototype.enqueueCb.call(this, "getParent", function(e) {
                        e && e.name && e.fullPath && n && n(new t(r.queue_, e.name, e.fullPath))
                    }, o, i)
                }, t.prototype.getFile = function(t, n, o, r) {
                    var i = this;
                    (n = n || {}).filePath = t, n.fullPath = this.fullPath, e.prototype.enqueueCb.call(this, "getFile", function(e) {
                        e && e.name && e.fullPath && o && o(new c.FileEntry(i.queue_, e.name, e.fullPath))
                    }, r, n)
                }, t.prototype.getDirectory = function(n, o, r, i) {
                    var a = this;
                    (o = o || {}).path = n, o.fullPath = this.fullPath, e.prototype.enqueueCb.call(this, "getDirectory", function(e) {
                        e && e.name && e.fullPath && r && r(new t(a.queue_, e.name, e.fullPath))
                    }, i, o)
                }, t.prototype.moveTo = function(n, o, r, i) {
                    var a = this,
                        c = {
                            fullPath: this.fullPath,
                            parentPath: n.fullPath,
                            newName: o || this.name
                        };
                    e.prototype.enqueueCb.call(this, "moveTo", function(e) {
                        e && e.name && e.fullPath && r && r(new t(a.queue_, e.name, e.fullPath))
                    }, i, c)
                }, t.prototype.copyTo = function(n, o, r, i) {
                    var a = this,
                        c = {
                            fullPath: this.fullPath,
                            parentPath: n.fullPath,
                            newName: o || this.name
                        };
                    e.prototype.enqueueCb.call(this, "copyTo", function(e) {
                        e && e.name && e.fullPath && r && r(new t(a.queue_, e.name, e.fullPath))
                    }, i, c)
                }, t.prototype.remove = function(t, n) {
                    var o = {
                        fullPath: this.fullPath
                    };
                    e.prototype.enqueueCb.call(this, "remove", t, n, o)
                }, t.prototype.removeRecursively = function(t, n) {
                    var o = {
                        fullPath: this.fullPath
                    };
                    e.prototype.enqueueCb.call(this, "removeRecursively", t, n, o)
                }, t.prototype.toURL = function() {
                    return this.fullPath
                }, t.API_CLASS_ID = "applican.filesystem.directoryentry", t
            }(a.Base);
        t.DirectoryEntry = u
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(7),
            c = n(1),
            u = n(8),
            s = function(e) {
                function t(n, o, r) {
                    var i = e.call(this, t.API_CLASS_ID, n) || this;
                    return i.name = o, i.fullPath = r, i.isFile = !0, i.isDirectory = !1, i.filesystem = null, i.queue_ = n, i
                }
                return r(t, e), t.prototype.createWriter = function(t, n) {
                    var o = this,
                        r = {
                            name: this.name,
                            fullPath: this.fullPath
                        };
                    e.prototype.enqueueCb.call(this, "createWriter", function(e) {
                        if (e && e.name && e.fullPath && t) {
                            var n = new a._File(e.name, e.fullPath, e.type, e.lastModifiedDate, e.size);
                            t(new u.FileWriter(o.queue_, n))
                        }
                    }, n, r)
                }, t.prototype.file = function(t, n) {
                    var o = {
                        name: this.name,
                        fullPath: this.fullPath
                    };
                    e.prototype.enqueueCb.call(this, "file", function(e) {
                        e && e.name && e.fullPath && t && t(new a._File(e.name, e.fullPath, e.type, e.lastModifiedDate, e.size))
                    }, n, o)
                }, t.prototype.getParent = function(t, n) {
                    var o = this,
                        r = {
                            fullPath: this.fullPath
                        };
                    e.prototype.enqueueCb.call(this, "getParent", function(e) {
                        e && e.name && e.fullPath && t && t(new c.DirectoryEntry(o.queue_, e.name, e.fullPath))
                    }, n, r)
                }, t.prototype.moveTo = function(t, n, o, r) {
                    var i = {
                        fullPath: this.fullPath,
                        parentPath: t.fullPath,
                        newName: n || this.name
                    };
                    e.prototype.enqueueCb.call(this, "moveTo", function(e) {
                        e && e.name && e.fullPath && o && o(new a._File(e.name, e.fullPath, e.type, e.lastModifiedDate, e.size))
                    }, r, i)
                }, t.prototype.copyTo = function(t, n, o, r) {
                    var i = {
                        fullPath: this.fullPath,
                        parentPath: t.fullPath,
                        newName: n || this.name
                    };
                    e.prototype.enqueueCb.call(this, "copyTo", function(e) {
                        e && e.name && e.fullPath && o && o(new a._File(e.name, e.fullPath, e.type, e.lastModifiedDate, e.size))
                    }, r, i)
                }, t.prototype.remove = function(t, n) {
                    var o = {
                        fullPath: this.fullPath
                    };
                    e.prototype.enqueueCb.call(this, "remove", t, n, o)
                }, t.prototype.toURL = function() {
                    return this.fullPath
                }, t.API_CLASS_ID = "applican.filesystem.fileentry", t
            }(i.Base);
        t.FileEntry = s
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.generateId = function() {
            return Date.now().toString(36) + Math.random().toString(36).slice(2)
        }
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            function e(t) {
                this.instanceId = t, this.handlers = {}, e.callbacks[this.instanceId] = this
            }
            return e.nativeCallback = function(t, n, o) {
                return !!t && (!!n && e.callbacks[t].handleCallback(n, o))
            }, e.prototype.registerCallback = function(e, t) {
                this.handlers[e] = t
            }, e.prototype.handleCallback = function(e, t) {
                return !!e && (!!this.handlers[e] && this.handlers[e](t))
            }, e.callbacks = {}, e
        }();
        t.Callback = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(11),
            r = function() {
                function e(e) {
                    this.sessionId = e
                }
                return e.nativeDeque = function() {
                    if (0 === e.commands.length) return null;
                    var t = e.commands.shift();
                    return t && t.setRemainApis(e.commands.length), t || null
                }, e.nativeResolve = function(t, n) {
                    var o = e.results[t];
                    return !!o && (o.resolve(n), delete e.results[t], !0)
                }, e.nativeReject = function(t, n) {
                    var o = e.results[t];
                    return !!o && (o.reject(n), delete e.results[t], !0)
                }, e.prototype.enqueue = function(t, n, r, i, a) {
                    var c = new o.Command(this.sessionId, t, n, r, a);
                    e.commands.push(c);
                    var u = c.getTransactionId();
                    return i && (e.results[u] = i), setTimeout(function() {
                        window.location.href = "applican-api://localhost/enqueue"
                    }), u
                }, e.commands = [], e.results = {}, e
            }();
        t.Queue = r
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(1),
            c = n(2),
            u = function(e) {
                function t(n, o) {
                    var r = e.call(this, t.API_CLASS_ID, n) || this;
                    return r.path = o, r.queue_ = n, r.path = r.path || null, r
                }
                return r(t, e), t.prototype.readEntries = function(t, n) {
                    var o = this,
                        r = {
                            path: this.path
                        };
                    e.prototype.enqueueCb.call(this, "readEntries", function(e) {
                        if (Array.isArray(e) && t) {
                            for (var n = [], r = 0, i = e; r < i.length; r++) {
                                var u = i[r],
                                    s = void 0;
                                u.isDirectory ? s = new a.DirectoryEntry(o.queue_, u.name, u.fullPath) : u.isFile && (s = new c.FileEntry(o.queue_, u.name, u.fullPath)), s && n.push(s)
                            }
                            t(n)
                        }
                    }, n, r)
                }, t.API_CLASS_ID = "applican.filesystem.directoryreader", t
            }(i.Base);
        t.DirectoryReader = u
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
                value: !0
            }),
            function(e) {
                e[e.NOT_FOUND_ERR = 1] = "NOT_FOUND_ERR", e[e.SECURITY_ERR = 2] = "SECURITY_ERR", e[e.ABORT_ERR = 3] = "ABORT_ERR", e[e.NOT_READABLE_ERR = 4] = "NOT_READABLE_ERR", e[e.ENCODING_ERR = 5] = "ENCODING_ERR", e[e.NO_MODIFICATION_ALLOWED_ERR = 6] = "NO_MODIFICATION_ALLOWED_ERR", e[e.INVALID_STATE_ERR = 7] = "INVALID_STATE_ERR", e[e.SYNTAX_ERR = 8] = "SYNTAX_ERR", e[e.INVALID_MODIFICATION_ERR = 9] = "INVALID_MODIFICATION_ERR", e[e.QUOTA_EXCEEDED_ERR = 10] = "QUOTA_EXCEEDED_ERR", e[e.TYPE_MISMATCH_ERR = 11] = "TYPE_MISMATCH_ERR", e[e.PATH_EXISTS_ERR = 12] = "PATH_EXISTS_ERR"
            }(t.FileError || (t.FileError = {}));
        var o = function() {
            return function(e, t, n, o, r) {
                this.name = e, this.fullPath = t, this.type = n, this.lastModifiedDate = o, this.size = r, this.name = this.name || "", this.fullPath = this.fullPath || null, this.type = this.type || null, this.lastModifiedDate = this.lastModifiedDate || null, this.size = this.size || 0, this.start = 0, this.end = this.size
            }
        }();
        t._File = o
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n) || this;
                return r.fileName = null, r.length = 0, r.position = 0, r.onwritestart = null, r.onprogress = null, r.onwrite = null, r.onwriteend = null, r.onabort = null, r.onerror = null, o && (r.fileName = o.fullPath || o.name, r.length = o.size || 0), e.prototype.registerCallback.call(r, "onWriteStart", r._onWriteStart.bind(r)), e.prototype.registerCallback.call(r, "onWrite", r._onWrite.bind(r)), e.prototype.registerCallback.call(r, "onWriteEnd", r._onWriteEnd.bind(r)), e.prototype.registerCallback.call(r, "onWriteError", r._onWriteError.bind(r)), e.prototype.registerCallback.call(r, "onWriteProgress", r._onWriteProgress.bind(r)), e.prototype.registerCallback.call(r, "onWriteAbort", r._onWriteAbort.bind(r)), r
            }
            return r(t, e), t.prototype.abort = function() {}, t.prototype.write = function(t) {
                var n = {
                    text: t,
                    position: this.position,
                    fileName: this.fileName,
                    length: this.length
                };
                e.prototype.enqueueCb.call(this, "write", null, null, n)
            }, t.prototype._onWriteStart = function(e) {
                return this.onwritestart && this.onwritestart(e), !0
            }, t.prototype._onWrite = function(e) {
                return this.onwrite && this.onwrite(e), !0
            }, t.prototype._onWriteEnd = function(e) {
                return this.onwriteend && this.onwriteend(e), !0
            }, t.prototype._onWriteError = function(e) {
                return this.onerror && this.onerror(e), !0
            }, t.prototype._onWriteProgress = function(e) {
                return this.onprogress && this.onprogress(e), !0
            }, t.prototype._onWriteAbort = function(e) {
                return this.onabort && this.onabort(e), !0
            }, t.INIT = 0, t.WRITING = 1, t.DONE = 2, t.API_CLASS_ID = "applican.filesystem.filewriter", t
        }(n(0).Base);
        t.FileWriter = i
    }, function(e, t, n) {
        e.exports = n(10)
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(4),
            r = n(5),
            i = n(3),
            a = n(12),
            c = n(14),
            u = n(15),
            s = n(16),
            l = n(17),
            p = n(18),
            f = n(19),
            h = n(20),
            _ = n(21),
            y = n(22),
            d = n(23),
            b = n(24),
            g = n(25),
            P = n(26),
            C = n(27),
            v = n(28),
            E = n(29),
            I = n(30),
            O = n(31),
            A = n(32),
            S = n(33),
            m = n(34),
            w = n(35),
            T = n(36),
            R = n(37),
            L = n(38),
            G = n(39),
            q = n(41),
            D = n(42),
            N = n(43),
            F = n(44),
            B = n(45),
            j = n(46),
            W = n(47),
            M = n(48),
            U = n(49),
            k = n(50),
            x = n(53),
            V = n(55),
            K = n(56),
            H = n(57),
            Y = n(58),
            z = n(59),
            Q = n(64),
            X = n(65),
            Z = n(66),
            J = n(67),
            $ = n(68),
            ee = n(69),
            te = n(70),
            ne = n(71),
            oe = n(7),
            re = n(72),
            ie = n(73),
            ae = function() {
                function e() {
                    this.queue_ = null, this.accelerometer_ = null, this.notification_ = null, this.application_ = null, this.barcode_ = null, this.beacon_ = null, this.bluetooth_ = null, this.camera_ = null, this.capture_ = null, this.compass_ = null, this.connection_ = null, this.console_ = null, this.contacts_ = null, this.contents_ = null, this.database_ = null, this.device_ = null, this.dcmlocation_ = null, this.event_ = null, this.filesystem_ = null, this.gamesound_ = null, this.geopla_ = null, this.geopop_ = null, this.geofencing_ = null, this.geolocation_ = null, this.globalization_ = null, this.googanalytics_ = null, this.http_ = null, this.keyboard_ = null, this.launcher_ = null, this.list_ = null, this.localnotification_ = null, this.media_ = null, this.platform_ = null, this.popinfo_ = null, this.purchase_ = null, this.simplestorage_ = null, this.slidemenu_ = null, this.splash_ = null, this.tab_ = null, this.utilities_ = null, this.video_ = null, this.websocket_ = null, this.webview_ = null, this.wifi_ = null, this.sessionId_ = i.generateId();
                    var t = "applican-api://localhost/init?session_id=" + this.sessionId_;
                    e.instances[this.sessionId_] = this, setTimeout(function() {
                      // Opera 8.0+
                      var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
  
                      // Firefox 1.0+
                      var isFirefox = typeof InstallTrigger !== 'undefined';
  
                      // Safari 3.0+ "[object HTMLElementConstructor]" 
                      var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));
  
                      // Internet Explorer 6-11
                      var isIE = /*@cc_on!@*/false || !!document.documentMode;
  
                      // Edge 20+
                      var isEdge = !isIE && !!window.StyleMedia;
  
                      // Chrome 1 - 71
                      var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);
  
                      // Blink engine detection
                      var isBlink = (isChrome || isOpera) && !!window.CSS;
                        if (!isFirefox && !isEdge && !isSafari && !isIE && !isOpera && !isBlink) {
                          window.location.href = t
                        }
                    })
                }
                return e.initialize = function() {
                    "complete" === document.readyState ? e.applicanLoader() : document.addEventListener("DOMContentLoaded", e.applicanLoader)
                }, e.nativeOnReady = function(t) {
                    if (!t) return null;
                    if (!t.sessionId) return null;
                    e.config_.device_os = t.device.platformName;
                    var n = e.instances[t.sessionId];
                    if (!n) return null;
                    delete e.instances[t.sessionId], n.sessionId_ = i.generateId(), e.instances[n.sessionId_] = n, n.queue_ = new r.Queue(n.sessionId_), n.accelerometer_ = new U.Accelerometer(n.queue_), n.notification_ = new D.Notification(n.queue_), n.application_ = new K.Application(n.queue_), n.barcode_ = new j.Barcode(n.queue_), n.beacon_ = new c.Beacon(n.queue_), n.bluetooth_ = new y.Bluetooth(n.queue_), n.capture_ = new I.Capture(n.queue_), n.camera_ = new N.Camera(n.queue_), n.compass_ = new M.Compass(n.queue_), n.connection_ = new F.Connection(n.queue_), n.contacts_ = new G.Contacts(n.queue_), n.console_ = new H.Console(n.queue_), n.contents_ = new s.Contents(n.queue_), n.database_ = new x.DatabaseFactory(n.queue_), n.device_ = new a.Device(n.queue_, t.device), n.dcmlocation_ = new B.DocomoGeolocation(n.queue_), n.event_ = new V._Event(n.queue_), n.filesystem_ = new z.FileSystemFactory(n.queue_), n.gamesound_ = new C.GameSound(n.queue_), n.geofencing_ = new l.Geofencing(n.queue_), n.geolocation_ = new W.Geolocation(n.queue_), n.geopla_ = new p.Geopla(n.queue_), n.geopop_ = new te.Geopop(n.queue_), n.globalization_ = new E.Globalization(n.queue_), n.googanalytics_ = new T.GoogleAnalytics(n.queue_), n.http_ = new u.Http(n.queue_), n.keyboard_ = new O.Keyboard(n.queue_), n.launcher_ = new _.Launcher(n.queue_), n.list_ = new w._List(n.queue_), n.localnotification_ = new q.LocalNotification(n.queue_), n.media_ = new k.Media(n.queue_), n.platform_ = new h.Platform(n.queue_, t.baseAppVersion, e.API_VERSION_STR), n.popinfo_ = new A.Popinfo(n.queue_), n.purchase_ = new P.Purchase(n.queue_), n.simplestorage_ = new L.SimpleStorage(n.queue_), n.slidemenu_ = new g.SlideMenu(n.queue_), n.splash_ = new R.SplashScreen(n.queue_), n.tab_ = new v.Tab(n.queue_), n.utilities_ = new f.Utilities(n.queue_), n.video_ = new m.Video(n.queue_), n.websocket_ = new b._WebSocket(n.queue_), n.webview_ = new d.WebView(n.queue_), n.wifi_ = new S.WiFi(n.queue_), setTimeout(function() {
                        n.onReady()
                    });
                    var o = {
                        sessionId: n.sessionId
                    };
                    return n.webView && (o.webViewInstanceId = n.webView.instanceId), o
                }, e.nativeDeque = function(t) {
                    if (!t) return null;
                    if (!t.sessionId) return null;
                    if (!e.instances[t.sessionId]) return null;
                    var n = r.Queue.nativeDeque();
                    return n ? JSON.stringify(n) : null
                }, e.nativeResolve = function(t) {
                    return !!t && (!!t.sessionId && (!!e.instances[t.sessionId] && r.Queue.nativeResolve(t.transactionId, t.result)))
                }, e.nativeReject = function(t) {
                    return !!t && (!!t.sessionId && (!!e.instances[t.sessionId] && r.Queue.nativeReject(t.transactionId, t.error)))
                }, e.nativeCallback = function(t) {
                    return !!t && (!!t.sessionId && (!!e.instances[t.sessionId] && o.Callback.nativeCallback(t.instanceId, t.callbackName, t.args)))
                }, e.nativeFireHTMLEvent = function(e) {
                    V._Event.nativeFireHTMLEvent(e)
                }, e.nativeFireBatteryEvent = function(e, t, n) {
                    V._Event.nativeFireBatteryEvent(e, t, n)
                }, e.nativeFireOrientationEvent = function(e) {
                    V._Event.nativeFireOrientationEvent(e)
                }, e.nativeFireWhitelistBlockedEvent = function(e, t, n) {
                    V._Event.nativeFireWhitelistBlockedEvent(e, t, n)
                }, e.nativeFireGcmRegistrationTokenReceivedEvent = function(e) {
                    V._Event.nativeFireGcmRegistrationTokenReceivedEvent(e)
                }, e.applicanLoader = function() {
                    document.removeEventListener("DOMContentLoaded", e.applicanLoader), window.applican || (window.LocalFileSystem = Y.LocalFileSystem, window.FileUploadOptions = Q._FileUploadOptions, window.ContactFindOptions = X._ContactFindOptions, window.ContactName = Z._ContactName, window.ContactField = J._ContactField, window.ContactAddress = $._ContactAddress, window.ContactOrganization = ee._ContactOrganization, window.GFPGPSGeofencingLocationUpdateFrequency = p.GFPGPSGeofencingLocationUpdateFrequency, window.GFPFetchingDataSettings = p.GFPFetchingDataSettings, window.GFPMonitoringEnabledType = p.GFPMonitoringEnabledType, window.GFPBeaconMonitoringScheduleType = p.GFPBeaconMonitoringScheduleType, window.GFPSendingLogScheduleType = p.GFPSendingLogScheduleType, window.GFPErrorType = p.GFPErrorType, window.GpsGeofencingSettings = p.GpsGeofencingSettings, window.WifiGeofencingSettings = p.WifiGeofencingSettings, window.BeaconGenreBulkFetchGeofencing = p.BeaconGenreBulkFetchGeofencing, window.BeaconGeofencingSettings = p.BeaconGeofencingSettings, window.BeaconGeofencing = p.BeaconGeofencing, window.ApplicanError = ne.ApplicanError, window.CompassError = M.CompassError, window.ListError = w.ListError, window.PositionError = W.PositionError, window.LocalNotificationError = q.LocalNotificationError, window.WiFiError = S.WiFiError, window.WiFiStatus = S.WiFiStatus, window.VideoError = m.VideoError, window.CaptureError = I.CaptureError, window.GameSoundError = C.GameSoundError, window.GlobalizationError = E.GlobalizationError, window.PurchaseError = P.PurchaseError, window.BluetoothError = y.BluetoothError, window.LauncherError = _.LauncherError, window.UtilitiesError = f.UtilitiesError, window.FileError = oe.FileError, window.FileTransferError = re.FileTransferError, window.FileUploadResult = ie.FileUploadResult, window.applican = new e)
                }, Object.defineProperty(e.prototype, "config", {
                    get: function() {
                        return e.config_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "sessionId", {
                    get: function() {
                        return this.sessionId_
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.init = function() {}, e.prototype.onReady = function() {
                    var e = document.createEvent("HTMLEvents");
                    e.initEvent("deviceready", !1, !1), document.dispatchEvent(e)
                }, Object.defineProperty(e.prototype, "accelerometer", {
                    get: function() {
                        return this.accelerometer_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "barcode", {
                    get: function() {
                        return this.barcode_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "beacon", {
                    get: function() {
                        return this.beacon_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "bluetooth", {
                    get: function() {
                        return this.bluetooth_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "camera", {
                    get: function() {
                        return this.camera_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "capture", {
                    get: function() {
                        return this.capture_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "compass", {
                    get: function() {
                        return this.compass_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "connection", {
                    get: function() {
                        return this.connection_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "contacts", {
                    get: function() {
                        return this.contacts_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "console", {
                    get: function() {
                        return this.console_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "contents", {
                    get: function() {
                        return this.contents_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "device", {
                    get: function() {
                        return this.device_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "docomolocation", {
                    get: function() {
                        return this.dcmlocation_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "event", {
                    get: function() {
                        return this.event_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "gamesound", {
                    get: function() {
                        return this.gamesound_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "geopla", {
                    get: function() {
                        return this.geopla_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "geopop", {
                    get: function() {
                        return this.geopop_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "geofencing", {
                    get: function() {
                        return this.geofencing_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "geolocation", {
                    get: function() {
                        return this.geolocation_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "globalization", {
                    get: function() {
                        return this.globalization_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "googleAnalytics", {
                    get: function() {
                        return this.googanalytics_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "http", {
                    get: function() {
                        return this.http_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "keyboard", {
                    get: function() {
                        return this.keyboard_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "launcher", {
                    get: function() {
                        return this.launcher_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "list", {
                    get: function() {
                        return this.list_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "localNotification", {
                    get: function() {
                        return this.localnotification_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "notification", {
                    get: function() {
                        return this.notification_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "platform", {
                    get: function() {
                        return this.platform_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "popinfo", {
                    get: function() {
                        return this.popinfo_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "purchase", {
                    get: function() {
                        return this.purchase_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "simpleStorage", {
                    get: function() {
                        return this.simplestorage_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "slideMenu", {
                    get: function() {
                        return this.slidemenu_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "splashscreen", {
                    get: function() {
                        return this.splash_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "tab", {
                    get: function() {
                        return this.tab_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "utilities", {
                    get: function() {
                        return this.utilities_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "video", {
                    get: function() {
                        return this.video_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "webSocket", {
                    get: function() {
                        return this.websocket_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "webView", {
                    get: function() {
                        return this.webview_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "wifi", {
                    get: function() {
                        return this.wifi_
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.addLaunchWebviewCloseEventListener = function(e) {
                    this.webView && this.webView.addLaunchWebviewCloseEventListener(e)
                }, e.prototype.finish = function() {
                    this.application && this.application.finish()
                }, e.prototype.showLogConsole = function() {
                    this.console && this.console.show()
                }, e.prototype.openDatabase = function(e, t, n) {
                    this.database && this.database.open(e, t, n)
                }, e.prototype.getApplicationFilesRoot = function(e, t) {
                    this.filesystem && this.filesystem.getApplicationFilesRoot(e, t)
                }, e.prototype.getApplicationExternalFilesRoot = function(e, t) {
                    this.filesystem && this.filesystem.getApplicationExternalFilesRoot(e, t)
                }, e.prototype.getApplicationCacheRoot = function(e, t) {
                    this.filesystem && this.filesystem.getApplicationCacheRoot(e, t)
                }, e.prototype.getApplicationExternalCacheRoot = function(e, t) {
                    this.filesystem && this.filesystem.getApplicationExternalCacheRoot(e, t)
                }, e.prototype.requestFileSystem = function(e, t, n, o) {
                    this.filesystem && this.filesystem.requestFileSystem(e, t, n, o)
                }, Object.defineProperty(e.prototype, "application", {
                    get: function() {
                        return this.application_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "database", {
                    get: function() {
                        return this.database_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "filesystem", {
                    get: function() {
                        return this.filesystem_
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "media", {
                    get: function() {
                        return this.media_
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.API_VERSION_STR = "2.1.0", e.API_VERSION_NUM = 2.001, e.config_ = {
                    version: e.API_VERSION_STR,
                    version_num: e.API_VERSION_NUM,
                    debug: !1,
                    device_os: "UNKNOWN"
                }, e.instances = {}, e
            }();
        t.Applican = ae, ae.initialize()
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(3),
            r = function() {
                function e(e, t, n, r, i) {
                    this.sessionId = e, this.className = t, this.methodName = n, this.instanceId = r, this.args = i, this.remainApis = 0, this.transactionId = o.generateId(), this.sessionId = this.sessionId || "", this.className = this.className || "", this.methodName = this.methodName || "", this.instanceId = this.instanceId || "", this.args = i || {}
                }
                return e.prototype.setRemainApis = function(e) {
                    this.remainApis = e
                }, e.prototype.getRemainApis = function() {
                    return this.remainApis
                }, e.prototype.getArgs = function() {
                    return this.args
                }, e.prototype.getTransactionId = function() {
                    return this.transactionId
                }, e
            }();
        t.Command = r
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n) || this;
                return r.deviceInfo = o, r
            }
            return r(t, e), t.prototype.getPushToken = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "getPushToken", t, n, o)
            }, t.prototype.light = function(t, n, o) {
                var r = {
                    enable: t
                };
                e.prototype.enqueueCb.call(this, "light", n || null, o || null, r)
            }, t.prototype.getDisplayInfo = function(t, n) {
                e.prototype.enqueueCb.call(this, "getDisplayInfo", t, n)
            }, t.prototype.keepScreenOn = function(t, n, o) {
                var r = {
                    enable: t
                };
                e.prototype.enqueueCb.call(this, "keepScreenOn", n || null, o || null, r)
            }, t.prototype.getAdvertisingId = function(t, n) {
                e.prototype.enqueueCb.call(this, "getAdvertisingId", t, n)
            }, Object.defineProperty(t.prototype, "platformName", {
                get: function() {
                    return this.deviceInfo.platformName
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "platformVersion", {
                get: function() {
                    return this.deviceInfo.platformVersion
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "modelName", {
                get: function() {
                    return this.deviceInfo.modelName
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "name", {
                get: function() {
                    return this.deviceInfo.modelName
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "platform", {
                get: function() {
                    return this.deviceInfo.platformName
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "uuid", {
                get: function() {
                    return this.deviceInfo.uuid
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "uuid_rfc4122", {
                get: function() {
                    return this.deviceInfo.uuid_rfc4122
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "version", {
                get: function() {
                    return this.deviceInfo.platformVersion
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "applican", {
                get: function() {
                    return this.deviceInfo.applican
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "applican_type", {
                get: function() {
                    return this.deviceInfo.applican_type
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "package_name", {
                get: function() {
                    return this.deviceInfo.package_name
                },
                enumerable: !0,
                configurable: !0
            }), t.API_CLASS_ID = "applican.device", t
        }(n(0).Base);
        t.Device = i
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            function e(e) {
                this.callback = e
            }
            return e.prototype.resolve = function(e) {
                this.callback && this.callback.resolve && this.callback.resolve(e)
            }, e.prototype.reject = function(e) {
                this.callback && this.callback.reject && this.callback.reject(e)
            }, e
        }();
        t.Result = o
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.currentWatchId_ = 0, o.watchBeaconCallbacks = {}, e.prototype.registerCallback.call(o, "onWatchBeacon", o.onWatchBeacon.bind(o)), o
            }
            return r(t, e), t.prototype.init = function(t, n) {
                e.prototype.enqueueCb.call(this, "init", t, n)
            }, t.prototype.startMonitoring = function(t, n) {
                e.prototype.enqueueCb.call(this, "startMonitoring", t, n)
            }, t.prototype.stopMonitoring = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopMonitoring", t, n)
            }, t.prototype.isMonitoring = function(t, n) {
                e.prototype.enqueueCb.call(this, "isMonitoring", t, n)
            }, t.prototype.watchBeacon = function(t, n, o, r) {
                var i = {
                    watchId: this.currentWatchId_,
                    beacon: t
                };
                return this.watchBeaconCallbacks[this.currentWatchId_] = n, e.prototype.enqueueCb.call(this, "watchBeacon", o, r, i), this.currentWatchId_++
            }, t.prototype.clearBeacon = function(t) {
                this.watchBeaconCallbacks[t] && delete this.watchBeaconCallbacks[t];
                var n = {
                    watchId: t
                };
                e.prototype.enqueueCb.call(this, "clearBeacon", null, null, n)
            }, t.prototype.getBeaconHistory = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "getBeaconHistory", n, o, t)
            }, t.prototype.onWatchBeacon = function(e) {
                return !!e && (this.watchBeaconCallbacks[e.watchId] && this.watchBeaconCallbacks[e.watchId](e.beacon, e.error), !0)
            }, t.API_CLASS_ID = "applican.beacon", t
        }(n(0).Base);
        t.Beacon = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.get = function(t, n, o, r) {
                var i = n = n || {};
                i.url = t, e.prototype.enqueueCb.call(this, "get", o, r, i)
            }, t.prototype.post = function(t, n, o, r) {
                var i = n = n || {};
                i.url = t, e.prototype.enqueueCb.call(this, "post", o, r, i)
            }, t.API_CLASS_ID = "applican.http", t
        }(n(0).Base);
        t.Http = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(t) {
                return e.call(this, "applican.contents", t) || this
            }
            return r(t, e), t.prototype.getContentsVersion = function() {}, t.prototype.updateContents = function() {}, t
        }(n(0).Base);
        t.Contents = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.init = function(t, n) {
                e.prototype.enqueueCb.call(this, "init", t, n)
            }, t.prototype.addFence = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "addFence", n, o, t)
            }, t.prototype.removeFence = function(t, n, o) {
                var r = {
                    identifier: t
                };
                e.prototype.enqueueCb.call(this, "removeFence", n, o, r)
            }, t.prototype.getFences = function(t, n) {
                e.prototype.enqueueCb.call(this, "getFences", t, n)
            }, t.API_CLASS_ID = "applican.geofencing", t
        }(n(0).Base);
        t.Geofencing = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.GFPGPSGeofencingLocationUpdateFrequencyHigh = 0] = "GFPGPSGeofencingLocationUpdateFrequencyHigh", e[e.GFPGPSGeofencingLocationUpdateFrequencyLow = 1] = "GFPGPSGeofencingLocationUpdateFrequencyLow"
        }(t.GFPGPSGeofencingLocationUpdateFrequency || (t.GFPGPSGeofencingLocationUpdateFrequency = {})),
        function(e) {
            e[e.GFPFetchingDataSettingsPriorityCache = 0] = "GFPFetchingDataSettingsPriorityCache", e[e.GFPFetchingDataSettingsPriorityNetwork = 1] = "GFPFetchingDataSettingsPriorityNetwork", e[e.GFPFetchingDataSettingsOnlyCache = 2] = "GFPFetchingDataSettingsOnlyCache", e[e.GFPFetchingDataSettingsOnlyNetwork = 3] = "GFPFetchingDataSettingsOnlyNetwork"
        }(t.GFPFetchingDataSettings || (t.GFPFetchingDataSettings = {})),
        function(e) {
            e[e.GFPMonitoringTypeDisable = 0] = "GFPMonitoringTypeDisable", e[e.GFPMonitoringEnabledGPS = 1] = "GFPMonitoringEnabledGPS", e[e.GFPMonitoringEnabledWifi = 2] = "GFPMonitoringEnabledWifi", e[e.GFPMonitoringEnabledBeacon = 4] = "GFPMonitoringEnabledBeacon", e[e.GFPMonitoringEnabledUbiquitous = 8] = "GFPMonitoringEnabledUbiquitous", e[e.GFPMonitoringEnabledAll = 15] = "GFPMonitoringEnabledAll"
        }(t.GFPMonitoringEnabledType || (t.GFPMonitoringEnabledType = {})),
        function(e) {
            e[e.GFPBeaconMonitoringScheduleTypeOnStartService = 0] = "GFPBeaconMonitoringScheduleTypeOnStartService", e[e.GFPBeaconMonitoringScheduleTypeOnEnterGeoArea = 1] = "GFPBeaconMonitoringScheduleTypeOnEnterGeoArea", e[e.GFPBeaconMonitoringScheduleTypeNone = 2] = "GFPBeaconMonitoringScheduleTypeNone"
        }(t.GFPBeaconMonitoringScheduleType || (t.GFPBeaconMonitoringScheduleType = {})),
        function(e) {
            e[e.GFPSendingLogScheduleTypeSendImmediate = 0] = "GFPSendingLogScheduleTypeSendImmediate", e[e.GFPSendingLogScheduleTypeUserInterval = 1] = "GFPSendingLogScheduleTypeUserInterval", e[e.GFPSendingLogScheduleTypeNone = 2] = "GFPSendingLogScheduleTypeNone"
        }(t.GFPSendingLogScheduleType || (t.GFPSendingLogScheduleType = {})),
        function(e) {
            e[e.GFPErrorTypeNotAuthorized = 0] = "GFPErrorTypeNotAuthorized", e[e.GFPErrorTypeNoNetworkConnection = 1] = "GFPErrorTypeNoNetworkConnection", e[e.GFPErrorTypeWifiObserverAlreadyStarted = 2] = "GFPErrorTypeWifiObserverAlreadyStarted", e[e.GFPErrorTypeAppAuthorizationAppIdInvalid = 3] = "GFPErrorTypeAppAuthorizationAppIdInvalid", e[e.GFPErrorTypeUserPermissionDeny = 4] = "GFPErrorTypeUserPermissionDeny", e[e.GFPErrorTypeServerAuthroizedFailed = 5] = "GFPErrorTypeServerAuthroizedFailed", e[e.GFPErrorTypeServerResponseTimedout = 6] = "GFPErrorTypeServerResponseTimedout", e[e.GFPErrorTypeServerUnknownError = 7] = "GFPErrorTypeServerUnknownError", e[e.GFPErrorTypeInvalidLocationAttribute = 8] = "GFPErrorTypeInvalidLocationAttribute", e[e.GFPErrorTypeInvalidArgument = 9] = "GFPErrorTypeInvalidArgument", e[e.GFPErrorTypeInvalidState = 10] = "GFPErrorTypeInvalidState", e[e.GFPErrorTypeLocationServicePermissionDeny = 11] = "GFPErrorTypeLocationServicePermissionDeny", e[e.GFPErrorTypeLocationServiceUnknownError = 12] = "GFPErrorTypeLocationServiceUnknownError", e[e.GFPErrorTypeBeaconMonitoringFailed = 13] = "GFPErrorTypeBeaconMonitoringFailed", e[e.GFPErrorTypeBeaconRangingFailed = 14] = "GFPErrorTypeBeaconRangingFailed", e[e.GFPErrorTypeNoBeaconsInGPSPoint = 15] = "GFPErrorTypeNoBeaconsInGPSPoint", e[e.GFPErrorTypeNoBeaconsInGeoArea = 16] = "GFPErrorTypeNoBeaconsInGeoArea", e[e.GFPErrorTypeExpiredCacheError = 17] = "GFPErrorTypeExpiredCacheError", e[e.GFPErrorTypeFetchingCacheError = 18] = "GFPErrorTypeFetchingCacheError", e[e.GFPErrorTypeFailedToFetchAllBeaconPoints = 19] = "GFPErrorTypeFailedToFetchAllBeaconPoints", e[e.GFPErrorTypeFailedToFetchAllWifiPoints = 20] = "GFPErrorTypeFailedToFetchAllWifiPoints", e[e.GFPErrorTypeFailedToFetchAllUbiquitousPoints = 21] = "GFPErrorTypeFailedToFetchAllUbiquitousPoints", e[e.GFPErrorTypeUnknown = 22] = "GFPErrorTypeUnknown"
        }(t.GFPErrorType || (t.GFPErrorType = {})),
        function(e) {
            e[e.LOCATION_REQUEST_INTERVAL_HIGH_ACCURACY_IN_MILLIS = 6e4] = "LOCATION_REQUEST_INTERVAL_HIGH_ACCURACY_IN_MILLIS", e[e.LOCATION_REQUEST_INTERVAL_MIDDLE_ACCURACY_IN_MILLIS = 3e5] = "LOCATION_REQUEST_INTERVAL_MIDDLE_ACCURACY_IN_MILLIS", e[e.LOCATION_REQUEST_INTERVAL_LOW_ACCURACY_IN_MILLIS = 9e5] = "LOCATION_REQUEST_INTERVAL_LOW_ACCURACY_IN_MILLIS"
        }(t.GpsGeofencingSettings || (t.GpsGeofencingSettings = {})),
        function(e) {
            e[e.GFPWifiGeofencingScanIntervalHigh = 10] = "GFPWifiGeofencingScanIntervalHigh", e[e.GFPWifiGeofencingScanIntervalMiddle = 60] = "GFPWifiGeofencingScanIntervalMiddle", e[e.GFPWifiGeofencingScanIntervalLow = 300] = "GFPWifiGeofencingScanIntervalLow"
        }(t.WifiGeofencingSettings || (t.WifiGeofencingSettings = {})),
        function(e) {
            e[e.TARGET_IBEACON = 1] = "TARGET_IBEACON", e[e.TARGET_UBIQUITOUS = 2] = "TARGET_UBIQUITOUS", e[e.TARGET_TRACKR = 4] = "TARGET_TRACKR"
        }(t.BeaconGenreBulkFetchGeofencing || (t.BeaconGenreBulkFetchGeofencing = {})),
        function(e) {
            e[e.GFPBLEBeaconGeofencingScanIntervalHigh = 1.5] = "GFPBLEBeaconGeofencingScanIntervalHigh", e[e.GFPBLEBeaconGeofencingScanIntervalMiddle = 60] = "GFPBLEBeaconGeofencingScanIntervalMiddle", e[e.GFPBLEBeaconGeofencingScanIntervalLow = 300] = "GFPBLEBeaconGeofencingScanIntervalLow"
        }(t.BeaconGeofencingSettings || (t.BeaconGeofencingSettings = {})),
        function(e) {
            e[e.TARGET_IBEACON = 1] = "TARGET_IBEACON", e[e.TARGET_UBIQUITOUS = 2] = "TARGET_UBIQUITOUS"
        }(t.BeaconGeofencing || (t.BeaconGeofencing = {}));
        var a = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                for (var r in o.geoplaCallback = null, o.registeredCallbacks = {
                        didEnterWithEvent: o.onDidEnterWithEvent,
                        didExitWithEvent: o.onDidExitWithEvent,
                        didFailWithError: o.onDidFailWithError,
                        didRangeWithBeaconEvent: o.onDidRangeWithBeaconEvent,
                        didEnterWithGpsEvent: o.onDidEnterWithGpsEvent,
                        didExitWithGpsEvent: o.onDidExitWithGpsEvent,
                        didEnterWithWifiEvent: o.onDidEnterWithWifiEvent,
                        didExitWithWifiEvent: o.onDidExitWithWifiEvent,
                        didEnterWithBeaconEvent: o.onDidEnterWithBeaconEvent,
                        didExitWithBeaconEvent: o.onDidExitWithBeaconEvent
                    }, o.registeredCallbacks) r && e.prototype.registerCallback.call(o, r, o.registeredCallbacks[r].bind(o));
                return o
            }
            return r(t, e), t.prototype.init = function(t, n, o) {
                this.geoplaCallback = t, e.prototype.enqueueCb.call(this, "init", n, o)
            }, t.prototype.showTermsOfService = function(t, n) {
                e.prototype.enqueueCb.call(this, "showTermsOfService", t, n)
            }, t.prototype.getTermsOfServiceVersion = function(t, n) {
                e.prototype.enqueueCb.call(this, "getTermsOfServiceVersion", t, n)
            }, t.prototype.clearCache = function(t, n) {
                e.prototype.enqueueCb.call(this, "clearCache", t, n)
            }, t.prototype.getVersion = function(t, n) {
                e.prototype.enqueueCb.call(this, "getVersion", t, n)
            }, t.prototype.getClientId = function(t, n) {
                e.prototype.enqueueCb.call(this, "getClientId", t, n)
            }, t.prototype.getGenres = function(t, n) {
                e.prototype.enqueueCb.call(this, "getGenres", t, n)
            }, t.prototype.getSSID = function(t, n) {
                e.prototype.enqueueCb.call(this, "getSSID", t, n)
            }, t.prototype.setExternalParameters = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "setExternalParameters", n, o, t)
            }, t.prototype.setSendingLogScheduleType = function(t, n, o, r) {
                var i = {
                    type: t,
                    interval: n
                };
                e.prototype.enqueueCb.call(this, "setSendingLogScheduleType", o, r, i)
            }, t.prototype.sendLog = function(t, n) {
                e.prototype.enqueueCb.call(this, "sendLog", t, n)
            }, t.prototype.startGpsMeshGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startGpsMeshGeofencing", n, o, t)
            }, t.prototype.stopGpsMeshGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopGpsMeshGeofencing", t, n)
            }, t.prototype.startGpsGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startGpsGenreGeofencing", n, o, t)
            }, t.prototype.stopGpsGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopGpsGenreGeofencing", t, n)
            }, t.prototype.startWifiGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startWifiGenreGeofencing", n, o, t)
            }, t.prototype.stopWifiGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopWifiGenreGeofencing", t, n)
            }, t.prototype.startWifiNearbyGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startWifiNearbyGeofencing", n, o, t)
            }, t.prototype.stopWifiNearbyGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopWifiNearbyGeofencing", t, n)
            }, t.prototype.startBeaconGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startBeaconGenreGeofencing", n, o, t)
            }, t.prototype.stopBeaconGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopBeaconGenreGeofencing", t, n)
            }, t.prototype.startIBeaconGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startIBeaconGenreGeofencing", n, o, t)
            }, t.prototype.stopIBeaconGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopIBeaconGenreGeofencing", t, n)
            }, t.prototype.startBLEBeaconGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startBLEBeaconGenreGeofencing", n, o, t)
            }, t.prototype.stopBLEBeaconGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopBLEBeaconGenreGeofencing", t, n)
            }, t.prototype.changeLocationUpdateFrequency = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "changeLocationUpdateFrequency", n, o, t)
            }, t.prototype.startGpsV1Geofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startGpsV1Geofencing", n, o, t)
            }, t.prototype.stopGpsV1Geofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopGpsV1Geofencing", t, n)
            }, t.prototype.startWifiV1Geofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startWifiV1Geofencing", n, o, t)
            }, t.prototype.stopWifiV1Geofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopWifiV1Geofencing", t, n)
            }, t.prototype.startBeaconV1Geofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startBeaconV1Geofencing", n, o, t)
            }, t.prototype.stopBeaconV1Geofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopBeaconV1Geofencing", t, n)
            }, t.prototype.startIBeaconV1Geofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startIBeaconV1Geofencing", n, o, t)
            }, t.prototype.stopIBeaconV1Geofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopIBeaconV1Geofencing", t, n)
            }, t.prototype.startBLEBeaconV1Geofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startBLEBeaconV1Geofencing", n, o, t)
            }, t.prototype.stopBLEBeaconV1Geofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopBLEBeaconV1Geofencing", t, n)
            }, t.prototype.onDidEnterWithEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didEnterWithEvent) && (this.geoplaCallback.didEnterWithEvent(e), !0)
            }, t.prototype.onDidExitWithEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didExitWithEvent) && (this.geoplaCallback.didExitWithEvent(e), !0)
            }, t.prototype.onDidFailWithError = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didFailWithError) && (this.geoplaCallback.didFailWithError(e), !0)
            }, t.prototype.onDidRangeWithBeaconEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didRangeWithBeaconEvent) && (this.geoplaCallback.didRangeWithBeaconEvent(e), !0)
            }, t.prototype.onDidEnterWithGpsEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didEnterWithGpsEvent) && (this.geoplaCallback.didEnterWithGpsEvent(e), !0)
            }, t.prototype.onDidExitWithGpsEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didExitWithGpsEvent) && (this.geoplaCallback.didExitWithGpsEvent(e), !0)
            }, t.prototype.onDidEnterWithWifiEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didEnterWithWifiEvent) && (this.geoplaCallback.didEnterWithWifiEvent(e), !0)
            }, t.prototype.onDidExitWithWifiEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didExitWithWifiEvent) && (this.geoplaCallback.didExitWithWifiEvent(e), !0)
            }, t.prototype.onDidEnterWithBeaconEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didEnterWithBeaconEvent) && (this.geoplaCallback.didEnterWithBeaconEvent(e), !0)
            }, t.prototype.onDidExitWithBeaconEvent = function(e) {
                return !(!this.geoplaCallback || !this.geoplaCallback.didExitWithBeaconEvent) && (this.geoplaCallback.didExitWithBeaconEvent(e), !0)
            }, t.API_CLASS_ID = "applican.geopla", t
        }(i.Base);
        t.Geopla = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.NOT_FOUND_ERR = "NOT_FOUND_ERR", e[e.UNZIP_INVALID_PATH = 1] = "UNZIP_INVALID_PATH", e[e.UNZIP_UNZIP_ERROR = 2] = "UNZIP_UNZIP_ERROR"
        }(t.UtilitiesError || (t.UtilitiesError = {}));
        var a = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.downloadProgressCallback = null, e.prototype.registerCallback.call(o, "downloadProgress", o.onDownloadProgress.bind(o)), o
            }
            return r(t, e), t.prototype.download = function(t, n, o, r) {
                this.downloadProgressCallback = n, e.prototype.enqueueCb.call(this, "download", o, r, t)
            }, t.prototype.unzip = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "unzip", n, o, t)
            }, t.prototype.onDownloadProgress = function(e) {
                return !!this.downloadProgressCallback && (this.downloadProgressCallback(e), !0)
            }, t.API_CLASS_ID = "applican.utilities", t
        }(i.Base);
        t.Utilities = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o, r) {
                var i = e.call(this, t.API_CLASS_ID, n) || this;
                return i.baseAppVersion = o, i.libraryVersion = r, i
            }
            return r(t, e), t.prototype.getLibraryVersion = function() {
                return this.libraryVersion
            }, t.prototype.getBaseVersion = function() {
                return this.baseAppVersion
            }, t.prototype.getAppVersion = function(t, n) {
                e.prototype.enqueueCb.call(this, "getAppVersion", function(e) {
                    var n = e.versionCode,
                        o = e.versionName;
                    t(o, n)
                }, n)
            }, t.API_CLASS_ID = "applican.platform", t
        }(n(0).Base);
        t.Platform = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i, a = n(0);
        ! function(e) {
            e.BUSY_ERROR = "BUSY_ERROR", e.NOT_FOUND = "NOT_FOUND"
        }(t.LauncherError || (t.LauncherError = {})),
        function(e) {
            e.COVER = "cover", e.FLIP = "flip", e.CURL = "curl", e.CROSS = "cross"
        }(i = t.LauncherWebViewTransitionStyle || (t.LauncherWebViewTransitionStyle = {}));
        var c = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.urlScheme = function(t, n) {
                var o = {
                    url: t
                };
                e.prototype.enqueueCb.call(this, "urlScheme", null, n, o)
            }, t.prototype.webview = function(t, n, o) {
                (n = n || {}).url = t, n.transitionStyle = n.transitionStyle || i.COVER, e.prototype.enqueueCb.call(this, "webview", null, o || null, n)
            }, t.API_CLASS_ID = "applican.launcher", t
        }(a.Base);
        t.Launcher = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.BUSY_ERROR = "BUSY_ERROR", e.BLUETOOT_NOT_SUPPORTED = "BLUETOOTH_NOT_SUPPORTED", e.UNKNOWN_ERROR = "UNKNOWN_ERROR", e.BLUETOOT_DISABLED = "BLUETOOTH_DISABLED", e.BLUETOOTH_NOT_SUPPORTED = "BLUETOOTH_NOT_SUPPORTED", e.BLUETOOTH_DISABLED = "BLUETOOTH_DISABLED"
        }(t.BluetoothError || (t.BluetoothError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.isSupported = function(t, n) {
                e.prototype.enqueueCb.call(this, "isSupported", t, n)
            }, t.prototype.isEnabled = function(t, n) {
                e.prototype.enqueueCb.call(this, "isEnabled", t, n)
            }, t.prototype.enable = function(t, n) {
                e.prototype.enqueueCb.call(this, "enable", t, n)
            }, t.prototype.disable = function(t, n) {
                e.prototype.enqueueCb.call(this, "disable", t, n)
            }, t.prototype.discover = function(t, n, o) {
                e.prototype.registerCallback.call(this, "discoveredCallback", function(e) {
                    return !!t && (t(e), !0)
                }), e.prototype.registerCallback.call(this, "finishedCallback", function(e) {
                    return !!n && (n(e), !0)
                }), e.prototype.enqueueCb.call(this, "discover", null, o)
            }, t.prototype.discoverableOn = function(t, n, o) {
                var r = {
                    discoverableDuration: t
                };
                e.prototype.enqueueCb.call(this, "discoverableOn", n, o, r)
            }, t.prototype.getBondedDevices = function(t, n) {
                e.prototype.enqueueCb.call(this, "getBondedDevices", t, n)
            }, t.prototype.cancelDiscovery = function(t, n) {
                e.prototype.enqueueCb.call(this, "cancelDiscovery", t, n)
            }, t.prototype.watchConnection = function(t, n, o, r) {
                e.prototype.registerCallback.call(this, "onWatchConnectionOpen", function(e) {
                    return !!t && (t(), !0)
                }), e.prototype.registerCallback.call(this, "onWatchConnectionMessage", function(e) {
                    return !!n && (n(e), !0)
                }), e.prototype.registerCallback.call(this, "onWatchConnectionClose", function(e) {
                    return !!o && (o(), !0)
                }), e.prototype.registerCallback.call(this, "onWatchConnectionError", function(e) {
                    return !!r && (r(e), !0)
                }), e.prototype.enqueueCb.call(this, "watchConnection", null, null)
            }, t.prototype.connect = function(t, n, o, r, i) {
                e.prototype.registerCallback.call(this, "onConnectionOpen", function(e) {
                    return !!n && (n(), !0)
                }), e.prototype.registerCallback.call(this, "onConnectionMessage", function(e) {
                    return !!o && (o(e), !0)
                }), e.prototype.registerCallback.call(this, "onConnectionClose", function(e) {
                    return !!r && (r(), !0)
                }), e.prototype.registerCallback.call(this, "onConnectionError", function(e) {
                    return !!i && (i(e), !0)
                });
                var a = {
                    address: t
                };
                e.prototype.enqueueCb.call(this, "connect", null, null, a)
            }, t.prototype.send = function(t) {
                var n = {
                    data: t
                };
                e.prototype.enqueueCb.call(this, "send", null, null, n)
            }, t.prototype.disconnect = function() {
                e.prototype.enqueueCb.call(this, "disconnect", null, null)
            }, t.API_CLASS_ID = "applican.bluetooth", t
        }(i.Base);
        t.Bluetooth = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.launchWebViewClosedEventListeners = [], e.prototype.registerCallback.call(o, "onWebViewClosed", o.onWebViewClosed.bind(o)), o
            }
            return r(t, e), t.prototype.goBack = function() {
                e.prototype.enqueueCb.call(this, "goBack", null, null)
            }, t.prototype.goForward = function() {
                e.prototype.enqueueCb.call(this, "goForward", null, null)
            }, t.prototype.reload = function() {
                e.prototype.enqueueCb.call(this, "reload", null, null)
            }, t.prototype.addLaunchWebviewCloseEventListener = function(e) {
                e && this.launchWebViewClosedEventListeners.push(e)
            }, t.prototype.onWebViewClosed = function() {
                for (var e = 0, t = this.launchWebViewClosedEventListeners; e < t.length; e++) {
                    (0, t[e])()
                }
                return !0
            }, t.API_CLASS_ID = "applican.webview", t
        }(n(0).Base);
        t.WebView = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.ws = null, o.onopen_ = null, o.onmessage_ = null, o.onclose_ = null, o.onerror_ = null, o
            }
            return r(t, e), t.prototype.open = function(e, t, n, o, r) {
                this.ws || (this.ws = new WebSocket(e), this.onopen_ = t, this.onmessage_ = n, this.onclose_ = o, this.onerror_ = r, this.ws.onopen = this.onWsOpen.bind(this), this.ws.onmessage = this.onWsMessage.bind(this), this.ws.onclose = this.onWsClose.bind(this), this.ws.onerror = this.onWsError.bind(this))
            }, t.prototype.send = function(e) {
                this.ws && this.ws.send(e)
            }, t.prototype.close = function(e, t) {
                this.ws && (this.ws.close(e, t), this.ws = null)
            }, t.prototype.onWsOpen = function(e) {
                this.onopen_ && this.onopen_(e)
            }, t.prototype.onWsMessage = function(e) {
                this.onmessage_ && this.onmessage_(e)
            }, t.prototype.onWsClose = function(e) {
                this.onclose_ && this.onclose_(e)
            }, t.prototype.onWsError = function(e) {
                this.onerror_ && this.onerror_(e)
            }, t.API_CLASS_ID = "applican.websocket", t
        }(n(0).Base);
        t._WebSocket = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.getCurrentMenu = function(t) {
                e.prototype.enqueueCb.call(this, "getCurrentMenu", t, null)
            }, t.prototype.setMenu = function(t) {
                var n = {
                    menu: t
                };
                e.prototype.enqueueCb.call(this, "setMenu", null, null, n)
            }, t.prototype.resetMenu = function() {
                e.prototype.enqueueCb.call(this, "resetMenu", null, null)
            }, t.API_CLASS_ID = "applican.slidemenu", t
        }(n(0).Base);
        t.SlideMenu = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.UNKNOWN_ERROR = 0] = "UNKNOWN_ERROR", e[e.INVALID_ARGUMENT = 1] = "INVALID_ARGUMENT", e[e.BUSY = 2] = "BUSY", e[e.NOT_SUPPORTED = 3] = "NOT_SUPPORTED", e[e.CANCELED = 4] = "CANCELED", e[e.ALREADY_OWNED = 5] = "ALREADY_OWNED", e[e.NOT_OWNED = 6] = "NOT_OWNED"
        }(t.PurchaseError || (t.PurchaseError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.getProducts = function(t, n, o, r) {
                var i = {
                    productIds: t,
                    productType: n
                };
                e.prototype.enqueueCb.call(this, "getProducts", o, r, i)
            }, t.prototype.makePurchase = function(t, n, o, r) {
                var i = {
                    productId: t,
                    productType: n
                };
                e.prototype.enqueueCb.call(this, "makePurchase", o, r, i)
            }, t.prototype.finishPurchase = function(t, n, o) {
                var r = {
                    purchaseId: t
                };
                e.prototype.enqueueCb.call(this, "finishPurchase", n, o, r)
            }, t.prototype.restorePurchase = function(t, n, o) {
                var r = {
                    productType: t
                };
                e.prototype.enqueueCb.call(this, "restorePurchase", n, o, r)
            }, t.prototype.toggleSandbox = function(t, n) {
                var o = {
                    enabled: t
                };
                e.prototype.enqueueCb.call(this, "toggleSandbox", n, null, o)
            }, t.prototype.setSharedPassword = function(t, n) {
                var o = {
                    password: t
                };
                e.prototype.enqueueCb.call(this, "setSharedPassword", n, null, o)
            }, t.prototype.finishAllPurchases = function(t) {
                e.prototype.enqueueCb.call(this, "finishAllPurchases", t, null)
            }, t.API_CLASS_ID = "applican.purchase", t
        }(i.Base);
        t.Purchase = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.INVALID_DATA = 1] = "INVALID_DATA", e[e.ILLEGAL_TRACK = 2] = "ILLEGAL_TRACK", e[e.NOW_LOADING = 3] = "NOW_LOADING", e[e.BUSY_ERROR = 4] = "BUSY_ERROR"
        }(t.GameSoundError || (t.GameSoundError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.loadBGM = function(t, n, o) {
                var r = {
                    list: t
                };
                e.prototype.enqueueCb.call(this, "loadBGM", n, o, r)
            }, t.prototype.setBGMVolume = function(t, n) {
                var o = {
                    track: t,
                    volume: n
                };
                e.prototype.enqueueCb.call(this, "setBGMVolume", null, null, o)
            }, t.prototype.playBGM = function(t) {
                e.prototype.enqueueCb.call(this, "playBGM", null, null, t)
            }, t.prototype.pauseBGM = function(t) {
                var n = {
                    track: t
                };
                e.prototype.enqueueCb.call(this, "pauseBGM", null, null, n)
            }, t.prototype.stopBGM = function(t) {
                var n = {
                    track: t
                };
                e.prototype.enqueueCb.call(this, "stopBGM", null, null, n)
            }, t.prototype.stopAllBGM = function() {
                e.prototype.enqueueCb.call(this, "stopAllBGM", null, null)
            }, t.prototype.releaseAllBGM = function() {
                e.prototype.enqueueCb.call(this, "releaseAllBGM", null, null)
            }, t.prototype.loadSE = function(t, n, o) {
                var r = {
                    list: t
                };
                e.prototype.enqueueCb.call(this, "loadSE", n, o, r)
            }, t.prototype.setSEVolume = function(t, n) {
                var o = {
                    track: t,
                    volume: n
                };
                e.prototype.enqueueCb.call(this, "setSEVolume", null, null, o)
            }, t.prototype.playSE = function(t) {
                var n = {
                    track: t
                };
                e.prototype.enqueueCb.call(this, "playSE", null, null, n)
            }, t.prototype.pauseSE = function(t) {
                var n = {
                    track: t
                };
                e.prototype.enqueueCb.call(this, "pauseSE", null, null, n)
            }, t.prototype.stopSE = function(t) {
                var n = {
                    track: t
                };
                e.prototype.enqueueCb.call(this, "stopSE", null, null, n)
            }, t.prototype.stopAllSE = function() {
                e.prototype.enqueueCb.call(this, "stopAllSE", null, null)
            }, t.prototype.releaseAllSE = function() {
                e.prototype.enqueueCb.call(this, "releaseAllSE", null, null)
            }, t.API_CLASS_ID = "applican.gamesound", t
        }(i.Base);
        t.GameSound = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.setBadge = function(t, n) {
                var o = {
                    tab: t,
                    num: n
                };
                e.prototype.enqueueCb.call(this, "setBadge", null, null, o)
            }, t.prototype.changeTabImage = function(t) {
                var n = {
                    folder: t
                };
                e.prototype.enqueueCb.call(this, "changeTabImage", null, null, n)
            }, t.API_CLASS_ID = "applican.tab", t
        }(n(0).Base);
        t.Tab = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.UNKNOWN_ERROR = 0] = "UNKNOWN_ERROR", e[e.FORMATTING_ERROR = 1] = "FORMATTING_ERROR", e[e.PARSING_ERROR = 2] = "PARSING_ERROR", e[e.PATTERN_ERROR = 3] = "PATTERN_ERROR", e[e.BUSY_ERROR = 30] = "BUSY_ERROR"
        }(t.GlobalizationError || (t.GlobalizationError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.getPreferredLanguage = function(t, n) {
                e.prototype.enqueueCb.call(this, "getPreferredLanguage", t, n)
            }, t.prototype.getLocaleName = function(t, n) {
                e.prototype.enqueueCb.call(this, "getLocaleName", t, n)
            }, t.prototype.getCountry = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCountry", t, n)
            }, t.prototype.dateToString = function(t, n, o) {
                var r = {
                    date: t.getTime() / 1e3
                };
                e.prototype.enqueueCb.call(this, "dateToString", n, o, r)
            }, t.API_CLASS_ID = "applican.globalization", t
        }(i.Base);
        t.Globalization = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.CAPTURE_INTERNAL_ERR = 0] = "CAPTURE_INTERNAL_ERR", e[e.CAPTURE_APPLICATION_BUSY = 1] = "CAPTURE_APPLICATION_BUSY", e[e.CAPTURE_INVALID_ARGUMENT = 2] = "CAPTURE_INVALID_ARGUMENT", e[e.CAPTURE_NO_MEDIA_FILES = 3] = "CAPTURE_NO_MEDIA_FILES", e[e.CAPTURE_NOT_SUPPORTED = 20] = "CAPTURE_NOT_SUPPORTED", e[e.CAPTURE_BUSY = 30] = "CAPTURE_BUSY"
        }(t.CaptureError || (t.CaptureError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.captureWithOverlay = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "captureWithOverlay", t, n, o)
            }, t.prototype.captureAudio = function(t, n) {
                e.prototype.enqueueCb.call(this, "captureAudio", t, n)
            }, t.prototype.captureVideo = function(t, n) {
                e.prototype.enqueueCb.call(this, "captureVideo", t, n)
            }, t.prototype.captureImage = function(t, n) {
                e.prototype.enqueueCb.call(this, "captureImage", t, n)
            }, t.API_CLASS_ID = "applican.capture", t
        }(i.Base);
        t.Capture = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.watchKeyDownCallback = null, o.watchKeyUpCallback = null, o.registerCallback("onKeyUp", o.onKeyUp.bind(o)), o.registerCallback("onKeyDown", o.onKeyDown.bind(o)), o
            }
            return r(t, e), t.prototype.watchKeyDown = function(t) {
                this.watchKeyDownCallback = function(e) {
                    t && t(e)
                }, e.prototype.enqueueCb.call(this, "watchKeyDown", t, null)
            }, t.prototype.clearWatchKeyDown = function() {
                this.watchKeyDownCallback = null, e.prototype.enqueueCb.call(this, "clearWatchKeyDown", null, null)
            }, t.prototype.watchKeyUp = function(t) {
                this.watchKeyUpCallback = function(e) {
                    t && t(e)
                }, e.prototype.enqueueCb.call(this, "watchKeyUp", t, null)
            }, t.prototype.clearWatchKeyUp = function() {
                this.watchKeyUpCallback = null, e.prototype.enqueueCb.call(this, "clearWatchKeyUp", null, null)
            }, t.prototype.onKeyDown = function(e) {
                return !!e && (this.watchKeyDownCallback && this.watchKeyDownCallback(e), !0)
            }, t.prototype.onKeyUp = function(e) {
                return !!e && (this.watchKeyUpCallback && this.watchKeyUpCallback(e), !0)
            }, t.API_CLASS_ID = "applican.keyboard", t
        }(n(0).Base);
        t.Keyboard = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.init = function(t, n) {
                e.prototype.enqueueCb.call(this, "init", t, n)
            }, t.prototype.showPopinfoList = function(t, n) {
                e.prototype.enqueueCb.call(this, "showPopinfoList", t, n)
            }, t.prototype.getId = function(t, n) {
                e.prototype.enqueueCb.call(this, "getId", t, n)
            }, t.prototype.showPopinfoSettings = function(t, n) {
                e.prototype.enqueueCb.call(this, "showPopinfoSettings", t, n)
            }, t.prototype.showSegmentSettings = function(t, n) {
                e.prototype.enqueueCb.call(this, "showSegmentSettings", t, n)
            }, t.API_CLASS_ID = "applican.popinfo", t
        }(n(0).Base);
        t.Popinfo = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i, a = n(0);
        ! function(e) {
            e.PERMISSION_DENIED = "PERMISSION_DENIED", e.UNKNOWN_ERROR = "UNKNOWN_ERROR", e.DISCONNECT = "DISCONNECT", e.ILLEGAL_PARAMETER = "ILLEGAL_PARAMETER", e.CONNECT_FAILED = "CONNECT_FAILED", e.NOT_SUPPORTED = "NOT_SUPPORTED", e.BUSY = "BUSY"
        }(t.WiFiError || (t.WiFiError = {})),
        function(e) {
            e.WIFI_ON = "WIFI_ON", e.WIFI_OFF = "WIFI_OFF"
        }(t.WiFiStatus || (t.WiFiStatus = {})),
        function(e) {
            e.WPA = "WPA", e.WEP = "WEP", e.NONE = "NONE"
        }(i = t.SecurityType || (t.SecurityType = {}));
        var c = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.SecurityType = i, o
            }
            return r(t, e), t.prototype.getStatus = function(t, n) {
                e.prototype.enqueueCb.call(this, "getStatus", t, n)
            }, t.prototype.connect = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "connect", t, n, o)
            }, t.prototype.hadConnected = function(t, n, o) {
                var r = {
                    ssid: t
                };
                e.prototype.enqueueCb.call(this, "hadConnected", n, o, r)
            }, t.prototype.on = function(t, n) {
                e.prototype.enqueueCb.call(this, "on", t, n)
            }, t.prototype.off = function(t, n) {
                e.prototype.enqueueCb.call(this, "off", t, n)
            }, t.prototype.getSSIDList = function(t, n) {
                e.prototype.enqueueCb.call(this, "getSSIDList", t, n)
            }, t.prototype.getCurrentSSID = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentSSID", t, n)
            }, t.prototype.getCurrentBSSID = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentBSSID", t, n)
            }, t.prototype.getCurrentIPv4Address = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentIPv4Address", t, n)
            }, t.prototype.getCurrentIPv6Address = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentIPv6Address", t, n)
            }, t.prototype.getAccessPointList = function(t, n) {
                e.prototype.enqueueCb.call(this, "getAccessPointList", t, n)
            }, t.prototype.getConfiguredNetworks = function(t, n) {
                e.prototype.enqueueCb.call(this, "getConfiguredNetworks", t, n)
            }, t.API_CLASS_ID = "applican.wifi", t
        }(a.Base);
        t.WiFi = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.NOT_FOUND_ERR = "NOT_FOUND_ERR", e.CANCELED = "CANCELED", e.BUSY = "BUSY"
        }(t.VideoError || (t.VideoError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.play = function(t, n, o, r) {
                var i = r || {};
                i.src = t, i.clientWidth = document.documentElement.clientWidth, i.clientHeight = document.documentElement.clientHeight, i.width = i.width || i.clientWidth, i.height = i.height || i.clientHeight, i.top || (i.bottom ? i.top = i.clientHeight - i.height - i.bottom : i.top = 0), i.left || (i.right ? i.left = i.clientWidth - i.width - i.right : i.left = 0), i.control = i.control || !1, e.prototype.enqueueCb.call(this, "play", n, o, r)
            }, t.prototype.stop = function() {
                e.prototype.enqueueCb.call(this, "stop", null, null)
            }, t.API_CLASS_ID = "applican.video", t
        }(i.Base);
        t.Video = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i, a = n(0);
        ! function(e) {
            e.CANCELED = "CANCELED", e.BUSY = "BUSY"
        }(t.ListError || (t.ListError = {})),
        function(e) {
            e[e.TITLE = 1] = "TITLE", e[e.SUBTITLE = 2] = "SUBTITLE", e[e.VALUE = 3] = "VALUE", e[e.SUBTITLE_VALUE = 4] = "SUBTITLE_VALUE", e[e.PICTURE = 5] = "PICTURE", e[e.PICTURE_SUBTITLE = 6] = "PICTURE_SUBTITLE", e[e.PICTURE_VALUE = 7] = "PICTURE_VALUE", e[e.PICTURE_SUBTITLE_VALUE = 8] = "PICTURE_SUBTITLE_VALUE"
        }(i = t.ListType || (t.ListType = {}));
        var c = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.LIST_TYPE_VALUE = {
                    TITLE: i.TITLE,
                    SUBTITLE: i.SUBTITLE,
                    VALUE: i.VALUE,
                    SUBTITLE_VALUE: i.SUBTITLE_VALUE,
                    PICTURE: i.PICTURE,
                    PICTURE_SUBTITLE: i.PICTURE_SUBTITLE,
                    PICTURE_VALUE: i.PICTURE_VALUE,
                    PICTURE_SUBTITLE_VALUE: i.PICTURE_SUBTITLE_VALUE
                }, o.listItems = null, o
            }
            return r(t, e), Object.defineProperty(t.prototype, "ListType", {
                get: function() {
                    return this.LIST_TYPE_VALUE
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype.show = function(t, n, o, r, i, a) {
                var c = this;
                (a = a || {}).type = t, a.title = n, a.listData = o, a.width = a.width || 50, a.height = a.height || 50, this.listItems = o, e.prototype.enqueueCb.call(this, "show", function(e) {
                    if (e && e.index && r) {
                        var t = c.listItems ? c.listItems[e.index] : null;
                        r(t || null)
                    }
                }, i, a)
            }, t.API_CLASS_ID = "applican.list", t
        }(a.Base);
        t._List = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.trackView = function(t) {
                var n = {
                    screen: t
                };
                e.prototype.enqueueCb.call(this, "trackView", null, null, n)
            }, t.prototype.trackEvent = function(t, n, o, r) {
                var i = {
                    category: t,
                    action: n,
                    label: o,
                    value: r
                };
                e.prototype.enqueueCb.call(this, "trackEvent", null, null, i)
            }, t.API_CLASS_ID = "applican.googleanalytics", t
        }(n(0).Base);
        t.GoogleAnalytics = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.show = function(t, n, o) {
                var r = {
                    portrait: "",
                    landscape: "",
                    timeout: -1
                };
                r.portrait = t || r.portrait, r.landscape = n || r.landscape, r.timeout = o || r.timeout, e.prototype.enqueueCb.call(this, "show", null, null, r)
            }, t.prototype.hide = function() {
                e.prototype.enqueueCb.call(this, "hide", null, null)
            }, t.API_CLASS_ID = "applican.splashscreen", t
        }(n(0).Base);
        t.SplashScreen = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.get = function(t, n) {
                var o = {
                    key: t
                };
                e.prototype.enqueueCb.call(this, "get", n, null, o)
            }, t.prototype.set = function(t, n, o) {
                var r = {
                    key: t,
                    value: n
                };
                e.prototype.enqueueCb.call(this, "set", o, null, r)
            }, t.prototype.remove = function(t, n) {
                var o = {
                    key: t
                };
                e.prototype.enqueueCb.call(this, "remove", n, null, o)
            }, t.prototype.clear = function(t) {
                e.prototype.enqueueCb.call(this, "clear", t, null)
            }, t.API_CLASS_ID = "applican.simplestorage", t
        }(n(0).Base);
        t.SimpleStorage = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(40),
            c = function(e) {
                function t(n) {
                    var o = e.call(this, t.API_CLASS_ID, n) || this;
                    return o.queue_ = n, o
                }
                return r(t, e), t.prototype.create = function(e) {
                    return new a.Contact(this.queue_, e)
                }, t.prototype.find = function(t, n, o, r) {
                    var i = this;
                    (r = r || {}).fields = t, e.prototype.enqueueCb.call(this, "find", function(e) {
                        if (Array.isArray(e)) {
                            for (var t = [], o = 0, r = e; o < r.length; o++) {
                                var c = r[o];
                                t.push(new a.Contact(i.queue_, c))
                            }
                            n && n(t)
                        }
                    }, o, r)
                }, t.API_CLASS_ID = "applican.contacts", t
            }(i.Base);
        t.Contacts = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e[e.UNKNOWN_ERROR = 0] = "UNKNOWN_ERROR", e[e.INVALID_ARGUMENT_ERROR = 1] = "INVALID_ARGUMENT_ERROR", e[e.TIMEOUT_ERROR = 2] = "TIMEOUT_ERROR", e[e.PENDING_OPERATION_ERROR = 3] = "PENDING_OPERATION_ERROR", e[e.IO_ERROR = 4] = "IO_ERROR", e[e.NOT_SUPPORTED_ERROR = 5] = "NOT_SUPPORTED_ERROR", e[e.PERMISSION_DENIED_ERROR = 20] = "PERMISSION_DENIED_ERROR", e[e.CONTACT_BUSY = 30] = "CONTACT_BUSY"
        }(t.ContactError || (t.ContactError = {}));
        var a = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n) || this;
                return r.id = null, r.displayName = null, r.name = null, r.nickname = null, r.phoneNumbers = null, r.emails = null, r.addresses = null, r.ims = null, r.organizations = null, r.birthday = null, r.note = null, r.photos = null, r.categories = null, r.urls = null, r.queue_ = n, r.rawId = null, o && (r.id = o.id, r.displayName = o.displayName, r.name = o.name, r.nickname = o.nickname, r.phoneNumbers = o.phoneNumbers, r.emails = o.emails, r.addresses = o.addresses, r.ims = o.ims, r.organizations = o.organizations, r.birthday = o.birthday, r.note = o.note, r.photos = o.photos, r.categories = o.categories, r.urls = o.urls), r.id = r.id || null, r.displayName = r.displayName || null, r.name = r.name || null, r.nickname = r.nickname || null, r.phoneNumbers = r.phoneNumbers || null, r.emails = r.emails || null, r.addresses = r.addresses || null, r.ims = r.ims || null, r.organizations = r.organizations || null, r.birthday = r.birthday || null, r.note = r.note || null, r.photos = r.photos || null, r.categories = r.categories || null, r.urls = r.urls || null, r
            }
            return r(t, e), t.prototype.getRawId = function() {
                return this.rawId
            }, t.prototype.remove = function(t, n) {
                var o = {
                    id: this.id
                };
                e.prototype.enqueueCb.call(this, "remove", t, n, o)
            }, t.prototype.clone = function() {
                var e = {
                    id: this.id,
                    displayName: this.displayName,
                    nickname: this.nickname,
                    note: this.note,
                    name: this.name,
                    phoneNumbers: this.phoneNumbers,
                    emails: this.emails,
                    addresses: this.addresses,
                    ims: this.ims,
                    organizations: this.organizations,
                    photos: this.photos,
                    categories: this.categories,
                    urls: this.urls,
                    birthday: this.birthday
                };
                return new t(this.queue_, e)
            }, t.prototype.save = function(t, n) {
                var o = {
                    id: this.id,
                    displayName: this.displayName,
                    nickname: this.nickname,
                    note: this.note,
                    name: this.name,
                    phoneNumbers: this.phoneNumbers,
                    emails: this.emails,
                    addresses: this.addresses,
                    ims: this.ims,
                    organizations: this.organizations,
                    photos: this.photos,
                    categories: this.categories,
                    urls: this.urls,
                    birthday: this.birthday
                };
                e.prototype.enqueueCb.call(this, "save", t, n, o)
            }, t.API_CLASS_ID = "applican.contact", t
        }(i.Base);
        t.Contact = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.ILLEGAL_PARAMETER = "ILLEGAL_PARAMETER", e.NOTIFICATIO_BUSY_ERR = "NOTIFICATIO_BUSY_ERR", e.NOT_ALLOWED = "NOT_ALLOWED"
        }(t.LocalNotificationError || (t.LocalNotificationError = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.schedule = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "schedule", t, n, o)
            }, t.prototype.cancel = function(t) {
                e.prototype.enqueueCb.call(this, "cancel", null, null, t)
            }, t.prototype.allCancel = function() {
                e.prototype.enqueueCb.call(this, "allCancel", null, null)
            }, t.prototype.getBadgeNum = function(t) {
                e.prototype.enqueueCb.call(this, "getBadgeNum", t, null)
            }, t.prototype.setBadgeNum = function(t) {
                var n = {
                    num: t
                };
                e.prototype.enqueueCb.call(this, "setBadgeNum", null, null, n)
            }, t.API_CLASS_ID = "applican.localnotification", t
        }(i.Base);
        t.LocalNotification = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.alert = function(t, n, o, r) {
                var i = {
                    message: t,
                    title: o = o || "Alert",
                    buttonName: r = r || "OK"
                };
                e.prototype.enqueueCb.call(this, "alert", n, null, i)
            }, t.prototype.confirm = function(t, n, o, r) {
                var i = {
                    message: t,
                    title: o = o || "Confirm",
                    buttonName: r = r || "OK,Cancel"
                };
                e.prototype.enqueueCb.call(this, "confirm", n, null, i)
            }, t.prototype.beep = function(t) {
                var n = {
                    times: t = t || 1
                };
                e.prototype.enqueueCb.call(this, "beep", null, null, n)
            }, t.prototype.vibrate = function(t) {
                var n = {
                    milliseconds: t = t || 100
                };
                e.prototype.enqueueCb.call(this, "vibrate", null, null, n)
            }, t.API_CLASS_ID = "applican.notification", t
        }(n(0).Base);
        t.Notification = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), Object.defineProperty(t.prototype, "DestinationType", {
                get: function() {
                    return {
                        DATA_URL: 0,
                        FILE_URI: 1
                    }
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "PictureSourceType", {
                get: function() {
                    return {
                        PHOTOLIBRARY: 0,
                        CAMERA: 1,
                        SAVEDPHOTOALBUM: 2
                    }
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "EncodingType", {
                get: function() {
                    return {
                        JPEG: 0,
                        PNG: 1
                    }
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "MediaType", {
                get: function() {
                    return {
                        PICTURE: 0,
                        VIDEO: 1,
                        ALLMEDIA: 2
                    }
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype.takePicture = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "takePicture", t, n, o)
            }, t.prototype.getPicture = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "getPicture", t, n, o)
            }, t.prototype.cleanup = function(t, n) {
                e.prototype.enqueueCb.call(this, "cleanup", t, n)
            }, t.prototype.saveToPhotoAlbum = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "saveToPhotoAlbum", n, o, {
                    data: t
                })
            }, t.prototype.light = function(t, n, o) {
                var r = {
                    enable: t
                };
                e.prototype.enqueueCb.call(this, "light", n || null, o || null, r)
            }, t.API_CLASS_ID = "applican.camera", t
        }(n(0).Base);
        t.Camera = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.CELL = "CELL", e.WIFI = "WIFI", e.NONE = "NONE", e.UNKNOWN = "UNKNOWN"
        }(t.ConnectionType || (t.ConnectionType = {}));
        var a = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.getCurrentConnectionType = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentConnectionType", t, n)
            }, t.API_CLASS_ID = "applican.connection", t
        }(i.Base);
        t.Connection = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.getFirstChildText = function(e, t) {
                try {
                    return e.getElementsByTagName(t).item(0).textContent || ""
                } catch (e) {
                    return ""
                }
            }, t.parseAddressString = function(e) {
                var t = e.match(/^(東京都|京都府|[^都道府県]+[都道府県])/);
                if (!t) return null;
                var n = t[0],
                    o = "",
                    r = (e = e.replace(new RegExp("^" + n), "")).split("");
                if (e.match(/区/))
                    for (var i = 0, a = r.length; i < a; ++i) {
                        if (o += c = r[i], "区" === c) break
                    } else if (e.match(/^(市川市|四日市市|八日市市|町田市|十日町市|大町市|原町市|武蔵村山市|東村山市|羽村市|村上市|中村市|大村市|村山市|市来町|東市来町|余市町|種市町|市貝町|上市町|野々市町|市川大門町|市川町|下市町|六日市町|市場町|野市町|大町町|鹿町町|村田町|玉村町|村松町|村岡町|市浦村)/)) o = RegExp.$1;
                    else if (e.match(/[市町村]/))
                    for (i = 0, a = r.length; i < a; ++i) {
                        var c;
                        if (o += c = r[i], c.match(/[市町村]/)) break
                    }
                return {
                    region: n,
                    city: o,
                    street: e = e.replace(new RegExp("^" + o), "")
                }
            }, t.prototype.getCurrentPosition = function(e, n, o) {
                var r = '\n<?xml version="1.0" encoding="UTF-8"?>\n<DDF ver="1.0">\n  <RequestInfo>\n    <RequestParam>\n      <APIKey>\n        <APIKey1_ID>' + o.APIKey1 + "</APIKey1_ID >\n        <APIKey2>" + o.APIKey2 + "</APIKey2>\n      </APIKey>\n      <OptionProperty>\n        <AreaCode></AreaCode>\n        <AreaName></AreaName>\n        <Adr></Adr>\n        <AdrCode></AdrCode>\n        <PostCode></PostCode>\n      </OptionProperty>\n    </RequestParam>\n  </RequestInfo>\n</DDF>",
                    i = new XMLHttpRequest;
                i.open("POST", "https://api.spmode.ne.jp/nwLocation/GetLocation", !0), i.setRequestHeader("If-Modified-Since", "Mon, 27 Mar 1972 00:00:00 GMT"), i.setRequestHeader("Content-Type", "application/xml; charset=UTF-8"), i.send(r);
                var a = window.setTimeout(function() {
                    i.abort(), n && n({
                        code: 0,
                        message: "タイムアウト"
                    })
                }, 3e3);
                i.onload = function(o) {
                    window.clearTimeout(a);
                    var r = i.responseXML,
                        c = {
                            status: i.status,
                            statusText: i.statusText,
                            responseText: i.responseText,
                            responseXML: r,
                            code: 0,
                            message: ""
                        };
                    if (200 !== i.status || !r) return c.message = "通信エラー", void(n && n(c));
                    var u = t.getFirstChildText(r, "ResultCode");
                    if (!u) return c.message = "不正な応答", void(n && n(c));
                    var s = parseInt(u, 10);
                    c.code = s;
                    var l = t.getFirstChildText(r, "Message");
                    if (c.message = l, 2e3 > s || 3e3 <= s) n && n(c);
                    else {
                        var p = t.getFirstChildText(r, "Lat"),
                            f = t.getFirstChildText(r, "Lon"),
                            h = t.getFirstChildText(r, "Time"),
                            _ = t.getFirstChildText(r, "AdrCode"),
                            y = t.getFirstChildText(r, "AreaCode"),
                            d = t.getFirstChildText(r, "AreaName"),
                            b = t.getFirstChildText(r, "adrCode"),
                            g = t.getFirstChildText(r, "Adr"),
                            P = t.parseAddressString(g),
                            C = {
                                coords: {
                                    latitude: parseFloat(p.replace(/^[A-Z]/, "")),
                                    longitude: parseFloat(f.replace(/^[A-Z]/, "")),
                                    Lat: p,
                                    Lon: f
                                },
                                address: {
                                    region: P && P.region || "",
                                    city: P && P.city || "",
                                    street: P && P.street || "",
                                    postalCode: _,
                                    AreaCode: y,
                                    AreaName: d,
                                    Adr: g,
                                    AdrCode: b,
                                    PostalCode: _
                                },
                                timestamp: h,
                                code: s,
                                message: l
                            };
                        e && e(C)
                    }
                }
            }, t.API_CLASS_ID = "applican.docomogeolocation", t
        }(n(0).Base);
        t.DocomoGeolocation = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.captureBarcode = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "captureBarcode", function(e) {
                    e && t(e)
                }, n, o)
            }, t.API_CLASS_ID = "applican.barcode", t
        }(n(0).Base);
        t.Barcode = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.PERMISSION_DENIED = "PERMISSION_DENIED", e.POSITION_UNAVAILABLE = "POSITION_UNAVAILABLE", e.TIMEOUT = "TIMEOUT", e.POSITION_BUSY_ERR = "POSITION_BUSY_ERR"
        }(t.PositionError || (t.PositionError = {}));
        var a = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.currentWatchId = 0, o.successCb = {}, o.errorCb = {}, e.prototype.registerCallback.call(o, "onWatchPosition", o.onWatchPosition.bind(o)), o
            }
            return r(t, e), t.prototype.getCurrentPosition = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "getCurrentPosition", t, n, o)
            }, t.prototype.watchPosition = function(t, n, o) {
                return (o = o || {}).watchId = this.currentWatchId, o.frequency = o.frequency || 1e3, e.prototype.enqueueCb.call(this, "watchPosition", t, n, o), this.successCb[this.currentWatchId] = t, this.errorCb[this.currentWatchId] = n, this.currentWatchId++
            }, t.prototype.clearWatch = function(t) {
                var n = {
                    watchId: t
                };
                this.successCb[t] && delete this.successCb[t], this.errorCb[t] && delete this.errorCb[t], e.prototype.enqueueCb.call(this, "clearWatch", null, null, n)
            }, t.prototype.onWatchPosition = function(e) {
                return !(!e || void 0 === e.id) && (!!this.successCb[e.id] && (this.successCb[e.id](e), !0))
            }, t.API_CLASS_ID = "applican.geolocation", t
        }(i.Base);
        t.Geolocation = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0);
        ! function(e) {
            e.COMPASS_INTERNAL_ERR = "COMPASS_INTERNAL_ERR", e.COMPASS_NOT_SUPPORTED = "COMPASS_NOT_SUPPORTED", e.COMPASS_BUSY_ERR = "COMPASS_BUSY_ERR"
        }(t.CompassError || (t.CompassError = {}));
        var a = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.currentWatchId = 0, o.successCb = {}, o.errorCb = {}, e.prototype.registerCallback.call(o, "onWatchHeading", o.onWatchHeading.bind(o)), o
            }
            return r(t, e), t.prototype.getCurrentHeading = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "getCurrentHeading", t, n, o)
            }, t.prototype.watchHeading = function(t, n, o) {
                return (o = o || {}).watchId = this.currentWatchId, o.frequency = o.frequency || 1e3, e.prototype.enqueueCb.call(this, "watchHeading", t, n, o), this.successCb[this.currentWatchId] = t, this.errorCb[this.currentWatchId] = n, this.currentWatchId++
            }, t.prototype.clearWatch = function(t) {
                var n = {
                    watchId: t
                };
                this.successCb[t] && delete this.successCb[t], this.errorCb[t] && delete this.errorCb[t], e.prototype.enqueueCb.call(this, "clearWatch", null, null, n)
            }, t.prototype.onWatchHeading = function(e) {
                return !(!e || void 0 === e.id) && (!!this.successCb[e.id] && (this.successCb[e.id](e), !0))
            }, t.API_CLASS_ID = "applican.compass", t
        }(i.Base);
        t.Compass = a
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.currentWatchId = 0, o.successCb = {}, o.errorCb = {}, o.shakeCb = null, e.prototype.registerCallback.call(o, "onWatchAccelerometer", o.onWatchAccelerometer.bind(o)), e.prototype.registerCallback.call(o, "onWatchShake", o.onWatchShake.bind(o)), o
            }
            return r(t, e), t.prototype.getCurrentAcceleration = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentAcceleration", t, n)
            }, t.prototype.watchAcceleration = function(t, n, o) {
                return (o = o || {}).watchId = this.currentWatchId, o.frequency = o.frequency || 1e3, e.prototype.enqueueCb.call(this, "watchAcceleration", t, n, o), this.successCb[this.currentWatchId] = t, this.errorCb[this.currentWatchId] = n, this.currentWatchId++
            }, t.prototype.clearWatch = function(t) {
                var n = {
                    watchId: t
                };
                this.successCb[t] && delete this.successCb[t], this.errorCb[t] && delete this.errorCb[t], e.prototype.enqueueCb.call(this, "clearWatch", null, null, n)
            }, t.prototype.watchShake = function(t, n) {
                this.shakeCb = t, e.prototype.enqueueCb.call(this, "watchShake", t, n)
            }, t.prototype.clearWatchShake = function(t, n) {
                this.shakeCb = null, e.prototype.enqueueCb.call(this, "clearWatchShake", t, n)
            }, t.prototype.onWatchAccelerometer = function(e) {
                return !(!e || void 0 === e.id) && (!!this.successCb[e.id] && (this.successCb[e.id](e), !0))
            }, t.prototype.onWatchShake = function(e) {
                return !!this.shakeCb && (this.shakeCb(), !0)
            }, t.API_CLASS_ID = "applican.accelerometer", t
        }(n(0).Base);
        t.Accelerometer = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(51),
            c = n(52),
            u = function(e) {
                function t(n) {
                    var o = e.call(this, t.API_CLASS_ID, n) || this;
                    return o.players_ = {}, o.recorders_ = {}, o.queue_ = n, e.prototype.registerCallback.call(o, "onMediaPlayerReleased", o.onMediaPlayerReleased.bind(o)), e.prototype.registerCallback.call(o, "onMediaRecorderReleased", o.onMediaRecorderReleased.bind(o)), o
                }
                return r(t, e), t.prototype.createMediaPlayer = function(t, n, o) {
                    var r = this,
                        i = {
                            infile: t
                        };
                    e.prototype.enqueueCb.call(this, "createMediaPlayer", function(e) {
                        if (e && n && e.infile) {
                            var t = new a.MediaPlayer(r.queue_, e.infile);
                            r.players_[t.instanceId] = t, n(t)
                        }
                    }, o, i)
                }, t.prototype.createMediaRecorder = function(t, n, o) {
                    var r = this,
                        i = {
                            outfile: t
                        };
                    e.prototype.enqueueCb.call(this, "createMediaRecorder", function(e) {
                        if (e && n && e.outfile) {
                            var t = new c.MediaRecorder(r.queue_, e.outfile);
                            r.recorders_[t.instanceId] = t, n(t)
                        }
                    }, o, i)
                }, t.prototype.onMediaPlayerReleased = function(e) {
                    return !(!e || !e.instanceId) && (this.players_[e.instanceId] && delete this.players_[e.instanceId], !0)
                }, t.prototype.onMediaRecorderReleased = function(e) {
                    return !(!e || !e.instanceId) && (this.recorders_[e.instanceId] && delete this.recorders_[e.instanceId], !0)
                }, t.API_CLASS_ID = "applican.media", t
            }(i.Base);
        t.Media = u
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n, {
                    infile: o
                }) || this;
                return r.onplaybackfinished = null, e.prototype.registerCallback.call(r, "onPlaybackFinished", r.onPlaybackFinished.bind(r)), r
            }
            return r(t, e), t.prototype.release = function(t, n) {
                e.prototype.enqueueCb.call(this, "release", t, n)
            }, t.prototype.play = function(t, n, o) {
                t = t || {}, e.prototype.enqueueCb.call(this, "play", n, o, t)
            }, t.prototype.stop = function(t, n) {
                e.prototype.enqueueCb.call(this, "stop", t, n)
            }, t.prototype.pause = function(t, n) {
                e.prototype.enqueueCb.call(this, "pause", t, n)
            }, t.prototype.seekTo = function(t, n, o) {
                var r = {
                    position: t
                };
                e.prototype.enqueueCb.call(this, "seekTo", function(e) {
                    e && !e.position && n && n(e.position)
                }, o, r)
            }, t.prototype.getDuration = function(t, n) {
                e.prototype.enqueueCb.call(this, "getDuration", function(e) {
                    e && !e.duration && t && t(e.duration)
                }, n)
            }, t.prototype.getCurrentPosition = function(t, n) {
                e.prototype.enqueueCb.call(this, "getCurrentPosition", function(e) {
                    e && !e.position && t && t(e.position)
                }, n)
            }, t.prototype.setVolume = function(t, n, o) {
                var r = {
                    volume: t
                };
                e.prototype.enqueueCb.call(this, "setVolume", function(e) {
                    e && !e.volume && n && n(e.volume)
                }, o, r)
            }, t.prototype.getVolume = function(t, n) {
                e.prototype.enqueueCb.call(this, "getVolume", function(e) {
                    e && !e.volume && t && t(e.volume)
                }, n)
            }, t.prototype.onPlaybackFinished = function(e) {
                return this.onplaybackfinished && this.onplaybackfinished(), !0
            }, t.API_CLASS_ID = "applican.media.mediaplayer", t
        }(n(0).Base);
        t.MediaPlayer = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n, {
                    outfile: o
                }) || this;
                return r.onrecordfinished = null, e.prototype.registerCallback.call(r, "onRecordingFinished", r.onRecordingFinished.bind(r)), r
            }
            return r(t, e), t.prototype.release = function(t, n) {
                e.prototype.enqueueCb.call(this, "release", t, n)
            }, t.prototype.record = function(t, n, o) {
                t = t || {}, e.prototype.enqueueCb.call(this, "record", n, o, t)
            }, t.prototype.stop = function(t, n) {
                e.prototype.enqueueCb.call(this, "stop", t, n)
            }, t.prototype.onRecordingFinished = function(e) {
                return this.onrecordfinished && this.onrecordfinished(), !0
            }, t.API_CLASS_ID = "applican.media.mediarecorder", t
        }(n(0).Base);
        t.MediaRecorder = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(54),
            c = function(e) {
                function t(n) {
                    var o = e.call(this, t.API_CLASS_ID, n) || this;
                    return o.databases_ = {}, o.queue_ = n, e.prototype.registerCallback.call(o, "onDatabaseClosed", o.onDatabaseClosed.bind(o)), o
                }
                return r(t, e), t.prototype.open = function(t, n, o) {
                    var r = this,
                        i = {
                            name: t
                        };
                    e.prototype.enqueueCb.call(this, "open", function(e) {
                        if (e && n && e.name) {
                            var t = new a.Database(r.queue_, e.name);
                            r.databases_[t.instanceId] = t, n(t)
                        }
                    }, o, i)
                }, t.prototype.closeAllDatabases = function(t, n) {
                    e.prototype.enqueueCb.call(this, "closeAllDatabases", t, n)
                }, t.prototype.onDatabaseClosed = function(e) {
                    return !(!e || !e.instanceId) && (this.databases_[e.instanceId] && delete this.databases_[e.instanceId], !0)
                }, t.API_CLASS_ID = "applican.database.databasefactory", t
            }(i.Base);
        t.DatabaseFactory = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n, o) {
                var r = e.call(this, t.API_CLASS_ID, n, {
                    name: o
                }) || this;
                return r.name = o, r
            }
            return r(t, e), t.prototype.close = function(t, n) {
                e.prototype.enqueueCb.call(this, "close", t, n)
            }, t.prototype.exec = function(t, n, o) {
                var r = {
                    sql: t
                };
                e.prototype.enqueueCb.call(this, "exec", n, o, r)
            }, t.prototype.execTransaction = function(t, n, o) {
                var r = {
                    sqls: t
                };
                e.prototype.enqueueCb.call(this, "execTransaction", n, o, r)
            }, t.prototype.query = function(t, n, o) {
                var r = {
                    sql: t
                };
                e.prototype.enqueueCb.call(this, "query", n, o, r)
            }, t.API_CLASS_ID = "applican.database", t
        }(n(0).Base);
        t.Database = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.nativeFireHTMLEvent = function(e) {
                var t = document.createEvent("HTMLEvents");
                t.initEvent(e, !1, !1), document.dispatchEvent(t)
            }, t.nativeFireBatteryEvent = function(e, t, n) {
                var o = document.createEvent("HTMLEvents");
                o.initEvent(e, !1, !1), o.level = t, o.isPlugged = n, document.dispatchEvent(o)
            }, t.nativeFireOrientationEvent = function(e) {
                var t = document.createEvent("HTMLEvents");
                t.initEvent("orientationchanged", !1, !1), t.orientation = e, document.dispatchEvent(t)
            }, t.nativeFireWhitelistBlockedEvent = function(e, t, n) {
                var o = document.createEvent("HTMLEvents");
                o.initEvent("whitelistblocked", !1, !1), o.applican_whitelist_url = e, o.applican_whitelist_scope = t, o.applican_whitelist_api = n, document.dispatchEvent(o)
            }, t.nativeFireGcmRegistrationTokenReceivedEvent = function(e) {
                var t = document.createEvent("HTMLEvents");
                t.initEvent("gcmtokenreceived", !1, !1), t.token = e, document.dispatchEvent(t)
            }, t.API_CLASS_ID = "applican.event", t
        }(n(0).Base);
        t._Event = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.finish = function() {
                e.prototype.enqueueCb.call(this, "finish", null, null)
            }, t.API_CLASS_ID = "applican.application", t
        }(n(0).Base);
        t.Application = i
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.show = function() {
                e.prototype.enqueueCb.call(this, "show", null, null)
            }, t.prototype.verbose = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var o = {
                    args: t
                };
                e.prototype.enqueueCb.call(this, "verbose", null, null, o)
            }, t.prototype.debug = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var o = {
                    args: t
                };
                e.prototype.enqueueCb.call(this, "debug", null, null, o)
            }, t.prototype.info = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var o = {
                    args: t
                };
                e.prototype.enqueueCb.call(this, "info", null, null, o)
            }, t.prototype.warn = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var o = {
                    args: t
                };
                e.prototype.enqueueCb.call(this, "warn", null, null, o)
            }, t.prototype.error = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var o = {
                    args: t
                };
                e.prototype.enqueueCb.call(this, "error", null, null, o)
            }, t.API_CLASS_ID = "applican.console", t
        }(n(0).Base);
        t.Console = i
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            function e() {}
            return e.TEMPORARY = 0, e.PERSISTENT = 1, e
        }();
        t.LocalFileSystem = o
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(60),
            c = n(1),
            u = n(61),
            s = n(8),
            l = n(63),
            p = n(2),
            f = n(6),
            h = function(e) {
                function t(n) {
                    var o = e.call(this, t.API_CLASS_ID, n) || this;
                    return o.queue_ = n, o
                }
                return r(t, e), t.prototype.getApplicationFilesRoot = function(t, n) {
                    e.prototype.enqueueCb.call(this, "getApplicationFilesRoot", t, n)
                }, t.prototype.getApplicationExternalFilesRoot = function(t, n) {
                    e.prototype.enqueueCb.call(this, "getApplicationExternalFilesRoot", t, n)
                }, t.prototype.getApplicationCacheRoot = function(t, n) {
                    e.prototype.enqueueCb.call(this, "getApplicationCacheRoot", t, n)
                }, t.prototype.getApplicationExternalCacheRoot = function(t, n) {
                    e.prototype.enqueueCb.call(this, "getApplicationExternalCacheRoot", t, n)
                }, t.prototype.requestFileSystem = function(t, n, o, r) {
                    var i = this,
                        u = {
                            type: t,
                            size: n
                        };
                    e.prototype.enqueueCb.call(this, "requestFileSystem", function(e) {
                        if (e && o) {
                            var t = new a.FileSystem(i.queue_, e.name, new c.DirectoryEntry(i.queue_, e.root_name, e.root_path));
                            o(t)
                        }
                    }, r, u)
                }, t.prototype.createDirectoryEntry = function(e, t) {
                    return new c.DirectoryEntry(this.queue_, e, t)
                }, t.prototype.createDirectoryReader = function(e) {
                    return new f.DirectoryReader(this.queue_, e)
                }, t.prototype.createFileEntry = function(e, t) {
                    return new p.FileEntry(this.queue_, e, t)
                }, t.prototype.createFileReader = function() {
                    return new l._FileReader(this.queue_)
                }, t.prototype.createFileWriter = function(e) {
                    return new s.FileWriter(this.queue_, e)
                }, t.prototype.createFileTransfer = function() {
                    return new u.FileTransfer(this.queue_)
                }, t.API_CLASS_ID = "applican.filesystem.filesystemfactory", t
            }(i.Base);
        t.FileSystemFactory = h
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(1),
            c = function(e) {
                function t(n, o, r) {
                    var i = e.call(this, t.API_CLASS_ID, n) || this;
                    return i.name = o, i.root = null, r && (i.root = new a.DirectoryEntry(n, r.name, r.fullPath)), i
                }
                return r(t, e), t.API_CLASS_ID = "applican.filesystem", t
            }(i.Base);
        t.FileSystem = c
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n(0),
            a = n(62),
            c = n(2),
            u = function(e) {
                function t(n) {
                    var o = e.call(this, t.API_CLASS_ID, n) || this;
                    return o.onprogress = null, o.queue_ = n, e.prototype.registerCallback.call(o, "onProgress", o._onProgress.bind(o)), o
                }
                return r(t, e), t.prototype.upload = function(t, n, o, r, i, a) {
                    (i = i || {}).filePath = t, i.server = n, i.trustAllHosts = a || !1, e.prototype.enqueueCb.call(this, "upload", function(e) {
                        e && o && o(e)
                    }, r, i)
                }, t.prototype.download = function(t, n, o, r, i) {
                    var a = this,
                        u = {
                            source: t,
                            target: n,
                            trustAllHosts: i
                        };
                    e.prototype.enqueueCb.call(this, "download", function(e) {
                        e && o && o(new c.FileEntry(a.queue_, e.name, e.fullPath))
                    }, r, u)
                }, t.prototype.abort = function(t, n) {
                    e.prototype.enqueueCb.call(this, "abort", t, n)
                }, t.prototype._onProgress = function(e) {
                    if (!e) return !1;
                    if (this.onprogress) {
                        var t = new a.ProgressEvent(e.total, e.loaded);
                        this.onprogress(t)
                    }
                    return !0
                }, t.API_CLASS_ID = "applican.filesystem.filetransfer", t
            }(i.Base);
        t.FileTransfer = u
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t) {
                this.total = e, this.loaded = t, this.lengthComputable = 0 < this.total
            }
        }();
        t.ProgressEvent = o
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                var o = e.call(this, t.API_CLASS_ID, n) || this;
                return o.onloadend = null, o.onloadstart = null, o.onerror = null, o.onprogress = null, o.onload = null, o.onabort = null, e.prototype.registerCallback.call(o, "onLoadStart", o._onLoadStart.bind(o)), e.prototype.registerCallback.call(o, "onLoad", o._onLoad.bind(o)), e.prototype.registerCallback.call(o, "onLoadEnd", o._onLoadEnd.bind(o)), e.prototype.registerCallback.call(o, "onLoadError", o._onLoadError.bind(o)), e.prototype.registerCallback.call(o, "onLoadProgress", o._onLoadProgress.bind(o)), e.prototype.registerCallback.call(o, "onLoadAbort", o._onLoadAbort.bind(o)), o
            }
            return r(t, e), t.prototype.readAsText = function(t, n) {
                var o = {
                    fullPath: t.fullPath,
                    encoding: n
                };
                e.prototype.enqueueCb.call(this, "readAsText", null, null, o)
            }, t.prototype.readAsDataURL = function(t) {
                var n = {
                    fullPath: t.fullPath
                };
                e.prototype.enqueueCb.call(this, "readAsDataURL", null, null, n)
            }, t.prototype.abort = function() {}, t.prototype.readAsBinaryString = function(e) {
                this.abort()
            }, t.prototype.readAsArrayBuffer = function(e) {
                this.abort()
            }, t.prototype._onLoadStart = function(e) {
                return this.onloadstart && this.onloadstart(e), !0
            }, t.prototype._onLoad = function(e) {
                return this.onload && this.onload(e), !0
            }, t.prototype._onLoadEnd = function(e) {
                return this.onloadend && this.onloadend(e), !0
            }, t.prototype._onLoadError = function(e) {
                return this.onerror && this.onerror(e), !0
            }, t.prototype._onLoadProgress = function(e) {
                return this.onprogress && this.onprogress(e), !0
            }, t.prototype._onLoadAbort = function(e) {
                return this.onabort && this.onabort(e), !0
            }, t.EMPTY = 0, t.LOADING = 1, t.DONE = 2, t.API_CLASS_ID = "applican.filesystem.filereader", t
        }(n(0).Base);
        t._FileReader = i
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t, n, o, r) {
                this.fileKey = e, this.fileName = t, this.mimeType = n, this.params = o, this.headers = r
            }
        }();
        t._FileUploadOptions = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t) {
                this.filter = e, this.multiple = t, this.filter = this.filter || "", void 0 === this.multiple && (this.multiple = !1)
            }
        }();
        t._ContactFindOptions = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t, n, o, r, i) {
                this.formatted = e, this.familyName = t, this.givenName = n, this.middleName = o, this.honorificPrefix = r, this.honorificSuffix = i, this.formatted = this.formatted || null, this.familyName = this.familyName || null, this.givenName = this.givenName || null, this.middleName = this.middleName || null, this.honorificPrefix = this.honorificPrefix || null, this.honorificSuffix = this.honorificSuffix || null
            }
        }();
        t._ContactName = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t, n) {
                this.type = e, this.value = t, this.pref = n, this.id = null, this.type = this.type && this.type.toString() || null, this.value = this.value && this.value.toString() || null, this.pref = void 0 !== this.pref && this.pref
            }
        }();
        t._ContactField = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t, n, o, r, i, a, c) {
                this.pref = e, this.type = t, this.formatted = n, this.streetAddress = o, this.locality = r, this.region = i, this.postalCode = a, this.country = c, this.id = null, this.pref = this.pref || !1, this.type = this.type || null, this.formatted = this.formatted || null, this.streetAddress = this.streetAddress || null, this.locality = this.locality || null, this.region = this.region || null, this.postalCode = this.postalCode || null, this.country = this.country || null
            }
        }();
        t._ContactAddress = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function(e, t, n, o, r) {
                this.pref = e, this.type = t, this.name = n, this.department = o, this.title = r, this.id = null, this.pref = this.pref || !1, this.type = this.type || null, this.name = this.name || null, this.department = this.department || null, this.title = this.title || null
            }
        }();
        t._ContactOrganization = o
    }, function(e, t, n) {
        "use strict";
        var o, r = this && this.__extends || (o = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            });
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = function(e) {
            function t(n) {
                return e.call(this, t.API_CLASS_ID, n) || this
            }
            return r(t, e), t.prototype.showGeopopList = function(t, n) {
                e.prototype.enqueueCb.call(this, "showGeopopList", t, n)
            }, t.prototype.startGpsMeshGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startGpsMeshGeofencing", n, o, t)
            }, t.prototype.startWifiGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startWifiGenreGeofencing", n, o, t)
            }, t.prototype.startIBeaconGenreGeofencing = function(t, n, o) {
                e.prototype.enqueueCb.call(this, "startIBeaconGenreGeofencing", n, o, t)
            }, t.prototype.stopGpsMeshGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopGpsMeshGeofencing", t, n)
            }, t.prototype.stopWifiGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopWifiGenreGeofencing", t, n)
            }, t.prototype.stopIBeaconGenreGeofencing = function(t, n) {
                e.prototype.enqueueCb.call(this, "stopIBeaconGenreGeofencing", t, n)
            }, t.API_CLASS_ID = "applican.geopop", t
        }(n(0).Base);
        t.Geopop = i
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
                value: !0
            }),
            function(e) {
                e.DEVICE_BUSY_ERR = "DEVICE_BUSY_ERR"
            }(t.ApplicanError || (t.ApplicanError = {}))
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            function e(e, t, n, o, r) {
                this.code = e, this.source = t, this.target = n, this.http_status = o, this.body = r
            }
            return e.FILE_NOT_FOUND_ERR = 1, e.INVALID_URL_ERR = 2, e.CONNECTION_ERR = 3, e.ABORT_ERR = 4, e
        }();
        t.FileTransferError = o
    }, function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = function() {
            return function() {
                this.bytesSent = 0, this.responseCode = 0, this.response = null
            }
        }();
        t.FileUploadResult = o
    }])
  });