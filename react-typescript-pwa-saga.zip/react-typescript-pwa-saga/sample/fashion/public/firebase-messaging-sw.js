const extractPayload = event => {
  let payload = {};
  if (event && event.data && event.data.text) {
    try {
      let eventData = JSON.parse(event.data.text());
      if (typeof eventData === 'object') {
        payload = eventData.data;
      }
    } catch (e) {
      console.log(e);
    }
  }
  return payload;
};
self.addEventListener('push', function (event) {
  let payload = extractPayload(event);
  const options = {
    body: payload.body,
    icon: payload.icon,
    badge: payload.icon,
    data: payload
  };
  event.waitUntil(self.registration.showNotification(payload.title, options));
});
/**
 * Handle onlick notification
 */
self.addEventListener('notificationclick', function (event) {
  event.notification.close();

  if (typeof event !== 'undefined' && event.notification && event.notification.data) {
    const data = event.notification.data;
    /**
     * Check if link is applican link
     */
    if (data.link.includes('url=local')) {
      data.link = './open-link-notification.html?redirect-link=' + data.link;
    }
    event.waitUntil(clients.openWindow(data.link));
  }
});
