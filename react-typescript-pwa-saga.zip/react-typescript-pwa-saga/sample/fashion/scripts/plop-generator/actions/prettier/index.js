const { exec } = require('child_process');

const sh = (cmd, successMsg) =>
  new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) {
        reject(`sh ${cmd} error: ${err.message}`);
      } else {
        resolve(successMsg);
      }
    });
  });

exports.prettier = (SRC_PATH, filePath, message) => {
  return sh(`npm run fix:prettier "${filePath.replace(SRC_PATH, './src/')}"`, message);
};
