const { modifyAction } = require('../../helpers');

exports.addRoute = (answers, config, plop) => {
  modifyAction(
    answers,
    {
      path: `${config.SRC_PATH}features/apps/Routes.tsx`,
      pattern: new RegExp(`(\\/\\* GEN: ${answers.url_route_type.toUpperCase()} ROUTE \\*\\/)`, 'g'),
      templateFile: `generators/feature/templates/apps/Routes.{{properCase url_route_type}}.hbs`
    },
    plop
  );
  return config.prettier(
    config.SRC_PATH,
    `${config.SRC_PATH}features/apps/Routes.tsx`,
    `Add route '${answers.url_route_path}' to 'src/features/apps/Routes'`
  );
};
