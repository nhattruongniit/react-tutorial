const { addRoute } = require('./actions');

exports.getGenerator = (plop, config) => {
  plop.setActionType('add-route', addRoute);
  return {
    name: 'Feature:',
    generator: {
      description: 'A basic feature! Wiki[Creating-page-Hello-World]',
      prompts: [
        {
          type: 'input',
          name: 'feature_name',
          message: "Feature's name?"
        },
        {
          type: 'input',
          name: 'default_page_name',
          message: "Default page's name?",
          default: answers => plop.getHelper('properCase')(answers.feature_name)
        },
        {
          type: 'input',
          name: 'url_route_path',
          message: 'Route PATH default page?',
          default: answers => `/${plop.getHelper('kebabCase')(answers.feature_name)}`
        },
        {
          type: 'list',
          name: 'url_route_type',
          message: 'Route type?',
          choices: ['Public', 'Private'],
          default: 'Private'
        }
      ],
      actions: [
        {
          type: 'add',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/index.ts`,
          templateFile: 'generators/feature/templates/new-feature/index.hbs'
        },
        {
          type: 'prettier',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/index.ts`
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/pages/index.ts`,
          templateFile: 'generators/feature/templates/new-feature/pages/index.hbs'
        },
        {
          type: 'prettier',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/pages/index.ts`
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/pages/{{properCase default_page_name}}.tsx`,
          templateFile: 'generators/feature/templates/new-feature/pages/container.hbs'
        },
        {
          type: 'prettier',
          path: `${config.SRC_PATH}features/{{kebabCase feature_name}}/pages/{{properCase default_page_name}}.tsx`
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}features/apps/Routes.tsx`,
          pattern: /(\/\* GEN: IMPORT ROUTE \*\/)/g,
          templateFile: 'generators/feature/templates/apps/Routes.import.hbs'
        },
        {
          type: 'add-route',
          ...config
        },
        {
          type: 'message',
          message: `Done! Let's open "http://localhost:3000{{url_route_path}}".`
        }
      ]
    }
  };
};
