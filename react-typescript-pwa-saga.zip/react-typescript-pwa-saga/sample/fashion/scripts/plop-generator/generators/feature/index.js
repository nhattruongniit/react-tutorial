module.exports = { ...require('./generator'), ...require('./actions') };
