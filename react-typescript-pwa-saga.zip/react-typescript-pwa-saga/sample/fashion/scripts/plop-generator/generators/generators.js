const importedGenerators = [require('./feature'), require('./redux'), require('./saga')];

const featureFromPath = path => {
  const dirs = path.split('\\');
  let allFeaturesIndex = 0;
  for (let i = 0; i < dirs.length; i++) {
    if (dirs[i] === 'features') {
      allFeaturesIndex = i;
      break;
    }
  }
  return dirs[allFeaturesIndex + 1];
};
exports.getGenerators = (plop, config) => {
  plop.setWelcomeMessage(
    '******************\nThis automation process base on Rex Wiki: Mochi core some theories and practices adding saga\n******************\nChoose a generator:\n'
  );
  plop.setPrompt('fuzzypath', require('inquirer-fuzzy-path'));
  plop.setHelper('featureName', path => plop.getHelper('camelCase')(featureFromPath(path)));
  plop.setHelper('feature-name', path => featureFromPath(path));
  plop.setHelper('FeatureName', path => plop.getHelper('properCase')(featureFromPath(path)));
  plop.setHelper('FEATURE_NAME', path => plop.getHelper('constantCase')(featureFromPath(path)));
  const generators = [];
  importedGenerators.forEach(g => generators.push(g.getGenerator(plop, config)));
  return generators;
};
