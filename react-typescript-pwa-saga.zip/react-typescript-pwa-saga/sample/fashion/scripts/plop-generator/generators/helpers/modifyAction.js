const replace = require('replace-in-file');
const fs = require('fs');

exports.modifyAction = (answers, config, plop) => {
  process.chdir(plop.getPlopfilePath());
  const templateFile = plop.renderString(config.templateFile, answers);
  const template = fs.readFileSync(templateFile).toString();
  const modifyContent = plop.renderString(template, answers);
  const path = plop.renderString(config.path, answers);

  replace.sync({
    files: [path],
    from: config.pattern,
    to: match => `   ${modifyContent}\r\n${match}`
  });

  return `Modified ${path}`;
};
