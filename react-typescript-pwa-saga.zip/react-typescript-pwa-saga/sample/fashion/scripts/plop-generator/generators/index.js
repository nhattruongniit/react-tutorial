module.exports = { ...require('./feature'), ...require('./redux'), ...require('./generators') };
