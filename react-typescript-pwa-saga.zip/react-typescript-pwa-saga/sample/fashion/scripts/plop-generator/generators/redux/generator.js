const { isDir } = require('../helpers');

exports.getGenerator = (plop, config) => {
  return {
    name: 'Redux:',
    generator: {
      description: 'A basic Redux!',
      prompts: [
        {
          type: 'fuzzypath',
          name: 'feature_page',
          itemType: 'file',
          excludePath: path => {
            if (isDir(path)) {
              return false;
            }

            return path.indexOf('\\pages\\') < 0;
          },
          suggestOnly: false,
          rootPath: 'src/features',
          message: 'Page:',
          depthLimit: 2
        }
      ],
      actions: [
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_page}}/../../redux/reducer.ts`,
          templateFile: 'generators/redux/templates/new-feature/redux/reducer.hbs'
        },
        {
          type: 'prettier',
          path: `${config.SRC_PATH}../{{feature_page}}/../../redux/reducer.ts`
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_page}}/../../redux/index.ts`,
          templateFile: 'generators/redux/templates/new-feature/redux/index.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../index.ts`,
          pattern: /(\/\* GEN: MORE EXPORTS \*\/)/g,
          templateFile: 'generators/redux/templates/new-feature/index.exports.redux.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../../reducers.ts`,
          pattern: /(\/\* GEN: MORE IMPORT \*\/)/g,
          templateFile: 'generators/redux/templates/features/reducers.import.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../../reducers.ts`,
          pattern: /(\/\* GEN: REDUCER DECLARATION \*\/)/g,
          templateFile: 'generators/redux/templates/features/reducers.declare.hbs'
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_page}}/../../models/index.ts`,
          templateFile: 'generators/redux/templates/models/new.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../index.ts`,
          pattern: /(\/\* GEN: MORE EXPORTS \*\/)/g,
          templateFile: 'generators/redux/templates/models/index.export.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../../../models/IState.ts`,
          pattern: /(\/\* GEN: MORE IMPORT \*\/)/g,
          templateFile: 'generators/redux/templates/models/IState.import.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}/../../../../models/IState.ts`,
          pattern: /(\/\* GEN: MODEL DECLARATION \*\/)/g,
          templateFile: 'generators/redux/templates/models/IState.declare.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}`,
          pattern: /(\/\* GEN: MORE IMPORT \*\/)/g,
          templateFile: 'generators/redux/templates/new-feature/pages/page.import.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_page}}`,
          pattern: /(\/\* GEN: REDUCER USING COMMENT \*\/)/g,
          templateFile: 'generators/redux/templates/new-feature/pages/page.use.reducer.comment.hbs'
        }
      ]
    }
  };
};
