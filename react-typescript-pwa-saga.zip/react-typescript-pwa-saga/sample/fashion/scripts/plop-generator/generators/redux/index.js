module.exports = require('./generator');
