const { modifyAction } = require('../../helpers');

exports.modifyReducer = (answers, config, plop) => {
  if (answers.is_need_update_reducer === 'yes') {
    return `${modifyAction(
      answers,
      {
        type: 'modify',
        path: `${config.SRC_PATH}../{{feature_path}}/redux/reducer.ts`,
        pattern: /(\/\* GEN: MORE IMPORT \*\/)/g,
        templateFile: 'generators/saga/templates/new-feature/redux/reducer.import.hbs'
      },
      plop
    )}
    ${modifyAction(
      answers,
      {
        type: 'modify',
        path: `${config.SRC_PATH}../{{feature_path}}/redux/reducer.ts`,
        pattern: /(\/\* GEN: USING REDUCER \*\/)/g,
        templateFile: 'generators/saga/templates/new-feature/redux/reducer.using.hbs'
      },
      plop
    )}`;
  }

  return 'Skip update reducer';
};
