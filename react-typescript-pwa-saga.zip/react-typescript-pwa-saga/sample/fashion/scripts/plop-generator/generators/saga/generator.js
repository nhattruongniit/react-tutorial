const { modifyReducer } = require('./actions');

exports.getGenerator = (plop, config) => {
  plop.setActionType('modify-reducer', modifyReducer);
  return {
    name: 'Saga:',
    generator: {
      description: 'A basic Saga!',
      prompts: [
        {
          type: 'input',
          name: 'rest_api_url',
          message: 'Mock Rest API Path:'
        },
        {
          type: 'fuzzypath',
          name: 'feature_path',
          itemType: 'directory',
          suggestOnly: false,
          rootPath: 'src/features',
          message: 'Feature:',
          depthLimit: 0
        },
        {
          type: 'list',
          name: 'is_need_update_reducer',
          message: 'Need update sample reducer?',
          choices: ['yes', 'no'],
          default: 'yes'
        }
      ],
      actions: [
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_path}}/redux/constants.ts`,
          templateFile: 'generators/saga/templates/new-feature/redux/constants.hbs'
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_path}}/redux/actions.ts`,
          templateFile: 'generators/saga/templates/new-feature/redux/actions.hbs'
        },
        {
          type: 'add',
          path: `${config.SRC_PATH}../{{feature_path}}/redux/saga.ts`,
          templateFile: 'generators/saga/templates/new-feature/redux/saga.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_path}}/redux/index.ts`,
          pattern: /(\/\* GEN: MORE EXPORTS \*\/)/g,
          templateFile: 'generators/saga/templates/new-feature/redux/index.export.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_path}}/../sagas.ts`,
          pattern: /(\/\* GEN: MORE IMPORT \*\/)/g,
          templateFile: 'generators/saga/templates/features/sagas.import.hbs'
        },
        {
          type: 'modify',
          path: `${config.SRC_PATH}../{{feature_path}}/../sagas.ts`,
          pattern: /(\/\* GEN: SAGA DECLARATION \*\/)/g,
          templateFile: 'generators/saga/templates/features/sagas.declare.hbs'
        },
        {
          type: 'modify-reducer',
          SRC_PATH: config.SRC_PATH
        },
        {
          type: 'prettier',
          path: `${config.SRC_PATH}../{{feature_path}}/**/*.{ts,tsx}`
        },
        {
          type: 'message',
          message: `Done! Let's dispatch(action) 
Refer: http://18.182.78.70/ppt/ppt-rex/wikis/Mochi-Core-Some-theories-and-practices-Adding-saga
& Enjoy result!`
        }
      ]
    }
  };
};
