const { prettier } = require('./actions');
const { getGenerators } = require('./generators');
const SRC_PATH = '../../src/';
module.exports = plop => {
  plop.setActionType('prettier', (answers, config, plop) => {
    const path = plop.renderString(config.path, answers);
    return prettier(SRC_PATH, path, ` ${path}`);
  });

  plop.setActionType('message', (answers, config, plop) => plop.renderString(config.message, answers));

  const generators = getGenerators(plop, { SRC_PATH, prettier });
  generators.forEach(gen => plop.setGenerator(gen.name, gen.generator));
};
