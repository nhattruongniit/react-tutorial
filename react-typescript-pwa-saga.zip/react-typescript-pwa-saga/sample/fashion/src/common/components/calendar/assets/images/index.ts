export const image = {
  iconCircle: require('./picture_01.png'),
  iconTriangle: require('./picture_02.png')
};
