import * as React from 'react';
import { Component } from 'react';
import BigCalendar from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import './calendar.css';
import 'globalize/lib/cultures/globalize.culture.en-GB';
import localizer from 'react-big-calendar/lib/localizers/globalize';
import globalize from 'globalize';
import moment from 'moment';
import { image } from './assets/images';

const globalizeLocalizer = localizer(globalize);
const formats = {
  timeGutterFormat: 'HH:mm',
  dayFormat: 'dd ddd',
  dayHeaderFormat: 'YY'
};

/**
 * Calendar event data.
 */
export interface ICalendarEvent {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Start */
  start: Date;
  /** End */
  end: Date;
  /** Enabled = false => Gray */
  enabled: boolean;
}
/**
 * Timeline Calendar properties.
 */
export interface ITimelineCalendarProps {
  /** Rendering events */
  events?: ICalendarEvent[];
  /** Event select handle */
  onSelectEvent?: (event: ICalendarEvent) => void;
}

/**
 * Timeline Calendar properties.
 */
export interface ITimelineCalendarState {
  /** Filtered rendered events */
  events?: ICalendarEvent[];
  /** UI Viewing month */
  month: any;
  /** UI Viewing year */
  year: any;
}

/**
 * Calendar
 */
export default class TimelineCalendar extends Component<ITimelineCalendarProps, ITimelineCalendarState> {
  currentDate: Date = new Date();
  currentMonth: any;
  currentYear: any;

  constructor(props: ITimelineCalendarProps) {
    super(props);
    this.currentMonth = this.currentDate.getMonth();
    this.currentYear = this.currentDate.getFullYear();

    this.state = {
      month: this.currentMonth,
      year: this.currentYear,
      events: props.events
    };
  }

  customSlotPropGetter = (date: Date) => {
    const todayTime = new Date();
    const slotTime = date;

    const styleTime = {
      background: '#D8D8D8',
      zIndex: '10',
      position: 'absolute',
      top: '0',
      left: '0',
      width: '46.5px',
      height: '103%',
      border: '1px solid #D8D8D8',
      borderLeft: 0,
      borderRight: 0
    };

    const styleHours = date.getHours() === 12 ? styleTime : '';

    return {
      className: slotTime < todayTime ? 'slotTimeDisplayNone special-hours' : 'special-hours',
      style: { styleHours }
    };
  };

  helper = (param1: number, param2: number) => (param1 === param2 ? true : false);
  helperGetDay = (day: number) => (day !== 0 && day !== 6 ? true : false);

  customDayPropGetter = (date: Date) => {
    const todayTime = new Date();
    const currentTime = this.helper(date.getDay(), todayTime.getDay());
    const notDay = this.helperGetDay(todayTime.getDay());
    const isSun = date.getDay() === 6 ? true : false;
    const isSat = date.getDay() === 0 ? true : false;

    if (currentTime && notDay) {
      return { className: 'todayCustomDay' };
    }
    if (isSun) {
      return { style: { background: '#0099D5', color: 'white' } };
    }
    if (isSat) {
      return { style: { background: '#D0021B', color: 'white' } };
    }

    return { style: { background: '#DB8590', color: 'white' } };
  };

  eventPropGetter = (event: any, start: any, end: any, isSelected: any) => {
    const todayTime = new Date();
    const slotTime = start;
    let bGround = '#D8D8D8';
    if (todayTime <= slotTime) {
      bGround = event.enabled
        ? `#fff url(${image.iconCircle}) 50% 50% no-repeat`
        : `#fff url(${image.iconTriangle}) 50% 50% no-repeat`;
    }

    return {
      className: 'event-time',
      style: {
        background: bGround,
        borderRadius: '0px',
        color: 'black',
        padding: '0',
        display: 'flex',
        alignContent: 'center',
        justifyContent: 'center',
        textIndent: '-1000px',
        border: '0',
        borderTop: '1px solid #f7f7f7',
        borderBottom: '1px solid #979797'
      }
    };
  };

  setStateDate = (date: any, toolbar: any) => {
    this.setState({
      month: date.format('MM'),
      year: toolbar.date.getFullYear()
    });
  };

  CustomToolbar = (toolbar: any) => {
    const date = moment(toolbar.date);

    const goToBack = () => {
      toolbar.onNavigate('PREV');
      this.setStateDate(date, toolbar);
    };
    const goToNext = () => {
      toolbar.onNavigate('NEXT');
      this.setStateDate(date, toolbar);
    };
    const label = () => (
      <span>
        <b>{date.format('MMM YYYY')}</b>
      </span>
    );

    const todayTime = new Date();
    const showButtonPrevious = () => {
      const buttonPrevious =
        todayTime < toolbar.date ? (
          <button onClick={goToBack}>
            <span className="icon">&#8249;</span> <span> Previous</span>
          </button>
        ) : (
            ''
          );
      return buttonPrevious;
    };

    const justify = todayTime < toolbar.date ? 'space-between' : 'flex-end';

    return (
      <div className="toolbarCustom">
        <label className="toolbarLabel">{label()}</label>
        <div className="toolbarButton" style={{ justifyContent: justify }}>
          {showButtonPrevious()}
          <button onClick={goToNext}>
            <span> Next</span> <span className="icon">&#8250;</span>
          </button>
        </div>
      </div>
    );
  };

  objEvent = (
    year: number,
    month: number,
    day: number,
    starHours: number,
    endHours: number,
    startMinute: number,
    endMinute: number
  ) => {
    return {
      start: new Date(year, month, day, starHours, startMinute, 0),
      end: new Date(year, month, day, endHours, endMinute, 0),
      enabled: true
    };
  };

  loopDate = (month: number, minHours: number, maxHours: number, minute: number) => {
    const timeSlots: any = [];
    const { year } = this.state;
    let obj = {};
    let obj2 = {};
    const noColumn = 6;
    for (let days = 0; days <= 31 + noColumn; days++) {
      for (let hours = minHours; hours <= maxHours; hours++) {
        if (hours !== 12 && new Date() <= new Date(year, month, days, hours, 0, 0)) {
          if (hours === 23) {
            obj = this.objEvent(year, month, days, hours, hours, 0, 30);
            obj2 = this.objEvent(year, month, days, hours, hours, 30, 59);
          } else if (hours % 2 === 0) {
            obj = this.objEvent(year, month, days, hours, hours, 0, minute);
            obj2 = this.objEvent(year, month, days, hours, hours + 1, 30, 0);
          } else {
            obj = this.objEvent(year, month, days, hours, hours, 0, 30);
            obj2 = this.objEvent(year, month, days, hours, hours + 1, 30, 0);
          }
          timeSlots.push(obj, obj2);
        }
      }
    }
    return timeSlots;
  };

  eventsWeeks = () => {
    const timeSlots = this.loopDate(this.state.month - 1, 8, 23, 30).concat(
      this.loopDate(this.state.month, 8, 23, 30),
      this.loopDate(this.state.month - 2, 8, 23, 30),
      this.state.events
    );
    return timeSlots;
  };

  render() {
    const minTime = new Date();
    minTime.setHours(8, 0, 0);
    const maxTime = new Date();
    maxTime.setHours(23, 59, 0);
    const eventsWeek = this.eventsWeeks();

    return (
      <BigCalendar
        formats={formats}
        localizer={globalizeLocalizer}
        events={eventsWeek}
        defaultDate={new Date()}
        showMultiDayTimes={true}
        defaultView="week"
        toolbar={true}
        timeslots={1}
        slotPropGetter={this.customSlotPropGetter}
        dayPropGetter={this.customDayPropGetter}
        eventPropGetter={this.eventPropGetter}
        culture="en"
        min={minTime}
        max={maxTime}
        components={{
          timeGutterHeader: () => <p>Time</p>,
          toolbar: this.CustomToolbar
        }}
        selectable={true}
        onSelectEvent={this.props.onSelectEvent}
        drilldownView={null}
      />
    );
  }
}
