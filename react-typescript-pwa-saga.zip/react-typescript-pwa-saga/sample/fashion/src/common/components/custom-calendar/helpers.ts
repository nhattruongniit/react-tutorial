import moment from 'moment';
import 'moment/locale/ja';
import _ from 'lodash';
moment.locale('ja');

/* return background color for days 
  sa: 6 ===> '#ef9a9a'
  su: 0 ===> '#e3f2fd'
  other: ===> '#8d8d8d'
*/
export const bgDateTime = day => {
  const bg = day === 0 ? '#e3f2fd' : day === 6 ? '#ef9a9a' : '#8d8d8d';
  return bg;
};

/* return background color for slot time when user omnClick */
export const bgSlotTime = (key, selectedKey, selected) => {
  const bg = key === selectedKey && selected === 0 ? '#1976d2' : key === selectedKey && selected === 1 ? '#1976d2' : '';
  return bg;
};

/* return text  '午後' or '午前' when use onClick*/
export const renderText = (key, selectedKey, selected) => {
  const text = key === selectedKey && selected === 1 ? '午後' : key === selectedKey && selected === 0 ? '午前' : '';
  return text;
}

/* return all days */
export const daysInMonth = (endDate, disableSlotTimes) => {
  const currentDate = moment();
  const weekStart = currentDate.clone().startOf('week');
  const ymdSunCurrentWeek = moment(weekStart)
    .add(0, 'days')
    .format('L');

  const formatStarMonth = moment(ymdSunCurrentWeek);
  const formatEndMonth = moment(endDate);
  const numberDays = formatEndMonth.diff(formatStarMonth, 'days');

  const days: any = [];
  for (let i = 0; i < numberDays + 1; i++) {
    const date = moment(weekStart)
      .add(i, 'days')
      .format('YYYY-MM-DD');
    const obj = {
      date,
      select: 0,
      status: true
    };
    days.push(obj);
  }
  disableSlotTimes.map(val => {
    const index = _.findIndex(days, { date: val.date });
    days.splice(index, 1, val);
  });

  return days;
};
