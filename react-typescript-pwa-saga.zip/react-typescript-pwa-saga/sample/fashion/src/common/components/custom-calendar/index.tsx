import * as React from 'react';
import { bgDateTime, bgSlotTime, renderText, daysInMonth } from './helpers';
import moment from 'moment';
import 'moment/locale/ja';
moment.locale('ja');

interface IProps {
  endDate: string;
  disableSlotTimes: any[];
}

const Calendar: React.FC<IProps> = ({ endDate, disableSlotTimes }) => {
  const ref: any = React.createRef();
  const [year, setYear] = React.useState(moment().year());
  const [selectedKey, setSelectedKey] = React.useState('');
  const [selected, setSelected] = React.useState();
  const [days]: any = React.useState(daysInMonth(endDate, disableSlotTimes));

  const handleSelected = val => {
    setSelectedKey(val.key);
    setSelected(val.select);
    console.log(val);
  };

  const handleScroll = e => {
    const element = e.target;
    element.scrollTop >= ref.current.offsetTop ? setYear(moment().year() + 1) : setYear(moment().year());
  };

  const HeaderTable = () => {
    const stylesHeader: any = {
      tableHeader: {
        width: '100%',
        textAlign: 'center',
        borderCollapse: 'collapse',
        border: '1px solid black',
        margin: '0 auto',
        position: 'fixed',
        backgroundColor: ' #fff',
        opacity: 1,
        height: 30
      },
      slot: {
        width: 100,
        padding: '5px 10px',
        color: '#1a1a1a'
      }
    };
    return (
      <table style={stylesHeader.tableHeader}>
        <thead>
          <tr>
            <th style={stylesHeader.slot}>{year} </th>
            <th style={stylesHeader.slot}>午前</th>
            <th style={stylesHeader.slot}>午後</th>
          </tr>
        </thead>
      </table>
    );
  };

  const DateTime = ({ date, bgColor }) => {
    const styles: any = {
      date: {
        padding: '5px 10px',
        border: '1px solid black',
        background: `${bgColor}`,
        width: 100
      }
    };
    return <td style={styles.date}>{moment(date).format('MM/DD(dd)')}</td>;
  };

  const SlotTime = ({ bgColor, showText, data, index }) => {
    const styles: any = {
      slotEvent: {
        width: 100,
        padding: '5px 10px',
        border: '1px solid black',
        cursor: 'pointer',
        color: '#fff',
        backgroundColor: selected === 0 ? bgColor : ''
      },
      slot: {
        backgroundColor: selected === 1 ? bgColor : '',
        width: 100,
        padding: '5px 10px',
        border: '1px solid black',
        cursor: 'pointer',
        color: '#fff'
      }
    };
    return (
      <>
        <td
          style={styles.slotEvent}
          onClick={() =>
            (data.status === false && data.select === 0) || data.select === 2
              ? null
              : handleSelected({ key: index, select: 0, date: data.date })
          }
        >
          {selectedKey === index && selected === 0 && showText}
          {data.status === false && data.select === 0 && <p style={{ color: 'red', margin: 0 }}>xxx</p>}
          {data.status === false && data.select === 2 && <p style={{ color: 'red', margin: 0 }}>xxx</p>}
        </td>
        <td
          style={styles.slot}
          onClick={() =>
            (data.status === false && data.select === 1) || data.select === 2
              ? null
              : handleSelected({ key: index, select: 1, date: data.date })
          }
        >
          {selectedKey === index && selected === 1 && showText}
          {data.status === false && data.select === 1 && <p style={{ color: 'red', margin: 0 }}>xxx</p>}
          {data.status === false && data.select === 2 && <p style={{ color: 'red', margin: 0 }}>xxx</p>}
        </td>
      </>
    );
  };

  const BodyTable = () => {
    const renderDays = days.map((val, key) => {
      const currentYear = moment(val.date).format('YYYY-MM-DD');
      const nextYears = (moment().year() + 1).toString();

      return (
        <tr key={key} ref={currentYear === `${nextYears}-01-01` ? ref : null}>
          <DateTime date={val.date} bgColor={bgDateTime(new Date(val.date).getDay())} />
          <SlotTime
            index={key}
            bgColor={bgSlotTime(key, selectedKey, selected)}
            showText={renderText(key, selectedKey, selected)}
            data={val}
          />
        </tr>
      );
    });

    return renderDays;
  };

  const styles: any = {
    warper: {
      height: 500,
      overflow: 'auto',
      marginTop: 10,
      borderBottom: '1px solid #1a1a1a'
    },
    tables: {
      width: '100%',
      textAlign: 'center',
      borderCollapse: 'collapse',
      border: '1px solid black',
      margin: '29px auto 0'
    }
  };

  return (
    <div style={styles.warper} onScroll={e => handleScroll(e)}>
      <HeaderTable />
      <table style={styles.tables}>
        <tbody>
          <BodyTable />
        </tbody>
      </table>
    </div>
  );
};

export default Calendar;
