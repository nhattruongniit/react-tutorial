import React, { FC, useEffect } from 'react';
import { withRouter, RouteComponentProps } from 'react-router';
import { connect } from 'react-redux';

// state
import { IFashionState } from '../../../models';
import { showSidebarRequest } from '../sidebar/redux/actions';

// material ui
import {
  Grid,
  BottomNavigation,
  BottomNavigationAction,
  WithStyles,
  withStyles,
  createStyles
} from '@material-ui/core';
import Home from '@material-ui/icons/Home';
import ShoppingCart from '@material-ui/icons/ShoppingCart';
import Menu from '@material-ui/icons/Menu';
import ArrowUpward from '@material-ui/icons/ArrowUpward';

const styles = createStyles({
  shopping: {
    position: 'relative',
    flex: 1
  },
  badge: {
    position: 'absolute',
    top: 2,
    left: 54,
    backgroundColor: '#fff',
    color: '#f00',
    fontWeight: 'bold',
    borderRadius: 20,
    fontSize: 12,
    padding: '0 4px',
    height: 25,
    minWidth: 28,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  text: {
    position: 'absolute',
    left: -3,
    bottom: 4,
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    color: '#fff'
  },
  button: {
    paddingTop: '7px !important'
  },
  navigator: {
    zIndex: 1300
  }
});

const routesWithoutFooter = [
  { pathname: '/' },
  { pathname: '/home' },
  { pathname: '/login' },
  { pathname: '/contact' }
];

interface IProps extends WithStyles<typeof styles>, RouteComponentProps {
  showSidebarRequest: () => void;
}

const Footer: FC<IProps> = ({ location, showSidebarRequest: actionShowSideBar, history, classes }) => {
  const [showFooter, setShowFooter] = React.useState(false);

  useEffect(() => {
    const result = routesWithoutFooter.some(route => route.pathname === location.pathname);
    setShowFooter(result);
  }, [location.pathname]);

  function handleGoToTop() {
    window.scrollTo(0, 0);
  }

  function handleSidebar() {
    actionShowSideBar();
  }

  function handleGoToHome() {
    history.push('/');
  }

  if (showFooter) {
    return <></>;
  }

  return (
    <Grid container={true} style={{ height: 56 }}>
      <BottomNavigation showLabels={true} className={classes.navigator}>
        <BottomNavigationAction label="Home" icon={<Home />} onClick={handleGoToHome} />
        <BottomNavigationAction label="Menu" icon={<Menu />} onClick={handleSidebar} />
        <BottomNavigationAction label="Cart" icon={<ShoppingCart />} className={classes.button} />
        {/* <div className={classes.shopping}>
          <BottomNavigationAction label="Cart" icon={<ShoppingCart />} className={classes.button} />
          <span className={classes.text}>Cart</span>
          <span className={classes.badge}>99+</span>
        </div> */}
        <BottomNavigationAction label="Go Top" icon={<ArrowUpward />} onClick={handleGoToTop} />
      </BottomNavigation>
    </Grid>
  );
};

const mapStateToProps = (state: IFashionState) => {
  const {
    sidebar: { show }
  } = state;
  return {
    show
  };
};

const mapDispatchToProps = {
  showSidebarRequest
};

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(withStyles(styles)(Footer))
);
