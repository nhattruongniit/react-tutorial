import React, { FC } from 'react';
import { Grid } from '@material-ui/core';

interface IListOfDataItem {
  key: any;
  data: any;
  wrap?: string;
  xs?: number;
  direction: string;
}

interface IProps {
  direction: 'row' | 'column';
  listData?: [];
  render: (props: IListOfDataItem) => JSX.Element;
  wrap?: 'wrap' | 'nowrap';
  xs?: number;
}

const GridView: FC<IProps> = ({ listData, direction, render, xs }) => {
  const displayParams = { wrap: 'nowrap', xs: 12 };
  if (direction === 'column') {
    displayParams.wrap = 'wrap';
    displayParams.xs = xs ? xs : 4;
  }

  return (
    <Grid container={true} xs={12} item={true} justify="space-between">
      {listData &&
        listData.map((value: any, key: any) => {
          return render({
            key,
            data: value,
            wrap: displayParams.wrap,
            xs: displayParams.xs,
            direction
          });
        })}
    </Grid>
  );
};

export default GridView;
