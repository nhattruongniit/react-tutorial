import React, { FC, useEffect, Fragment } from 'react';
import { connect } from 'react-redux';
import { withRouter, RouteComponentProps } from 'react-router';
import { Link } from 'react-router-dom';

import { AppBar, Grid, Button, Typography, IconButton } from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu';
import ArrowBack from '@material-ui/icons/ArrowBack';

import Contact from '../responsive-header/img/ChatBot';
import { showSidebarRequest } from '../sidebar/redux/actions';

interface IProps extends RouteComponentProps {
  showSidebarRequest: () => void;
}

const routesWithHamburgerMenu = [{ pathname: '/' }, { pathname: '/home' }, { pathname: '/contact' }];

const Header: FC<IProps> = ({ history, location, showSidebarRequest: actionShowSidebar }) => {
  const { pathname } = location;
  const [hideHamburgerIcon, setHideHamburgerIcon] = React.useState(true);

  useEffect(() => {
    const result = routesWithHamburgerMenu.some(route => route.pathname === pathname);
    setHideHamburgerIcon(result);
  }, [pathname]);

  if (pathname === '/login' || pathname === '/contact') {
    return <></>;
  }

  return (
    <Fragment>
      <Grid container={true} style={{ height: 61 }}>
        <AppBar position="fixed" style={{ padding: '10px 0' }}>
          <Grid container={true} justify="space-between" alignItems="center">
            {!hideHamburgerIcon ? (
              <IconButton
                color="secondary"
                aria-label="Menu"
                style={{ padding: '6px 20px' }}
                onClick={() => history.go(-1)}
              >
                <ArrowBack />
              </IconButton>
            ) : (
              <Button style={{ color: '#850F3B' }} onClick={actionShowSidebar}>
                <MenuIcon />
              </Button>
            )}

            <Typography variant="h1" color="primary">
              Fashion
            </Typography>
            <Button color="inherit">
              <Link to="/contact">
                <Contact style={{ height: 28 }} />
              </Link>
            </Button>
          </Grid>
        </AppBar>
      </Grid>
    </Fragment>
  );
};

const mapDispatchToProp = {
  showSidebarRequest
};

export default connect(
  null,
  mapDispatchToProp
)(withRouter(Header));
