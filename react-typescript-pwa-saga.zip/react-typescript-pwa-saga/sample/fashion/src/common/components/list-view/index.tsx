import React, { Component } from 'react'; // !Important. Help display props & methods to docs.
import { Grid } from '@material-ui/core';

/**
 * List Data Item properties.
 */
export interface IListOfDataItem {
  /** Key of item. */
  key: any;
  /** Forward from list. */
  data: any;
  /** Forward from list. */
  wrap?: string;
  /** Forward from list. */
  xs?: number;
  /** Forward from list. */
  direction: string;
}

/**
 * List Of Data View properties.
 */
export interface IListOfDataViewProps {
  /** Data display direction. */
  direction: 'row' | 'column';
  /** Displayed data. */
  listData?: [];
  /** Item component render. */
  render: (props: IListOfDataItem) => JSX.Element;
  /** HTML flex display props. */
  wrap?: 'wrap' | 'nowrap';
  /** Number of columns. Default 12(direction='row'), 4(direction='column'). */
  xs?: number;
}

/**
 * Render list of data by grid(direction='column') or list(direction='row')
 */
export class ListOfDataView extends Component<IListOfDataViewProps, any> {
  // !Important. Help display props & methods to docs.

  render() {
    const { listData, render } = this.props;
    let direction = 'row';
    if (this.props.direction) {
      direction = this.props.direction;
    }
    const displayParams = { wrap: 'nowrap', xs: 12 };
    if (direction === 'column') {
      displayParams.wrap = 'wrap';
      displayParams.xs = this.props.xs ? this.props.xs : 4;
    }

    return (
      <Grid container={true} xs={12} item={true} justify="space-between">
        {listData &&
          listData.map((value: any, key: any) => {
            return render({
              key,
              data: value,
              wrap: displayParams.wrap,
              xs: displayParams.xs,
              direction
            });
          })}
      </Grid>
    );
  }
}

export default ListOfDataView;
