import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

const RawNavigationLink = ({ classes, name, imageSrc, href }) => {
  return (
    <Button size="small" className={classes.button}>
      <RouterLink to={href} style={{ display: 'flex', alignItems: 'center', textDecoration: 'none', color: '#555555' }}>
        <img src={imageSrc} alt="save point" className={classes.image} />
        {name}
      </RouterLink>
    </Button>
  );
};

const NavigationLink = withStyles(({ palette, spacing }) => ({
  button: {
    margin: '0 10px',
    '&:hover': {
      backgroundColor: 'transparent'
    },
    '&:hover span > a': {
      backgroundColor: 'transparent',
      color: '#000000 !important'
    }
  },
  image: { marginRight: '5px' }
}))(RawNavigationLink);

interface IPropsNavigation {
  classes?: any;
}

export default function Navigation({ classes }: IPropsNavigation) {
  return (
    <nav>
      <NavigationLink name="Save Point" imageSrc={require('./assets/star-2.png')} href="/membership" />
      <NavigationLink name="Reservation" imageSrc={require('./assets/reservation.png')} href="/reservation/services" />
      <NavigationLink name="Coupon" imageSrc={require('./assets/coupon.png')} href="/coupons" />
      <NavigationLink name="Search Store" imageSrc={require('./assets/store-2.png')} href="/shops" />
      <NavigationLink name="Search Shop" imageSrc={require('./assets/search.png')} href="/products" />
    </nav>
  );
}
