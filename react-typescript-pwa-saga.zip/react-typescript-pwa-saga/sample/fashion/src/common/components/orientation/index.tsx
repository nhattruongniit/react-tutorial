import styled from 'styled-components';
const { width, height } = window.screen;

const Orientation = styled.div(props => ({
	'@global': {
		'html, body': {
			width: '100%',
			height: '100%'
		},
		'@media screen and (max-device-width : 1024px) and (orientation: portrait)': {
			html: {
				transform: props.type === 'landscape' ? 'rotate(-90deg)' : 'rotate(0deg)',
				transformOrigin: 'left top',
				width: props.type === 'landscape' ? '100vh' : width,
				height: props.type === 'landscape' ? (width > height ? width : height) : '100%',
				overflowX: 'scroll',
				position: 'absolute',
				top: props.type === 'landscape' ? '100%' : 0,
				left: 0
			}
		},
	}
}));

export default Orientation;