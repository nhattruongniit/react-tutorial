import React from 'react';
import { unstable_useMediaQuery as useMediaQuery } from '@material-ui/core/useMediaQuery';
import { default as MobileHeader } from '../header';
import DesktopHeader from './desktop-header';

const ResponsiveHeader = () => {
  const matchesLargerThanOrEqualTablet = useMediaQuery('(min-width:1024px)');

  if (matchesLargerThanOrEqualTablet) {
    return <DesktopHeader />;
  } else {
    return <MobileHeader />;
  }
};

export default ResponsiveHeader;
