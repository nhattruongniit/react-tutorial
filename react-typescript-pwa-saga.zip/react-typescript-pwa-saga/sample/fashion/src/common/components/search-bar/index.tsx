import React, { FC } from 'react';

// material ui
import { createStyles, withStyles, WithStyles } from '@material-ui/core';
import * as Icons from '@material-ui/icons';

const styles = createStyles({
  form: {
    position: 'relative',
    '& button': {
      width: 40,
      height: '100%',
      position: 'absolute',
      top: 0,
      left: 0,
      opacity: 0
    }
  },
  searchBarOuter: {
    backgroundColor: '#FFFFFF',
    marginTop: 12,
    position: 'relative',
    border: '1px solid #291E2D',
    paddingLeft: 48,
    paddingRight: 10,
    borderRadius: 8
  },
  searchBarInput: {
    width: '100%',
    height: 40,
    backgroundColor: '#FFFFFF',
    color: '#4A4A4A',
    fontFamily: 'Helvetica',
    fontSize: 16,
    lineHeight: 19,
    borderRadius: 8,
    textAlign: 'justify',
    border: 0,
    outline: 0
  },
  searchBarIcon: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 10,
    left: 10,
    color: '#111111'
  }
});

interface IProps extends WithStyles<typeof styles> {
  handleSubmitSearch?: (e: { preventDefault }) => void;
  handleChangeValue?: (e: { preventDefault }) => void;
  placeholder: string;
}

const SearchBar: FC<IProps> = ({ handleSubmitSearch, classes, handleChangeValue, placeholder }) => {
  return (
    <form onSubmit={handleSubmitSearch} className={classes.form}>
      <div className={classes.searchBarOuter}>
        <input className={classes.searchBarInput} placeholder={placeholder} onChange={handleChangeValue} />
        <Icons.Search className={classes.searchBarIcon} />
        <button type="submit" />
      </div>
    </form>
  );
};

export default withStyles(styles)(SearchBar);
