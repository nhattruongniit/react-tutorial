import React, { FC } from 'react';
import { connect } from 'react-redux';
import { withRouter, NavLink } from 'react-router-dom';

// material
import {
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Typography,
  Grid,
  Drawer,
  withStyles,
  WithStyles
} from '@material-ui/core';
import Home from '@material-ui/icons/Home';
import AddAlert from '@material-ui/icons/AddAlert';
import ChromeReaderModeIcon from '@material-ui/icons/ChromeReaderMode';
import StarsIcon from '@material-ui/icons/Stars';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import ShopTwoIcon from '@material-ui/icons/ShopTwo';
import DateRangeIcon from '@material-ui/icons/DateRange';
import HelpIcon from '@material-ui/icons/Help';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import PersonIcon from '@material-ui/icons/Person';
import GestureIcon from '@material-ui/icons/Gesture';
import AspectRatioIcon from '@material-ui/icons/AspectRatio';
import FolderIcon from '@material-ui/icons/Folder';
import SDStorage from '@material-ui/icons/SdStorage';
import Chat from '@material-ui/icons/Chat';
// state
import { IFashionState } from '../../../models';
import { hideSidebarRequest } from './redux/actions';
import { selectors } from '../../../features';
import { action as userLanguageAction } from '../../../features/user/language';

const AuthButton = withRouter(({ history }) => {
  return (
    <ListItem button={true} onClick={() => history.push('/logout')}>
      <ListItemIcon>
        <ExitToAppIcon />
      </ListItemIcon>
      <ListItemText primary="Logout" />
    </ListItem>
  );
});

const QRIcon = require('@material-ui/icons/utils/createSvgIcon').default(
  React.createElement(
    React.Fragment,
    null,
    React.createElement('path', {
      fill: 'none',
      d: 'M0 0h24v24H0z'
    }),
    React.createElement('path', {
      d:
        'M4,4H10V10H4V4M20,4V10H14V4H20M14,15H16V13H14V11H16V13H18V11H20V13H18V15H20V18H18V20H16V18H13V20H11V16H14V15M16,15V18H18V15H16M4,20V14H10V20H4M6,6V8H8V6H6M16,6V8H18V6H16M6,16V18H8V16H6M4,11H6V13H4V11M9,11H13V15H11V13H9V11M11,6H13V10H11V6M2,2V6H0V2A2,2 0 0,1 2,0H6V2H2M22,0A2,2 0 0,1 24,2V6H22V2H18V0H22M2,18V22H6V24H2A2,2 0 0,1 0,22V18H2M22,22V18H24V22A2,2 0 0,1 22,24H18V22H22Z'
    })
  )
);

const sideBar = [
  {
    icon: <Home />,
    label: 'Home',
    link: '/'
  },
  {
    icon: <AddAlert />,
    label: 'Local Notification',
    link: '/local-notification'
  },
  {
    icon: <StarsIcon />,
    label: 'Membership',
    link: '/membership'
  },
  {
    icon: <ChromeReaderModeIcon />,
    label: 'Coupon',
    link: '/coupons'
  },
  {
    icon: <ShoppingCartIcon />,
    label: 'Search Shop',
    link: '/shops'
  },
  {
    icon: <ShopTwoIcon />,
    label: 'Search Product',
    link: '/products/list'
  },
  {
    icon: <GestureIcon />,
    label: 'Signature',
    link: '/signature'
  },
  {
    icon: <DateRangeIcon />,
    label: 'Reservation',
    link: '/reservation/services'
  },
  {
    icon: <HelpIcon />,
    label: 'Help',
    link: '/help'
  },
  {
    icon: <HelpIcon />,
    label: 'Capture Image',
    link: '/capture'
  },
  {
    icon: <QRIcon />,
    label: 'Scan QR Code',
    link: '/qr-scan'
  },
  {
    icon: <AspectRatioIcon />,
    label: 'Rendering Textbox',
    link: '/rendering-textbox'
  },
  {
    icon: <SDStorage />,
    label: 'SSD Images',
    link: '/ssd-images'
  },
  {
    icon: <ExitToAppIcon />,
    label: 'Logout',
    logout: 'logout',
    link: '/logout'
  },
  {
    icon: <FolderIcon />,
    label: 'Simulate Error',
    link: '/error-with-login'
  },
  {
    icon: <FolderIcon />,
    label: 'Public Products',
    link: '/public-products'
  },
  {
    icon: <FolderIcon />,
    label: 'About Us',
    link: '/public-contact'
  },
  {
    icon: <Chat />,
    label: 'Rocket Chat',
    link: '/rocket-chat'
  },
  {
    icon: <Chat />,
    label: 'Calendar',
    link: '/calendar'
  }
];

const styles = theme => ({
  userAvatar: {
    width: '40px',
    height: '40px',
    borderRadius: '20px',
    backgroundColor: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#000',
    marginRight: '12.5pt'
  },
  link: {
    display: 'flex',
    width: '100%',
    textDecoration: 'none'
  },
  paper: {
    [theme.breakpoints.up('lg')]: {
      width: '30%'
    }
  }
});

interface IProps extends WithStyles<typeof styles> {
  show: boolean;
  language: string;
  actionHideSidebar(): boolean;
  setLanguage(language: string): void;
}

const Sidebar: FC<IProps> = ({ show, actionHideSidebar, classes }) => {
  return (
    <Drawer
      open={show}
      onClick={actionHideSidebar}
      classes={{
        paper: classes.paper
      }}
    >
      <Grid tabIndex={0} role="button">
        <Grid
          container={true}
          direction="row"
          alignItems="center"
          style={{ backgroundColor: '#850F3B', height: '99px', padding: 10 }}
        >
          <div className={classes.userAvatar}>
            <PersonIcon />
          </div>
          <Typography variant="h5" component="p" color="primary" gutterBottom={true}>
            山田 太郎 様 <br />
            ID: undefined.
          </Typography>
        </Grid>

        <List>
          {sideBar.map((value, index) => {
            if (value.logout) {
              return <AuthButton key={index} />;
            }
            return (
              <ListItem button={true} key={index}>
                <NavLink to={value.link} className={classes.link}>
                  <ListItemIcon>{value.icon}</ListItemIcon>
                  <ListItemText primary={value.label} />
                </NavLink>
              </ListItem>
            );
          })}
        </List>
      </Grid>
    </Drawer>
  );
};

function mapStateToProps(state: IFashionState) {
  const {
    sidebar: { show }
  } = state;
  return {
    language: selectors.getUserLanguage(state),
    show
  };
}

function mapDispatchToProps(dispatch) {
  return {
    setLanguage: (language: string) => dispatch(userLanguageAction.setLanguage(language)),
    actionHideSidebar: () => dispatch(hideSidebarRequest())
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Sidebar));
