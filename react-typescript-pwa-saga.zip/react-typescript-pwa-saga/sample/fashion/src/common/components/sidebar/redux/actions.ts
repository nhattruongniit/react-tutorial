import { SHOW_SIDEBAR_REQUEST, SHOW_SIDEBAR_SUCCESS, HIDE_SIDEBAR_REQUEST, HIDE_SIDEBAR_SUCCESS } from './constant';

export const showSidebarRequest = () => ({ type: SHOW_SIDEBAR_REQUEST });

export const showSidebarSuccess = () => ({ type: SHOW_SIDEBAR_SUCCESS });

export const hideSidebarRequest = () => ({ type: HIDE_SIDEBAR_REQUEST });

export const hideSidebarSuccess = () => ({ type: HIDE_SIDEBAR_SUCCESS });
