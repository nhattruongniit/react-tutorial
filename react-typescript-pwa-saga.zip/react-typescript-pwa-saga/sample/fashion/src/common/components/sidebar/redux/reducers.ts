import { SHOW_SIDEBAR_SUCCESS, HIDE_SIDEBAR_SUCCESS } from './constant';

import { ISidebar, IAction } from '../../../../models/index';

const initialState: ISidebar = {
  show: false
};

export const reducers = (state: ISidebar = initialState, { type }: IAction) => {
  switch (type) {
    case SHOW_SIDEBAR_SUCCESS:
      return {
        ...state,
        show: true
      };
    case HIDE_SIDEBAR_SUCCESS:
      return {
        ...state,
        show: false
      };
    default:
      return state;
  }
};
