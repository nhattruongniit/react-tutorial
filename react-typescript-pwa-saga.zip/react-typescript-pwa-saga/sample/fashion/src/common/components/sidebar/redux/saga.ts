import { takeLatest, put } from 'redux-saga/effects';

import { SHOW_SIDEBAR_REQUEST, HIDE_SIDEBAR_REQUEST } from './constant';
import { showSidebarSuccess, hideSidebarSuccess } from './actions';

function* showSidebarSaga() {
  yield put(showSidebarSuccess());
}

function* hideSidebarSaga() {
  yield put(hideSidebarSuccess());
}

export function* sidebarSaga() {
  yield takeLatest(SHOW_SIDEBAR_REQUEST, showSidebarSaga);
  yield takeLatest(HIDE_SIDEBAR_REQUEST, hideSidebarSaga);
}
