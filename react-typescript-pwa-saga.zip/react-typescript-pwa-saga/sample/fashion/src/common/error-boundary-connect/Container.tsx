import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import ErrorBoundary from 'react-error-boundary';
import * as LoginSession from '@mochi/misc/auth/util/loginSession';
import platform from 'platform';
import { getUtcNow } from '../helpers';
import { pushLogToServer } from './redux/actions';
import { NetWorkStatus, syncLog, saveLogDataOffline } from '../../services/log';

const ErrorFallbackComponent = () => {
  return (
    <div>
      <p>
        <strong>Oops! An error occurred!</strong>
      </p>
    </div>
  );
};

const ErrorBoundaryConnect = ({ component: ComponentMayHaveError, sendLog }) => {
  useEffect(() => {
    NetWorkStatus.init();
    /**
     * Sync log when user refresh app
     */
    if (NetWorkStatus.isOnline()) {
      syncLog(sendLog);
    }
    /**
     * Sync log when network change from offline to online
     */
    NetWorkStatus.onChange(() => {
      if (NetWorkStatus.isOnline()) {
        syncLog(sendLog);
      }
    });
  });

  function myErrorHandler(error: Error, componentStack: string) {
    const userSession = LoginSession.get();
    const errorLog = {
      level: 'ERROR',
      datetime: getUtcNow('YYYYMMDDHHmmssSSS'),
      os: platform.os,
      description: platform.description,
      userId: (userSession && userSession.userId) || '',
      error: (error && error.stack) || '',
      componentStack,
      location: window.location.href,
      version: process.env.REACT_APP_VERSION
    };
    saveLogDataOffline([errorLog]);
    syncLog(sendLog);
  }
  return (
    <ErrorBoundary onError={myErrorHandler} FallbackComponent={ErrorFallbackComponent}>
      <ComponentMayHaveError />
    </ErrorBoundary>
  );
};

const mapDispatchToProps = dispatch => ({
  sendLog: (data: any) => dispatch(pushLogToServer(data))
});

export const WithReduxErrorBoundary = connect(
  null,
  mapDispatchToProps
)(ErrorBoundaryConnect);
