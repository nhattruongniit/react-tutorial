import { createAction } from 'redux-actions';
import { ERROR_LOG } from './constants';

export const pushLogToServer = createAction(ERROR_LOG.SEND);
export const pushLogToServerSuccess = createAction(ERROR_LOG.SEND_SUCCESS, (payload: any) => payload);
export const pushLogToServerFailure = createAction(ERROR_LOG.SEND_FAILURE);
