import { defineAction } from 'redux-define';

// Action Constant
export const ERROR_LOG = defineAction('ERROR_LOG', ['SEND', 'SEND_FAILURE', 'SEND_SUCCESS']);
