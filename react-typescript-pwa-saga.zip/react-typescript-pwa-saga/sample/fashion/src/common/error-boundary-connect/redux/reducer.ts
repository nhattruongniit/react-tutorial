import { handleActions } from 'redux-actions';
import { ERROR_LOG } from './constants';

// Reducer and initial state
const initialState = {
  errorsLog: []
};

export const reducer = handleActions(
  {
    [ERROR_LOG.SEND_SUCCESS]: state => ({ ...state, errorsLog: [] }),
    [ERROR_LOG.SEND_FAILURE]: (state, { error }) => state
  },
  initialState
);
