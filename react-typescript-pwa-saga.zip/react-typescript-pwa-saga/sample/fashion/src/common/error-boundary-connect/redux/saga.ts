import { takeLatest, put, call } from 'redux-saga/effects';
import { ERROR_LOG } from './constants';
import { pushLogToServerSuccess, pushLogToServerFailure } from './actions';
import { fetchNetworkApi, FETCH_API, fetchApi } from '@mochi/core';
import { makeLambdaRequest } from '@mochi/misc/fetch-api';
import { DeviceUUID } from 'device-uuid';
import { delay } from 'redux-saga';
import { NetWorkStatus, saveLogDataOffline } from '../../../services/log';

function* retry(sentRequestTimes: number, action: any) {
  const {
    REACT_APP_SEND_ERROR_RETRY_DURATION_IN_MINUTES: retryDuration,
    REACT_APP_SEND_ERROR_RETRY_TIMES: retryTimes
  } = process.env;

  if (sentRequestTimes <= parseInt(retryTimes as string, 10)) {
    const delayTime = parseInt(retryDuration as string, 10);
    yield delay(delayTime * 60 * 1000);
    yield call(sendErrorLog, { ...action, meta: sentRequestTimes + 1 });
    return yield;
  }
  const { payload: errorLog } = action;

  return yield call(saveLogDataOffline, errorLog);
}
// saga
function* sendErrorLog(action: { payload: any; meta?: number }) {
  const { payload: errorLog } = action;
  const isOnline = yield call(NetWorkStatus.isOnline);

  if (!isOnline) {
    return yield call(saveLogDataOffline, errorLog);
  }

  const sentRequestTimes = action.meta || 0;

  const request = makeLambdaRequest(
    ERROR_LOG.SEND,
    {
      mode: 'MODE_SEND_LOG',
      param: {
        tenantId: { content: '1' },
        uuid: { content: new DeviceUUID().get() },
        dataArray: { content: errorLog },
        type: {
          content: 'vn-format'
        }
      }
    },
    { noCached: true }
  );

  const { payload, type: statusType } = yield call(fetchNetworkApi, fetchApi(request));

  if (statusType === FETCH_API.SUCCESS) {
    const {
      httpResponseJson: { isSuccess }
    } = payload;
    if (isSuccess) {
      yield put(pushLogToServerSuccess());
      return yield call(saveLogDataOffline, errorLog, true);
    }

    yield put(pushLogToServerFailure());
    return yield call(retry, sentRequestTimes + 1, action);
  }

  if (statusType === FETCH_API.FAILURE) {
    yield put(pushLogToServerFailure());
    yield call(retry, sentRequestTimes + 1, action);
  }
  return yield;
}

export function* errorLogFlow() {
  yield takeLatest(ERROR_LOG.SEND, sendErrorLog);
}
