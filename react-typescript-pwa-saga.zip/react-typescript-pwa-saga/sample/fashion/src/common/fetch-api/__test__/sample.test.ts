describe('SAMPLE', () => {
  it('just a sample passed test', () => {
    const expectedAction = 'do some sample';
    expect('do some other sample').not.toEqual(expectedAction);
  });
});
