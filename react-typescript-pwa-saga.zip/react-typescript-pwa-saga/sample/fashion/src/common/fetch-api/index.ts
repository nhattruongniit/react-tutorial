import * as model from '@mochi/core';

export const makeMockJsonRequest = (
  key: string,
  database: string,
  option?: model.IRequestOption,
  api?: string
): model.IApiRequest => ({
  key,
  option,
  httpRequest: {
    fullUrl: api || `${process.env.REACT_APP_MOCK_API_URL as string}/${database}`,
    method: model.RequestMethod.Get
  }
});
