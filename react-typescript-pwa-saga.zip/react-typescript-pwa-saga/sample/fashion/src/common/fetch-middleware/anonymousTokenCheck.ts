export const anonymousTokenCheck = (url: string, options) => {
  if (options && options.body) {
    let body = { mode: '' };
    try {
      body = JSON.parse(options.body);

      if (body.mode) {
        return (
          ['MODE_REGISTER_FCM_TOKEN', 'MODE_SEND_LOG', 'MODE_CREATE_LOGIN_TOKEN_WITH_GOOGLE_OAUTH'].indexOf(
            body.mode
          ) >= 0
        );
      }
    } catch (e) {
      console.error(e, body);
    }
  }
  return false;
};
