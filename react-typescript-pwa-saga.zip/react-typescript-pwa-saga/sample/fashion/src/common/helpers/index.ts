import moment from 'moment';

export const getUtcNow = (format: string) => {
  return moment()
    .utc()
    .format(format);
};

/**
 * Converting circular structure to JSON
 * @param object
 */
export const simpleStringify = object => {
  const simpleObject = {};
  for (const prop in object) {
    if (!object.hasOwnProperty(prop)) {
      continue;
    }
    if (typeof object[prop] === 'object') {
      continue;
    }
    if (typeof object[prop] === 'function') {
      continue;
    }
    simpleObject[prop] = object[prop];
  }
  return JSON.stringify(simpleObject);
};
