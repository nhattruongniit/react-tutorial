// session of indexDB
export const TABLE_NAME_INDEXDB = 'session';

// TABLE NAME POSTGRESQL
export const TABLE_NAME_POSTGRESQL = {
  product: 'pptrex_product',
  coupon: 'pptrex_coupon'
};

export const MODE_API = {
  read: 'MODE_READ'
};
