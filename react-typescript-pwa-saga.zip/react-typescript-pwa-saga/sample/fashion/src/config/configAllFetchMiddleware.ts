import { injectAnonymousCheck, anonymousTokenConfig } from '@mochi/fetch-middleware/helpers/napa-backend';
import { anonymousToken, apply } from '@mochi/fetch-middleware';
import { anonymousTokenCheck } from '../common/fetch-middleware/anonymousTokenCheck';
import { offlineSaveConfigs, offlineSearchConfigs } from './offlineDataConfig';
import { offlineSave, offlineSearch } from '@mochi/fetch-offline-middleware';
import { IProductOfflineData } from '../models/IProductOfflineData';

export const configAllFetchMiddleware = () => {
  injectAnonymousCheck('ANONYMOUS_TOKEN_CHECK', anonymousTokenCheck);
  apply([
    anonymousToken(anonymousTokenConfig),
    offlineSave<IProductOfflineData>(offlineSaveConfigs),
    offlineSearch<IProductOfflineData>(offlineSearchConfigs)
  ]);
};
