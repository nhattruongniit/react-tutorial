import PouchDB from "pouchdb";

export const configOfflineSync = (couchUrl: string, couchDB: string) => {
  const remoteDatabase = new PouchDB(`${couchUrl}/${couchDB}`);
  PouchDB.sync('product', remoteDatabase, { live: true, retry: true});
}