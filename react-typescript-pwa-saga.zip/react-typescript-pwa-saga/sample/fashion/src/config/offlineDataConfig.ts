import { NetWorkStatus } from '../services/log';

const { REACT_APP_PROD_API_URL: NAPA_BACKEND, REACT_APP_MOCK_API_URL: MOCK_BACKEND } = process.env;
const productOfflineConfig = {
  for: (url, options) => {
    if (url !== (NAPA_BACKEND as string)) {
      return false;
    }

    if (!options.body) {
      return false;
    }
    try {
      const body = JSON.parse(options.body);
      if (!body || !body.mode || !body.tableName || !body.search) {
        return false;
      }
      return body.mode === 'MODE_READ' && body.tableName === 'pptrex_product';
    } catch (e) {
      console.error(e);
      return false;
    }
  },
  rows: data =>
    [...data.rows].map(item => {
      item.id = ~~(Math.random() * 100000) + '_' + ~~(Math.random() * 1000);
      item._id = '';
      item._rev = '';
      return { _id: '' + item.id, ...item };
    }),
  to: { dbName: 'product' },
  when: NetWorkStatus.isOnline,
  getConfig: function(url, options) {
    if (url !== (NAPA_BACKEND as string)) {
      return false;
    }

    if (!options.body) {
      return false;
    }

    try {
      const body = JSON.parse(options.body);
      if (!body || !body.mode || !body.tableName) {
        return false;
      }
      const returnObject = { search: body.search, fields: body.fields || [] };
      return returnObject;
    } catch (e) {
      console.error(e);
      return false;
    }
  }
};

const mockProductOfflineConfig = {
  ...productOfflineConfig,
  for: (url, options) => {
    return url.startsWith(`${MOCK_BACKEND}/offline-products`);
  }
};

export const offlineSaveConfigs = [productOfflineConfig, mockProductOfflineConfig];

export const offlineSearchConfigs = [
  {
    ...productOfflineConfig,
    when: () => !NetWorkStatus.isOnline()
  }
];
