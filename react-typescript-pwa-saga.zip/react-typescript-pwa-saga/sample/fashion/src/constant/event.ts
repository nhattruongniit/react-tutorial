export default [
  // {
  //   id: 14,
  //   title: 'Today',
  //   start: new Date(new Date().setHours(new Date().getHours())),
  //   end: new Date(new Date().setHours(new Date().getHours() + 1)),

  // },
  {
    id: 13,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 1, 26, 13, 0, 0)),
    end: new Date(Date.UTC(2019, 1, 26, 14, 0, 0)),
    enabled: false
  },
  {
    id: 14,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 1, 25, 10, 0, 0)),
    end: new Date(Date.UTC(2019, 1, 25, 11, 0, 0)),
    enabled: true
  },
  {
    id: 15,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 1, 28, 10, 0, 0)),
    end: new Date(Date.UTC(2019, 1, 28, 11, 0, 0)),
    enabled: true
  },
  {
    id: 16,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 1, 28, 15, 0, 0)),
    end: new Date(Date.UTC(2019, 1, 28, 17, 0, 0)),
    enabled: false
  },
  {
    id: 17,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 2, 1, 17, 30, 0)),
    end: new Date(Date.UTC(2019, 2, 1, 18, 0, 0)),
    enabled: true
  },
  {
    id: 18,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 2, 8, 18, 0, 0)),
    end: new Date(Date.UTC(2019, 2, 8, 18, 30, 0)),
    enabled: false
  },
  {
    id: 19,
    title: 'Tomorrow',
    start: new Date(Date.UTC(2019, 2, 8, 19, 0, 0)),
    end: new Date(Date.UTC(2019, 2, 8, 19, 30, 0)),
    enabled: false
  }
];
