export { default as RocketChat } from './pages/RocketChat';
