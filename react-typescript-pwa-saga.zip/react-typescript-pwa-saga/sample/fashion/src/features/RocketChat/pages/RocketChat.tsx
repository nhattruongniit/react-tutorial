import React, { FC, useEffect, useState, useRef } from 'react';
import { connect } from 'react-redux';

const RocketChat: FC<any> = ({ rocketChat }) => {
  const refIframe = useRef<any>();
  const [height, setHeight] = useState(0);

  useEffect(() => {
    setHeight(window.innerHeight);
  }, []);
  
  function onLoad() {
    const authToken = rocketChat.authToken || localStorage.getItem('_AuthTokenRC');

    refIframe.current.contentWindow.postMessage(
      {
        externalCommand: 'login-with-token',
        token: authToken
      },
      '*'
    )
  }

  return (
    <div>
      {' '}
      <iframe
        width="100%;"
        height={height}
        src="http://13.114.131.214:8080/channel/general?layout=embedded"
        ref={refIframe}
        onLoad={onLoad}
        id="iframe"
      ></iframe>
    </div>
  );
};
const mapStateToProps = state => ({ rocketChat: state.rocketChat })
export default connect(mapStateToProps)(RocketChat);
