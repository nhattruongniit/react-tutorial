import * as React from 'react';

const PanelItem = [
  {
    title: 'About Point',
    content:
      '高ソシウ行5活翼52情イぼぴ三之ぐそ測暮ぐをいす屋養なもひお済辞勝せき建6次フオヒモ展医だ。球ミテヒヘ全視エ模講口タ響歌こき岸断み高札よむとな昨9迫ッばえが概族コホ著6帯マ介争効段究ょ。入型ゅがぜ印加本ヲヨハミ判定たふてみ指城リユニロ選都促てぞわけ領形アトニヒ再懲新サレ称健しかては位秋ぱで線木ろにくゃ雑時ヌ達那オコエ岩傾ネセコト第沸く済化庫せひかめ。'
  },
  {
    title: 'Membership Rank',
    content:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
  },
  {
    title: 'How to get point',
    content:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
  }
];

const Guide = () => {
  return (
    <>
      <div class="header">
        <header class="headerbar">
          <div role="button" on="tap:sidebar1.toggle" tabindex="0" class="hamburger">
            ☰
          </div>
          <div class="site-name">
            <p class="logo">Fashion</p>
          </div>
        </header>
      </div>

      <amp-sidebar id="sidebar1" layout="nodisplay" side="left">
        <div role="button" aria-label="close sidebar" on="tap:sidebar1.toggle" tabindex="0" class="close-sidebar">
          ✕
        </div>

        <div class="user">
          <amp-img src="icon-amp.png" width="62" height="60"></amp-img>
          <p>
            山田 太郎 様 <br />
            ID: undefined.
          </p>
        </div>

        <ul class="sidebar">
          <li>
            <a href="#">Home</a>
          </li>
          <li>
            <a href="#">MemberShip</a>
          </li>
          <li>
            <a href="#">Coupon</a>
          </li>
        </ul>
      </amp-sidebar>
      <amp-accordion style={{ padding: 10 }}>
        {PanelItem.map((val, index) => (
          <section key={index} style={{ marginBottom: 7 }}>
            <h2 style={{ padding: 7, backgroundColor: '#A65070', color: 'white' }}>{val.title}</h2>
            <p style={{ border: '1px solid #979797' }}>{val.content}</p>
          </section>
        ))}
      </amp-accordion>
    </>
  );
};
export default Guide;
