import React from 'react';
import * as Amp from 'react-amphtml';
import { renderToStaticMarkup } from 'react-dom/server';
import { AmpScripts, AmpScriptsManager, headerBoilerplate } from 'react-amphtml/setup';

import Guide from './Guide';

const ampScripts = new AmpScripts();

const bodyContent = renderToStaticMarkup(
  <AmpScriptsManager ampScripts={ampScripts}>
    <div>
      <Amp.AmpImg specName="default" src="/" width={0} height={0} layout="responsive" alt="test" />
      <Guide />
      <Amp.AmpAccordion />
    </div>
  </AmpScriptsManager>
);

/* eslint-disable react/no-danger */
const html = renderToStaticMarkup(
  <Amp.Html>
    <head>
      {headerBoilerplate('/')}
      <title>react-amphtml</title>
      {ampScripts.getScriptElements()}
    </head>
    <body dangerouslySetInnerHTML={{ __html: bodyContent }} />
  </Amp.Html>
);
/* eslint-enable */

const htmlPage = `
  <!doctype html>
  ${html}
`;

const AmpHtml = () => {
  return (
    <>{htmlPage}</>
  )
};

export default AmpHtml;
