import React, { Fragment } from 'react';

// component
import { Routes } from './Routes';
import { Footer, Sidebar } from '../../common/components/';
import Progress from '../../setting-themes/components/Progress';
import ResponsiveHeader from '../../common/components/responsive-header';

const Apps = () => {
  return (
    <Fragment>
      <Progress />
      <Sidebar />
      <ResponsiveHeader />
      <main>
        <Routes />
      </main>
      <Footer />
    </Fragment>
  );
};

export default Apps;
