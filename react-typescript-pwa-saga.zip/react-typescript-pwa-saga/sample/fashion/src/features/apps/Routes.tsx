import React, { Suspense, lazy } from 'react';
import { Route, Redirect } from 'react-router-dom';
import Switch from '../../common/components/slide-switch';
import SignatureDemo from '../signature';
import { RegexURL } from '../demo/regex-url';
import LocalNotificationDemo from '../local-notification';
import CaptureImage from '../capture-image';
// core
import * as LoginSession from '@mochi/misc/auth/util/loginSession';

// hocs
import { WithReduxPrivateRoute as PrivateRoute } from '../../hocs';
import { withTracker as GATracker } from '../../features/google-analytics';
import NavigationBar from '../navigation';

// component
const GATrackedLogin = GATracker(lazy(() => import('../login/Container')));
const Logout = lazy(() => import('../logout/Container'));
const Home = lazy(() => import('../home/pages/Home'));
const Coupon = lazy(() => import('../coupon/pages/Coupon'));
const CouponDetail = lazy(() => import('../coupon/pages/CouponDetail'));
const Product = lazy(() => import('../product/pages/Product'));
const ProductList = lazy(() => import('../product/pages/ProductList'));
const Membership = lazy(() => import('../member-ship/pages/Membership'));
const ProductDetail = lazy(() => import('../product/pages/ProductDetail'));
const Guide = lazy(() => import('../member-ship/pages/Guide'));
const History = lazy(() => import('../member-ship/pages/History'));
const Shop = lazy(() => import('../shop/pages/Shop'));
const ShopDetail = lazy(() => import('../shop/pages/ShopDetail'));
const ReservationDate = lazy(() => import('../reservation/pages/ReservationDate'));
const ServiceChooser = lazy(() => import('../reservation/pages/ServiceChooser'));
const ServiceDetail = lazy(() => import('../reservation/pages/ServiceDetail'));
const Reservation = lazy(() => import('../reservation/pages/Reservation'));
const ReservationConfirm = lazy(() => import('../reservation/pages/ReservationConfirm'));
const Chat = lazy(() => import('../chat/pages/Chat'));
const QRScan = lazy(() => import('../qr-scan/pages/QRScan'));
const StaffDetail = lazy(() => import('../reservation/pages/StaffDetail'));
const RenderingComponent = lazy(() => import('../demo/rendering-textbox'));
const PublicProducts = lazy(() => import('../demo/seo/list'));
const PublicProductDetail = lazy(() => import('../demo/seo/detail'));
const PublicContact = lazy(() => import('../demo/seo/contact'));
const SSDImages = lazy(() => import('../ssd-images'));
const Calendar = lazy(() => import('../calendar'));
const RocketChat = lazy(() => import('../RocketChat/pages/RocketChat'));
/* GEN: IMPORT ROUTE */

const ErrorPage = () => {
  throw new Error('Error test');
};

const authFnc = () => !!LoginSession.get();

export const Routes = () => (
  <Suspense fallback={<div />}>
    <Switch>
      <Route exact path="/calendar" component={Calendar} />
      <Route exact path="/testnav" component={NavigationBar} />
      <Route exact path="/login" render={props => (authFnc() ? <Redirect to="/" /> : <GATrackedLogin {...props} />)} />
      <Route exact path="/regex" component={RegexURL} />
      <Route exact path="/signature" component={SignatureDemo} />
      <Route exact path="/local-notification" component={LocalNotificationDemo} />
      <PrivateRoute exact path="/" component={Home} callbackAuth={authFnc} />
      <PrivateRoute exact path="/logout" component={Logout} callbackAuth={authFnc} />
      <PrivateRoute exact path="/coupons" component={Coupon} callbackAuth={authFnc} />
      <PrivateRoute exact path="/coupons/detail/:id" component={CouponDetail} callbackAuth={authFnc} />
      <PrivateRoute exact path="/products" component={Product} callbackAuth={authFnc} />
      <PrivateRoute exact path="/products/list" component={ProductList} callbackAuth={authFnc} />
      <PrivateRoute exact path="/products/detail/:id" component={ProductDetail} callbackAuth={authFnc} />
      <PrivateRoute exact path="/membership" component={Membership} callbackAuth={authFnc} />
      <PrivateRoute exact path="/membership/guide" component={Guide} callbackAuth={authFnc} />
      <PrivateRoute exact path="/membership/history" component={History} callbackAuth={authFnc} />
      <PrivateRoute exact path="/shops" component={Shop} callbackAuth={authFnc} />
      <PrivateRoute exact path="/shops/detail/:id" component={ShopDetail} callbackAuth={authFnc} />
      <PrivateRoute exact path="/reservation/date" component={ReservationDate} callbackAuth={authFnc} />
      <PrivateRoute exact path="/reservation/services" component={ServiceChooser} callbackAuth={authFnc} />
      <PrivateRoute exact path="/reservation/services/d/:id" component={ServiceDetail} callbackAuth={authFnc} />
      <PrivateRoute exact path="/reservation/services/take" component={Reservation} callbackAuth={authFnc} />
      <PrivateRoute exact path="/reservation/date" component={ReservationDate} callbackAuth={authFnc} />
      <PrivateRoute exact path="/contact" component={Chat} callbackAuth={authFnc} />
      <PrivateRoute exact path="/capture" component={CaptureImage} callbackAuth={authFnc} />
      <PrivateRoute exact path="/qr-scan" component={QRScan} callbackAuth={authFnc} />
      <PrivateRoute exact path="/rendering-textbox" component={RenderingComponent} callbackAuth={authFnc} />
      <PrivateRoute
        exact
        path="/services/reservation/take/confirm"
        component={ReservationConfirm}
        callbackAuth={authFnc}
      />
      <PrivateRoute exact path="/reservation/staffs/d/:id" callbackAuth={authFnc} component={StaffDetail} />
      <PrivateRoute exact path="/error-with-login" component={ErrorPage} callbackAuth={authFnc} />
      /* GEN: PRIVATE ROUTE */
      <Route exact path="/ssd-images" component={SSDImages} />
      <Route exact path="/error-no-login" component={ErrorPage} />
      <Route exact path="/public-products" component={PublicProducts} />
      <Route exact path="/public-product/detail/:slug" component={PublicProductDetail} />
      <Route exact path="/public-contact" component={PublicContact} />
      <Route exact path="/rocket-chat" component={RocketChat} />
    /* GEN: PUBLIC ROUTE */
    </Switch>
  </Suspense>
);

interface IRoutes {
  path: string;
  hideFooter: boolean;
  hideHamburgerIcon: boolean;
  component: any;
}

export const routes: IRoutes[] = [
  {
    path: '/',
    hideFooter: true,
    hideHamburgerIcon: false,
    component: Home
  },
  {
    path: '/home',
    hideFooter: true,
    hideHamburgerIcon: false,
    component: Home
  },
  {
    path: '/coupons',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: Coupon
  },
  {
    path: '/coupons/detail/:id',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: CouponDetail
  },
  {
    path: '/products',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: Product
  },
  {
    path: '/products/list',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: ProductList
  },
  {
    path: '/products/detail/:id',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: ProductDetail
  },
  {
    path: '/shops',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: Shop
  },
  {
    path: '/shops/detail/:id',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: ShopDetail
  },
  {
    path: '/membership',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: Membership
  },
  {
    path: '/membership/guide',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: Guide
  },
  {
    path: '/membership/history',
    hideFooter: false,
    hideHamburgerIcon: true,
    component: History
  }
];
