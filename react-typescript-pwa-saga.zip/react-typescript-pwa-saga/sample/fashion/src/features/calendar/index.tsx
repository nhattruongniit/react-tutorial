import * as React from 'react';
import Calendar from '../../common/components/custom-calendar/';

const endDate = '2020-01-25';

const noEvents = [
  {
    date: '2019-08-27',
    select: 0,
    status: false
  },
  {
    date: '2019-08-28',
    select: 1,
    status: false
  },
  ,
  {
    date: '2020-01-01',
    select: 2,
    status: false
  }
];

const CalendarCustom = () => {
  return <Calendar endDate={endDate} disableSlotTimes={noEvents} />;
};

export default CalendarCustom;