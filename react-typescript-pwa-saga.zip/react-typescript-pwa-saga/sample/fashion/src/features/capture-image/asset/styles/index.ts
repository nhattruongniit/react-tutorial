import { makeStyles } from '@material-ui/styles';

export const useStyles = makeStyles({
  hideCanvas: {
    zIndex: -1
  },
  blockCanvas: {
    zIndex: 1
  }
});
