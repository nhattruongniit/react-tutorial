import React, { FC, useEffect } from 'react';
import { useStyles } from '../asset/styles';

const AddTextImage: FC<any> = ({ resizeImage, textImage, refCanvas, refImage, showCrop }) => {
  const classes = useStyles();

  useEffect(() => {
    const canvas: any = document.getElementById('myCanvas');
    canvas.width = refImage.current.width;
    canvas.height = refImage.current.height;
    const ctx: any = canvas.getContext('2d');
    const image: any = new Image();
    image.src = resizeImage;
    image.onload = () => {
      if (refImage.current) {
        ctx.drawImage(image, 0, 0, refImage.current.width, refImage.current.height);
        ctx.fillStyle = 'red';
        ctx.font = '20px Arial';
        ctx.fillText(textImage, 5, 20);
      }
    };
  });

  return (
    <canvas
      id="myCanvas"
      className={`${showCrop ? classes.hideCanvas : classes.blockCanvas}`}
      ref={refCanvas}
      style={{ position: 'absolute' }}
    />
  );
};
export default AddTextImage;
