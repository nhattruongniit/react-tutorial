import React from 'react';
import IconButton from '@material-ui/core/IconButton';
import CameraAlt from '@material-ui/icons/CameraAlt';
import { useStyles } from './styles';

export default function CameraIconButton({ handleClick }) {
  const classes = useStyles();
  return (
    <IconButton aria-label="Open camera" onClick={handleClick} className={classes.iconButton}>
      <CameraAlt fontSize="large" />
    </IconButton>
  );
}
