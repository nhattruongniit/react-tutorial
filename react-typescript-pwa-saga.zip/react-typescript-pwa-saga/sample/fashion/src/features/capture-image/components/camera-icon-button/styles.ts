import { makeStyles } from '@material-ui/styles';

export const useStyles = makeStyles({
  iconButton: {
    padding: '15px',
    backgroundColor: 'rgba(0,0,0,0.7)',
    color: '#ffffff'
  }
});
