import React, { useState } from 'react';
import { Dialog, CardActions, IconButton, Slide } from '@material-ui/core';
import { Crop, Done, RotateLeft, RotateRight, Save, TextFormat, Restore } from '@material-ui/icons';
import ReactCrop from 'react-image-crop';
import { useStyles } from './styles';
import { rotateImg, drawText } from '../../utility';
const Transition = props => <Slide direction="up" {...props} />;
let imageEl;
let modifiedImg: unknown = null;
/* Component */
export default function ImageDialog({ imgSrc, setImgSrc, isEditingImage, setEditingImage }) {
  const classes = useStyles();
  const canvasEl = React.useRef<HTMLCanvasElement>(null);
  const [isCropping, setIsCropping] = useState<boolean>(false);
  const [cropConfig, setCropConfig] = useState({ unit: '%', width: 50, height: 75 });
  const [showAddText, setShowAddText] = useState<boolean>(false);
  const [editMode, setEditMode] = useState<string>('unknown');

  const save = () => {
    setImgSrc(modifiedImg);
    setEditingImage(false);
  };
  function clickFinishEditImage() {
    if (editMode === 'drawing_text') {
      setShowAddText(false);
    } else if (editMode === 'cropping') {
      finishCrop();
      setIsCropping(false);
    }
    setEditMode('unknown');
  }
  const handleImageLoaded = image => {
    imageEl = image;
  };
  const handleCropChanged = conf => setCropConfig(conf);
  function rotate(deg: number) {
    setEditMode('rotating');
    rotateImg(canvasEl, deg).then(url => {
      modifiedImg = url;
    });
  }
  const clickRotateCounterClockwise = () => rotate(-90);
  const clickRotateClockwise = () => rotate(90);
  function getCroppedImg(image, crop) {
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext('2d');
    ctx!.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );
    return new Promise(resolve => {
      const img = new Image();
      img.src = canvas.toDataURL();
      modifiedImg = img.src;
      img.width = canvas.width;
      img.height = canvas.height;
      img.onload = () => resolve(img);
    });
  }
  async function finishCrop() {
    if (imageEl && cropConfig.width && cropConfig.height) {
      const croppedImg = await getCroppedImg(imageEl, cropConfig);
      const { current: canvas } = canvasEl;
      const ctx = canvas!.getContext('2d');
      ctx!.clearRect(0, 0, canvas!.width, canvas!.height);
      ctx!.save();
      ctx!.drawImage(croppedImg as HTMLImageElement, 0, 0);
      ctx!.restore();
    }
  }
  function clickCrop() {
    setEditMode('cropping');
    setIsCropping(true);
  }
  const handleTextImage = () => {
    setEditMode('drawing_text');
    setShowAddText(true);
  };
  const onChangeText = (e: React.ChangeEvent<HTMLInputElement>) => {
    drawText(canvasEl, e!.target!.value).then(url => {
      modifiedImg = url;
    });
  };
  const clickRestore = () => {
    setEditMode('unknown');
    const { current: canvas } = canvasEl;
    const originalImg = new Image();
    originalImg.src = imgSrc;
    originalImg.onload = () => {
      canvas!.getContext('2d')!.drawImage(originalImg, 0, 0, canvas!.width, canvas!.height);
      modifiedImg = imgSrc;
    };
  };
  return (
    <Dialog
      open={isEditingImage}
      TransitionComponent={Transition}
      classes={{ paper: classes.paperRoot }}
      onEntered={() => {
        const { current: canvas } = canvasEl;
        const ctx = canvas!.getContext('2d');
        const image = new Image();
        image.src = imgSrc;
        image.onload = () => {
          ctx!.drawImage(image, 0, 0, canvas!.width, canvas!.height);
        };
      }}
    >
      <canvas ref={canvasEl} height={500} style={{ display: isCropping ? 'none' : '' }} />
      {isCropping && (
        <ReactCrop src={imgSrc} crop={cropConfig} onImageLoaded={handleImageLoaded} onChange={handleCropChanged} />
      )}
      <CardActions className={classes.actions} disableActionSpacing>
        {showAddText && (
          <div className={classes.addText}>
            <p>Add text: </p>
            <input type="text" placeholder="Enter text" onChange={onChangeText} />
          </div>
        )}
        <div className={classes.areaAction}>
          <IconButton
            aria-label="Add Text Image"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'drawing_text' && editMode !== 'unknown'}
            onClick={handleTextImage}
          >
            <div className={classes.fontSizeLarge}>
              <TextFormat />
            </div>
          </IconButton>
          <IconButton
            aria-label="Crop Image"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'cropping' && editMode !== 'unknown'}
            onClick={clickCrop}
          >
            <Crop />
          </IconButton>
          <IconButton
            aria-label="RotateLeft"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'rotating' && editMode !== 'unknown'}
            onClick={clickRotateCounterClockwise}
          >
            <RotateLeft />
          </IconButton>
          <IconButton
            aria-label="RotateRight"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'rotating' && editMode !== 'unknown'}
            onClick={clickRotateClockwise}
          >
            <RotateRight />
          </IconButton>
          <IconButton
            aria-label="Reset"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'unknown'}
            onClick={clickRestore}
          >
            <Restore />
          </IconButton>
          <IconButton
            aria-label="DoneImage"
            classes={{ root: classes.actionIconButton }}
            onClick={clickFinishEditImage}
          >
            <Done />
          </IconButton>
          <IconButton
            aria-label="SaveImage"
            classes={{ root: classes.actionIconButton, disabled: classes.disabledIconButton }}
            disabled={editMode !== 'unknown'}
            onClick={save}
          >
            <Save />
          </IconButton>
        </div>
      </CardActions>
    </Dialog>
  );
}
