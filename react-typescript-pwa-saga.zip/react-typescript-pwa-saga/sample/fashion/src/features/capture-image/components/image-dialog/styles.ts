import { makeStyles } from '@material-ui/styles';

const btnColor = 'rgba(255,255,255,1)';
export const useStyles = makeStyles({
  pre: {
    padding: '20px'
  },
  wrapper: {
    padding: 10,
    'text-align': 'center'
  },
  imageStyle: {
    width: '100%'
  },
  default: {
    width: '100%',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    display: 'flex',
    '& canvas': {
      transition: 'all .2s linear',
      width: '100%',
      height: 275
    },
    '& img,': {
      transition: 'all .2s linear',
      width: '100%'
    }
  },
  card: {
    maxWidth: 600,
    width: '100%',
    backgroundColor: '#fff',
    overflow: 'hidden',
    marginBottom: 15
  },
  media: {
    width: '100%',
    height: 'auto'
  },
  girdMain: {
    padding: '0 10px'
  },
  rightIcon: {
    marginLeft: 7,
    fontSize: 12
  },
  paper: {
    width: '100%',
    maxWidth: '100%',
    margin: '10px 0 0 0'
  },
  addText: {
    width: '100%',
    padding: '0 12px',
    '& p': {
      color: 'rgba(255,255,255,0.7)',
      margin: '0 0 5px 0',
      padding: 0
    },
    '& input': {
      height: 35,
      width: '100%',
      padding: '0 10px'
    }
  },
  modalCard: {
    maxWidth: 600,
    maxHeight: 400,
    minHeight: 275,
    width: '100%',
    backgroundColor: '#fff',
    overflow: 'hidden',
    marginBottom: 15
  },
  scrollPaper: {
    display: 'block',
    margin: '0 10px'
  },
  action: {
    textAlign: 'right',
    width: '100%',
    marginTop: 20,
    '& button': {
      display: 'inline-block',
      minWidth: 100
    },
    '& button + button': {
      marginLeft: 10
    }
  },
  paperRoot: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    margin: '0 10px',
    padding: 0
  },
  pictureCard: {
    maxWidth: '100%',
    borderRadius: 0
  },
  picture: {
    height: 0,
    paddingTop: '56.25%' // 16:9
  },
  actions: {
    display: 'block',
    backgroundColor: 'rgba(0,0,0,0.7)'
  },
  actionIconButton: {
    color: btnColor
  },
  imagePreview: {
    maxWidth: '100%',
    height: '300px'
  },
  fontSizeLarge: {
    display: 'flex',
    '& svg': {
      fontSize: 30
    }
  },
  disableAction: {
    opacity: 0.5,
    pointerEvents: 'none'
  },
  enableAction: {
    opacity: 1
  },
  areaAction: {
    display: 'flex'
  },
  actionAddText: {
    color: btnColor,
    padding: '10px 12px'
  },
  saveButton: {
    textAlign: 'right',
    padding: '0 10px'
  },
  actionDoneButton: {
    color: btnColor
  },
  disabledIconButton: {
    color: 'rgba(255,255,255,0.21) !important'
  }
});
