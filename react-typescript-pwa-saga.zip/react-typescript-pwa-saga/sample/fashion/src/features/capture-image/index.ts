import TakeImage from './pages/PictureTaker';

export default TakeImage;
