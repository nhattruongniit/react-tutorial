import React, { useState } from 'react';
import Grid from '@material-ui/core/Grid';
import CameraIconButton from '../components/camera-icon-button';
import ImageDialog from '../components/image-dialog';
import '../asset/styles/orientation.css';
import 'react-image-crop/dist/ReactCrop.css';

export default function PictureTaker() {
  const applican = window[`applican`] || '';
  const [imageSrc, setImageSrc] = useState<string>('');
  const [isEditingImage, setEditingImage] = useState(false);

  function clickCameraButton() {
    if (applican.capture) {
      applican.camera.getPicture(
        imgSrc => {
          setImageSrc(`data:image/jpeg;base64,${imgSrc}`);
          setEditingImage(true);
        },
        err => {
          alert(err.message);
        },
        {
          quality: 100,
          destinationType: applican.camera.DestinationType.DATA_URL,
          sourceType: applican.camera.PictureSourceType.CAMERA,
          encodingType: applican.camera.EncodingType.JPEG
        }
      );
    }
  }

  return (
    <React.Fragment>
      <Grid container direction="column" justify="center" alignItems="center">
        <h1>Demo Capture Picture</h1>
        <Grid item xs={12}>
          <CameraIconButton handleClick={clickCameraButton} />
        </Grid>
        <Grid item xs={12}>
          <img src={imageSrc} style={{ maxWidth: '100%', height: '500px' }} />
        </Grid>
        <ImageDialog
          imgSrc={imageSrc}
          setImgSrc={setImageSrc}
          isEditingImage={isEditingImage}
          setEditingImage={setEditingImage}
        />
      </Grid>
    </React.Fragment>
  );
}
