export function exportImage(canvasEl) {
  const { current: canvas } = canvasEl;
  const img = new Image();
  img.src = canvas!.toDataURL();
  return img;
}

export function rotateImg(canvasEl, deg) {
  return new Promise((resolve, reject) => {
    const { current: canvas } = canvasEl;
    const ctx = canvas!.getContext('2d');
    const img = exportImage(canvasEl);
    img.onload = () => {
      if (deg === 90 || deg === -90) {
        canvas.width = img.height;
        canvas.height = img.width;
      }
      ctx!.clearRect(0, 0, canvas!.width, canvas!.height);
      ctx!.save();
      ctx!.translate(canvas!.width / 2, canvas!.height / 2);
      ctx!.rotate((deg * Math.PI) / 180);
      ctx!.drawImage(img, -img.width / 2, -img.height / 2);
      resolve(canvas!.toDataURL());
      ctx!.restore();
    };
  });
}

export function drawText(canvasEl, value) {
  return new Promise((resolve, reject) => {
    const { current: canvas } = canvasEl;
    const ctx = canvas!.getContext('2d');
    const img = exportImage(canvasEl);
    img.onload = () => {
      ctx!.save();
      ctx!.fillStyle = 'red';
      ctx!.font = '20px Arial';
      ctx!.fillText(value, 5, 20);
      ctx!.restore();
      resolve(canvas!.toDataURL());
    };
  });
}
