import Chat from './pages/Chat';

export default Chat;
