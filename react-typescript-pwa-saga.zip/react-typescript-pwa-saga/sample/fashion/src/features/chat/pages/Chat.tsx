import * as React from 'react';
import { get } from '@mochi/misc/auth/util/loginSession';
import ChatSocket from '@mochi/chat';
function Chat() {
  return <ChatSocket userid={get().userId} wsurl={process.env.REACT_APP_CHAT_URL as string} />;
}

export default Chat;
