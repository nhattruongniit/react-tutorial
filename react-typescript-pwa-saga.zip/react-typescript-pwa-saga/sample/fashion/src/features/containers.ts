import { appsContainer } from './apps';
import { homeContainer } from './home';
import { couponContainer, couponDetailContainer } from './coupon';
import { productContainer, ProductList, ProductDetail } from './product';
import { Shop } from './shop';

export const containers = {
  appsContainer,
  homeContainer,
  couponContainer,
  couponDetailContainer,
  productContainer,
  ProductList,
  ProductDetail,
  Shop
};
