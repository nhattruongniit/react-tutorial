import React, { FC, Fragment } from 'react';
import { Link } from 'react-router-dom';
import { withStyles, WithStyles, createStyles, Theme } from '@material-ui/core';
import HomeIcon from '@material-ui/icons/Home';

export const styles = (theme: Theme) =>
  createStyles({
    box: {
      width: '100%',
      borderRadius: 5,
      border: `1px solid ${theme.palette.secondary.main}`,
      display: 'flex',
      '& + &': {
        marginTop: 17
      }
    },
    left: {
      flex: '70% 1'
    },
    right: {
      flex: '30% 1',
      backgroundColor: '#ebebe8',
      textAlign: 'center',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#111',
      borderTopRightRadius: 5,
      borderBottomRightRadius: 5,
      width: '100%',
      padding: '0 20px'
    },
    lead: {
      backgroundColor: `${theme.palette.secondary.main}`,
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      fontSize: 14
    },
    content: {
      display: 'flex',
      padding: '10px 5px',
      justifyContent: 'space-between'
    },
    item: {
      textAlign: 'center'
    },
    images: {
      width: 70,
      height: 81,
      backgroundColor: '#d8d8d8',
      marginBottom: 5,
      '& img': {
        width: '100%',
        height: '100%'
      }
    },
    price: {
      color: `${theme.palette.secondary.main}`,
      fontWeight: 'bold',
      fontSize: 13
    },
    discount: {
      fontSize: 11,
      color: '#4a4a4a',
      fontWeight: 'bold',
      textDecoration: 'line-through'
    },
    infor: {
      width: '100%',
      '& p': {
        margin: 0
      }
    },
    text: {
      fontSize: 17,
      fontWeight: 'bold'
    },
    much: {
      fontSize: 25,
      fontWeight: 'bold',
      padding: '10px 0 15px 0'
    },
    button: {
      backgroundColor: '#ba7402',
      display: 'block',
      width: '100%',
      height: 22,
      lineHeight: '20px',
      borderRadius: 8,
      color: '#fff',
      fontSize: 12,
      boxShadow: '0 2px 4px 0 rgba(0, 0, 0, 0.5)',
      textAlign: 'center',
      textDecoration: 'none'
    }
  });

interface IItems {
  image: string;
  price: string;
  price_default: string;
}

interface IData {
  id: number;
  name: string;
  discount: string;
  qrCode: string;
  items: IItems[];
}

interface IProps extends WithStyles<typeof styles> {
  data: IData;
}

export const ListBox: FC<IProps> = ({ data, classes }) => {
  return (
    <Fragment>
      <div className={classes.box}>
        <div className={classes.left}>
          <div className={classes.lead}>
            <HomeIcon /> {data.name}
          </div>
          <div className={classes.content}>
            {data.items.map((val, index: number) => (
              <div key={index} className={classes.item}>
                <div className={classes.images}>
                  <img src={val.image} title="Item" alt="" />
                </div>
                <div className={classes.price}>{val.price}</div>
                <div className={classes.discount}>{val.price_default}</div>
              </div>
            ))}
          </div>
        </div>
        <div className={classes.right}>
          <div className={classes.infor}>
            <p className={classes.text}> Discount </p>
            <p className={classes.much}>{data.discount}</p>
            <Link to={`/coupons/detail/${data.id}`} className={classes.button}>
              Get Coupon
            </Link>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default withStyles(styles)(ListBox);
