import React, { FC, useEffect } from 'react';
import { connect } from 'react-redux';
import { FixedSizeList } from 'react-window';
import AutoSizer from 'react-virtualized-auto-sizer';

// material ui
import { withStyles, createStyles, WithStyles } from '@material-ui/core';

// components
import ListBox from '../components/list-box';

// redux
import { fetchCoupon } from '../redux/coupon/actions';

// state
import { IFashionState } from '../../../models';

interface IItems {
  image: string;
  price: string;
  price_default: string;
}

interface IData {
  id: number;
  name: string;
  discount: string;
  qrCode: string;
  items: IItems[];
}

export const styles = createStyles({
  root: {
    padding: '20px 15px',
    height: 'calc(100vh - 110px)',
    overflowX: 'hidden'
  }
});

interface IProps extends WithStyles<typeof styles> {
  fetchCoupon: () => void;
  data: IData[];
}

export const Coupon: FC<IProps> = ({ fetchCoupon: actionFetchCoupon, data, classes }) => {
  useEffect(() => {
    actionFetchCoupon();
  }, [actionFetchCoupon]);

  const renderVirtualItem = ({ index, style }) => {
    return (
      <div style={style}>
        <ListBox key={index} data={data[index]} />
      </div>
    );
  };

  return (
    <div className={classes.root}>
      <AutoSizer>
        {({ height, width }) => (
          <FixedSizeList className="List" height={height} itemCount={data.length} itemSize={180} width={width}>
            {renderVirtualItem}
          </FixedSizeList>
        )}
      </AutoSizer>
    </div>
  );
};

export const mapStateToProps = (state: IFashionState) => {
  const {
    coupon: { data }
  } = state;
  return {
    data
  };
};

export const mapDispatchToProps = {
  fetchCoupon
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Coupon));
