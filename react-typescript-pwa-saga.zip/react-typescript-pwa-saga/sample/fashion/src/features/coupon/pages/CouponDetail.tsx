import React, { FC, Fragment, useEffect } from 'react';
import { connect } from 'react-redux';

import { withStyles, createStyles } from '@material-ui/core';

// state
import { IFashionState, ICouponDetail } from '../../../models';
import { IData } from '../../../models/ICouponDetail';

// redux
import { fetchData } from '../redux/coupon-detail/actions';

export const styles = createStyles({
  wrapperCSS: {
    backgroundColor: '#F1F1F0'
  }
});

interface IMatch {
  params: {
    id: number;
  };
}

interface ICouponDetailProps extends ICouponDetail {
  data: IData;
  match: IMatch;
  fetchData: (id: any) => void;
}

export const CouponDetail: FC<ICouponDetailProps> = ({ data, match, fetchData: actionFetchData }) => {
  const {
    params: { id }
  } = match;

  useEffect(() => {
    actionFetchData({ id });
  }, []);

  return (
    <Fragment>
      <img src={`img/coupon/${data.coupon}`} title="Item" style={{ width: '100%' }} alt="Coupon" />
    </Fragment>
  );
};

export const mapStateToProps = (state: IFashionState) => {
  const {
    couponDetail: { data }
  } = state;
  return {
    data
  };
};

export const mapDispatchToProps = {
  fetchData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(CouponDetail));
