import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

import { ICouponDetail } from '../../../../models/ICouponDetail';

export const fetchData = (payload: ICouponDetail) => ({ type: FETCH_DATA_REQUEST, payload });

export const fetchDataSuccess = (payload: ICouponDetail) => ({ type: FETCH_DATA_SUCCESS, payload });

export const fetchDataFailure = (error: string) => ({ type: FETCH_DATA_FAILURE, payload: { error } });
