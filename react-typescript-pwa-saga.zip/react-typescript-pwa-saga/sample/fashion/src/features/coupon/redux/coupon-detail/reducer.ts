import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

// model
import { IAction, ICouponDetail } from '../../../../models';

const initialState: ICouponDetail = {
  data: {
    coupon: ''
  },
  error: ''
};

export function reducer(state: ICouponDetail = initialState, { type, payload }: IAction): ICouponDetail {
  switch (type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        data: {
          coupon: payload.data.coupon
        }
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: payload.error
      };
    default:
      return state;
  }
}
