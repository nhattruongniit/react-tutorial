import { takeLatest, put, call } from 'redux-saga/effects';

import { FETCH_DATA_REQUEST } from './constants';
import { fetchDataSuccess, fetchDataFailure } from './actions';

// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

function* fetchCouponDetailData(action) {
  const { id } = action.payload;
  const payloadForFetchApiAction = makeMockJsonRequest(`DETAIL_COUPON_${id}`, `couponDetail?id=${id}`);
  yield put(fetchApi(payloadForFetchApiAction));
}

function* getDataCouponDetailSuccess(action: {
  payload: { httpResponseJson: any; request: { option: { meta: string } } };
}) {
  const {
    payload: { httpResponseJson }
  } = action;
  yield put(fetchDataSuccess({ data: httpResponseJson[0] }));
}

function* getDataCouponDetailError() {
  yield put(fetchDataFailure('Error fetch coupon detail!'));
}

function* getCouponDetailAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;
  if (request.key.startsWith('DETAIL_COUPON')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getDataCouponDetailSuccess, action);
    } else {
      yield call(getDataCouponDetailError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchCouponDetailData);
  yield takeLatest(FETCH_API.SUCCESS, getCouponDetailAsyncWorker);
  yield takeLatest(FETCH_API.FAILURE, getCouponDetailAsyncWorker);
}
