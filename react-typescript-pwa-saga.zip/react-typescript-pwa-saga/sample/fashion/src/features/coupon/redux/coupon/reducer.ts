import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

// model
import { IAction, ICoupon } from '../../../../models';

const initialState: ICoupon = {
  data: [],
  total: 0,
  page: 1,
  skip: 1,
  error: ''
};

export function reducer(state: ICoupon = initialState, { type, payload }: IAction): ICoupon {
  switch (type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        data: payload.data,
        total: payload.total,
        page: payload.page
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: payload.error
      };
    default:
      return state;
  }
}
