import { takeLatest, put, select, call } from 'redux-saga/effects';
import { FETCH_API, fetchApi } from '@mochi/core';

import { FETCH_DATA_REQUEST } from './constants';
import { fetchCouponSuccess, fetchCouponFailure } from './actions';
// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';

const getPage = ({ coupon: { page } }) => page;

function* fetchData() {
  const page = yield select(getPage);
  const skip = (page - 1) * 10;
  const payloadForFetchApiAction = makeMockJsonRequest(
    'COUPON_' + skip,
    'coupon',
    { noCached: true },
    `${process.env.REACT_APP_MOCK_API_URL as string}/coupon`
  );
  yield put(fetchApi(payloadForFetchApiAction));
}

function* getCouponSuccess(action: { payload: { httpResponseJson: any; request: { option: { meta: string } } } }) {
  const {
    payload: { httpResponseJson }
  } = action;
  const page = yield select(getPage);
  const skip = (page - 1) * 10;
  yield put(fetchCouponSuccess({ data: httpResponseJson, total: 1, page, skip }));
}

function* getCouponError() {
  yield put(fetchCouponFailure('Error fetch job list!'));
}

function* getCouponAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;
  if (request.key.startsWith('COUPON')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getCouponSuccess, action);
    } else {
      yield call(getCouponError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchData);
  yield takeLatest(FETCH_API.SUCCESS, getCouponAsyncWorker);
  yield takeLatest(FETCH_API.FAILURE, getCouponAsyncWorker);
}
