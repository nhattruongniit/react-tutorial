import React, { useState } from 'react';
import * as H from 'history';
import _ from 'lodash';

const FORM_STYLE = {
  marginTop: '2rem'
};
const INPUT_STYLE = {
  display: 'block',
  minWidth: '340px',
  height: 'calc(1.5em + .75rem + 2px)',
  padding: '.375rem .75rem',
  fontSize: '1rem',
  fontWeight: 400,
  lineHeight: '1.5',
  color: '#495057',
  backgroundColor: '#fff',
  backgroundClip: 'padding-box',
  border: '1px solid #ced4da',
  borderRadius: '.25rem',
  transition: 'border-color .15s ease-in-out,box-shadow .15s ease-in-out'
};

export interface IRegexURLComponentProps {
  location: H.Location;
}

export const RegexURL: React.FC<IRegexURLComponentProps> = ({ location }) => {
  const [message, setMessage] = useState('');
  const [displayMessage, setDisplayMessage] = useState('');

  function handleInputMessage(event: React.ChangeEvent<HTMLInputElement>) {
    setMessage(event.target.value);
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    const words = _.split(message, ' ');
    const rl = _.flatMap(words, word => {
      const wordContainLink = word.indexOf('link:') > -1;
      const wordIsEmptyString = word === '';
      if (wordContainLink) {
        const wordsArray = _.split(word, ':');
        const url = `<a href='/${wordsArray[1]}'>${wordsArray[1]}</a>`;
        return [url];
      } else if (wordIsEmptyString) {
        return ['\u00a0'];
      } else {
        return [word];
      }
    });
    setDisplayMessage(_.join(rl, ' '));
  }

  function createMarkup() {
    return { __html: displayMessage };
  }

  return (
    <form noValidate autoComplete="off" onSubmit={handleSubmit} style={FORM_STYLE}>
      <label htmlFor="content">Content</label>
      <input id="content" type="text" value={message} onChange={handleInputMessage} style={INPUT_STYLE} />
      <div>Original: {displayMessage}</div>
      <div dangerouslySetInnerHTML={createMarkup()} />
    </form>
  );
};
