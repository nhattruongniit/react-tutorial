import React, { useState, useMemo } from 'react';

const onChanged = (setter: (value: React.SetStateAction<string>) => void) => ({ target }) => {
  setter(target.value);
};

const MemoInput = ({ count }) => {
  const [name, setName] = useState('');

  return useMemo(() => {
    console.log('memo input re-render', count);
    return <input value={name} placeholder={`this is memo input ${count}`} onChange={onChanged(setName)} />;
  }, [name]);
};

const CustomInput = ({ count }) => {
  const [name, setName] = useState('');

  console.log('custom input re-render', count);

  return <input value={name} placeholder={`this is custom input ${count}`} onChange={onChanged(setName)} />;
};

const RenderingComponent = () => {
  const [name, setName] = useState('');

  const onChangedInner = (setter: (value: React.SetStateAction<string>) => void) => ({ target }) => {
    setter(target.value);
  };

  const renderMultiInput = () => {
    const arrayInput: any[] = [];
    for (let i = 1; i <= 30; i += 1) {
      arrayInput.push(<CustomInput count={i} />);
    }
    return arrayInput;
  };

  return (
    <div style={{ padding: '0 30px' }}>
      <h2>Default Texbox</h2>
      <input value={name} placeholder="this is default input" onChange={onChangedInner(setName)} />
      <br />
      <h3>This is custom input: It will re-render when user enter default input.</h3>
      {renderMultiInput()}

      <h3>This is memo input: It won't re-render when user enter default input.</h3>
      <MemoInput count={1} />
      <MemoInput count={2} />
      <MemoInput count={3} />
      <MemoInput count={4} />
      <MemoInput count={5} />
      <br />
      <br />
      <br />
    </div>
  );
};

export default RenderingComponent;
