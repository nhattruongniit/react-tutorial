import React from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { Helmet } from 'react-helmet';

const Album = () => {
  return (
    <div>
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            url: 'https://www.persol-pt.co.jp/en/',
            contactPoint: [{ '@type': 'ContactPoint', telephone: '+84-8-3848-1200', contactType: 'customer service' }]
          })}
        </script>
      </Helmet>
      {/* Hero unit */}
      <div>
        <div>
          <br />
          <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
            About Us
          </Typography>
        </div>
      </div>
      <div>
        {/* End hero unit */}
        <Grid container spacing={8}>
          <Grid item key={1} xs={12} sm={6} md={4}>
            <Card>
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  Fashion Rex
                </Typography>
                <Typography>This is a test application from Rex Team.</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item key={1} xs={12} sm={6} md={4}>
            <Card>
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  Contact US
                </Typography>
                <address>
                  Tel:
                  <a href="tel:+84838481200"> +84-8-3848-1200</a>
                  <br />
                  Visit us at: 117-119 Ly Chinh Thang, District 3, Ho Chi Minh City <br />
                  Vietnam
                </address>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default Album;
