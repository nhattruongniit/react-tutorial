import * as React from 'react';
import { Helmet } from 'react-helmet';
import classnames from 'classnames';
import _ from 'lodash';

// material ui
import { withStyles } from '@material-ui/core';
import * as Icons from '@material-ui/icons';

// component
import Rating from '../../product/components/rating';
import Gallery from '../../product/components/gallery';
import GroupColors from '../../product/components/group-colors';

// resource
import { Point, ProductDescription } from '../../product/assets';
import { styles } from '../../product/pages/ProductDetail';

export class ProductDetail extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      quantity: 1,
      activeColorImageId: -1,
      selectedIndex: 0,
      selectedColors: 0,
      data: [],
      jsonLdSchema: {},
      jsonLdSchema1: {}
    };
  }

  componentDidMount() {
    const {
      match: {
        params: { slug }
      }
    } = this.props;
    fetch(`${process.env.REACT_APP_MOCK_API_URL as string}/rexProducts?slug=${slug}`).then(async response => {
      const [item] = await response.json();
      this.setState({ data: item });

      const jsonObj = {
        '@context': 'https://schema.org/',
        '@type': 'Product',
        url: window.location.origin + '/public-product/detail/' + item.slug,
        name: item.name,
        image: item.images.map(a => a.src),
        description: item.description,
        aggregateRating: {
          '@type': 'AggregateRating',
          ratingValue: item.rating + '',
          reviewCount: '19',
          bestRating: '5',
          worstRating: '1'
        },
        offers: {
          '@type': 'Offer',
          price: '$119.99'
        }
      };

      const jsonObj1 = {
        '@context': 'https://schema.org/',
        '@type': 'CreativeWork',
        name: item.name,
        aggregateRating: {
          '@type': 'AggregateRating',
          ratingValue: item.rating + '',
          ratingCount: '19',
          bestRating: '5',
          worstRating: '1'
        }
      };

      console.log(JSON.stringify(jsonObj));

      this.setState({
        jsonLdSchema: jsonObj,
        jsonLdSchema1: jsonObj1
      });
    });
  }

  increaseQuantity = () => {
    this.setState(prevState => {
      return {
        ...prevState,
        quantity: prevState.quantity + 1
      };
    });
  };

  decreaseQuantity = () => {
    this.setState(prevState => {
      if (prevState.quantity <= 1) {
        return {
          ...prevState,
          quantity: 1
        };
      }
      return {
        ...prevState,
        quantity: prevState.quantity - 1
      };
    });
  };

  handleSize = (item: number) => {
    this.setState({ selectedIndex: item });
  };

  handleColors = (item: number) => {
    this.setState({ selectedColors: item });
  };

  render() {
    const {
      state: { selectedIndex, data, jsonLdSchema, jsonLdSchema1 },
      props: { classes }
    } = this;

    return (
      <div className={classnames('container-fluid', classes.root)} key="ProductDetailItem">
        <Helmet>
          <script type="application/ld+json">{JSON.stringify(jsonLdSchema1)}</script>
          <script type="application/ld+json">{JSON.stringify(jsonLdSchema)}</script>
        </Helmet>
        {data.length !== 0 && (
          <>
            <div className="group">
              <div className="title">{data.name}</div>
              <Rating rating={data.rating} />
              <div className="rex-row">
                <div className="price">
                  {data.currency}
                  {data.price}
                </div>
                <div>
                  <div className="quality">
                    <input type="button" value="-" onClick={this.decreaseQuantity} />
                    <input className="number" defaultValue={this.state.quantity} />
                    <input type="button" value="+" onClick={this.increaseQuantity} />
                  </div>
                </div>
              </div>
              <Gallery images={data.images} activeImageId={this.state.activeColorImageId} />
            </div>
            <div className="separator" />
            <div className={classnames('group', 'product-option', 'size')}>
              <div className="option-name">
                <div className="icon-title">
                  <Icons.ZoomOutMap />
                  <div className="name">Size</div>
                </div>
              </div>
              <ul className="option-values size">
                {data.sizes.map((item: React.ReactNode, index: number) => {
                  return (
                    <li
                      key={index}
                      className={selectedIndex === index ? 'selected' : ''}
                      onClick={() => this.handleSize(index)}
                    >
                      {item}
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="separator" />
            <div className={classnames('group', 'product-option', 'color')}>
              <div className="option-name">
                <div className="icon-title">
                  <img src={Point} title="Point" alt="Point" />
                  <div className="name">Color</div>
                </div>
              </div>
              <ul className="option-values color">
                <GroupColors
                  values={data.colors}
                  onSelect={(item: { imageId: string }) => {
                    this.setState(prevState => {
                      return { ...prevState, activeColorImageId: item.imageId };
                    });
                  }}
                />
              </ul>
            </div>
            <div className="separator" />
            <div className="group">
              <div className="icon-title">
                <ProductDescription />
                <div className="name">Product Description</div>
              </div>
              <div className="product-description">{data.description}</div>
            </div>
          </>
        )}
      </div>
    );
  }
}

export default withStyles(styles)(ProductDetail);
