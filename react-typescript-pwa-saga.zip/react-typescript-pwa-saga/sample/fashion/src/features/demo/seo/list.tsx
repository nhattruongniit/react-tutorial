import * as React from 'react';
import { Helmet } from 'react-helmet';

// material
import { Grid, withStyles } from '@material-ui/core';

// component
import { ListView } from '../../../common/components';
import Rating from '../../product/components/rating';
import { Point } from '../../product/assets';
import classnames from 'classnames';
import _ from 'lodash';
import { styles } from '../../product/pages/ProductList';
import { styles as itemStyles } from '../../product/components/product-item';

const RootItem: any = withStyles(itemStyles)((props: any) => {
  const classes: any = props.classes;
  const item: any = props.item;
  const history: any = props.history;
  const columnStyle = {};
  const imgStyle = {
    display: 'inline-block',
    height: '100%',
    maxHeight: 90
  };
  return (
    <Grid
      onClick={() => history.push('/public-product/detail/' + item.slug)}
      id={_.snakeCase(item.slug)}
      item={true}
      container={true}
      spacing={8}
      wrap="wrap"
      xs={12}
      key={item.id}
      justify="space-between"
      direction="row"
      className={classnames(classes.boxGrid, classes.rootItem)}
    >
      <Grid className="imageContainer" key={1} item={true} style={columnStyle}>
        <img style={imgStyle} src={item.featureImage} alt={item.name} />
      </Grid>

      <Grid key={2} className={classes.content} item={true} style={columnStyle}>
        <h2 className={classes.productName}>{item.name}</h2>
        <Rating rating={item.rating} />
        <h2 className={classes.price}>
          {item.currency}
          {item.price}
        </h2>
        <h2 className={classes.point}>
          <img src={Point} title="Point" alt="Point" className="svgPoint" />
          Get {item.getPoint} Point{item.getPoint !== 1 && 's'}
        </h2>
      </Grid>
    </Grid>
  );
});

export const ProductList = ({ classes, history }) => {
  const [data, setData]: [any, any] = React.useState([]);
  const [jsonLdSchema, setJsonLdSchema]: [any, any] = React.useState({});

  React.useEffect(() => {
    fetch(`${process.env.REACT_APP_MOCK_API_URL as string}/rexProducts`).then(async response => {
      const list = await response.json();
      setData(list);

      const top5 = _.take(list, 10);

      const jsonObj: any = {
        '@context': 'https://schema.org',
        '@type': 'ItemList',
        itemListElement: []
      };

      jsonObj.itemListElement = top5.map((item: any, i) => {
        return {
          '@type': 'ListItem',
          position: i + 1,
          item: {
            '@type': 'Recipe',
            url: window.location.origin + '/public-products/#' + _.snakeCase(item.slug),
            name: item.name,
            image: item.images[0].src,
            aggregateRating: {
              '@type': 'AggregateRating',
              ratingValue: item.rating + '',
              reviewCount: '2'
            },
            description: item.description
          }
        };
      });

      console.log(JSON.stringify(jsonObj));
      setJsonLdSchema(jsonObj);
    });
  }, []);

  return (
    <div className={classes.root} key="ProductListItem">
      <Helmet>
        <script type="application/ld+json">{JSON.stringify(jsonLdSchema)}</script>
      </Helmet>
      <div>
        <div className={classes.actions}>
          <div>
            <ListView
              listData={data}
              direction="row"
              render={({ data: itemData }) => {
                return <RootItem key={itemData.id} item={itemData} history={history} />;
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
export default withStyles(styles)(ProductList);
