/**
 * From ReactGA Community Wiki Page https://github.com/react-ga/react-ga/wiki/React-Router-v4-withTracker
 */

import React, { Component } from 'react';
import ReactGA from 'react-ga';


interface ILocation {
  pathname: string;
  search: string;
}
interface IProps {
  location: ILocation;
}
export default function withTracker(WrappedComponent, options = {}) {
  const trackPage = (page: string) => {
    ReactGA.set({
      page,
      ...options
    });
    ReactGA.pageview(page);
  };

  const HOC = class extends Component<IProps> {
    componentDidMount() {
      const { location } = this.props;
      const page = `${location.pathname}${location.search}`;
      trackPage(page);
    }

    componentWillReceiveProps(nextProps) {
      const { location } = this.props;
      const { location: nextLocation } = nextProps;

      const currentPage = `${location.pathname}${location.search}`;
      const nextPage = `${nextLocation.pathname}${nextLocation.search}`;

      if (currentPage !== nextPage) {
        trackPage(nextPage);
      }
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };

  return HOC;
}
