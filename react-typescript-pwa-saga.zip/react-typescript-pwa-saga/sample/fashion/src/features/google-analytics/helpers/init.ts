import ReactGA from 'react-ga';

export default function init(trackingId: string) {
  ReactGA.initialize(trackingId);
}

export function initWithHistory(trackingId: string, history) {
  ReactGA.initialize(trackingId);
  history.listen((location, action) => {
    ReactGA.pageview(location.pathname + location.search);
  });
}
