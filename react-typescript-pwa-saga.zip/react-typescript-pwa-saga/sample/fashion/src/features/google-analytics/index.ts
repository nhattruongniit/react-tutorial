// HOC enable tracked page component
export { default as withTracker } from './components/with-tracker';

// initGA required for HOC tracked page component
// initGAWithHistory: only need init only without HOC but required history of react-router-dom. v4 is not public.
export { default as initGA, initWithHistory as initGAWithHistory } from './helpers/init';
