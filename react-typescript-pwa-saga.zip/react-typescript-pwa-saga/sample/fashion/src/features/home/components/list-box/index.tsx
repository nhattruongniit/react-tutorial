import React, { FC, ReactElement, ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { withStyles, WithStyles, Grid, Paper, Typography, createStyles } from '@material-ui/core';
import { IconSVG } from '../../img';

const styles = createStyles({
  paper: {
    flex: 1,
    padding: '7px 15px',
    margin: '0 10px 15px',
    maxWidth: 360,
    minHeight: 97,
    borderRadius: 8,
    width: '100%',
    '& a': {
      textDecoration: 'none'
    }
  },
  TypographyTxt: {
    fontSize: '25px',
    fontFamily: 'Helvetica Neue',
    color: '#fff !important'
  }
});

interface IProps extends WithStyles<typeof styles> {
  icon: ReactElement;
  children: ReactElement;
  label: ReactNode;
  background: string;
  direction: any;
  link: string;
}

const ListBox: FC<IProps> = ({ icon, link, children, label, background, direction, classes }) => {
  return (
    <Paper className={classes.paper} elevation={0} style={{ background }}>
      <Grid
        container={true}
        direction="row"
        wrap="nowrap"
        justify="space-between"
        alignItems="center"
        spacing={16}
        style={{ minHeight: 97 }}
      >
        <Grid item={true}>{icon}</Grid>
        <Grid item={true} xs={8}>
          <Link to={link}>
            <Grid container={true} item={true} justify="flex-start" direction={direction} alignItems="center">
              <Grid
                container={true}
                justify="flex-start"
                direction="column"
                alignItems="center"
                style={{ marginLeft: '-30px' }}
              >
                {children}
              </Grid>
              <Typography className={classes.TypographyTxt}>{label}</Typography>
            </Grid>
          </Link>
        </Grid>
        <Grid item={true}>
          <Grid container={true} justify="flex-end">
            <IconSVG.IconArrow />
          </Grid>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default withStyles(styles)(ListBox);
