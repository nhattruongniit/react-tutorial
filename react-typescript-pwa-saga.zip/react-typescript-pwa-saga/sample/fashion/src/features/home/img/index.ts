import { ReactComponent as IconStar } from './iconStar.svg';
import { ReactComponent as IconReservation } from './iconReservation.svg';
import { ReactComponent as IconCoupon } from './iconCoupon.svg';
import { ReactComponent as IconSearchShop } from './iconSearchShop.svg';
import { ReactComponent as IconSearchProduct } from './iconSearchProduct.svg';
import { ReactComponent as IconArrow } from '../img/iconArrow.svg';
import homepagePicture from './homepagePicture.png';

export const IconSVG = {
  IconStar,
  IconReservation,
  IconCoupon,
  IconSearchShop,
  IconSearchProduct,
  IconArrow
};

export const picture = {
  homepagePicture
};
