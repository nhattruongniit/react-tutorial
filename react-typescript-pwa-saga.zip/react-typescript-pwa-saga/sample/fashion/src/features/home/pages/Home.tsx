import React, { FC, Fragment, useEffect } from 'react';
import { connect } from 'react-redux';
import Rating from 'react-rating';
import { orientationLandscape } from '../../orientation';

// material ui
import { withStyles, Typography, Grid, WithStyles } from '@material-ui/core';

// state
import { IFashionState } from '../../../models';

// redux
import { fetchData } from '../redux/actions';

import { IconSVG, picture } from '../img';
import ListBox from '../components/list-box';
import { unstable_useMediaQuery as useMediaQuery } from '@material-ui/core/useMediaQuery';

const onlyHome = {
  '@global': {
    'html, body': {
      overflow: 'hidden'
    }
  },
  '@media screen and (max-width : 1023px)': {
    '@global': {
      'html, body': {
        overflow: 'unset'
      }
    }
  }
};

const styles = theme => ({
  root: {
    [theme.breakpoints.down('sm')]: { marginTop: '-22px' }
  },
  picture: { marginBottom: 15, marginTop: -15 },
  wrapperCSS: { backgroundColor: '#F1F1F0' },
  empty: { color: 'white', fontSize: 23, margin: '0 3px' },
  full: { color: 'white', fontSize: 23, margin: '0 3px' },
  point: { fontSize: 30, fontWeightNormal: 'normal', lineHeight: '36px', color: '#fff' },
  group: { display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px' },
  level: { color: '#fff' },
  ...orientationLandscape,
  ...onlyHome
});

interface IProps extends WithStyles<typeof styles> {
  data: any;
  history: any;
  fetchData: () => void;
}

const listItem = [
  {
    icon: <IconSVG.IconStar />,
    background: '#E181A6',
    label: 'isStar',
    direction: 'column',
    link: 'membership'
  },
  {
    icon: <IconSVG.IconReservation />,
    background: '#752651',
    label: 'Reservation',
    direction: 'row',
    link: 'reservation/services'
  },
  {
    icon: <IconSVG.IconCoupon />,
    background: '#B97556',
    label: 'Coupon',
    direction: 'row',
    link: 'coupons'
  },
  {
    icon: <IconSVG.IconSearchShop />,
    background: '#6B331A',
    label: 'Search Shop',
    direction: 'row',
    link: 'shops'
  },
  {
    icon: <IconSVG.IconSearchProduct />,
    background: '#850F33',
    label: 'Search Product',
    direction: 'row',
    link: 'products'
  }
];

const showBoxIsStar = (isStar: boolean, data: any, classes: any): React.ReactElement => {
  if (!isStar) {
    return <Fragment />;
  }

  return (
    <Fragment>
      <Rating
        readonly={true}
        initialRating={data.rating}
        emptySymbol={`fa fa-star-o ${classes.empty}`}
        fullSymbol={`fa fa-star ${classes.full}`}
      />
      <Typography color="default" className={classes.point}>
        {data.point} pt
      </Typography>
      <Typography variant="h5" color="default" className={classes.level}>
        {data.level}
      </Typography>
    </Fragment>
  );
};

const Home: FC<IProps> = ({ data, fetchData: actionFetchData, classes }) => {
  useEffect(() => {
    actionFetchData();
  }, [actionFetchData]);

  const isSmallScreen = useMediaQuery('(max-width:1023px)');

  return (
    <div className={classes.root}>
      {isSmallScreen ? (
        <Grid className={classes.picture}>
          <img src={picture.homepagePicture} width="100%" alt="Homepage" />
        </Grid>
      ) : (
        <div
          className="full-bg-img"
          style={{
            backgroundImage: 'url(' + picture.homepagePicture + ')',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            height: '100vh'
          }}
        />
      )}
      {isSmallScreen && (
        <div className={classes.group}>
          {listItem.map((val, index) => {
            const isStar = val.label === 'isStar';
            return (
              <ListBox
                key={index}
                icon={val.icon}
                background={val.background}
                direction={val.direction}
                link={val.link}
                label={!isStar ? val.label : <React.Fragment />}
              >
                {showBoxIsStar(isStar, data, classes)}
              </ListBox>
            );
          })}
        </div>
      )}
    </div>
  );
};

const mapStateToProps = (state: IFashionState) => {
  const {
    home: { data }
  } = state;
  return {
    data
  };
};

const mapDispatchToProps = {
  fetchData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Home));
