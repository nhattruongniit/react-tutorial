import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

import { IHome } from '../../../models/IHome';

export const fetchData = () => ({ type: FETCH_DATA_REQUEST });

export const fetchDataSuccess = (payload: IHome) => ({ type: FETCH_DATA_SUCCESS, payload });

export const fetchDataFailure = (error: string) => ({ type: FETCH_DATA_FAILURE, payload: { error } });
