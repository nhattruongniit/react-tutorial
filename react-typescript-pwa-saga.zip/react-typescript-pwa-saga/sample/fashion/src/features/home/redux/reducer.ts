import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

// model
import { IAction, IHome } from '../../../models';

const initialState: IHome = {
  data: [],
  error: ''
};

export function reducer(state: IHome = initialState, { type, payload }: IAction): IHome {
  switch (type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        data: payload.data
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: payload.error
      };
    default:
      return state;
  }
}
