import { takeLatest, put, call } from 'redux-saga/effects';
import { FETCH_API, fetchApi } from '@mochi/core';

import { FETCH_DATA_REQUEST } from './constants';
import { fetchDataSuccess, fetchDataFailure } from './actions';

// utils
import { makeMockJsonRequest } from '../../../common/fetch-api';

function* fetchData() {
  const payloadForFetchApiAction = makeMockJsonRequest('HOME', 'user');
  yield put(fetchApi(payloadForFetchApiAction));
}

function* getDataSuccess(action: { payload: { httpResponseJson: any; request: { option: { meta: string } } } }) {
  const {
    payload: { httpResponseJson }
  } = action;
  yield put(fetchDataSuccess({ data: httpResponseJson }));
}

function* getDataError() {
  yield put(fetchDataFailure('Error fetch home!'));
}

function* getHomeAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;
  if (request.key.startsWith('HOME')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getDataSuccess, action);
    } else {
      yield call(getDataError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchData);
  yield takeLatest(FETCH_API.SUCCESS, getHomeAsyncWorker);
  yield takeLatest(FETCH_API.FAILURE, getHomeAsyncWorker);
}
