import React from 'react';
import { createRef } from 'react';
import { Grid, Button, TextField } from '@material-ui/core';
import * as moment from 'moment';

export default function LocalNotificationDemo() {
  const uri = 'http://www.yahoo.co.jp/';
  const applican = window[`applican`] || '';
  const textArea = createRef<HTMLTextAreaElement>();
  const message = createRef<HTMLTextAreaElement>();
  const time = createRef<HTMLInputElement>();
  const datetime = createRef<HTMLInputElement>();

  const localNotificationCancel1 = alertId => {
    applican.localNotification.cancel({ alertId });
    textArea!.current!.value = 'Local notification canceled\n';
  };

  const localNotificationSchedule1Success = res => {
    textArea!.current!.value = 'Local notification: in ' + res + '\n';
  };

  const localNotificationSchedule1Error = res => {
    textArea!.current!.value = 'Local notification failed\nError code:' + res.code + '\n';
  };

  const localNotificationSchedule1 = () => {
    const now = Math.floor(new Date().getTime() / 1000);
    const options = {
      alertId: 1,
      alertBody: message!.current!.value || 'message1',
      uri,
      fireDate: now + 5,
      alertAction: 'Open', // iOSのみ
      applicationIconBadgeNumber: 3 // iOSのみ
    };
    applican.localNotification.schedule(
      () => localNotificationSchedule1Success('5 seconds'),
      localNotificationSchedule1Error,
      options
    );
  };

  const handleNotify5Seconds = () => localNotificationSchedule1();

  const handleNotifySpecificTimeEveryday = () => {
    const [hh, mm] = time!.current!.value.split(':');
    const fireDateUnixtime = new Date(2000, 0, 1, parseInt(hh, 10), parseInt(mm, 10), 0).getTime() / 1000;
    const options = {
      alertId: 3,
      alertBody: message!.current!.value || 'message6',
      uri,
      fireDate: fireDateUnixtime,
      repeatInterval: 'day',
      alertAction: 'Open', // iOSのみ
      applicationIconBadgeNumber: 1 // iOSのみ
    };
    applican.localNotification.schedule(
      () => localNotificationSchedule1Success(`${hh}:${mm} everyday`),
      localNotificationSchedule1Error,
      options
    );
  };

  const handleFinalLN = () => {
    const dateInput = datetime!.current!.value;
    const fireDateUnixtime = new Date(`${dateInput}`).getTime() / 1000;
    const options = {
      alertId: 4,
      alertBody: 'message7',
      uri,
      fireDate: fireDateUnixtime,
      repeatInterval: 'month',
      alertAction: '開く', // iOSのみ
      applicationIconBadgeNumber: 1 // iOSのみ
    };
    applican.localNotification.schedule(
      () => localNotificationSchedule1Success(`Local notification: every month\n`),
      localNotificationSchedule1Error,
      options
    );
  };

  return (
    <div>
      <h5>LocalNotification</h5>
      <textarea
        ref={textArea}
        readOnly
        id="dumpAreaLocalNotification"
        className="form-control"
        rows={3}
        defaultValue=""
        placeholder=""
      />
      <textarea ref={message} rows={3} defaultValue="" placeholder="local notification message" />
      <Grid container spacing={24}>
        <Grid item xs={12}>
          <Button variant="contained" color="secondary" fullWidth onClick={handleNotify5Seconds} size="small">
            Notify in 5 seconds
          </Button>
          <Button variant="contained" color="default" fullWidth onClick={() => localNotificationCancel1(1)}>
            Cancel
          </Button>
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="time"
            label="Alarm clock"
            type="time"
            defaultValue="07:30"
            InputLabelProps={{
              shrink: true
            }}
            inputProps={{
              step: 60 // 5 min
            }}
            inputRef={time}
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            variant="contained"
            color="secondary"
            fullWidth
            onClick={handleNotifySpecificTimeEveryday}
            size="small"
          >
            Notify
          </Button>
          <Button
            variant="contained"
            color="default"
            fullWidth
            size="small"
            onClick={() => localNotificationCancel1(3)}
          >
            Cancel
          </Button>
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="datetime-local"
            label="Next appointment"
            type="datetime-local"
            defaultValue={moment().format('YYYY-MM-DDTHH:mm')}
            InputLabelProps={{
              shrink: true
            }}
            inputRef={datetime}
          />
        </Grid>
        <Grid item xs={12}>
          <Button onClick={handleFinalLN} variant="contained" color="secondary" fullWidth>
            Notify
          </Button>
          <Button variant="contained" color="default" fullWidth>
            Cancel
          </Button>
        </Grid>
      </Grid>
    </div>
  );
}
