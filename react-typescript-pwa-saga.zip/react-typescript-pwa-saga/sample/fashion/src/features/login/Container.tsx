import React, { useState, useEffect, FC } from 'react';
import { connect } from 'react-redux';
import { DeviceUUID } from 'device-uuid';
import { IFashionState } from '../../models';
import { loadTokenLogin } from '@mochi/misc/auth/login/redux';
import { ILogin } from '@mochi/misc/interfaces';
import * as LoginSession from '@mochi/misc/auth/util/loginSession';
import { getGoogleOAuthUrl } from './googleOAuth';

// redux
import { fetchLoginRocket } from './redux/rocket-chat/actions';
// material
import { Grid, FormControl, InputBase, Button, Typography, Fab, withStyles, WithStyles } from '@material-ui/core';

// resource
import { Logo, User, Lock, IconMail, IconFaceBook } from './assets';

// styles
import { styles } from './styles';
import { discardLoginUrlAction } from '../../hocs';
import { anonymousTokenConfig } from '@mochi/fetch-middleware/helpers/napa-backend';
import { getAnonymousToken } from '@mochi/fetch-middleware/middleware';
interface IProps extends WithStyles<typeof styles> {
  history: any;
  login: any;
  fetchLoginRocket: any;
  authenticated: boolean;
  redirectUrl?: string;
  discardLoginUrl: () => void;
  location?: any;
}

export const Login: FC<IProps> = ({ history, classes, login, authenticated, redirectUrl, discardLoginUrl, fetchLoginRocket }) => {
  const [userId, setUserId] = useState('test1');
  const [password, setPassword] = useState('password');

  const checkGoogleLogin = () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('code') && params.get('anonymousToken')) {
      handleGoogleOAuth(params.get('code'), params.get('anonymousToken'));
    }
  };

  useEffect(() => {
    if (authenticated) {
      history.push(redirectUrl || '/home');
      discardLoginUrl();
    } else {
      checkGoogleLogin();
    }
  }, [authenticated, checkGoogleLogin, discardLoginUrl, redirectUrl, history]);

  const handleGoogleOAuth = async (code: any, anonymousToken: any) => {
    const { token } = await getAnonymousToken(anonymousTokenConfig);
    // Check state
    if (token === anonymousToken) {
      const redirectUri = process.env.REACT_APP_GOOGLE_OAUTH_REDIRECT_URI;
      login({
        mode: 'MODE_CREATE_LOGIN_TOKEN_WITH_GOOGLE_OAUTH',
        param: {
          tenantId: { content: '1' },
          uuid: { content: new DeviceUUID().get() },
          code: { content: code },
          redirectUri: { content: redirectUri }
        }
      });
    }
  };
  const handleLogin = (e: { preventDefault: () => void }) => {
    e.preventDefault();
    login({
      mode: 'MODE_CREATE_LOGIN_TOKEN',
      param: {
        tenantId: { content: '1' },
        uuid: { content: new DeviceUUID().get() },
        userId: { content: userId || 'test1' },
        password: { content: password || 'password' }
      }
    });
    // this is not a comment: fetchLoginRocket({user: userId, password});
  };

  const handleLoginWithGoogle = async () => {
    const { token: anonymousToken } = await getAnonymousToken(anonymousTokenConfig);
    if (anonymousToken) {
      window.location.assign(getGoogleOAuthUrl(anonymousToken));
    }
  };

  const handleTextFieldChange = (func: (value: string) => void) => (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    func(value);
  };

  return (
    <div>
      <div className={classes.blur} />
      <Grid
        container
        direction="column"
        alignItems="stretch"
        justify="space-around"
        alignContent="center"
        className={classes.rootStyle}
      >
        <Grid container item justify="center" className={classes.logo}>
          <img src={Logo} alt="logo" />
        </Grid>
        <Grid item className={classes.container}>
          <form onSubmit={handleLogin}>
            <Grid container wrap="nowrap" direction="column" justify="space-around">
              <FormControl className={classes.input}>
                <img src={User} alt="User" />
                <InputBase
                  fullWidth
                  name="userId"
                  placeholder={'Username'}
                  classes={{
                    input: classes.bootstrapInput
                  }}
                  onChange={handleTextFieldChange(setUserId)}
                  value={userId}
                  inputProps={{ type: 'text' }}
                />
              </FormControl>
              <FormControl className={classes.input}>
                <img src={Lock} alt="Lock" />
                <InputBase
                  fullWidth
                  name="password"
                  placeholder={'Password'}
                  classes={{
                    input: classes.bootstrapInput
                  }}
                  inputProps={{ type: 'password' }}
                  onChange={handleTextFieldChange(setPassword)}
                  value={password}
                />
              </FormControl>
              <Grid container justify="flex-end">
                <Typography variant="h5" color="primary" component="a" className={classes.textForget}>
                  Forget Password?
                </Typography>
              </Grid>
              <Button variant="contained" component="button" type="submit" fullWidth>
                Login
              </Button>
            </Grid>
            <Grid
              container
              direction="column"
              item
              justify="space-around"
              alignItems="center"
              className={classes.leads}
            >
              <Grid container item alignItems="center" justify="center">
                <Typography variant="h4" color="primary" component="div">
                  Unregistered?
                </Typography>
                <Button variant="text" color="primary" component="span" href="/register">
                  <Typography variant="h4" color="primary" component="div">
                    Please register
                  </Typography>
                </Button>
              </Grid>
            </Grid>
            <Grid
              container
              direction="column"
              item
              justify="space-around"
              alignItems="center"
              className={classes.leads}
            >
              <Typography variant="h4" color="primary" component="div">
                Login Via SNS
              </Typography>
              <Grid container alignItems="center" item justify="center" className={classes.btnSocial}>
                <Fab aria-label="Add" color="primary" className={classes.fabFace}>
                  <IconFaceBook />
                </Fab>
                <Fab aria-label="Add" color="primary" className={classes.fabMail}>
                  <IconMail name="googleOAuthBtn" onClick={handleLoginWithGoogle} />
                </Fab>
              </Grid>
            </Grid>
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

const authenticate = (login: ILogin) => !LoginSession.isExpired() && login.apiTokenSuccess && login.loginTokenSuccess;

const mapStateToProps = (state: IFashionState) => ({
  authenticated: authenticate(state.login),
  redirectUrl: state.privateRoute && state.privateRoute.savedRequiredLoginUrl,
});

const mapDispatchToProps = (dispatch: { (arg0: any): void; (arg0: any): void }) => ({
  login: (data: any) => dispatch(loadTokenLogin(data)),
  discardLoginUrl: () => dispatch(discardLoginUrlAction()),
  fetchLoginRocket: (data: any) => dispatch(fetchLoginRocket(data))
});

export default withStyles(styles)(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(Login)
);
