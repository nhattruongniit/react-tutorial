import * as React from 'react';
import createSvgIcon from '@material-ui/icons/utils/createSvgIcon';

export default createSvgIcon(
  <React.Fragment>
    <g id="Pink-Design-For-Dev" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="Login-Copy-2" transform="translate(-215.000000, -607.000000)" fill="#F8F8F8" fillRule="nonzero">
        <g id="Group-11" transform="translate(117.000000, 589.000000)">
          <g id="Group-7" transform="translate(81.000000, 0.000000)">
            <g id="gmail">
              <path
                d="M40.375,18 L39.5,18 L18.5,18 L17.625,18 C16.176,18 15,19.176 15,20.625 L15,21.5 L15,35.5 L15,36.375 C15,37.824 16.176,39 17.625,39 L18.5,39 L39.5,39 L40.375,39 C41.824,39 43,37.824 43,36.375 L43,35.5 L43,21.5 L43,20.625 C43,19.176 41.824,18 40.375,18 Z M37.2845,19.75 L29,26.2915 L20.7155,19.75 L37.2845,19.75 Z M39.5,37.25 L18.5,37.25 L18.5,22.6305 L29,30.70675 L39.5,22.62875 L39.5,37.25 Z"
                id="Shape"
              />
            </g>
          </g>
        </g>
      </g>
    </g>
  </React.Fragment>,
  'IconMail'
);
