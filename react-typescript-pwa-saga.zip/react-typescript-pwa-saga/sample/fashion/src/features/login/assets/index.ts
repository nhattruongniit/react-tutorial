import Logo from './images/logo.png';
import Boutique from './images/boutique.jpg';
import Lock from './images/lock.png';
import User from './images/user.png';
import IconFaceBook from './images/IconFace';
import IconMail from './images/IconMail';

export { Logo, Boutique, Lock, User, IconFaceBook, IconMail };
