import { getPlatform, PLATFORM, isApplican } from '../../../services/applican';

const {
  REACT_APP_GOOGLE_OAUTH_CLIENT_ID: clientId,
  REACT_APP_GOOGLE_OAUTH_REDIRECT_URI: redirectUri,
  REACT_APP_GOOGLE_OAUTH_ANDROID_URL: androidCallbackUrl,
  REACT_APP_GOOGLE_OAUTH_IOS_URL: iOSCallBackUrl,
  REACT_APP_GOOGLE_OAUTH_WEB_URL: webCallBackUrl
} = process.env;

const googleOAuthUrl = 'https://accounts.google.com/o/oauth2/v2/auth';
const scope = 'email%20profile';

export const getGoogleOAuthPlatform = () => {
  const platform = getPlatform();
  let clientUrl: any;
  switch (platform) {
    case PLATFORM.ANDROID:
      clientUrl = androidCallbackUrl;
      break;
    case PLATFORM.IOS:
      clientUrl = iOSCallBackUrl;
      break;
    default:
      clientUrl = window.location.origin + webCallBackUrl;
  }

  return {
    platform,
    clientUrl
  };
};

export const getGoogleOAuthUrl: any = (anonymousToken: string) => {
  const { platform, clientUrl } = getGoogleOAuthPlatform();
  const state = encodeURI(
    JSON.stringify({
      platform,
      anonymousToken,
      clientUrl
    })
  );

  let url = `${googleOAuthUrl}?client_id=${clientId}&scope=${scope}&redirect_uri=${redirectUri}`;
  url += '&response_type=code&prompt=consent&access_type=offline';
  url += `&state=${state}`;
  url += isApplican() ? '&launch_browser=yes' : '';
  return url;
};
