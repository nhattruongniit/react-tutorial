import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

import { IAccountRocket } from '../../../../models';

export const fetchLoginRocket = (payload: IAccountRocket) => ({ type: FETCH_DATA_REQUEST, payload });

export const fetchLoginRocketSuccess = (payload: IAccountRocket) => ({ type: FETCH_DATA_SUCCESS, payload });

export const fetchLoginRocketFailure = (error: string) => ({ type: FETCH_DATA_FAILURE, payload: { error } });
