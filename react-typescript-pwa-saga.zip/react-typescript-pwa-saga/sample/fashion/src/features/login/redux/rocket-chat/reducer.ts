import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

// model
import { IAction, IAccountRocket } from '../../../../models';

const initialState: IAccountRocket = {
  user: '',
  password: '',
  authToken: ''
};

export function reducer(state: IAccountRocket = initialState, { type, payload }: IAction): IAccountRocket {
  switch (type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        authToken: payload
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: payload.error
      };
    default:
      return state;
  }
}
