import { takeLatest, put, call } from 'redux-saga/effects';

import { FETCH_DATA_REQUEST } from './constants';
import { fetchLoginRocketSuccess } from './actions';

const { REACT_APP_ROCKET_CHAT_SERVER: urlServerRC } = process.env;

function loginRocketChat (user, password) {
  return fetch(urlServerRC + '/api/v1/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ user: user + '@example.com', password })
  });
}

function registerRocketChat (user, password) {
  return fetch(urlServerRC + '/api/v1/users.register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username: user, email: user + '@example.com', pass: password, name: user })
  });
}

function* fetchData ({ payload, type }) {
  const { user, password } = payload;
  const res = yield loginRocketChat(user, password);

  if(res.status === 200) {
    const {data: { authToken }} = yield call({context: res, fn: res.json});
    localStorage.setItem('_AuthTokenRC', authToken)
    yield put(fetchLoginRocketSuccess(authToken));
  } else {
    yield registerRocketChat(user, password);
    const resLogin = yield loginRocketChat (user, password);
    const {data: { authToken }} = yield call({context: resLogin, fn: resLogin.json});
    localStorage.setItem('_AuthTokenRC', authToken)
    yield put(fetchLoginRocketSuccess(authToken));
  }
}
export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchData);
}
