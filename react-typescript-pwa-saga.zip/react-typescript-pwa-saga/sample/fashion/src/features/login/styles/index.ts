// material
import { createStyles, Theme } from '@material-ui/core';

import { Boutique } from '../assets';

export const styles = (theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
      flexWrap: 'wrap'
    },
    rootStyle: {
      backgroundImage: `url(${Boutique})`,
      backgroundRepeat: ' no-repeat',
      backgroundSize: 'cover',
      minHeight: '100vh',
      padding: '15px',
      zIndex: 1
    },
    container: {
      width: 293,
      margin: '20px auto 0'
    },
    fabFace: {
      backgroundColor: '#083871',
      marginRight: '25px',
      width: '57px',
      height: '57px',
      borderRadius: '50%'
    },
    fabMail: {
      backgroundColor: '#ab2020',
      width: '57px',
      height: '57px',
      marginRight: '25px',
      borderRadius: '50%',
      '& svg': {
        width: '34px'
      }
    },
    fabRocket: {
      backgroundColor: '#FF9933',
      width: '57px',
      height: '57px',
      borderRadius: '50%',
      '& svg': {
        width: '34px'
      }
    },
    input: {
      padding: '0 20px',
      height: '43px',
      borderRadius: '8px',
      backgroundColor: '#ffffff',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'row',
      '& + &': {
        marginTop: 36
      }
    },
    bootstrapInput: {
      borderRadius: 4,
      position: 'relative',
      backgroundColor: theme.palette.common.white,
      border: '0',
      fontSize: 16,
      padding: '10px 12px'
    },
    blur: {
      backgroundColor: '#590927',
      width: '100%',
      height: '100%',
      zIndex: 0,
      position: 'fixed',
      top: 0,
      left: 0,
      opacity: 0.91
    },
    logo: {
      zIndex: 1
    },
    textForget: {
      margin: '25px 0',
      textDecoration: 'underline'
    },
    leads: {
      margin: '30px 0 40px 0'
    },
    btnSocial: {
      marginTop: 20
    }
  });
