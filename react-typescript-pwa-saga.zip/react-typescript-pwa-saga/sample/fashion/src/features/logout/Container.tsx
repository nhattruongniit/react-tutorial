import * as React from 'react';
import { Redirect } from 'react-router';
import { connect } from 'react-redux';

// core
import * as LoginSession from '@mochi/misc/auth/util/loginSession';
import reducer, { loadTokenLogout, logoutFlow as saga } from '@mochi/misc/auth/logout/redux';

import { IFashionState } from '../../models';

// core
import { injectSaga } from '@mochi/core';
import { injectReducer } from '@mochi/misc';

function Logout({ logOutStatus, logout }) {
  React.useEffect(() => {
    injectReducer('logoutApiToken', reducer);
    injectSaga('logoutSaga', saga);
    logout();
  }, [logout]);
  return logOutStatus ? <Redirect to="/login" /> : <div>Log out...</div>;
}

export default connect(
  (state: IFashionState) => ({
    logOutStatus:
      LoginSession.isExpired() &&
      state.logoutApiToken &&
      !(state.logoutApiToken as any).loginTokenSuccess &&
      !(state as any).logoutApiToken.apiTokenSuccess
  }),
  dispatch => ({ logout: () => dispatch(loadTokenLogout()) })
)(Logout);
