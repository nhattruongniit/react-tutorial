import * as React from 'react';
import Barcode from 'react-barcode';
import { Grid } from '@material-ui/core';

interface IProps {
  code: string;
}

const BarcodeOptions = {
  height: 80,
  background: '#fff',
  textAlign: 'center',
  format: 'EAN13'
};

function Barcodes(props: IProps) {
  return (
    <Grid container justify="center" alignContent="center" style={{ border: '1px solid #291E2D', borderRadius: '8px' }}>
      <Barcode value={props.code} Options={BarcodeOptions} />
    </Grid>
  );
}
export default Barcodes;
