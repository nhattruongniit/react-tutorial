import * as React from 'react';
import { Grid, Typography } from '@material-ui/core';
import StarBorder from '@material-ui/icons/StarBorder';
import Star from '@material-ui/icons/Star';

import CardBox from './CardBox';
import { StarHalf } from '@material-ui/icons';

interface IProps {
  square: boolean;
  name: string;
  id: number;
  rating: any;
  point: number;
  level: string;
}

function showRating(rating: number) {
  const star = Math.floor(rating);
  const haveHalf = rating !== star;
  const rates: React.ReactElement[] = [];

  for (let i = 1; i <= 5; i++) {
    if (i <= star) {
      rates.push(<Star key={i} />);
    } else {
      if (i === star + 1) {
        if (haveHalf) {
          rates.push(<StarHalf key={i} />);
        } else {
          rates.push(<StarBorder key={i} />);
        }
      } else {
        rates.push(<StarBorder key={i} />);
      }
    }
  }

  return rates;
}

function BoxPoint(props: IProps) {
  return (
    <CardBox square={props.square} color="#E181A6">
      <Grid container={true} direction="column" justify="flex-start">
        <Typography variant="h3" color="primary">
          {props.name}
        </Typography>

        <Grid container={true} direction="row" justify="space-between" style={{ marginTop: '11px' }}>
          <Typography variant="h4" color="primary">
            ID: {props.id}
          </Typography>

          <Typography component="h6" color="primary">
            {showRating(props.rating)}
          </Typography>
        </Grid>

        <Grid container={true} direction="column" alignItems="center" style={{ marginTop: '10px' }}>
          <Typography variant="h2" color="primary">
            {props.point}pt
          </Typography>

          <Typography color="primary">{props.level}</Typography>
        </Grid>
      </Grid>
    </CardBox>
  );
}
export default BoxPoint;
