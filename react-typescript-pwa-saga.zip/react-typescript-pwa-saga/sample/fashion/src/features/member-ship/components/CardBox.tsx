import * as React from 'react';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import { Grid, Paper } from '@material-ui/core';

const styles = (theme: any) => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    margin: `${theme.spacing.unit}px 0`,
    height: '159px'
  }
});

function CardBox(props: any) {
  const { classes, className } = props;
  return (
    <Grid container={true} justify="center" wrap="nowrap">
      <Grid item={true} xs={12}>
        <Paper
          elevation={0}
          square={props.square}
          className={classNames(classes.root, className)}
          style={{
            background: props.color,
            borderWidth: props.borderWidth,
            borderColor: props.borderColor,
            borderStyle: props.borderStyle,
            margin: props.margin
          }}
        >
          <Grid container={true} justify="center">
            {props.children}
          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
}
export default withStyles(styles)(CardBox);
