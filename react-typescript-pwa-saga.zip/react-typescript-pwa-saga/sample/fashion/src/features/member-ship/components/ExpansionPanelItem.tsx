import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

interface IProps {
  classes?: any;
  title: string;
  content: string;
}

function ExpansionPanelItem(props: IProps) {
  const { classes } = props;
  return (
    <div className={classes.root}>
      <ExpansionPanel square={true}>
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon className={classes.icon} />}>
          <Typography className={classes.heading} color="primary">
            {props.title}
          </Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography component="p" color="textPrimary">
            {props.content}
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
  );
}
const styles = theme => ({
  root: {
    boxShadow: 'none'
  },
  heading: {
    fontSize: theme.typography.pxToRem(16),
    fontWeight: theme.typography.fontWeightReglar,
    flexShrink: 0,
    maxHeight: 50,
    margin: '0 auto',
    '&:last-child': {
      paddingRight: 0
    }
  },
  icon: {
    color: 'white',
    maxHeight: '50px !important'
  }
});
export default withStyles(styles)(ExpansionPanelItem);
