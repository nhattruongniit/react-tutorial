import * as React from 'react';
import { Link } from 'react-router-dom';
import { Typography, Grid } from '@material-ui/core';
interface IProps {
  to: string;
  label: string;
  icon: any;
}

const LinkMaterial = (props: IProps) => {
  return (
    <Link to={props.to} style={{ textDecoration: 'none' }}>
      <Grid container justify="center">
        <Typography gutterBottom component="span" color="textPrimary">
          {props.icon}
        </Typography>
        <Typography gutterBottom component="span" color="textPrimary">
          {props.label}
        </Typography>
      </Grid>
    </Link>
  );
};

export default LinkMaterial;
