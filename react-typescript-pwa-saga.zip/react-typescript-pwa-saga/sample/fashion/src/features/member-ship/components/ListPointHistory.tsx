import * as React from 'react';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

import Typography from '@material-ui/core/Typography';
import Place from '@material-ui/icons/Place';
import WatchLater from '@material-ui/icons/WatchLater';
import TextInline from './TextInline';

interface IProps {
  title: string;
  time: string;
  totalAmount: number;
  totalPointsReceived: number;
  totalPointsUsed: number;
  classes?: any;
  style?: any;
}

const styles = (theme: any) => ({
  place: {
    margin: '0px -4px',
    fontSize: '18px'
  }
});

function ListPointHistory(props: IProps) {
  const { classes }: any = props;
  return (
    <List style={props.style}>
      <ListItem alignItems="flex-start">
        <Place className={classes.place} />
        <ListItemText
          style={{ padding: '0 7px' }}
          primary={<Typography variant="h6">{props.title}</Typography>}
          secondary={
            <React.Fragment>
              <Typography
                component="span"
                style={{ color: '#111111', fontFamily: 'Helvetica', fontSize: '12px', margin: '14px 0' }}
              >
                <WatchLater style={{ fontSize: '15px', verticalAlign: 'sub' }} color="disabled" /> {props.time}
              </Typography>

              <TextInline label="The total amount of purchases" value={`¥ ${props.totalAmount}`} />

              <TextInline label="Points received" value={props.totalPointsReceived} />

              <TextInline label="Points used" value={`${props.totalPointsUsed} pt`} />
            </React.Fragment>
          }
        />
      </ListItem>
    </List>
  );
}

export default withStyles(styles)(ListPointHistory);
