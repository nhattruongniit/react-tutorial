import * as React from 'react';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';

interface IPRops {
  label: string;
  value: number | string
}

function TextInline(props: IPRops) {
  return (
    <Grid component="span" container={true} direction="row" justify="space-between" style={{ margin: '8px 0' }}>
      <Typography component="span">{props.label}</Typography>

      <Typography component="span">{props.value}</Typography>
    </Grid>
  );
}
export default TextInline;
