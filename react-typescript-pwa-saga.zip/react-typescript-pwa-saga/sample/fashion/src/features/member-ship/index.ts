import MemberShip from './pages/Membership';

export default MemberShip;
