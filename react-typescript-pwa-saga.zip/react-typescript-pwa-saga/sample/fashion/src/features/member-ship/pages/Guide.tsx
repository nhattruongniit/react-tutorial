import * as React from 'react';
import ExpansionPanelItem from '../components/ExpansionPanelItem';
import { Grid } from '@material-ui/core';

const PanelItem = [
  {
    title: 'About Point',
    content:
      '高ソシウ行5活翼52情イぼぴ三之ぐそ測暮ぐをいす屋養なもひお済辞勝せき建6次フオヒモ展医だ。球ミテヒヘ全視エ模講口タ響歌こき岸断み高札よむとな昨9迫ッばえが概族コホ著6帯マ介争効段究ょ。入型ゅがぜ印加本ヲヨハミ判定たふてみ指城リユニロ選都促てぞわけ領形アトニヒ再懲新サレ称健しかては位秋ぱで線木ろにくゃ雑時ヌ達那オコエ岩傾ネセコト第沸く済化庫せひかめ。'
  },
  {
    title: 'Membership Rank',
    content:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
  },
  {
    title: 'How to get point',
    content:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
  }
];

const Guide = () => {
  return (
    <Grid style={{ marginTop: 10 }}>
      {PanelItem.map((val, index) => (
        <ExpansionPanelItem key={index} title={val.title} content={val.content} />
      ))}
    </Grid>
  );
};
export default Guide;
