import * as React from 'react';
import { Grid, Typography } from '@material-ui/core';
import ListPointHistory from '../components/ListPointHistory';
import BoxPoint from '../components/BoxPoint';
import { connect } from 'react-redux';
import { fetchHistory } from './../redux/history/actions';
import { IFashionState } from '../../../models';

interface IHistory {
  title: string;
  date: string;
  totalAmount: number;
  pointsReceived: number;
  pointsUsed: number;
}

const renderPointHistoryList = (historyList: { data: any[] }) => {
  const { data } = historyList;
  return data.map((val: IHistory, key: number) => {
    return (
      <ListPointHistory
        key={key}
        title={val.title}
        time={val.date}
        totalAmount={val.totalAmount}
        totalPointsReceived={val.pointsReceived}
        totalPointsUsed={val.pointsUsed}
        style={{ backgroundColor: key % 2 !== 0 ? '#f2f2f2' : '#ffffff', padding: 0 }}
      />
    );
  });
};

function History({ fetchHistory: actHistory, historyList }) {
  React.useEffect(() => {
    actHistory();
  }, [actHistory]);

  return (
    <div key="PointHistoryItem" className="container-fluid">
      <div className="row">
        <BoxPoint square={true} name="山田 太郎 様" id={1239483822} rating={1} point={67} level="Standard" />

        <div style={{ overflow: 'hidden' }}>
          <Grid
            container={true}
            direction="column"
            alignItems="flex-start"
            style={{
              padding: '10px 0',
              borderBottom: '1px solid #111111'
            }}
          >
            <Typography variant="h3" color="textPrimary" style={{ marginLeft: '7px', fontWeight: 'bolder' }}>
              Point History
            </Typography>
          </Grid>
          {renderPointHistoryList(historyList)}
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (state: IFashionState) => {
  const { history } = state;
  return { historyList: history };
};

const mapDispatchToProps = {
  fetchHistory
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(History);
