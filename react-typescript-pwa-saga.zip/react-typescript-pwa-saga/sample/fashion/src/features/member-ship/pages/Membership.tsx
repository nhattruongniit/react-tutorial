import * as React from 'react';
import { Grid } from '@material-ui/core';
import History from '@material-ui/icons/History';
import Highlight from '@material-ui/icons/Highlight';
import BoxPoint from '../components/BoxPoint';
import Barcodes from '../components/Barcodes';
import LinkMaterial from '../components/Link';
import CumulativeProcess from '../asset/img/CumulativeProcess.png';
import { connect } from 'react-redux';
import { fetchMembership } from '../redux/membership/actions';
import { IFashionState } from '../../../models';

const Membership = ({ fetchMembership: getDataMembership, InfoUser }) => {
  React.useEffect(() => {
    getDataMembership();
  }, [getDataMembership]);

  return (
    <Grid style={{ padding: '0 2%', marginTop: 10 }}>
      <Barcodes code={InfoUser.data.barCode} />

      <BoxPoint
        square={false}
        name={InfoUser.data.name}
        id={InfoUser.data.id}
        point={InfoUser.data.point}
        level={InfoUser.data.level}
        rating={InfoUser.data.rating}
      />

      <Grid container={true} direction="column" justify="flex-start">
        <img src={CumulativeProcess} alt="rating" width="100%" />
      </Grid>

      <Grid container={true} direction="row" justify="space-between" style={{ margin: '15px 0' }}>
        <LinkMaterial icon={<History />} to="/membership/history" label="Point History" />
        <LinkMaterial icon={<Highlight />} to="/membership/guide" label="Learn Point" />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: IFashionState) => {
  const { user } = state;
  return { InfoUser: user };
};

const mapDispatchToProps = {
  fetchMembership
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Membership);
