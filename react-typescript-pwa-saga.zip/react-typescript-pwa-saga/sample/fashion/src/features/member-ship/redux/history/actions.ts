import { HISTORY_REQUEST, HISTORY_SUCCESS, HISTORY_FAILURE } from './constants';
import { IHistory } from '../../../../models/IHistory';

export const fetchHistory = () => ({ type: HISTORY_REQUEST });
export const fetchProductSuccess = (payload: IHistory) => ({ type: HISTORY_SUCCESS, payload });
export const fetchProductFailure = (error: string) => ({ type: HISTORY_FAILURE, payload: { error } });
