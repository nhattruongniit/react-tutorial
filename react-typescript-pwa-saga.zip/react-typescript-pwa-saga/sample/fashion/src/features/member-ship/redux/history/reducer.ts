import { HISTORY_SUCCESS, HISTORY_FAILURE } from './constants';
import { IAction, IHistory } from '../../../../models';
import { handleActions } from 'redux-actions';

const initialState: IHistory = {
  data: [],
  total: 0,
  page: 1,
  error: ''
};

export const reducer = handleActions(
  {
    [HISTORY_SUCCESS]: (state, { payload }: IAction) => {
      return {
        ...state,
        data: payload,
        total: payload.total
      };
    },
    [HISTORY_FAILURE]: (state, { payload }) => {
      return { ...state, error: payload.error };
    }
  },
  initialState
);
