import { HISTORY_REQUEST, HISTORY_SUCCESS, HISTORY_FAILURE } from './constants';
import { put, takeLatest, takeEvery } from 'redux-saga/effects';

// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi, FetchApiStatus } from '@mochi/core';

function* getHistoryFromApi() {
  const request = yield makeMockJsonRequest('History', 'pointHistory');
  yield put(fetchApi(request));
  yield takeEvery(FETCH_API.SUCCESS, fetchHistory);
  yield takeEvery(FETCH_API.FAILURE, fetchHistory);
}

function* fetchHistory(action) {
  if (action.payload.request.key !== 'History') {
    return;
  }

  action.payload.status !== FetchApiStatus.Error
    ? yield put({ type: HISTORY_SUCCESS, payload: action.payload.httpResponseJson })
    : yield put({ type: HISTORY_FAILURE, payload: 'error' });
}

export function* watchFetchHistory() {
  yield takeLatest(HISTORY_REQUEST, getHistoryFromApi);
}
