import { MEMBERSHIP_REQUEST, MEMBERSHIP_SUCCESS, MEMBERSHIP_FAILURE } from './constants';
import { IUser } from '../../../../models/IUser';

export const fetchMembership = () => ({ type: MEMBERSHIP_REQUEST });
export const fetchMembershipSuccess = (payload: IUser) => ({ type: MEMBERSHIP_SUCCESS, payload });
export const fetchMembershipFailure = (error: string) => ({ type: MEMBERSHIP_FAILURE, payload: { error } });
