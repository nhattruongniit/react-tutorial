import { MEMBERSHIP_SUCCESS, MEMBERSHIP_FAILURE } from './constants';
import { IAction, IUser } from '../../../../models';
import { handleActions } from 'redux-actions';

const initialState: IUser = {
  data: [],
  total: 0,
  page: 1,
  error: ''
};

export const reducer = handleActions(
  {
    [MEMBERSHIP_SUCCESS]: (state, { payload }: IAction) => {
      return {
        ...state,
        data: payload,
        total: payload.total
      };
    },
    [MEMBERSHIP_FAILURE]: (state, { payload }) => {
      return { ...state, error: payload.error };
    }
  },
  initialState
);
