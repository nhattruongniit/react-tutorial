import { MEMBERSHIP_REQUEST, MEMBERSHIP_SUCCESS, MEMBERSHIP_FAILURE } from './constants';
import { put, takeLatest, takeEvery } from 'redux-saga/effects';

// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi, FetchApiStatus } from '@mochi/core';

function* getUserFromApi() {
  const request = yield makeMockJsonRequest('User', 'user');
  yield put(fetchApi(request));
  yield takeEvery(FETCH_API.SUCCESS, fetchUser);
  yield takeEvery(FETCH_API.FAILURE, fetchUser);
}

function* fetchUser(action) {
  if (action.payload.request.key !== 'User') {
    return;
  }

  action.payload.status !== FetchApiStatus.Error
    ? yield put({ type: MEMBERSHIP_SUCCESS, payload: action.payload.httpResponseJson })
    : yield put({ type: MEMBERSHIP_FAILURE, payload: 'error' });
}

export function* watchFetchMembership() {
  yield takeLatest(MEMBERSHIP_REQUEST, getUserFromApi);
}
