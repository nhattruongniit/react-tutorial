import React from 'react';
import Navigation from '../../common/components/navigation';
import ResponsiveHeader from '../../common/components/responsive-header';

export default function TestNavigation() {
  return (
    <div>
      <Navigation />
      <ResponsiveHeader />
    </div>
  );
}
