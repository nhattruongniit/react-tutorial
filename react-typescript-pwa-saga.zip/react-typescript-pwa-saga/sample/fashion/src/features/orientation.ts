const { width, height } = window.screen;

export const orientationLandscape: any = {
  '@global': {
    'html, body': {
      width: '100%',
      height: '100%'
    },
    '@media screen and (max-device-width : 1024px) and (orientation: landscape)': {
      html: {
        transform: 'rotate(-90deg)',
        transformOrigin: 'left top',
        width: '100vh',
        height: width > height ? width : height,
        overflowX: 'scroll',
        position: 'absolute',
        top: '100%',
        left: 0
      }
    }
  }
};

export const orientationPortrait: any = {
  '@global': {
    'html, body': {
      width: '100%',
      height: '100%'
    },
    '@media screen and (max-device-width : 1024px) and (orientation: portrait)': {
      html: {
        transform: 'rotate(-90deg)',
        transformOrigin: 'top left',
        height: '100%',
        width: width > height ? width : height,
        overflow: 'scroll',
        position: 'absolute',
        top: '100%',
        left: 0
      }
    }
  }
};

export const lockPortrait: any = {
  orientation_portrait: {
    '@global': {
      'html, body': {
        width: '100%',
        height: '100%'
      },
      '@media screen and (max-device-width : 1024px) and (orientation:  portrait)': {
        // lock portrait
        body: {
          transform: 'rotate(0deg)',
          transformOrigin: 'left top',
          width: width > height ? height : width,
          height: '100%',
          overflowX: 'scroll',
          position: 'absolute',
          top: 0,
          left: 0
        }
      },
      '@media screen and (max-device-width : 1024px) and (orientation:  landscape)': {
        body: {
          transform: 'rotate(-90deg)',
          transformOrigin: 'left top',
          width: width > height ? height : width,
          height: width > height ? width : height,
          overflowX: 'scroll',
          position: 'absolute',
          top: '100%',
          left: 0
        }
      }
    }
  }

};

export const lockLandscape: any = {
  orientation_landscape: {
    '@global': {
      'html, body': {
        width: '100%',
        height: '100%'
      },
      '@media screen and (max-device-width : 1024px) and (orientation:  portrait)': {
        // lock portrait
        html: {
          transform: 'rotate(-90deg)',
          transformOrigin: 'left top',
          width: width > height ? width : height,
          height: width > height ? width : height,
          overflowX: 'scroll',
          position: 'absolute',
          top: '100%',
          left: 0
        }
      },
      '@media screen and (max-device-width : 1024px) and (orientation:  landscape)': {
        html: {
          transform: 'rotate(0deg)',
          transformOrigin: 'left top',
          width: width > height ? width : height,
          height: width > height ? width : height,
          overflowX: 'scroll',
          position: 'absolute',
          top: 0,
          left: 0
        }
      }
    }
  }

};

export const UnLock: any = {
  '@global': {
    'html, body': {
      width: '100%',
      height: '100%'
    },
    '@media screen and (max-device-width : 1024px) and (orientation:  portrait)': {
      // lock portrait
      html: {
        transform: 'none',
        transformOrigin: 'unset',
        width: '100%',
        height: '100%',
        overflowX: 'scroll',
        position: 'absolute',
        top: 0,
        left: 0
      }
    },
    '@media screen and (max-device-width : 1024px) and (orientation:  landscape)': {
      html: {
        transform: 'rotate(0deg)',
        width: '100%',
        height: 'auto',
        overflowX: 'scroll',
        position: 'absolute',
        top: 0,
        left: 0
      }
    }
  }
};
