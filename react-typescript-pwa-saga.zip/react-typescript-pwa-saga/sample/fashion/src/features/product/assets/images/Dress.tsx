import * as React from 'react';
import createSvgIcon from '@material-ui/icons/utils/createSvgIcon';

export default createSvgIcon(
  <>
    <g id="icon_24x24" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="dress" transform="translate(5.000000, 1.000000)" fill="#111111" fillRule="nonzero">
        <polygon
          id="Shape"
          points="10.4242837 9 11.5 5.75162915 10.1779895 3.08991779 10.1779895 0 8.90679368 0 8.90679368 2.97678464 7 4.89621591 5.09320632 2.97678464 5.09320632 0 3.82201053 0 3.82201053 3.08991779 2.5 5.75162915 3.57571634 9"
        />
        <path
          d="M14,18.8173432 C14,15.7555278 12.9337595,12.8200242 10.9921875,10.5 L3.00781252,10.5 C1.06624051,12.8200242 0,15.7555278 0,18.8173432 L0,19.3388347 L14,22 L14,18.8173432 Z"
          id="Shape"
        />
      </g>
    </g>
  </>,
  'Dress'
);
