import * as React from 'react';
import createSvgIcon from '@material-ui/icons/utils/createSvgIcon';

export default createSvgIcon(
  <React.Fragment>
    <g id="Pink-Design-For-Dev" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g
        id="Detail-Product"
        transform="translate(-123.000000, -540.000000)"
        fill="#FFFFFF"
        fillRule="nonzero"
        stroke="#9B9B9B"
      >
        <g id="check-mark-button" transform="translate(124.000000, 541.000000)">
          <path
            d="M13.5885518,0.482038849 L5.40561593,8.66560413 L2.41129088,5.67127908 C1.85988689,5.11924564 0.965429063,5.11924564 0.41402508,5.67127908 C-0.13800836,6.22268306 -0.13800836,7.11714089 0.41402508,7.66854487 L4.40729776,11.6618176 C4.68299975,11.9375195 5.0449373,12.076 5.40624539,12.076 C5.76755348,12.076 6.12886157,11.938149 6.40456356,11.6618176 L15.586447,2.4799341 C16.137851,1.92790066 16.137851,1.03407229 15.586447,0.482038849 C15.0344136,-0.069365134 14.1405852,-0.069365134 13.5885518,0.482038849 Z"
            id="Shape"
          />
        </g>
      </g>
    </g>
  </React.Fragment>,
  'SelectedColorCheck'
);
