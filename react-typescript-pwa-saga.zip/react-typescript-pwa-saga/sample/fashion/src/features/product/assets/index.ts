import Dress from './images/Dress';
import Eyeglasses from './images/Eyeglasses';
import Necklace from './images/Necklace';
import Shirt from './images/Shirt';
import Trousers from './images/Trousers';
import TShirt from './images/TShirt';
import WomenCoat from './images/WomenCoat';
import WomenTop from './images/WomenTop';
import Point from './images/point.png';
import ProductDescription from './images/ProductDescription';
import SelectedColorCheck from './images/SelectedColorCheck';

export {
  Dress,
  Eyeglasses,
  Necklace,
  Shirt,
  Trousers,
  TShirt,
  WomenCoat,
  WomenTop,
  Point,
  SelectedColorCheck,
  ProductDescription
};
