import React from 'react';
import { Theme, createStyles, withStyles, Grid } from '@material-ui/core';
import classnames from 'classnames';

const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      '& > div': {
        display: 'flex',
        width: '100%',
        justifyContent: 'center',
        textAlign: 'center'
      }
    },
    boxGrid: {
      margin: 0
    },
    icon: {
      height: 55,
      width: 55,
      border: '1px solid #282A39',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      '& svg': {
        width: 30,
        height: 30
      }
    },
    name: {
      color: '#111111',
      fontFamily: 'Helvetica Neue',
      fontSize: 14,
      paddingBottom: 12
    }
  });

class CategoryItem extends React.Component<any, any> {
  render() {
    const { classes, data } = this.props;

    return (
      <Grid
        item={true}
        container={true}
        spacing={8}
        wrap={this.props.isWrap}
        xs={this.props.xs}
        justify="flex-start"
        direction={this.props.direction}
        alignContent="center"
        className={classnames(classes.boxGrid, classes.root)}
      >
        <div>
          <div className={classes.icon}>{data.icon}</div>
        </div>
        <div className={classes.name}>{data.name}</div>
      </Grid>
    );
  }
}

export default withStyles(styles)(CategoryItem);
