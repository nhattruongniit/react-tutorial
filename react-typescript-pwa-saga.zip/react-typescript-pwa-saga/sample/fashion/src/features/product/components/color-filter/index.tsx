import React from 'react';
import { Theme, createStyles, withStyles } from '@material-ui/core';

const styles = ({ palette }: Theme) =>
  createStyles({
    color: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingRight: 10
    },
    checkbox: {
      width: 25,
      height: 21,
      backgroundColor: '#f19224',
      position: 'relative',
      border: '1px solid #979797',
      '& input': {
        width: '100%',
        height: '100%',
        opacity: 0,
        position: 'absolute',
        zIndex: 9
      },
      '&.active': {
        border: '1px solid #f00',
        opacity: 1
      },
      '& input:checked ~ span': {
        border: '1px solid #f00',
        width: '100%',
        height: '100%',
        position: 'absolute',
        top: 0,
        left: 0
      }
    }
  });

interface IProps {
  classes: any;
  handleChooseColor: any;
}

export const ColorFilter: React.FunctionComponent<IProps> = ({ classes, handleChooseColor }) => {
  const arrColors = ['#F19224', '#F6D9DD', '#ECD3F2', '#F5E4C9', '#EAAEB1', '#FFF'];
  return (
    <div className={classes.color}>
      {arrColors.map(name => (
        <div key={name} className={classes.checkbox} style={{ backgroundColor: name }}>
          <input type="checkbox" name="color" id={name} value={name} onClick={handleChooseColor} />
          <span />
        </div>
      ))}
    </div>
  );
};

export default withStyles(styles)(ColorFilter);
