import React from 'react';
import SwipeableViews from 'react-swipeable-views';

// material ui
import { withStyles } from '@material-ui/core/styles';
import MobileStepper from '@material-ui/core/MobileStepper';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@material-ui/icons';

const styles = (theme: { spacing: { unit: number }; palette: { background: { default: any } } }) => ({
  root: {
    maxWidth: 400,
    flexGrow: 1,
    '& .swippeable': {
      marginLeft: 50,
      marginRight: 50,
      marginTop: 10,
      zIndex: 10,
      '& .react-swipeable-view-container > div': {
        display: 'flex',
        alignItems: 'center',
        justifyItems: 'center'
      }
    },
    '& button': {
      width: 50,
      background: 'transparent',
      padding: 0
    },
    '& .navigate': {
      display: 'flex',
      justifyContent: 'space-between',
      width: 'calc( 100% - 2px )',
      top: 'calc( 50% - 45px )',
      zIndex: 1,
      '& svg': {
        fontSize: 66,
        color: '#291E2D'
      },
      '& > svg:first-child': {
        marginLeft: -10
      },
      '& > svg:nth-child(2)': {
        marginRight: -10
      }
    }
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    height: 50,
    paddingLeft: theme.spacing.unit * 4,
    backgroundColor: theme.palette.background.default
  },
  img: {
    overflow: 'hidden',
    display: 'block',
    width: '100%'
  },
  mobileStepper: {
    padding: 0,
    background: 'transparent',
    justifyContent: 'center',
    marginTop: 10,
    '& > div > div': {
      width: 12,
      height: 12
    },
    '& div[class*="-dot-"]': {
      backgroundColor: 'transparent',
      border: '1px solid #979797'
    },
    '& div[class*="-dotActive-"]': {
      backgroundColor: '#291E2D'
    }
  }
});

class Gallery extends React.Component<any, any> {
  state = {
    activeStep: 0
  };

  handleNext = () => {
    this.setState((prevState: { activeStep: number }) => {
      if (prevState.activeStep < this.props.images.length - 1) {
        prevState.activeStep++;
      }
      return prevState;
    });
  };

  handleBack = () => {
    this.setState((prevState: { activeStep: number }) => {
      if (prevState.activeStep > 0) {
        prevState.activeStep--;
      }
      return prevState;
    });
  };

  handleStepChange = (activeStep: number) => {
    this.setState({ activeStep });
  };

  componentWillReceiveProps(nextProps: { activeImageId: any }) {
    if (!nextProps.activeImageId || this.props.activeImageId === nextProps.activeImageId) {
      return;
    }
    if (!this.props.images) {
      return;
    }
    this.props.images.map((image: { id: any }, key: any) => {
      if (image.id === nextProps.activeImageId) {
        this.setState((prevState: any) => {
          return { ...prevState, activeStep: key };
        });
        return true;
      }
      return false;
    });
  }

  render() {
    const { classes, theme } = this.props;
    const { activeStep } = this.state;

    const maxSteps = this.props.images.length;

    return (
      <div className={classes.root} style={{ position: 'relative' }}>
        <SwipeableViews
          className="swippeable"
          style={{ position: 'relative' }}
          axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
          index={activeStep}
          onChangeIndex={this.handleStepChange}
          enableMouseEvents={true}
        >
          {this.props.images.map((step: { src: string }, index: number) => (
            <div key={index}>
              {Math.abs(activeStep - index) <= 2 ? <img className={classes.img} src={step.src} alt="Step" /> : null}
            </div>
          ))}
        </SwipeableViews>
        <MobileStepper
          position="static"
          steps={maxSteps}
          activeStep={activeStep}
          className={classes.mobileStepper}
          nextButton={<></>}
          backButton={<></>}
        />
        <div className="navigate" style={{ position: 'absolute' }}>
          <KeyboardArrowLeft onClick={this.handleBack} />
          <KeyboardArrowRight onClick={this.handleNext} />
        </div>
      </div>
    );
  }
}

export default withStyles(styles, { withTheme: true })(Gallery);
