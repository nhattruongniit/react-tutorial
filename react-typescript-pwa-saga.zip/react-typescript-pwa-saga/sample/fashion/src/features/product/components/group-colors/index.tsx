import React from 'react';
import OptionColor from '../option-color';

export default class GroupColors extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = { selectedIndex: 0, selectedValue: this.props.values[0] };
  }

  optionItem = (item: { code: string; border: string }, key: number): any => {
    return (
      <OptionColor
        color={item.code}
        border={item.border}
        key={key}
        selected={key === this.state.selectedIndex}
        onClick={(e: any) => {
          this.setState(() => {
            return { selectedIndex: key, selectedValue: item };
          });
          this.props.onSelect(item, key);
        }}
      />
    );
  };

  render() {
    const { values } = this.props;
    const options: any[] = [];
    values.map((item: any, key: any) => {
      options.push(this.optionItem(item, key));
      return null;
    });
    return options;
  }
}
