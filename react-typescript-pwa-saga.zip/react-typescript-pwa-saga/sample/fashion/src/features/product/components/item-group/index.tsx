import React, { FC } from 'react';
import { createStyles, withStyles, WithStyles } from '@material-ui/core';
import { GridView } from '../../../../common/components';

const styles = createStyles({
  title: {
    height: 40,
    width: '100%',
    background: 'linear-gradient(220.44deg, #3B081B 0%, #5A0B29 46.35%, #850F3B 100%)',
    color: '#FFFFFF',
    fontFamily: 'Helvetica Neue',
    fontSize: 18,
    fontWeight: 'bold',
    lineHeight: '38px',
    '& span': {
      paddingLeft: 10
    }
  },
  viewMore: {
    right: 10,
    top: 0,
    color: '#FFFFFF',
    fontFamily: 'Helvetica Neue',
    fontSize: 14,
    fontWeight: 'bold',
    textDecoration: 'underline'
  }
});

interface IProps extends WithStyles<typeof styles> {
  className: string;
  title: string;
  isViewMore: boolean;
  xs?: number;
  items: any;
  viewMoreHref?: string;
  viewMoreText?: string;
  viewMoreOnClick?: any;
  itemRender: any;
}

const ItemsGroup: FC<IProps> = ({
  className,
  title,
  isViewMore,
  xs,
  items,
  viewMoreHref,
  viewMoreText,
  viewMoreOnClick,
  itemRender,
  classes
}) => {
  return (
    <div className={className}>
      <div className={classes.title} style={{ position: 'relative' }}>
        <span>{title}</span>
        {isViewMore && (
          <a
            style={{ position: 'absolute' }}
            className={classes.viewMore}
            onClick={viewMoreOnClick}
            href={viewMoreHref}
          >
            {viewMoreText}
          </a>
        )}
      </div>
      <GridView xs={xs} listData={items} render={itemRender} direction="column" />
    </div>
  );
};

export default withStyles(styles)(ItemsGroup);
