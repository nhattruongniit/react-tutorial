import React from 'react';

import { SelectedColorCheck } from '../../assets';

export default class OptionColor extends React.Component<any> {
  render() {
    const { color, border, selected, onClick } = this.props;
    const style = { backgroundColor: color, border: 'none' };
    if (border) {
      style.border = `solid 1px ${border}`;
    }
    return (
      <li onClick={onClick} style={style} className={selected ? 'selected' : ''}>
        {selected && <SelectedColorCheck />}
      </li>
    );
  }
}
