import React from 'react';
import { withStyles, Theme, createStyles } from '@material-ui/core';
import classnames from 'classnames';
import RangePrice from '../range-price';
import RatingStar from '../rating-star';
import ColorFilter from '../color-filter';

export interface IProps {
  classes: any;
  isOpenFilter: boolean;
  subCategory: string;
  branch: string;
  rating: number;
  minPrice: string;
  maxPrice: string;
  region: string;
  handleCloseFilter: any;
  handleChooseCategory: any;
  handleSubmitFilter: any;
  handleChooseBranch: any;
  handleVoteStar: any;
  handleChangePrice: any;
  handleChooseColor: any;
  handleChooseRegion: any;
  handleReset: any;
}

// styles
const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      position: 'fixed',
      width: '100%',
      height: '100%',
      top: 0,
      left: 0,
      zIndex: 99999,
      transform: 'translateX(100%)',
      transition: 'all 0.3s ease-in-out',
      opacity: 0,
      '&.active': {
        opacity: 1,
        transform: 'translateX(0)'
      }
    },
    h4: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#291E2D',
      marginBottom: '15px'
    },
    wrapper: {
      position: 'fixed',
      top: 0,
      right: 0,
      zIndex: 9,
      height: '100%',
      width: '70%',
      boxShadow: '0 2px 4px 0 rgba(0,0,0,0.5)'
    },
    content: {
      position: 'absolute',
      top: 0,
      right: 0,
      zIndex: 9,
      height: '100%',
      width: '100%',
      backgroundColor: '#fff',
      overflowY: 'scroll',
      padding: '30px 0 60px 0'
    },
    blur: {
      position: 'absolute',
      backgroundColor: '#818181',
      width: '100%',
      height: '100%',
      top: 0,
      left: 0,
      opacity: 0.5
    },
    ul: {
      margin: '-10px 0 0 0',
      padding: 0,
      '& li': {
        listStyle: 'none',
        cursor: 'pointer',
        width: '80px',
        padding: '1px 0',
        display: 'inline-block',
        textAlign: 'center',
        color: '#291E2D',
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '10px 10px 0 0',
        '& input': {
          width: '100%',
          border: '1px solid #291E2D',
          outline: 0,
          borderRadius: '8px',
          textAlign: 'center',
          backgroundColor: '#fff',
          '&.active': {
            border: '1px solid #850F38',
            backgroundColor: '#850F38',
            color: '#fff'
          }
        }
      }
    },
    box: {
      padding: '0 0 15px 10px',
      '& + &': {
        borderTop: '1px solid #898889',
        paddingTop: '15px'
      }
    },
    btn: {
      display: 'flex',
      alignItems: 'center',
      position: 'absolute',
      bottom: 0,
      right: 0,
      zIndex: 99,
      width: '100%',
      '& button': {
        height: '55px',
        lineHeight: '55px',
        border: '1px solid #291E2D',
        background4: '#FFFFFF',
        fontSize: '16px',
        color: '#4A4A4A',
        width: '100%'
      },
      '& .btnDone': {
        backgroundColor: '#BA7402',
        color: '#FFF',
        border: 'none'
      }
    }
  });

const arrCategorys = ['All Tops', 'Basic', 'Blouses'];
const arrBranchs = ['Shimamura', 'Wego', 'Gu', 'Uniqlo'];
const arrRegions = ['警視庁', '東京都'];

export const ProductFilter: React.FunctionComponent<IProps> = ({
  subCategory,
  branch,
  region,
  minPrice,
  maxPrice,
  rating,
  classes,
  isOpenFilter,
  handleCloseFilter,
  handleChooseCategory,
  handleSubmitFilter,
  handleChooseBranch,
  handleVoteStar,
  handleChangePrice,
  handleChooseColor,
  handleChooseRegion,
  handleReset
}) => {
  return (
    <div className={classnames(classes.root, `${isOpenFilter ? 'active' : ''}`)}>
      <div className={classes.wrapper}>
        <div className={classes.content}>
          <div className={classes.box}>
            <h4 className={classes.h4}>Sub Category</h4>
            <ul className={classes.ul}>
              {arrCategorys.map(name => (
                <li key={name}>
                  <input
                    type="text"
                    className={subCategory === name ? 'active' : ''}
                    onClick={handleChooseCategory}
                    value={name}
                    readOnly={true}
                  />
                </li>
              ))}
            </ul>
          </div>
          <div className={classes.box}>
            <h4 className={classes.h4}>Branch</h4>
            <ul className={classes.ul}>
              {arrBranchs.map(name => (
                <li key={name}>
                  <input
                    type="text"
                    className={branch === name ? 'active' : ''}
                    onClick={handleChooseBranch}
                    value={name}
                    readOnly={true}
                  />
                </li>
              ))}
            </ul>
          </div>
          <div className={classes.box}>
            <h4 className={classes.h4}>Review</h4>
            <RatingStar rating={rating} handleVoteStar={handleVoteStar} />
          </div>
          <div className={classes.box}>
            <h4 className={classes.h4}>Price</h4>
            <RangePrice minPrice={minPrice} maxPrice={maxPrice} handleChangePrice={handleChangePrice} />
          </div>
          <div className={classes.box}>
            <h4 className={classes.h4}>Color</h4>
            <ColorFilter handleChooseColor={handleChooseColor} />
          </div>
          <div className={classes.box}>
            <h4 className={classes.h4}>Region</h4>
            <ul className={classes.ul}>
              {arrRegions.map(name => (
                <li key={name}>
                  <input
                    type="text"
                    className={region === name ? 'active' : ''}
                    onClick={handleChooseRegion}
                    value={name}
                    readOnly={true}
                  />
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className={classes.btn}>
          <button type="button" onClick={handleReset}>
            Reset
          </button>
          <button type="button" onClick={handleSubmitFilter} className="btnDone">
            DONE
          </button>
        </div>
      </div>
      <div className={classes.blur} onClick={handleCloseFilter} />
    </div>
  );
};

export default withStyles(styles)(ProductFilter);
