import * as React from 'react';
import { Grid, withStyles, createStyles } from '@material-ui/core';
import Rating from '../rating';
import { Point } from '../../assets';
import classnames from 'classnames';

export const styles = createStyles({
  root: {
    '& .imageContainer': {
      height: 100,
      width: 100,
      overflow: 'hidden',
      textAlign: 'center',
      '& img': {
        display: 'inline-block',
        height: '100%'
      }
    }
  },
  boxGrid: {
    marginTop: 15,
    justifyContent: 'end'
  },
  productName: {
    color: '#111111',
    fontFamily: 'Helvetica',
    fontSize: 13,
    fontWeight: 'bold'
  },
  price: {
    color: '#A1081B',
    fontFamily: 'Helvetica',
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 5
  },
  point: {
    marginTop: 5,
    color: '#291E2D',
    fontFamily: 'Helvetica',
    fontSize: 9,
    display: 'flex',
    alignItems: 'center',
    '& .svgPoint': {
      paddingRight: 5
    }
  },
  content: {
    '& .rating': {
      display: 'block'
    },
    width: 'calc( 100% - 100px )'
  }
});

class ProductItem extends React.Component<any, any> {
  handleGoToDetail = (slug: string) => {
    const { history } = this.props;
    history.push(`/products/detail/${slug}`);
  };

  render() {
    const { classes, data } = this.props;
    let columnStyle = {};
    let imgStyle = {};
    if (this.props.direction === 'column') {
      columnStyle = {
        width: '100%'
      };
    } else {
      imgStyle = {
        display: 'inline-block',
        height: '100%',
        maxHeight: 90
      };
    }
    return (
      <Grid
        onClick={() => this.handleGoToDetail(data.slug)}
        item={true}
        container={true}
        spacing={8}
        wrap={this.props.isWrap}
        xs={this.props.xs}
        justify="space-between"
        direction={this.props.direction}
        className={classnames(classes.boxGrid, classes.root)}
      >
        <Grid className="imageContainer" key={1} item={true} style={columnStyle}>
          <img style={imgStyle} src={data.featureImage} alt={data.name} />
        </Grid>

        <Grid key={2} className={classes.content} item={true} style={columnStyle}>
          <h2 className={classes.productName}>{data.name}</h2>
          <Rating rating={data.rating} />
          <h2 className={classes.price}>
            {data.currency}
            {data.price}
          </h2>
          <h2 className={classes.point}>
            <img src={Point} title="Point" alt="Point" className="svgPoint" />
            Get {data.getPoint} Point{data.getPoint !== 1 && 's'}
          </h2>
        </Grid>
      </Grid>
    );
  }
}

export default withStyles(styles)(ProductItem);
