import React from 'react';
import { Theme, createStyles, withStyles } from '@material-ui/core';

const styles = ({ palette }: Theme) =>
  createStyles({
    range: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingRight: '10px',
      '& input': {
        width: '95px',
        height: '35px',
        border: '1px solid #898889',
        textAlign: 'center',
        fontSize: '16px'
      }
    }
  });

interface IProps {
  classes: any;
  handleChangePrice: any;
  minPrice: string;
  maxPrice: string;
}

const RangePrice: React.FunctionComponent<IProps> = ({ classes, minPrice, maxPrice, handleChangePrice }) => {
  return (
    <div className={classes.range}>
      <input type="number" placeholder="Min" name="min" value={minPrice} onChange={handleChangePrice} />
      <span className={classes.line}>{' - '}</span>
      <input type="number" placeholder="Max" name="max" value={maxPrice} onChange={handleChangePrice} />
    </div>
  );
};

export default withStyles(styles)(RangePrice);
