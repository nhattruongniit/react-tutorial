import React from 'react';
import { Theme, createStyles, withStyles } from '@material-ui/core';
import ReactStars from 'react-stars';

const styles = ({ palette }: Theme) =>
  createStyles({
    rating: {}
  });

interface IProps {
  classes: any;
  handleVoteStar;
  rating: number;
}

export const RatingStar: React.FunctionComponent<IProps> = ({ classes, handleVoteStar, rating }) => {
  return (
    <div className={classes.rating}>
      <ReactStars count={5} size={24} color2={'#ffd700'} value={rating} onChange={handleVoteStar} />
    </div>
  );
};

export default withStyles(styles)(RatingStar);
