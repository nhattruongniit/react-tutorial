import * as React from 'react';
import { Star, StarHalf, StarBorder } from '@material-ui/icons';
import { createStyles, withStyles } from '@material-ui/core';
import classnames from 'classnames';

const styles = createStyles({
  root: {
    '& svg': {
      color: '#989898',
      marginTop: 5
    },
    '& .rate': {
      color: '#f5a623',
      marginTop: 5
    }
  }
});

function Rating(props: any) {
  const { rating, classes } = props;

  const star = Math.floor(rating);
  const haveHalf = rating !== star;
  const rates: React.ReactElement[] = [];

  for (let i = 1; i <= 5; i++) {
    if (i <= star) {
      rates.push(<Star key={i} className="rate" />);
    } else {
      if (i === star + 1) {
        if (haveHalf) {
          rates.push(<StarHalf key={i} className="rate" />);
        } else {
          rates.push(<StarBorder key={i} />);
        }
      } else {
        rates.push(<StarBorder key={i} />);
      }
    }
  }

  return <div className={classnames('rating', classes.root)}>{rates}</div>;
}

export default withStyles(styles)(Rating);
