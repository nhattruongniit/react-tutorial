import React, { FC, useEffect, Fragment } from 'react';
import { connect } from 'react-redux';
import classnames from 'classnames';

// material ui
import { withStyles, createStyles, WithStyles } from '@material-ui/core';

// resource
import { Dress, Eyeglasses, Necklace, Shirt, Trousers, TShirt, WomenCoat, WomenTop } from '../assets';

// state
import { IFashionState } from '../../../models';

// component
import { SearchBar } from '../../../common/components';
import ItemsGroup from '../components/item-group';
import CategoryItem from '../components/category-item';
import ProductItem from '../components/product-item';

// redux
import { fetchProduct } from '../redux/product/actions';

export const styles = createStyles({
  root: {
    paddingLeft: 8,
    paddingRight: 8
  },
  wrapperCSS: {
    backgroundColor: '#FFF'
  },
  group: {
    marginTop: 10,
    marginBottom: 5
  }
});

interface IProps extends WithStyles<typeof styles> {
  data: any;
  history: any;
  fetchProduct: () => void;
}

export const Product: FC<IProps> = ({ data, fetchProduct: actionFetchProduct, history, classes }) => {
  useEffect(() => {
    actionFetchProduct();
  }, [actionFetchProduct]);

  return (
    <div className={classnames(classes.root, 'container-fluid')} key="ProductsHomeItem">
      <SearchBar placeholder="Search Shop" />

      <ItemsGroup
        className={classes.group}
        title="Category"
        isViewMore={false}
        xs={3}
        items={[
          { icon: <Dress />, name: 'Dress' },
          { icon: <WomenTop />, name: 'Top' },
          { icon: <WomenCoat />, name: 'Coats & Jackets' },
          { icon: <Trousers />, name: 'Jeans' },
          { icon: <TShirt />, name: 'T-Shirt' },
          { icon: <Shirt />, name: 'Shirt' },
          { icon: <Eyeglasses />, name: 'Accessories' },
          { icon: <Necklace />, name: 'Jewelry' }
        ]}
        itemRender={(renderProps: any) => <CategoryItem {...renderProps} />}
      />

      {data && (
        <Fragment>
          <ItemsGroup
            className={classes.group}
            title="Top selling"
            isViewMore={true}
            viewMoreHref="#/products/list"
            viewMoreText="View more >>"
            items={data}
            itemRender={(renderProps: any) => <ProductItem history={history} {...renderProps} />}
          />

          <ItemsGroup
            className={classes.group}
            title="The most discounted"
            isViewMore={true}
            viewMoreHref="#/products/list"
            viewMoreText="View more >>"
            items={data}
            itemRender={(renderProps: any) => <ProductItem history={history} {...renderProps} />}
          />
        </Fragment>
      )}
    </div>
  );
};

export const mapStateToProps = (state: IFashionState) => {
  const {
    product: { data }
  } = state;
  return {
    data
  };
};

export const mapDispatchToProps = {
  fetchProduct
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Product));
