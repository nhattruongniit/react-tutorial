import * as React from 'react';
import { connect } from 'react-redux';
import classnames from 'classnames';

// material ui
import { withStyles, createStyles } from '@material-ui/core';
import * as Icons from '@material-ui/icons';

// component
import Rating from '../components/rating';
import Gallery from '../components/gallery';
import GroupColors from '../components/group-colors';

// resource
import { Point, ProductDescription } from '../assets';

// state
import { IFashionState } from '../../../models';

// redux
import { fetchProductDetail } from '../redux/product-detail/actions';

export const styles = createStyles({
  root: {
    '& .icon-title': {
      display: 'flex',
      alignItems: 'center',
      color: '#4A4A4A',
      fontFamily: 'Helvetica',
      fontSize: 16,
      fontWeight: 'bold',
      '& .svgPoint': {
        paddingTop: 10
      },
      '& .name': {
        marginLeft: 10
      }
    },
    '& .separator': {
      height: 5,
      width: '100%',
      background: '#D9D9D6'
    },
    '& .title': {
      color: '#291E2D',
      fontFamily: 'Helvetica',
      fontSize: 16,
      fontWeight: 'bold'
    },
    '& .rex-row': {
      display: 'flex',
      alignItems: 'baseline',
      paddingTop: 8,
      '& > div': {
        width: '50%',
        '& .quality': {
          display: 'flex',
          justifyContent: 'flex-end',
          '& input': {
            borderTop: '1px solid #4A4A4A',
            borderBottom: '1px solid #4A4A4A',
            borderLeft: 'none',
            borderRight: 'none',
            height: 30,
            width: 40,
            lineHeight: '30px',
            textAlign: 'center',
            fontFamily: 'Helvetica',
            fontSize: 16,
            fontWeight: 'bold'
          },
          '& .number': {
            height: 30
          },
          '& input[type=button]': {
            minWidth: 60,
            backgroundColor: '#4A4A4A',
            color: '#FFFFFF',
            fontSize: 32,
            lineHeight: '27px'
          }
        }
      },
      '& .price': {
        color: '#A1081B',
        fontFamily: 'Helvetica',
        fontSize: 20,
        fontWeight: 'bold'
      }
    },
    '& .group': {
      paddingLeft: 8,
      paddingRight: 8,
      padding: 8,
      '& .product-description': {
        color: '#111111',
        fontFamily: 'Helvetica',
        fontSize: 14,
        marginTop: 15
      }
    },
    '& .product-option.size': {
      '& .option-name': {
        paddingTop: 7
      }
    },
    '& .product-option.color': {
      alignItems: 'center'
    },
    '& .product-option': {
      width: '100%',
      display: 'flex',
      minHeight: 60,
      '& .option-name': {
        width: '25%'
      },
      '& .option-values.size': {
        '& li': {
          width: 72,
          height: 25,
          lineHeight: '25px',
          textAlign: 'center',
          border: '1px solid #291E2D',
          borderRadius: 8,
          backgroundColor: '#FFFFFF',
          color: '#291E2D',
          fontFamily: 'Helvetica',
          fontSize: 16
        },
        '& li.selected': {
          backgroundColor: '#850F3B',
          color: '#fff',
          border: 'none'
        }
      },
      '& .option-values.color': {
        margin: 0,
        '& li': {
          height: 22,
          width: 25
        },
        '& li.selected': {
          '& svg': {
            marginTop: 4,
            marginLeft: 4
          }
        }
      },
      '& .option-values': {
        display: 'flex',
        flexWrap: 'wrap',
        width: '75%',
        margin: 0,
        justifyContent: 'flex-start',
        listStyleType: 'none',
        paddingInlineStart: 0,
        '& li': {
          display: 'block',
          marginTop: 5,
          marginBottom: 5,
          marginLeft: 7,
          marginRight: 7
        }
      }
    },
    paddingLeft: 0,
    paddingRight: 0
  },
  wrapperCSS: {
    backgroundColor: '#fff'
  }
});

export class ProductDetail extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      quantity: 1,
      activeColorImageId: -1,
      selectedIndex: 0,
      selectedColors: 0
    };
  }

  componentDidMount() {
    const {
      fetchProductDetail: actionFetchProductDetail,
      match: {
        params: { id }
      }
    } = this.props;
    actionFetchProductDetail({ id });
  }

  increaseQuantity = () => {
    this.setState(prevState => {
      return {
        ...prevState,
        quantity: prevState.quantity + 1
      };
    });
  };

  decreaseQuantity = () => {
    this.setState(prevState => {
      if (prevState.quantity <= 1) {
        return {
          ...prevState,
          quantity: 1
        };
      }
      return {
        ...prevState,
        quantity: prevState.quantity - 1
      };
    });
  };

  handleSize = (item: number) => {
    this.setState({ selectedIndex: item });
  };

  handleColors = (item: number) => {
    this.setState({ selectedColors: item });
  };

  render() {
    const {
      state: { selectedIndex },
      props: { classes, data }
    } = this;

    return (
      <div className={classnames('container-fluid', classes.root)} key="ProductDetailItem">
        {data.length !== 0 && (
          <>
            <div className="group">
              <div className="title">{data.name}</div>
              <Rating rating={data.rating} />
              <div className="rex-row">
                <div className="price">
                  {data.currency}
                  {data.price}
                </div>
                <div>
                  <div className="quality">
                    <input type="button" value="-" onClick={this.decreaseQuantity} />
                    <input className="number" defaultValue={this.state.quantity} />
                    <input type="button" value="+" onClick={this.increaseQuantity} />
                  </div>
                </div>
              </div>
              <Gallery images={data.images} activeImageId={this.state.activeColorImageId} />
            </div>
            <div className="separator" />
            <div className={classnames('group', 'product-option', 'size')}>
              <div className="option-name">
                <div className="icon-title">
                  <Icons.ZoomOutMap />
                  <div className="name">Size</div>
                </div>
              </div>
              <ul className="option-values size">
                {data.sizes.map((item: React.ReactNode, index: number) => {
                  return (
                    <li
                      key={index}
                      className={selectedIndex === index ? 'selected' : ''}
                      onClick={() => this.handleSize(index)}
                    >
                      {item}
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="separator" />
            <div className={classnames('group', 'product-option', 'color')}>
              <div className="option-name">
                <div className="icon-title">
                  <img src={Point} title="Point" alt="Point" />
                  <div className="name">Color</div>
                </div>
              </div>
              <ul className="option-values color">
                <GroupColors
                  values={data.colors}
                  onSelect={(item: { imageId: string }) => {
                    this.setState(prevState => {
                      return { ...prevState, activeColorImageId: item.imageId };
                    });
                  }}
                />
              </ul>
            </div>
            <div className="separator" />
            <div className="group">
              <div className="icon-title">
                <ProductDescription />
                <div className="name">Product Description</div>
              </div>
              <div className="product-description">{data.description}</div>
            </div>
          </>
        )}
      </div>
    );
  }
}

export const mapStateToProps = (state: IFashionState) => {
  const {
    productDetail: { data }
  } = state;
  return {
    data
  };
};

const mapDispatchToProps = {
  fetchProductDetail
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ProductDetail));
