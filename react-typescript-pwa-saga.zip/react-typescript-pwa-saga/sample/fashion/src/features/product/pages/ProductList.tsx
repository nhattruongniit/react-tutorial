import * as React from 'react';
import { connect } from 'react-redux';
import classnames from 'classnames';

// material
import * as Icons from '@material-ui/icons';
import { Theme, withStyles, createStyles, MenuItem, Select } from '@material-ui/core';

// libs
import InfiniteScroll from 'react-infinite-scroll-component';

// redux
import { fetchProductList, loadMoreProductList } from '../redux/product-list/actions';

// state
import { IFashionState, ISearchOffline } from '../../../models';

// component
import { SearchBar, ListView } from '../../../common/components';
import ProductItem from '../components/product-item';
import ProductFilter from '../components/product-filter';

export const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      padding: '0 15px'
    },
    categories: {
      marginLeft: 8,
      marginRight: 8,
      marginTop: 12,
      '& span': {
        height: 22,
        width: 82,
        border: '1px solid #291E2D',
        display: 'inline-block',
        borderRadius: 8,
        backgroundColor: '#FFFFFF',
        color: '#291E2D',
        fontFamily: 'Helvetica Neue',
        fontSize: 14,
        textAlign: 'center'
      },
      '& span.selected': {
        fontWeight: 'bold',
        color: '#FFFFFF',
        backgroundColor: '#850F3B'
      },
      '& span:not(:first-child)': {
        marginLeft: 12
      }
    },
    uiLabel: {
      color: '#4A4A4A',
      fontFamily: 'Helvetica',
      fontSize: 16,
      textAlign: 'justify'
    },
    selectBox: {
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: 16,
      width: 95
    },
    actions: {
      position: 'relative',
      marginTop: 20,
      '& svg': {
        color: '#111111'
      },
      '& select': {
        color: '#111111',
        fontFamily: 'Helvetica',
        fontSize: 16,
        textAlign: 'justify'
      },
      '& .icons': {
        display: 'flex',
        alignContent: 'center',
        '& i': {
          marginLeft: 10,
          marginRight: 10,
          display: 'inline-block',
          height: 29,
          width: 1,
          background: '#4A4A4A'
        },
        '& svg': {
          display: 'inline-block',
          width: 25,
          height: 25
        },
        '& svg:not(:first-child)': {
          display: 'inline-block',
          width: 38,
          height: 30,
          marginLeft: 10
        }
      }
    },
    select: {
      '&::before': {
        borderBottom: 'none !important'
      }
    },
    options: {
      display: 'flex',
      justifyContent: 'space-between',
      alignContent: 'center',
      marginBottom: 10
    },
    sortably: {
      display: 'inline-block',
      '& #select-sort': {
        fontWeight: 'bold'
      }
    },
    item: {
      fontSize: '14px',
      color: '#111',
      width: '160px',
      '& + &': {
        borderTop: '1px solid #979797'
      }
    },
    view: {
      border: '1px solid #979797'
    },
    filter: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#111',
      display: 'flex',
      alignItems: 'center'
    },
    arrow: {
      width: 0,
      height: 0,
      borderLeft: '7px solid transparent',
      borderRight: '7px solid transparent',
      borderTop: '7px solid #111',
      marginLeft: '5px'
    },
    '@media (max-width: 400px)': {
      selectSort: {
        width: '50%'
      },
      select: {
        width: 110
      }
    },
    active: {
      color: '#850F3B !important',
      background: 'none',
      border: '1px solid #850F3B'
    }
  });

interface IProductListState {
  isOpenFilter: boolean;
  searchProduct: string;
  sortBy: string;
  subCategory: string;
  branch: string;
  rating: number;
  minPrice: string;
  maxPrice: string;
  color: any;
  region: string;
  displayDirection: string;
  fields: string[];
}

interface IProductListProps {
  data: any;
  total: number;
  classes: any;
  fetchProductList: (payload?) => void;
  loadMoreProductList: (payload?) => void;
  history: any;
}

const arrColorSelected: any[] = [];

export class ProductList extends React.Component<IProductListProps, IProductListState> {
  state = {
    isOpenFilter: false,
    searchProduct: '',
    sortBy: 'featured',
    subCategory: '',
    branch: '',
    rating: 0,
    minPrice: '',
    maxPrice: '',
    color: '',
    region: '',
    displayDirection: 'row',
    fields: ['name']
  };

  componentDidMount() {
    this.handleFetchProductList();
  }

  handleFetchProductList = () => {
    const { fetchProductList: actionFetchProductList } = this.props;
    const { fields } = this.state;
    actionFetchProductList({ fields });
  };

  handleLoadMoreProductList = () => {
    const { loadMoreProductList: actionLoadMoreProductList } = this.props;
    const { fields } = this.state;
    actionLoadMoreProductList({ fields });
    console.log('=========handleLoadMoreProductList=============');
  };

  handleFetchDataSearchOffline = (e: ISearchOffline) => {
    const { loadMoreProductList: actionLoadMoreProductList } = this.props;
    const { fields } = this.state;
    const { search } = e;
    actionLoadMoreProductList({ search: search.trim(), fields });
  };

  handleOpenFiler = () => {
    this.setState({ isOpenFilter: true });
  };

  handleCloseFilter = () => {
    this.setState({ isOpenFilter: false });
  };

  handleSubmitSearch = (event: { preventDefault }) => {
    event.preventDefault();
    const {
      state: { searchProduct },
      handleFetchDataSearchOffline
    } = this;
    const search: string = searchProduct;
    handleFetchDataSearchOffline({ search });
  };

  handleChangeValue = (event: any) => {
    event.preventDefault();
    const { value } = event.target;
    this.setState({ searchProduct: value });
  };

  handleChangeSort = (event: any) => {
    const { value } = event.target;
    this.setState({ sortBy: value });
    event.currentTarget = { value: { sortBy: value } };
    console.log('handleChangeSort');
  };

  handleChooseCategory = (e: any) => {
    const { value } = e.target;
    this.setState({ subCategory: value });
  };

  handleChooseBranch = (e: any) => {
    const { value } = e.target;
    this.setState({ branch: value });
  };

  handleVoteStar = (newRating: number) => {
    this.setState({ rating: newRating });
  };

  handleChangePrice = (e: any) => {
    const { name, value } = e.target;
    if (name === 'min') {
      this.setState({ minPrice: value });
    }
    if (name === 'max') {
      this.setState({ maxPrice: value });
    }
  };

  handleChooseColor = (e: any) => {
    const { value, checked } = e.target;
    if (checked) {
      arrColorSelected.push(value);
    } else {
      const index = arrColorSelected.indexOf(value);
      if (index > -1) {
        arrColorSelected.splice(index, 1);
      }
    }
    this.setState({ color: arrColorSelected });
  };

  handleChooseRegion = (e: any) => {
    const { value } = e.target;
    this.setState({ region: value });
  };

  handleReset = () => {
    this.setState({
      subCategory: '',
      branch: '',
      region: '',
      minPrice: '',
      maxPrice: '',
      color: '',
      rating: 0
    });
  };

  handleSubmitFilter = (e: any) => {
    e.preventDefault();
    const {
      state: { subCategory, branch, region, minPrice, maxPrice, color, rating, isOpenFilter }
    } = this;
    this.setState({ isOpenFilter: !isOpenFilter });
    e.currentTarget = {
      value: {
        listFilter: {
          subCategory,
          branch,
          region,
          minPrice,
          maxPrice,
          color,
          rating
        }
      }
    };
    console.log('handleSubmitFilter');
  };

  handleChangeViewMode = (displayDirection: string) => {
    this.setState(prevState => {
      return { ...prevState, displayDirection };
    });
  };

  render() {
    const {
      state: { sortBy, displayDirection, isOpenFilter, subCategory, branch, rating, minPrice, maxPrice, region },
      props: { classes, data, total, history },
      handleOpenFiler,
      handleChangeSort,
      handleChangeViewMode,
      handleCloseFilter,
      handleChooseCategory,
      handleSubmitFilter,
      handleChooseBranch,
      handleVoteStar,
      handleChangePrice,
      handleChooseColor,
      handleChooseRegion,
      handleReset,
      handleSubmitSearch,
      handleChangeValue
    } = this;

    return (
      <div className={classes.root} key="ProductListItem">
        <div>
          <SearchBar
            handleSubmitSearch={handleSubmitSearch}
            handleChangeValue={handleChangeValue}
            placeholder="Search Shop"
          />
          <div className={classes.categories}>
            <span className="selected">All Tops</span>
            <span>Basics</span>
            <span>Blouses</span>
          </div>
          <div className={classes.actions}>
            <div className={classes.options}>
              <div className={classes.selectSort}>
                <span className={classes.uiLabel}>Sort by: </span>
                <div className={classes.sortably}>
                  <Select value={sortBy} onChange={handleChangeSort} className={classes.select} name="sort">
                    <MenuItem className={classes.item} value="featured">
                      Featured
                    </MenuItem>
                    <MenuItem className={classes.item} value="newest">
                      Newest
                    </MenuItem>
                    <MenuItem className={classes.item} value="asc">
                      Price: Low to High
                    </MenuItem>
                    <MenuItem className={classes.item} value="desc">
                      Price: High to Low
                    </MenuItem>
                  </Select>
                </div>
              </div>
              <div className="icons">
                <span className={classes.filter} onClick={handleOpenFiler}>
                  <span>Filter</span>
                  <span className={classes.arrow} />
                </span>
                <Icons.List
                  className={classnames(classes.view, `${displayDirection}` === 'row' ? classes.active : '')}
                  onClick={() => handleChangeViewMode('row')}
                />
                <Icons.ViewModule
                  className={classnames(classes.view, `${displayDirection}` === 'column' ? classes.active : '')}
                  onClick={() => handleChangeViewMode('column')}
                />
              </div>
            </div>
            <div>
              <InfiniteScroll
                dataLength={data.length}
                next={this.handleLoadMoreProductList}
                hasMore={total > data.length}
                endMessage={
                  <p style={{ textAlign: 'center' }}>
                    <b>Yay! You have seen it all</b>
                  </p>
                }
                refreshFunction={this.handleFetchProductList}
                pullDownToRefresh
                pullDownToRefreshContent={<h3 style={{ textAlign: 'center' }}>&#8595; Pull down to refresh</h3>}
                releaseToRefreshContent={<h3 style={{ textAlign: 'center' }}>&#8593; Release to refresh</h3>}
              >
                <ListView
                  listData={data}
                  direction={displayDirection as ('row' | 'column')}
                  render={(renderProps: any) => <ProductItem history={history} {...renderProps} />}
                />
              </InfiniteScroll>
            </div>
          </div>
        </div>
        <ProductFilter
          isOpenFilter={isOpenFilter}
          subCategory={subCategory}
          branch={branch}
          rating={rating}
          minPrice={minPrice}
          maxPrice={maxPrice}
          region={region}
          handleCloseFilter={handleCloseFilter}
          handleChooseCategory={handleChooseCategory}
          handleSubmitFilter={handleSubmitFilter}
          handleChooseBranch={handleChooseBranch}
          handleVoteStar={handleVoteStar}
          handleChangePrice={handleChangePrice}
          handleChooseColor={handleChooseColor}
          handleChooseRegion={handleChooseRegion}
          handleReset={handleReset}
        />
      </div>
    );
  }
}

export const mapStateToProps = (state: IFashionState) => {
  const {
    productList: { data, total }
  } = state;
  return {
    data,
    total
  };
};

export const mapDispatchToProps = {
  fetchProductList,
  loadMoreProductList
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ProductList));
