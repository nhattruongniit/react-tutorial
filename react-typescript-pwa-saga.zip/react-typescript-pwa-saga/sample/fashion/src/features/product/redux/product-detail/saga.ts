import { takeLatest, put, call } from 'redux-saga/effects';

import { FETCH_DATA_REQUEST } from './constants';
import { fetchProductDetailSuccess, fetchProductDetailFailure } from './actions';

// utils
import { makeMockJsonRequest } from './../../../../common/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

function* fetchProductDetailData(action) {
  const { id } = action.payload;
  const payloadForFetchApiAction = makeMockJsonRequest(`DETAIL_PRODUCT_${id}`, `rexProducts?slug=${id}`);
  yield put(fetchApi(payloadForFetchApiAction));
}

function* getProductDetailSuccess(action: { payload: { httpResponseJson: any } }) {
  const {
    payload: { httpResponseJson }
  } = action;
  yield put(fetchProductDetailSuccess({ data: httpResponseJson[0] }));
}

function* getProductDetailError() {
  yield put(fetchProductDetailFailure('Error fetch product detail!'));
}

function* getProductDetailAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;
  if (request.key.startsWith('DETAIL_PRODUCT')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getProductDetailSuccess, action);
    } else {
      yield call(getProductDetailError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchProductDetailData);
  yield takeLatest(FETCH_API.SUCCESS, getProductDetailAsyncWorker);
  yield takeLatest(FETCH_API.FAILURE, getProductDetailAsyncWorker);
}
