import {
  FETCH_DATA_REQUEST,
  FETCH_DATA_SUCCESS,
  FETCH_DATA_FAILURE,
  FETCH_DATA_LOAD_MORE_REQUEST,
  FETCH_DATA_LOAD_MORE_SUCCESS
} from './constants';

import { IProductList } from '../../../../models';

export const fetchProductList = (payload?) => ({ type: FETCH_DATA_REQUEST, payload });

export const fetchProductListSuccess = (payload: IProductList) => ({ type: FETCH_DATA_SUCCESS, payload });

export const fetchProductListFailure = (error: string) => ({ type: FETCH_DATA_FAILURE, payload: { error } });

export const loadMoreProductList = (payload?) => ({ type: FETCH_DATA_LOAD_MORE_REQUEST, payload });

export const loadMoreProductListSuccess = (payload: IProductList) => ({ type: FETCH_DATA_LOAD_MORE_SUCCESS, payload });
