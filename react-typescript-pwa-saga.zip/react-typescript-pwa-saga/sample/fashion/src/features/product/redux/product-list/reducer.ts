import {
  FETCH_DATA_REQUEST,
  FETCH_DATA_SUCCESS,
  FETCH_DATA_FAILURE,
  FETCH_DATA_LOAD_MORE_REQUEST,
  FETCH_DATA_LOAD_MORE_SUCCESS
} from './constants';

import { IAction, IProductList } from '../../../../models';

const initialState: IProductList = {
  data: [],
  total: 0,
  page: 1,
  error: ''
};

export function reducer(state: IProductList = initialState, action: IAction): IProductList {
  switch (action.type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state,
        page: 1
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        data: action.payload.data,
        total: action.payload.total
      };
    case FETCH_DATA_LOAD_MORE_REQUEST:
      const { page } = state;
      return {
        ...state,
        page: page + 1
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: action.payload.error
      };
    case FETCH_DATA_LOAD_MORE_SUCCESS:
      const { data } = state;
      return {
        ...state,
        data: [...data, ...action.payload.data]
      };
    default:
      return state;
  }
}
