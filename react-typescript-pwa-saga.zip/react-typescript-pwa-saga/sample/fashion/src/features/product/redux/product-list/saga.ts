import { takeLatest, put, select, call } from 'redux-saga/effects';

// config
import { TABLE_NAME_POSTGRESQL, MODE_API } from '../../../../config';

// redux

import { FETCH_DATA_REQUEST, FETCH_DATA_LOAD_MORE_REQUEST } from './constants';
import { fetchProductListSuccess, loadMoreProductListSuccess, fetchProductListFailure } from './actions';
//  fetchProductList
// utils
import { makePrivateLambdaRequest } from '@mochi/misc/fetch-api';
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { fetchApiSaga, FETCH_API, fetchApi } from '@mochi/core';

const getPage = ({ productList: { page } }) => page;

function* fetchProductListData(action: { type: string; payload: any }) {
  const page = yield select(getPage);
  const skip = (page - 1) * 10;
  const configSearch: any = {};
  let payloadForFetchApiAction;
  // assign index full text search
  configSearch.search = action.payload.search;
  configSearch.fields = action.payload.fields || [];
  payloadForFetchApiAction = makePrivateLambdaRequest(
    'SEARCH_PRODUCT_' + configSearch.search,
    {
      mode: MODE_API.read,
      tableName: TABLE_NAME_POSTGRESQL.product,
      ...configSearch
    },
    { meta: action.type, noCached: true }
  );
  const {
    payload: {
      httpResponseJson: { rows, total }
    }
  } = yield call(fetchApiSaga, fetchApi(payloadForFetchApiAction));
  if (action.payload && action.payload.search) {
    // action search
    yield put(fetchProductListSuccess({ data: rows, total, page: 0 }));
  } else {
    // action save data
    payloadForFetchApiAction = makeMockJsonRequest('LIST_PRODUCT_' + skip, `offline-products-1`, {
      meta: action.type,
      noCached: true
    });
    yield put(fetchApi(payloadForFetchApiAction));
  }
}

function* getProductListSuccess(action: { payload: { httpResponseJson: any; request: { option: { meta: string } } } }) {
  const {
    payload: {
      httpResponseJson,
      request: {
        option: { meta }
      }
    }
  } = action;

  const page = yield select(getPage);
  if (meta === FETCH_DATA_LOAD_MORE_REQUEST) {
    yield put(loadMoreProductListSuccess({ data: httpResponseJson.rows, total: httpResponseJson.total, page }));
  } else {
    yield put(fetchProductListSuccess({ data: httpResponseJson.rows, total: httpResponseJson.total, page: 1 }));
  }
}

function* getProductListError() {
  yield put(fetchProductListFailure('Error fetch product list!'));
}

function* getProductListAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;

  if (request.key.startsWith('LIST_PRODUCT')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getProductListSuccess, action);
    } else {
      yield call(getProductListError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchProductListData);
  yield takeLatest(FETCH_DATA_LOAD_MORE_REQUEST, fetchProductListData);
  yield takeLatest(FETCH_API.SUCCESS, getProductListAsyncWorker);
  yield takeLatest(FETCH_API.FAILURE, getProductListAsyncWorker);
}
