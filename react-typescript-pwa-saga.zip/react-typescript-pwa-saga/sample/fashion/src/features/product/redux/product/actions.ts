import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

import { IProduct } from '../../../../models/IProduct';

export const fetchProduct = () => ({ type: FETCH_DATA_REQUEST });

export const fetchProductSuccess = (payload: IProduct) => ({ type: FETCH_DATA_SUCCESS, payload });

export const fetchProductFailure = (error: string) => ({ type: FETCH_DATA_FAILURE, payload: { error } });
