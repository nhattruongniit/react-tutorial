import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './constants';

// model
import { IAction, IProduct } from '../../../../models';

const initialState: IProduct = {
  data: [],
  total: 1,
  page: 1,
  error: ''
};

export function reducer(state: IProduct = initialState, { type, payload }: IAction): IProduct {
  switch (type) {
    case FETCH_DATA_REQUEST:
      return {
        ...state
      };
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        data: payload.data
      };
    case FETCH_DATA_FAILURE:
      return {
        ...state,
        error: payload.error
      };
    default:
      return state;
  }
}
