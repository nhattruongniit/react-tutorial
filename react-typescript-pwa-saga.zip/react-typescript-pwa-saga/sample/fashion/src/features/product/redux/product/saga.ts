import { takeLatest, takeEvery, put, select, call } from 'redux-saga/effects';

// config
import { TABLE_NAME_POSTGRESQL, MODE_API } from '../../../../config';

// redux

import { FETCH_DATA_REQUEST } from './constants';
import { fetchProductSuccess, fetchProductFailure } from './actions';

// core
import { makePrivateLambdaRequest } from '@mochi/misc/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

const getPage = ({ product: { page } }) => page;

function* fetchProductData(action: { type: string }) {
  const page = yield select(getPage);
  const skip = (page - 1) * 10;

  const payloadForFetchApiAction = makePrivateLambdaRequest(
    'PRODUCT_' + skip,
    {
      mode: MODE_API.read,
      tableName: TABLE_NAME_POSTGRESQL.product,
      skip
    },
    { meta: action.type, noCached: false }
  );

  yield put(fetchApi(payloadForFetchApiAction));
}

function* getProductSuccess(action: { payload: { httpResponseJson: any; request: { option: { meta: string } } } }) {
  const {
    payload: { httpResponseJson }
  } = action;

  const page = yield select(getPage);
  yield put(fetchProductSuccess({ data: httpResponseJson.rows, total: httpResponseJson.total, page }));
}

function* getProductError() {
  yield put(fetchProductFailure('Error fetch product!'));
}

function* getProductAsyncWorker(action: { payload: any; type?: string }) {
  const { request } = action.payload;
  if (request.key.startsWith('PRODUCT')) {
    if (action.type === FETCH_API.SUCCESS) {
      yield call(getProductSuccess, action);
    } else {
      yield call(getProductError, action);
    }
  }
}

export function* saga() {
  yield takeLatest(FETCH_DATA_REQUEST, fetchProductData);
  yield takeEvery(FETCH_API.SUCCESS, getProductAsyncWorker);
  yield takeEvery(FETCH_API.FAILURE, getProductAsyncWorker);
}
