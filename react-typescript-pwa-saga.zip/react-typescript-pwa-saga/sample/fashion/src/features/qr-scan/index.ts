import QRScan from './pages/QRScan';
export default QRScan;