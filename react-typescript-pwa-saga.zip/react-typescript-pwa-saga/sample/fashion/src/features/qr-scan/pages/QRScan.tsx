import React, { useState } from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { isApplican } from '../../../services/applican';

/**
 * check if string is url or not
 * @param {String} url url to check
 */
const isUrl = (url: string) => {
  const urlRegex = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi;
  return urlRegex.test(url);
};

/**
 * Handle on scan QR code on web
 * @param content scan data result
 * @param self scanner instance
 * @param videoElement video element in html
 */
const onScanQRWeb = (content: any, self: any, videoElement: any, callback: any) => {
  callback.setData(content);
  // Exit fullscreen mode
  if (typeof videoElement.webkitExitFullScreen === 'function') {
    videoElement.webkitExitFullScreen();
    // Handle on fullscreen change
    videoElement.onfullscreenchange = () => {
      onFullScreenChanged(self);
    };
  }
  // Stop scanner after detect success
  self.scanner.stop();
  // Open confirm modal
  callback.setOpen(true);
};

/**
 * Get back camera
 * @param item list camera detected
 */
const findBackCamera = (item: any) => {
  if (item && typeof item.name === 'string' && item.name.toLocaleLowerCase().includes('back')) {
    return true;
  } else {
    return false;
  }
};

/**
 * Get back camera of device
 * @param cameras list camera detected.
 * @return back camera
 */
const getBackCamera = (cameras: any) => {
  const _window = window as any,
    iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !_window.MSStream;
  if (iOS) {
    return cameras.find(findBackCamera);
  } else {
    // Back camera for Android is the seconds camera in list => Need to be improved more
    return cameras[1];
  }
};

/**
 * Start scanner for qr reading
 * @param self scanner instance
 * @param cameras list camera detected
 */
const startScaner = (self: any, cameras: any) => {
  const camera = getBackCamera(cameras);
  if (camera) {
    self.activeCameraId = camera.id;
    self.scanner.start(camera);
    // Stop scan when user move to other page.
    window.onhashchange = () => {
      self.scanner.stop();
    };
  } else {
    alert('Not found back camera');
  }
};

/**
 * Handle scan qr code using web api.
 */
const handleScanQRCodeWeb = (callback: any) => {
  const self = {
      scanner: null,
      activeCameraId: null,
      cameras: [],
      scans: []
    } as any,
    _window = window as any,
    videoElement = document.getElementById('preview') as any;
  if (
    _window &&
    typeof _window.Instascan !== 'undefined' &&
    videoElement &&
    typeof videoElement.requestFullscreen === 'function'
  ) {
    // Request full screen video element
    videoElement.requestFullscreen();
    // Initial scanner
    self.scanner = new _window.Instascan.Scanner({
      video: videoElement,
      scanPeriod: 5,
      mirror: false
    });
    // Handle on scan QR success
    self.scanner.addListener('scan', (content: any) => {
      onScanQRWeb(content, self, videoElement, callback);
    });
    // Detect camera support on device
    _window.Instascan.Camera.getCameras()
      .then((cameras: any) => {
        handleDetectCameras(cameras, self);
      })
      .catch((e: any) => {
        alert(JSON.stringify(e));
      });
  }
};

/**
 * Handle detect list camera of device
 * @param cameras list camera detected
 * @param self scanner instance
 */
const handleDetectCameras = (cameras: any, self: any) => {
  if (cameras.length > 1) {
    startScaner(self, cameras);
  } else {
    alert('No cameras found.');
  }
};

const styles = {
  wrapper: {
    padding: 10,
    'text-align': 'center'
  },
  text: {
    wordBreak: 'break-all'
  } as React.CSSProperties,
  button: {
    width: '50%',
    height: '50px'
  }
};

/**
 * Handle on change full screen video mode
 * @param self scanner instance
 */
const onFullScreenChanged = (self: any) => {
  // Detect when user exit full screen video
  if (document.fullscreenElement === null) {
    // Stop scanner
    self.scanner.stop();
  }
};

/**
 * Handle scan code error
 * @param {Object} err error object
 */
const captureBarcodeError = (err: any) => {
  alert(err.message);
};

function QRScan() {
  const [data, setData] = useState<any>('');
  const [open, setOpen] = useState(false);
  /**
   * Handle on click button event
   */
  const onClickButton = () => {
    if (isApplican()) {
      handleScanBarCodeApplican();
    } else {
      handleScanQRCodeWeb({ callback: { setData: setData, setOpen: setOpen } });
    }
  };

  /**
   * Handle scan qr code using applican api.
   */
  const handleScanBarCodeApplican = () => {
    const applican = window['applican'];
    if (applican !== 'undefined' && applican.barcode) {
      applican.barcode.captureBarcode(captureBarcodeSuccess, captureBarcodeError);
    }
  };

  /**
   * Handle scan code success
   * @param {Object} res scan response
   */
  const captureBarcodeSuccess = (res: any) => {
    setData(res.codeData);
    // Open confirm modal
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div style={styles.wrapper}>
      <h1>Demo QR Scan</h1>
      {isApplican() ? '' : <video id="preview" />}
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{'Scan result'}</DialogTitle>
        <DialogContent>
          {isUrl(data) && !isApplican() ? (
            <a style={styles.text} href={data} target="_blank">
              {data}
            </a>
          ) : (
            <p style={styles.text}>{data}</p>
          )}
        </DialogContent>
      </Dialog>
      <button style={styles.button} onClick={onClickButton}>
        Scan QR
      </button>
    </div>
  );
}

export default QRScan;
