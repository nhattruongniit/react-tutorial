import { refreshApiTokenReducer as refreshApiToken } from '@mochi/misc/auth/refresh-api-token';
import login from '@mochi/misc/auth/login/redux';
import { reducer as errorLogReducer } from '../common/error-boundary-connect/redux/reducer';
import { homeReducer as home } from './home';
import { couponReducer as coupon, couponDetailReducer as couponDetail } from './coupon';
import {
  productReducer as product,
  productListReducer as productList,
  productDetailReducer as productDetail
} from './product';
import { shopReducer as shop, shopDetailReducer as shopDetail } from './shop';
import { reducer as history } from './member-ship/redux/history/reducer';
import { reducer as user } from './member-ship/redux/membership/reducer';
import { userLanguageReducer } from './user/language';
import {
  serviceChooserReducer as serviceChooser,
  serviceDetailReducer as serviceDetail,
  reservationDateReducer as reservationDate
} from './reservation';
import { reducer as rocketChat } from './login/redux/rocket-chat/reducer';
/* GEN: MORE IMPORT */

export const reducers = {
  userLanguageReducer,
  login,
  errorLogReducer,
  home,
  coupon,
  couponDetail,
  product,
  productList,
  productDetail,
  refreshApiToken,
  shop,
  shopDetail,
  history,
  user,
  serviceChooser,
  serviceDetail,
  /* GEN: REDUCER DECLARATION */
  reservationDate,
  rocketChat
};
