import { createReducer } from 'reduxsauce';
import { Types } from './actions';

const INITIAL_STATE = { error: false };

const failure = (state, action) => {
  return { ...state, error: action.error };
};

const HANDLERS = {
  [Types.REFRESH_API_TOKEN_FAILURE]: failure,
  [Types.RE_AUTHENTICATE]: () => new Date()
};

export default createReducer(INITIAL_STATE, HANDLERS);
