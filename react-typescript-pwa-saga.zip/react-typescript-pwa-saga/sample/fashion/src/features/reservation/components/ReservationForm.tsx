import React from 'react';
import { withStyles, createStyles, WithStyles } from '@material-ui/core';

export const styles = () =>
  createStyles({
    form: {
      marginBottom: '20px',
      '& ul': {
        margin: 0,
        padding: 0
      },
      '& ul li': {
        listStyle: 'none',
        display: 'flex',
        alignItems: 'center',
        '& + li': {
          marginTop: '30px'
        }
      },
      '& input': {
        width: '100%',
        height: '40px',
        border: '1px solid #979797',
        backgroundColor: '#fff',
        padding: '0 15px'
      },
      '& select': {
        width: '100%',
        height: '40px',
        border: '1px solid #979797',
        backgroundColor: '#fff'
      },
      '& label': {
        margin: '0 10px 0 0',
        width: '25%'
      },
      '& .uppercase': {
        textTransform: 'uppercase'
      },
      '& textarea': {
        height: '88px',
        border: '1px solid #979797',
        padding: '14px',
        width: '100%'
      },
      '& p': {
        margin: 0,
        padding: 0,
        width: '100%'
      }
    },
    note: {
      alignSelf: 'flex-start',
      paddingTop: '10px'
    },
    link: {
      textAlign: 'center',
      '& button': {
        width: '228px',
        height: '40px',
        lineHeight: '40px',
        textAlign: 'center',
        color: '#fff',
        backgroundColor: '#BA7402',
        display: 'inline-block',
        border: 0
      }
    }
  });

export interface IProps extends WithStyles<typeof styles> {
  title: string;
  start: string;
  end: string;
  date: string;
  handleSubmitForm(e): any;
}

export const ReservationConfirmForm: React.FC<IProps> = ({ classes, handleSubmitForm, title, start, end, date }) => {
  return (
    <form onSubmit={e => handleSubmitForm(e)} className={classes.form}>
      <ul>
        <li>
          <label htmlFor="name">Name:</label>
          <input id="name" type="text" placeholder="ex: Sarah" />
        </li>
        <li>
          <label>Service:</label>
          <p className="uppercase">{title}</p>
        </li>
        <li>
          <label>Time:</label>
          <p>
            <span>
              {start} ~ {end}
            </span>
            <span>{date}</span>
          </p>
        </li>
        <li>
          <label>Staff:</label>
          <p>Liam</p>
        </li>
        <li>
          <label>People:</label>
          <select>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
          </select>
        </li>
        <li>
          <label>Email:</label>
          <input type="email" placeholder="ex: abc@gmail.com" />
        </li>
        <li>
          <label>Phone:</label>
          <input type="tel" placeholder="ex: 0193938444" />
        </li>
        <li>
          <label className={classes.note}>Note:</label>
          <textarea placeholder="Write something in here." />
        </li>
        <li>
          <p className={classes.link}>
            <button type="submit"> Send </button>
          </p>
        </li>
      </ul>
    </form>
  );
};

const ReservationConfirmFormWithStyles = withStyles(styles)(ReservationConfirmForm);

export default ReservationConfirmFormWithStyles;
