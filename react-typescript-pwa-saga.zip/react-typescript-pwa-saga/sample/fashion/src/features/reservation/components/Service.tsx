import React from 'react';
import { connect } from 'react-redux';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles({
  box: {
    minHeight: 65,
    backgroundColor: '#FFFFFF',
    boxShadow: '0 0 2px 0 rgba(0,0,0,0.5)',
    padding: 10,
    '& .name': {
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: 16,
      textTransform: 'uppercase'
    },
    '& .detail': {
      display: 'flex',
      alignItems: 'baseline',
      paddingTop: 8,
      '& div': {
        width: '50%'
      },
      '& .duration': {
        color: '#111111',
        fontFamily: 'Helvetica',
        fontSize: 14
      },
      '& .price': {
        textAlign: 'right',
        color: '#111111',
        fontFamily: 'Helvetica',
        fontSize: 14
      }
    },
    '& .controls': {
      display: 'inline-block',
      position: 'absolute',
      right: 10,
      '& label': {
        color: '#111111',
        fontFamily: 'Helvetica',
        fontSize: 16,
        '& input[type=radio]': {
          marginRight: 5
        }
      },
      '& label:nth-child(2)': {
        marginLeft: 10
      }
    }
  }
});

export function Service({ service, duration }) {
  const classes = useStyles();
  return (
    <div className={classes.box}>
      <div className="name">{service.name}</div>
      <div className="detail">
        <div className="duration">{duration}</div>
        <div className="price">
          {service.options[0].currency}
          {service.options[0].price}
        </div>
      </div>
    </div>
  );
}

function mapStateToProps(state) {
  return {
    service: state.serviceDetail.data
  };
}

export default connect(mapStateToProps)(Service);
