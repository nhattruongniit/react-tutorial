import * as React from 'react';
import { Grid, Theme, createStyles, withStyles, WithStyles } from '@material-ui/core';
import { Link } from '@material-ui/core';

const styles = ({ palette }: Theme) =>
  createStyles({
    container: {
      padding: '0 8pt',
      '& + &': {
        marginTop: '15pt'
      }
    },
    avatar: {
      overflow: 'hidden',
      maxHeight: '85px',
      textAlign: 'center',
      '& img': {
        height: '100%',
        display: 'inline-block'
      }
    },
    infor: {
      flex: '100%',
      fontFamily: 'Helvetica Regular',
      color: '#111111',
      paddingLeft: '10px'
    },
    name: {
      fontSize: '18px',
      fontWeight: 'bold'
    },
    price: {
      color: '#A1081B',
      margin: '4pt 0 5pt 0',
      fontWeight: 'bold'
    },
    link: {
      color: '#111',
      fontSize: '14px',
      textDecoration: 'underline',
      cursor: 'pointer',
      '&:hover, &:visited, &:focus': {
        color: '#111'
      }
    }
  });

export interface IProps extends WithStyles<typeof styles> {
  data: any;
}

export const StaffDetailsItem: React.FunctionComponent<IProps> = ({ classes, data }) => {
  return (
    <Grid container={true} className={classes.container}>
      <Grid item={true} xs={3} md={3} className={classes.avatar}>
        <img src={data.featureImage} alt="Staff" />
      </Grid>
      <Grid item={true} xs={9} md={9}>
        <div className={classes.infor}>
          <div className={classes.name}>{data.name}</div>
          <div className={classes.price}>Price: {data.price}</div>
          <Link className={classes.link} onClick={() => window.history.back()}>
            {'<<'} Back to list Staff
          </Link>
        </div>
      </Grid>
    </Grid>
  );
};

export default withStyles(styles)(StaffDetailsItem);
