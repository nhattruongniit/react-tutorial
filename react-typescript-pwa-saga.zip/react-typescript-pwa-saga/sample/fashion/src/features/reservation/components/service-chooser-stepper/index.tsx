import React from 'react';
import classnames from 'classnames';
import Button from '@material-ui/core/Button';
import withStyles, { WithStyles } from '@material-ui/core/styles/withStyles';
import { KeyboardArrowRight } from '@material-ui/icons';
import { Theme } from '@material-ui/core/styles/createMuiTheme';

const styles = (theme: Theme) => ({
  root: {
    width: '100%',
    height: 95,
    top: 55,
    'z-index': 1,
    backgroundColor: '#f1f1f1'
  },
  wrapper: {
    width: '100%',
    height: 75,
    backgroundColor: '#FFFFFF',
    borderTop: 'solid #dadada 1px',
    borderBottom: 'solid #dadada 1px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20
  },
  button: {
    background: 'transparent',
    fontFamily: 'Helvetica',
    color: '#9B9B9B',
    fontSize: 16,
    'font-weight': 'bold',
    '& svg': {
      height: '100%',
      width: 35,
      marginLeft: 15,
      '&.active': {
        color: '#000'
      },
      color: '#9B9B9B'
    },
    width: 'auto',
    height: 'auto',
    '& > span': {
      marginTop: 0,
      'text-transform': 'capitalize'
    },
    '&.active': {
      color: '#850F3B'
    }
  },
  instructions: {
    marginTop: theme.spacing.unit,
    marginBottom: theme.spacing.unit
  }
});

export interface IProps extends WithStyles<typeof styles> {
  step?: number;
}

export const ServiceChooserStepper: React.FunctionComponent<IProps> = ({ classes, step }) => {
  return (
    <div className={classes.root}>
      <div className={classes.wrapper}>
        <Button className={classnames(classes.button, 'active')} size="small">
          Service
          <KeyboardArrowRight className="active" />
        </Button>
        <Button className={step && step >= 2 ? classnames(classes.button, 'active') : classes.button} size="small">
          Date
          <KeyboardArrowRight className={step && step >= 2 ? 'active' : ''} />
        </Button>
        <Button className={step && step >= 3 ? classnames(classes.button, 'active') : classes.button} size="small">
          Booking
        </Button>
      </div>
    </div>
  );
};

export default withStyles(styles)(ServiceChooserStepper);
