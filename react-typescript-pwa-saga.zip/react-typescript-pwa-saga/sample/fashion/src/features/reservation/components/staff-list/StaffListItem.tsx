import React from 'react';
import { Grid, withStyles, createStyles } from '@material-ui/core';
import { Link as RouterLink } from 'react-router-dom';
const styles = () =>
  createStyles({
    container: {
      padding: '0 8pt',
      '& + &': {
        marginTop: '15pt'
      }
    },
    avatar: {
      overflow: 'hidden',
      maxHeight: '134px',
      textAlign: 'center',
      '& img': {
        height: '100%',
        display: 'inline-block'
      }
    },
    infor: {
      flex: '100%',
      fontFamily: 'Helvetica Regular',
      color: '#111111',
      paddingLeft: '10px'
    },
    name: {
      fontSize: '18px',
      fontWeight: 'bold'
    },
    bio: {
      fontSize: '14px',
      margin: '2px 0'
    },
    price: {
      color: '#A1081B',
      marginBottom: '5px',
      fontWeight: 'bold'
    },
    link: {
      backgroundColor: '#BA7402',
      width: '100%',
      height: '40px',
      lineHeight: '40px',
      color: '#fff',
      display: 'inline-block',
      textAlign: 'center',
      '&:hover': {
        color: '#fff'
      }
    },
    lead: {
      display: '-webkit-box',
      maxWidth: '400px',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      lineHeight: '18px',
      '-webkit-line-clamp': '2',
      '-webkit-box-orient': 'vertical'
    }
  });

function Staff({ classes, data, duration }) {
  const { featureImage, name, bio, price, id } = data;
  return (
    <Grid key={id} container={true} className={classes.container}>
      <Grid item={true} xs={4} md={4} className={classes.avatar}>
        <img src={featureImage} alt="Staff List" />
      </Grid>
      <Grid item={true} xs={8} md={8}>
        <div className={classes.infor}>
          <div className={classes.name}>{name}</div>
          <div className={classes.bio}>
            <p className={classes.lead}>{bio}</p>
            <p className={classes.price}>Price: {price}</p>
          </div>
          <RouterLink
            to={`/reservation/staffs/d/${id}?duration=${duration}&name=${name}&price=${price}&staff=${id}`}
            className={classes.link}
          >
            Time Available
          </RouterLink>
        </div>
      </Grid>
    </Grid>
  );
}

export default withStyles(styles)(Staff);
