import React from 'react';
import { withStyles } from '@material-ui/core';
import StaffListItem from './StaffListItem';
import styles from './styles';
interface IStaffList {
  featureImage: string;
  name: string;
  bio: string;
  price: string;
  id: number;
  duration: string;
}

function StaffList({ classes, staffList, duration }) {
  const renderStaffListItem = (data: IStaffList[] = []) =>
    data.map(({ id, ...rest }) => <StaffListItem key={id} data={{ ...rest, id }} duration={duration} />);
  return (
    <div key="StaffListItem">
      <div className="container-fluid">
        <div className="row">
          <div className={classes.containerScroll}>{renderStaffListItem(staffList)}</div>
        </div>
      </div>
    </div>
  );
}

export default withStyles(styles)(StaffList);
