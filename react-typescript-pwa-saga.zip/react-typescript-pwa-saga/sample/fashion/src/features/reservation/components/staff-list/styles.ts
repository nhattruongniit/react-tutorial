import { createStyles } from '@material-ui/core';

const styles = () =>
  createStyles({
    containerScroll: {
      width: '100%'
    }
  });

export default styles;
