import moment from 'moment';

export const handleSelectEvent = (calendar, title, history) => {
  moment.locale('en');
  const dateStart = moment(calendar.start).format('HH:mm');
  const dateEnd = moment(calendar.end).format('HH:mm');
  const currentDate = moment(calendar.end).format('YYYY/MM/DD');
  const url = `/reservation/services/take/?start=${dateStart}&end=${dateEnd}&title=${title}&currentDate=${currentDate}`;
  history.push(url);
};
