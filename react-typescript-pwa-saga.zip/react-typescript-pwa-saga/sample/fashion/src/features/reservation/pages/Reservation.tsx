import * as React from 'react';
import queryString from 'query-string';
import classnames from 'classnames';
import { Theme, withStyles, createStyles, WithStyles } from '@material-ui/core';
import ReservationConfirmForm from '../components/ReservationForm';

export const styles = ({ palette }: Theme) =>
  createStyles({
    wrapperCSS: {
      backgroundColor: '#F1F1F0'
    },
    root: {
      backgroundColor: '#FFFFFF',
      boxShadow: '0 0 2px 0 rgba(0,0,0,0.5)',
      padding: '14px 8px',
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: '16px',
      lineHeight: '24px',
      '& p + p': {
        marginTop: '14px'
      }
    },
    hr: {
      border: '1px dashed #979797',
      margin: '11px -8px'
    },
    note: {
      alignSelf: 'flex-start',
      paddingTop: '10px'
    }
  });

export const handleSubmitForm = history => e => {
  e.preventDefault();
  history.push('/services/reservation/take/confirm');
};

interface IProps extends WithStyles<typeof styles> {
  location: any;
  history: any;
}

export const Reservation: React.FunctionComponent<IProps> = ({ classes, location, history }) => {
  const { title, start, end, date } = queryString.parse(location.search);
  return (
    <div className="container-fluid" key="ReservationItem">
      <div className={classnames(classes.root, 'custom-root')}>
        <p>Regarding the contents of the inquiries, we will contact you later from the person in charge.</p>
        <p>Please complete the following required items, please press the send button.</p>
        <hr className={classes.hr} />
        <ReservationConfirmForm
          title={title}
          start={start}
          end={end}
          date={date}
          handleSubmitForm={handleSubmitForm(history)}
        />
      </div>
    </div>
  );
};

export default withStyles(styles)(Reservation);
