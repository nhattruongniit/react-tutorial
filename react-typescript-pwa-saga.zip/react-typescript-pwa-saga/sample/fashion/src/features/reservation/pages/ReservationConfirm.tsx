import * as React from 'react';
import { Theme, withStyles, createStyles, WithStyles } from '@material-ui/core';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import { Link } from 'react-router-dom';

const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      backgroundColor: '#FFFFFF',
      boxShadow: '0 0 2px 0 rgba(0,0,0,0.5)',
      padding: '14px 27px',
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: '16px',
      lineHeight: '24px',
      '& p + p': {
        marginTop: '14px'
      }
    },
    checkCircle: {
      width: '100%',
      textAlign: 'center',
      marginTop: '5px !important',
      '& svg': {
        width: '177px',
        height: '177px',
        textAlign: 'center',
        color: '#6AC269'
      }
    },
    link: {
      textAlign: 'center',
      '& a': {
        width: '228px',
        height: '40px',
        lineHeight: '40px',
        textAlign: 'center',
        color: '#fff',
        backgroundColor: '#BA7402',
        display: 'inline-block'
      }
    }
  });

interface IProps extends WithStyles<typeof styles> {}

const ReservationConfirm: React.FunctionComponent<IProps> = ({ classes }) => {
  return (
    <div className={classes.root} key="ReservationConfirmItem">
      <p>Your reservation has been sent.</p>
      <p className={classes.checkCircle}>
        <CheckCircleIcon />
      </p>
      <p>We will respond to your response within 3 business days.</p>
      <p>
        If you do not receive your reply for more than a week, there is a possibility that your contact information was
        entered incorrectly.
      </p>
      <p>In that case, sorry to trouble you, but, we hope that you will contact us by phone.</p>
      <p className={classes.link}>
        <Link to="/">Back To Home</Link>
      </p>
    </div>
  );
};

export default withStyles(styles)(ReservationConfirm);
