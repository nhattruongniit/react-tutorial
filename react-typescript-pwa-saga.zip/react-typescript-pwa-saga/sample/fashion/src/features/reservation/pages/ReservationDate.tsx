import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import queryString from 'query-string';
import classnames from 'classnames';
import { withStyles, createStyles, WithStyles, Theme } from '@material-ui/core/styles';
import { ServiceChooserStepper, StaffList } from '../components';
import { TimelineCalendar } from '../../../common/components';
import events from '../../../constant/event';
import { handleSelectEvent } from '../helpers';
import { staffListAction } from '../redux/reservation-date/actions';
import Service from '../components/Service';

export const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      paddingLeft: 0,
      paddingRight: 0,
      '& .calendar': {
        marginTop: 12
      },
      '& .action': {
        display: 'flex',
        alignItems: 'center',
        position: 'relative',
        marginTop: 12,
        '& label': {
          marginBottom: 0
        },
        '& .action-name': {
          color: '#111111',
          fontFamily: 'Helvetica',
          fontSize: 16,
          fontWeight: 'bold'
        }
      }
    },
    wrapperCSS: {
      backgroundColor: '#F1F1F0'
    }
  });

interface IStaffList {
  id: string;
  featureImage: string;
  name: string;
  bio: string;
  price: string;
}
export interface IProps extends WithStyles<typeof styles> {
  location: any;
  history: any;
  staffList: IStaffList[];
  staffListAction: () => void;
}

const handleOptionChange = setSelectedOption => e => setSelectedOption(e.target.value);

export const ReservationDate: React.FunctionComponent<IProps> = ({
  classes,
  history,
  location,
  staffList,
  staffListAction: actiontStaffList
}) => {
  useEffect(() => {
    actiontStaffList();
  }, [actiontStaffList]);
  const [selectedOption, setSelectedOption] = React.useState('n');
  const queryParams = queryString.parse(location.search);
  const serviceDetail = { name: queryParams.name };
  return (
    <div>
      <ServiceChooserStepper step={2} />
      <div className={classnames(classes.root, 'container-fluid')} key="ReservationDateItem">
        {serviceDetail && (
          <div>
            <Service duration={queryParams.option} />
            <div className="box action">
              <label className="action-name">Do you want choose the staff?</label>
              <div className="controls">
                <label className="radio">
                  <input
                    type="radio"
                    name="chooseStaff"
                    value="n"
                    checked={selectedOption === 'n'}
                    onChange={handleOptionChange(setSelectedOption)}
                  />
                  No
                </label>
                <label className="radio">
                  <input
                    type="radio"
                    name="chooseStaff"
                    value="y"
                    checked={selectedOption === 'y'}
                    onChange={handleOptionChange(setSelectedOption)}
                  />
                  Yes
                </label>
              </div>
            </div>
            <div className="box calendar">
              {selectedOption === 'n' ? (
                <TimelineCalendar
                  events={events}
                  onSelectEvent={e => handleSelectEvent(e, serviceDetail.name, history)}
                />
              ) : (
                <StaffList staffList={staffList} duration={queryParams.option} />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const mapStateToProps = (state: any) => {
  const {
    reservationDate: { staffList }
  } = state;
  return {
    staffList
  };
};

const mapDispatchToProps = {
  staffListAction
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ReservationDate));
