import React, { useEffect } from 'react';
import classnames from 'classnames';
import { withStyles, WithStyles } from '@material-ui/core/styles';
import { Button } from '@material-ui/core';
import { connect } from 'react-redux';
import { ServiceChooserStepper } from '../../components';
import { serviceChooserAction } from '../../redux/service-chooser/actions';
import styles from './styles';
interface IServiceOptions {
  name: string;
  price: number;
  currency: string;
  isRecommended: boolean;
}
interface IServiceChooser {
  id: number;
  name: string;
  coverImage: string;
  description: string;
  options: IServiceOptions[];
}
interface IProps extends WithStyles<typeof styles> {
  serviceChooserAction: () => void;
  data: IServiceChooser[];
  history: any;
}

const renderServicesChooser = (serviceChooserArr: IServiceChooser[] = [], history, classes) =>
  serviceChooserArr.map(({ name, coverImage, id }: any, key: any) => (
    <div key={key}>
      <img src={coverImage} alt="Service" />
      <div className="cover" />
      <div className="content">
        <span>{name}</span>
        <Button className={classes.chooseButton} onClick={() => history.push(`/reservation/services/d/${id}`)}>Choose</Button>
      </div>
    </div>
  ));

export const ServiceChooser: React.FunctionComponent<IProps> = ({
  classes,
  serviceChooserAction: actionFetchServiceChooser,
  data,
  history
}) => {
  useEffect(() => {
    actionFetchServiceChooser();
  }, [actionFetchServiceChooser]);
  return (
    <>
      <ServiceChooserStepper step={1} />
      <div className={classnames(classes.root, 'container-fluid')} key="ServiceChooserItem">
        <div key="title" className={classes.title}>
          * Please choose What is the servcie you want.
        </div>
        <div key="grid" className={classes.grid}>
          {renderServicesChooser(data, history, classes)}
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  const {
    serviceChooser: { data }
  } = state;
  return {
    data
  };
};

const mapDispatchToProps = {
  serviceChooserAction
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ServiceChooser));
