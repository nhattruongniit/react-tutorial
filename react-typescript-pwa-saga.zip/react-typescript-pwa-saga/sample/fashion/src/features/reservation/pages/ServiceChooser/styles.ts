import { createStyles } from '@material-ui/core/styles';

const styles = () =>
  createStyles({
    root: {
      '& > div:first-child': {
        width: '100%'
      },
      '& .infinite-scroll-component': {
        width: '100%',
        marginLeft: 0,
        marginRight: 0
      },
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      paddingTop: 10,
      marginLeft: 0,
      marginRight: 0,
      paddingLeft: 0,
      paddingRight: 0,
      width: '100%'
    },
    wrapperCSS: {
      backgroundColor: '#F1F1F0',
      marginTop: -15,
      paddingTop: 10
    },
    grid: {
      width: '100%',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      paddingLeft: 8,
      paddingRight: 8,
      background: '#fff',
      paddingTop: 8,
      '& > div': {
        width: '48%',
        textAlign: 'center',
        position: 'relative',
        height: 183,
        marginBottom: 15,
        '& .cover': {
          position: 'absolute',
          width: 'calc( 100% - 6px )',
          height: '100%',
          top: 0,
          opacity: 0.67,
          backgroundColor: 'rgba(0,0,0,0.98)'
        },
        '& .content': {
          position: 'absolute',
          width: 'calc( 100% - 6px )',
          top: 'calc( 50% - 20px )',
          left: 0,
          textAlign: 'center',
          '& span': {
            display: 'inline-block',
            color: '#FFFFFF',
            fontFamily: 'Helvetica',
            fontSize: 16,
            fontWeight: 'bold',
            textTransform: 'uppercase',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            width: 'calc(95% - 6px)'
          },
          '& button': {
            marginTop: 30,
            borderRadius: 8,
            backgroundColor: '#FFFFFF',
            '& > span:first-child': {
              fontFamily: 'Helvetica',
              fontSize: 16,
              fontWeight: 'bold',
              color: '#111'
            }
          }
        },
        '& img': {
          width: '100%',
          height: '100%',
          objectFit: 'cover'
        }
      },
      '& > div:nth-child(odd)': {
        paddingRight: 6,
        '& .cover': {
          right: 6
        },
        '& .content': {
          right: 6
        }
      },
      '& > div:nth-child(even)': {
        paddingLeft: 6,
        '& .cover': {
          left: 6
        },
        '& .content': {
          left: 6
        }
      }
    },
    scroll: {
      width: '100%'
    },
    title: {
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: 16,
      paddingLeft: 8,
      paddingBottom: 8
    },
    chooseButton: {
      minWidth: 100
    }
  });

export default styles;
