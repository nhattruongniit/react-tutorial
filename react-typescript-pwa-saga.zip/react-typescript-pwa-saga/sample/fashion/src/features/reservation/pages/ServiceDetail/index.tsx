import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Form, Field } from 'react-final-form';
import { withStyles } from '@material-ui/core';
import classnames from 'classnames';
import { ServiceChooserStepper } from '../../components';
import { serviceDetailAction } from '../../redux/service-detail/actions';

import styles from './styles';

const renderOptions = (options = []) =>
  options.map((item: any, key: any) => {
    const { name, isRecommended, currency, price } = item;
    const getColClassName = ({ isRecommended: recommended }) => (recommended ? 'rex-col recommended' : 'rex-col');
    return (
      <React.Fragment key={key}>
        <div className="line" />
        <div key={key + '-1'} className={getColClassName(item)}>
          <label className="radio">
            <Field name="serviceTime" component="input" type="radio" value={name} />
            {isRecommended && (
              <React.Fragment key={'fragment2-' + key}>
                <span className="message-box">Our recommend</span>
                <span className="item">{name}</span>
              </React.Fragment>
            )}
            {!isRecommended && name}
          </label>
        </div>
        <div key={key + '-2'} className={getColClassName(item)}>
          <p>
            {currency}
            {price}
          </p>
        </div>
        {key === options.length - 1 && <div className="line" />}
      </React.Fragment>
    );
  });

const createInitialValues = data => {
  const { options = [], name: serviceName } = data;
  const recommendedItem = options.filter(({ isRecommended }) => isRecommended);
  if (recommendedItem.length) {
    const [{ name, price, currency }] = recommendedItem;
    return { serviceTime: name, serviceName, price, currency };
  }
  return { serviceTime: '', serviceName };
};
export const ServiceDetail = ({
  classes,
  data,
  serviceDetailAction: actionFetchServiceDetail,
  match: {
    params: { id }
  },
  history
}) => {
  const { coverImage, name, description, options } = data;
  const onSubmit = formValues => {
    const { serviceTime, serviceName, price, currency } = formValues;
    history.push(`/reservation/date?option=${serviceTime}&name=${serviceName}&price=${price}&currency=${currency}`);
  };
  useEffect(() => {
    actionFetchServiceDetail(id);
  }, []);
  return (
    <>
      <ServiceChooserStepper step={1} />
      <div className={classnames(classes.rootDetail, 'container-fluid')} key="ServiceDetailItem">
        <div key="title" className={classes.title}>
          * Please choose What is the servcie you want.
        </div>
        <div key="grid" className={classes.gridDetail}>
          <div>
            <img src={coverImage} alt="Service" />
          </div>
          <div>
            <div className="title">{name}</div>

            <div className="description">{description}</div>
          </div>
          <div className="full-row">
            <Form
              onSubmit={onSubmit}
              initialValues={createInitialValues(data)}
              render={({ handleSubmit }) => (
                <form
                  id="form-options"
                  onSubmit={handleSubmit}
                  style={{
                    width: '100%',
                    display: 'flex',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between',
                    textAlign: 'left'
                  }}
                >
                  {renderOptions(options)}
                </form>
              )}
            />
          </div>
        </div>
        <div className={classes.navbar}>
          <div>
            <button data-test="btnBack" className="secondary" onClick={() => history.goBack()}>
              Back
            </button>
            <button className="primary" type="submit" form="form-options">
              Next Step
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  const {
    serviceDetail: { data }
  } = state;
  return {
    data
  };
};

const mapDispatchToProps = {
  serviceDetailAction
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ServiceDetail));
