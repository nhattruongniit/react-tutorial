import { createStyles } from '@material-ui/core';

const styles = () =>
  createStyles({
    rootDetail: {
      '& > div:first-child': {
        width: '100%'
      },
      '& .infinite-scroll-component': {
        width: '100%',
        marginLeft: 0,
        marginRight: 0
      },
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      paddingTop: 10,
      marginLeft: 0,
      marginRight: 0,
      paddingLeft: 0,
      paddingRight: 0,
      width: '100%'
    },
    gridDetail: {
      width: '100%',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      paddingLeft: 8,
      paddingRight: 8,
      paddingBottom: 88,
      background: '#fff',
      paddingTop: 8,
      '& > div': {
        width: '50%',
        textAlign: 'center',
        position: 'relative',
        marginBottom: 15,
        '& img': {
          width: '100%',
          height: '100%',
          objectFit: 'cover'
        },
        '& .title': {
          color: '#111111',
          fontFamily: 'Helvetica',
          fontSize: 16,
          fontWeight: 'bold'
        },
        '& .description': {
          color: '#111111',
          fontFamily: 'Helvetica',
          fontSize: 14,
          textAlign: 'left',
          paddingLeft: 5
        }
      },
      '& > div.full-row': {
        width: '100%',
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        textAlign: 'left',
        '& label': {
          display: 'flex',
          alignItems: 'center',
          minHeight: 60,
          marginBottom: 0
        },
        '& input[type=radio]': {
          boxSizing: 'border-box',
          height: 13,
          width: 13,
          border: '1px solid #111111',
          marginRight: 15,
          marginLeft: 5
        },
        '& .rex-col': {
          width: '50%',
          display: 'flex',
          alignItems: 'center',
          '& p': {
            textAlign: 'right',
            width: '100%',
            paddingRight: 20
          },
          '&.recommended': {
            backgroundColor: '#e0dddc',
            position: 'relative',
            '& .message-box': {
              height: 21,
              width: 122,
              backgroundColor: '#B97556',
              color: '#FFFFFF',
              fontFamily: 'Helvetica',
              textAlign: 'center',
              fontSize: 14,
              top: 8
            },
            '& span': {
              display: 'block',
              position: 'absolute',
              left: 30,
              '&.item': {
                top: 38,
                left: 34
              }
            }
          }
        },
        '& .line': {
          height: 1,
          width: '100%',
          border: '0.5px dashed #291E2D'
        }
      }
    },
    title: {
      color: '#111111',
      fontFamily: 'Helvetica',
      fontSize: 16,
      paddingLeft: 8,
      paddingBottom: 8
    },
    navbar: {
      backgroundColor: '#fff',
      height: 80,
      position: 'fixed',
      width: '100%',
      bottom: 56,
      left: 0,
      display: 'flex',
      alignItems: 'center',
      '& > div': {
        width: '100%',
        textAlign: 'right',
        paddingRight: 10,
        '& button': {
          height: 40,
          width: 122,
          fontFamily: 'Helvetica',
          fontSize: 16
        },
        '& button.secondary': {
          border: '1px solid #979797',
          color: '#111111'
        },
        '& button.primary': {
          backgroundColor: '#BA7402',
          color: '#FFFFFF',
          border: 'none'
        }
      }
    }
  });

export default styles;
