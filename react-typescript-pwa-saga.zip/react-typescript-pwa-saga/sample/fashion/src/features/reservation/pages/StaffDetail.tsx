import React from 'react';
import { Theme, createStyles, withStyles, WithStyles } from '@material-ui/core';
import ServiceChooserStepper from '../components/service-chooser-stepper';
import queryString from 'query-string';
import mockStaffList from '../components/staff-list/mockdata.json';
import StaffDetailsItem from '../components/StaffDetailsItem';
import { TimelineCalendar } from '../../../common/components';
import events from '../../../constant/event';
import { handleSelectEvent } from '../helpers';
import Service from '../components/Service';

export const styles = ({ palette }: Theme) =>
  createStyles({
    root: {
      width: '100%',
      borderTop: '1px solid #D0D0CF',
      paddingTop: '10px'
    },
    hr: {
      borderTop: '1px solid #4A4A4A',
      margin: '10px 0'
    }
  });

export interface IProps extends WithStyles<typeof styles> {
  location: any;
  history: any;
}

export const StaffDetail: React.FunctionComponent<IProps> = ({ classes, location, history }) => {
  const queryParams = queryString.parse(location.search);
  const staffDetail = { data: mockStaffList.find(staff => staff.id.toString() === queryParams.staff) };
  const serviceDetail = { name: queryParams.name };

  return (
    <div key="StaffListItem">
      <ServiceChooserStepper step={2} />
      <Service duration={queryParams.duration} />
      <div className="container-fluid">
        <div className="row">
          {staffDetail && staffDetail.data && (
            <div className={classes.root}>{<StaffDetailsItem data={staffDetail.data} />}</div>
          )}
        </div>
      </div>
      <hr className={classes.hr} />
      <TimelineCalendar events={events} onSelectEvent={e => handleSelectEvent(e, serviceDetail.name, history)} />
    </div>
  );
};

export default withStyles(styles)(StaffDetail);
