export { serviceDetailReducer as serviceDetail, selectors as serviceDetailSelector } from './serviceDetails';
