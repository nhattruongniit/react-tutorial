import { createAction } from 'redux-actions';
import { FETCH_STAFF_LIST } from './constants';

export const staffListAction = createAction(FETCH_STAFF_LIST.ACTION);
