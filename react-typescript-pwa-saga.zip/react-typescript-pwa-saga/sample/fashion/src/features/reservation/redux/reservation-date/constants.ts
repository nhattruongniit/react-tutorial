import { defineAction } from 'redux-define';
export const FETCH_STAFF_LIST = defineAction('FETCH_STAFF_LIST', ['REQUEST', 'ERROR', 'SUCCESS'], 'RESERVATION_DATE');
