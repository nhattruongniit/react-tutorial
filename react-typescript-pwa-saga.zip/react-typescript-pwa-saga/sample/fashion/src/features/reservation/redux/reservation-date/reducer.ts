import { handleActions } from 'redux-actions';
import { FETCH_STAFF_LIST } from './constants';

const initialState = {
  staffList: []
};

const reservationDateReducer: any = handleActions(
  {
    [FETCH_STAFF_LIST.SUCCESS]: (state, { payload }) => ({
      ...state,
      staffList: payload
    })
  },
  initialState
);

export default reservationDateReducer;
