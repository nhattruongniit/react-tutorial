import { FETCH_STAFF_LIST } from './constants';
import { put, takeLatest } from 'redux-saga/effects';
// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

function* fetchStaffList({ payload }) {
  const request = yield makeMockJsonRequest('staff-list', 'staffList');
  yield put(fetchApi(request));
}

function* getfetchStaffListSuccess({ payload, type }) {
  const { httpResponseJson, request } = payload;
  if (request.key.startsWith('staff-list') && type === FETCH_API.SUCCESS) {
    yield put({ type: FETCH_STAFF_LIST.SUCCESS, payload: httpResponseJson });
  }
}

export function* reservationDateSaga() {
  yield takeLatest(FETCH_STAFF_LIST.ACTION, fetchStaffList);
  yield takeLatest(FETCH_API.SUCCESS, getfetchStaffListSuccess);
}
