import { createAction } from 'redux-actions';
import { FETCH_SEVICE_CHOOSER } from './constants';

export const serviceChooserAction = createAction(FETCH_SEVICE_CHOOSER.ACTION);
