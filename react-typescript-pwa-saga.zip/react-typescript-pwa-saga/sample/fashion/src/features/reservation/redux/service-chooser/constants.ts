import { defineAction } from 'redux-define';
export const FETCH_SEVICE_CHOOSER = defineAction(
  'FETCH_SEVICE_CHOOSER',
  ['REQUEST', 'ERROR', 'SUCCESS'],
  'RESERVATION'
);
