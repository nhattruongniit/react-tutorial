import { handleActions } from 'redux-actions';
import { FETCH_SEVICE_CHOOSER } from './constants';

const initialState = {
  data: []
};

const serviceDetailReducer: any = handleActions(
  {
    [FETCH_SEVICE_CHOOSER.SUCCESS]: (state, { payload }) => ({
      ...state,
      data: payload
    })
  },
  initialState
);

export default serviceDetailReducer;
