import { FETCH_SEVICE_CHOOSER } from './constants';
import { put, takeLatest } from 'redux-saga/effects';
// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

function* fetchServiceChooser({ page = 1, limit = 0 }) {
  const request = yield makeMockJsonRequest('services-chooser', `services?_page=${page}&_limit=${limit}`);
  yield put(fetchApi(request));
}

function* getfetchServiceChooserSuccess({ payload, type }) {
  const { httpResponseJson, request } = payload;
  if (request.key.startsWith('services-chooser') && type === FETCH_API.SUCCESS) {
    yield put({ type: FETCH_SEVICE_CHOOSER.SUCCESS, payload: httpResponseJson });
  }
}

export function* reservationServiceChooserSaga() {
  yield takeLatest(FETCH_SEVICE_CHOOSER.ACTION, fetchServiceChooser);
  yield takeLatest(FETCH_API.SUCCESS, getfetchServiceChooserSuccess);
}
