import { createAction } from 'redux-actions';
import { FETCH_SEVICE_DETAIL } from './constants';

export const serviceDetailAction = createAction(FETCH_SEVICE_DETAIL.ACTION);
