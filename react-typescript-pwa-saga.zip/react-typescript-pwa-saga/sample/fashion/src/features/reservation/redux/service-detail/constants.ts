import { defineAction } from 'redux-define';
export const FETCH_SEVICE_DETAIL = defineAction('FETCH_SEVICE_DETAIL', ['REQUEST', 'ERROR', 'SUCCESS'], 'RESERVATION');
