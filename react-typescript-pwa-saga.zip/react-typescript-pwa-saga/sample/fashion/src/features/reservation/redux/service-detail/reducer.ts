import { handleActions } from 'redux-actions';
import { FETCH_SEVICE_DETAIL } from './constants';

const initialState = {
  data: []
};

const serviceChooserReducer: any = handleActions(
  {
    [FETCH_SEVICE_DETAIL.SUCCESS]: (state, { payload }) => ({
      ...state,
      data: payload
    })
  },
  initialState
);

export default serviceChooserReducer;
