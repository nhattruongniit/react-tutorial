import { FETCH_SEVICE_DETAIL } from './constants';
import { put, takeLatest } from 'redux-saga/effects';
// core
import { makeMockJsonRequest } from '../../../../common/fetch-api';
import { FETCH_API, fetchApi } from '@mochi/core';

function* fetchServiceDetail({ payload }) {
  const request = yield makeMockJsonRequest(`services-detail${payload}`, `services/${payload}`);
  yield put(fetchApi(request));
}

function* getfetchServiceDetailSuccess({ payload, type }) {
  const { httpResponseJson, request } = payload;
  if (request.key.startsWith('services-detail') && type === FETCH_API.SUCCESS) {
    yield put({ type: FETCH_SEVICE_DETAIL.SUCCESS, payload: httpResponseJson });
  }
}

export function* reservationServiceDetailSaga() {
  yield takeLatest(FETCH_SEVICE_DETAIL.ACTION, fetchServiceDetail);
  yield takeLatest(FETCH_API.SUCCESS, getfetchServiceDetailSuccess);
}
