import { handleActions } from 'redux-actions';

const initialState = {
  data: {
    id: 1,
    name: 'Aroma Treatment',
    coverImage: 'http://en.bliss.hr/wp-content/uploads/2016/02/1IMG_3767-680x282.jpg',
    description:
      'Aromatherapy is a holistic healing treatment that uses natural plant extracts to promote health and well-being. Sometimes it’s called essential oil therapy. Aromatherapy uses aromatic essential oils medicinally to improve the health of the body, mind, and spirit. It enhances both physical and emotional health.',
    options: [
      {
        name: '30min',
        price: 9000,
        currency: '$',
        isRecommended: false
      },
      {
        name: '60min',
        price: 9000,
        currency: '$',
        isRecommended: true
      },
      {
        name: '90min',
        price: 9000,
        currency: '$',
        isRecommended: false
      }
    ]
  }
};

export const serviceDetailReducer = handleActions({}, initialState);

export const selectors = {
  getServiceDetail: state => state.serviceDetail.data
};
