import { loginFlow as loginSaga } from '@mochi/misc/auth/login/redux/sagas';
import { errorLogFlow as errorLogSaga } from '../common/error-boundary-connect/redux/saga';
import { homeSaga } from './home';
import { couponSaga, couponDetailSaga } from './coupon';
import { productSaga, productListSaga, productDetailSaga } from './product';
import { shopSaga, shopDetailSaga } from './shop';
import { watchFetchHistory as membershipHistorySaga } from './member-ship/redux/history/saga';
import { reservationServiceChooserSaga, reservationServiceDetailSaga, reservationDateSaga } from './reservation';
import { watchFetchMembership as userSaga } from './member-ship/redux/membership/saga';
import { saga as loginSocketSaga } from './login/redux/rocket-chat/saga';
/* GEN: MORE IMPORT */

export const sagas = [
  loginSaga,
  errorLogSaga,
  homeSaga,
  couponSaga,
  couponDetailSaga,
  productSaga,
  productListSaga,
  productDetailSaga,
  shopSaga,
  shopDetailSaga,
  membershipHistorySaga,
  userSaga,
  reservationServiceChooserSaga,
  reservationServiceDetailSaga,
  reservationDateSaga,
  loginSocketSaga

  /* GEN: SAGA DECLARATION */
];
