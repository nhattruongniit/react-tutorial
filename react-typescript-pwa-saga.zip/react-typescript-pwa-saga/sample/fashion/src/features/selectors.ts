import { getUserLanguage } from './user/language';

export const selectors = {
  getUserLanguage
};
