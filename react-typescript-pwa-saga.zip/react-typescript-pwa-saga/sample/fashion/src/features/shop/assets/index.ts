import AddressPoint from './images/address-point.svg';
import Picture01 from './images/picture01.jpg';
import Picture02 from './images/picture02.jpg';
import Picture03 from './images/picture03.jpg';
import Picture04 from './images/picture04.jpg';
import Picture05 from './images/picture05.jpg';
import Picture06 from './images/picture06.jpg';

export { AddressPoint, Picture01, Picture02, Picture03, Picture04, Picture05, Picture06 };
