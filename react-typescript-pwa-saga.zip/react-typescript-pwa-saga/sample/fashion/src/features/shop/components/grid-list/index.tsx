import React, { Component } from 'react';
import { GridList, GridListTile, withStyles } from '@material-ui/core';
import Lightbox from 'react-image-lightbox';
import 'react-image-lightbox/style.css'; // This only needs to be imported once in your app

class ImageGridList extends Component<any, any> {
  constructor(props) {
    super(props);
    this.state = {
      photoIndex: 0,
      isOpen: this.props.isOpen
    };
  }

  render() {
    const { classes, tileData, images, showLightbox } = this.props;
    const { photoIndex, isOpen } = this.state;

    return (
      <GridList cellHeight={160} className={classes.gridList} cols={3}>
        {tileData &&
          tileData.map((tile, index) => (
            <GridListTile
              key={index}
              cols={tile.cols || 3}
              onClick={() => this.setState({ isOpen: true, photoIndex: index })}
            >
              <img src={tile.img} alt={tile.title} />
            </GridListTile>
          ))}
        {showLightbox && isOpen && (
          <Lightbox
            mainSrc={images[photoIndex]}
            nextSrc={images[(photoIndex + 1) % images.length]}
            prevSrc={images[(photoIndex + images.length - 1) % images.length]}
            onCloseRequest={() => this.setState({ isOpen: false })}
            onMovePrevRequest={() =>
              this.setState({
                photoIndex: (photoIndex + images.length - 1) % images.length
              })
            }
            onMoveNextRequest={() =>
              this.setState({
                photoIndex: (photoIndex + 1) % images.length
              })
            }
          />
        )}
      </GridList>
    );
  }
}
const styles = (): any => ({
  gridList: {
    width: '100%',
    height: 'auto'
  }
});
export default withStyles(styles)(ImageGridList);
